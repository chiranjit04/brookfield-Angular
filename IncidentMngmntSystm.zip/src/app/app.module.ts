import { BrowserModule } from "@angular/platform-browser";
import { NgModule, ErrorHandler } from "@angular/core";
import { ToastrModule } from "ngx-toastr";
import { DobDirective } from "../../src/app/shared/mask";
// Modules
import { SharedMaterialModule } from './shared/shared-material.module';
import { AppRoutingModule } from "./app-routing.module";
import { AppPreloadingStrategy } from "./helpers/app_preloading_strategy";
import { FormsModule } from "@angular/forms";
import { ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";

import { AuthModule } from "./modules/auth/auth.module";
//import { GoogleChartsModule } from 'angular-google-charts';
//import { HomeModule } from "./modules/home/home.module";
//import { DashboardModule } from "./modules/dashboard/dashboard.module";

// Component
import { AppComponent } from "./app.component";
// Services
import { AuthService } from "./services/auth.service";
import { TokenInterceptorService } from "./services/token-interceptor.service";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { ServiceWorkerModule } from "@angular/service-worker";
import { ServerhealthComponent } from "./modules/serverhealth/serverhealth.component";
import { ErrorService } from './services/error.service';
@NgModule({
  declarations: [AppComponent, ServerhealthComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AuthModule,
    //HomeModule,
    //DashboardModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    SharedMaterialModule,
   // GoogleChartsModule,
    ToastrModule.forRoot({ preventDuplicates: true }),
    ServiceWorkerModule.register("ngsw-worker.js", { enabled: true }),
  ],
  providers: [
    AuthService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptorService,
      multi: true,
    },
    AppPreloadingStrategy,
    {
      provide: ErrorHandler,
      useClass: ErrorService,
    }
  ],
  //exports: [HomeModule],
  bootstrap: [AppComponent],
})
export class AppModule {
  static compiler;
}
