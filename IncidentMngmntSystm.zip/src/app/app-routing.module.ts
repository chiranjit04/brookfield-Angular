import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { PagenotfoundComponent } from "./modules/global/pagenotfound/pagenotfound.component";
import { LoginComponent } from "./modules/auth/login/login.component";
import { SsoLoginComponent } from "./modules/auth/sso-login/sso-login.component";
import { ServerhealthComponent } from "./modules/serverhealth/serverhealth.component";

const routes: Routes = [
  { path: "", redirectTo: "/login", pathMatch: "full" },
  { path: "login", component: LoginComponent },
  { path: "ssologin", component: SsoLoginComponent },
  { path: "ServerHealth", component: ServerhealthComponent },
  {
    path: "products",
    // loadChildren: "./modules/home/home.module#HomeModule",
    loadChildren: () =>
      import("./modules/home/home.module").then((m) => m.HomeModule),
    //  data: { preload: true, delay: 150 },
  },
  {
    path: "products/dispatch",
    // loadChildren: "./modules/dispatch/dispatch.module#DispatchModule",
    //  data: { preload: true, delay: 3000 },
    loadChildren: () =>
      import("./modules/dispatch/dispatch.module").then(
        (m) => m.DispatchModule
      ),
  },
  {
    path: "products/dashboard",
    // loadChildren: "./modules/dashboard/dashboard.module#DashboardModule",
    //  data: { preload: true, delay: 6000 },
    loadChildren: () =>
      import("./modules/dashboard/dashboard.module").then(
        (m) => m.DashboardModule
      ),
  },
  {
    path: "products/administration",
    // loadChildren: "./modules/administration/administration.module#AdministrationModule",
    //  data: { preload: true, delay: 17000 }
    loadChildren: () =>
      import("./modules/administration/administration.module").then(
        (m) => m.AdministrationModule
      ),
  },
  {
    path: "products/inspections",
    // loadChildren: "./modules/inspections/inspections.module#InspectionsModule",
    //  data: { preload: true, delay: 22000 }
    loadChildren: () =>
      import("./modules/inspections/inspections.module").then(
        (m) => m.InspectionsModule
      ),
  },
  {
    path: "products/incidentreportboard",
    // loadChildren: "./modules/incidentreportboard/incidentreportboard.module#IncidentreportboardModule",
    //  data: { preload: true, delay: 27000 }
    loadChildren: () =>
      import("./modules/incidentreportboard/incidentreportboard.module").then(
        (m) => m.IncidentreportboardModule
      ),
  },
  {
    path: "products/incidentreporttabs",
    loadChildren: () =>
      import("./modules/incidentreporttabs/incidentreporttabs.module").then(
        (m) => m.IncidentreporttabsModule
      ),
    //  data: { preload: true, delay: 32000 }
  },
  {
    path: "products/managemap",
    loadChildren: () =>
      import("./modules/managemap/managemap.module").then(
        (m) => m.ManagemapModule
      ),
    //  data: { preload: true, delay: 37000 }
  },
  {
    path: "products/communication",
    loadChildren: () =>
      import("./modules/communication/communication.module").then(
        (m) => m.CommunicationModule
      ),
    //  data: { preload: true, delay: 42000 }
  },
  {
    path: "products/research",
    loadChildren: () =>
      import("./modules/research/research.module").then(
        (m) => m.ResearchModule
      ),
    //  data: { preload: true, delay: 45000 }
  },
  {
    path: "products/tiermanagement",
    loadChildren: () =>
      import("./modules/tiermanagement/tiermanagement.module").then(
        (m) => m.TiermanagementModule
      ),
    //  data: { preload: true, delay: 52000 }
  },
  {
    path: "products/deployment",
    loadChildren: () =>
      import("./modules/deployment/deployment.module").then(
        (m) => m.DeploymentModule
      ),
    //  data: { preload: true, delay: 57000 }
  },
  /**
   * egnyte module
   */
  {
    path: "products/egnyte",
    loadChildren: () =>
      import("./modules/egnyte/egnyte.module").then((m) => m.EgnyteModule),
  },
  /**
   * for ByPass Login in Incident Report Board, to create tokenn Auth key
   */
  {
    path: "tokenedLoginIncidentReportBaord",
    loadChildren: () =>
      import("./modules/auth/irftoken-login/irftoken-login.module").then(
        (m) => m.IRFTokenLoginModule
      ),
  },
  { path: "**", component: PagenotfoundComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
