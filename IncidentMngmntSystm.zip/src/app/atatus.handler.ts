// /app/atatus.handler.ts
import { ErrorHandler } from '@angular/core';
declare var atatus: any;

class AtatusErrorHandler implements ErrorHandler {
    handleError(error:any) : void {
        if (atatus) {
            // Send the error to Atatus
            atatus.notify(error.originalError || error);
        }
    }
}

export default AtatusErrorHandler;