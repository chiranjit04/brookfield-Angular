import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';

import { AssignCompanyService } from "../../../services/assign-company.service"

@Component({
  selector: 'app-assign-companies',
  templateUrl: './assign-companies.component.html',
  styleUrls: ['./assign-companies.component.scss']
})
export class AssignCompaniesComponent implements OnInit {

  constructor(private assignCompanyService: AssignCompanyService) { }

  addgop = false;
  propertiesassigned = false;
  propertytype = false;

  companiesType:any []
  selectedCompanyTypeID = false

  companies:any []
  selectedCompanyID = false

  subdivisions: any []
  selectedSubDevisionID=false

  companyTypeForm = new FormGroup({
    SectorGroupID: new FormControl(''),
    SectorGroupName: new FormControl('', [ Validators.required ]),
    SectorGroupDesc: new FormControl('', [ Validators.required ]),
    OrganizationID: new FormControl(''),
  });
  get SectorGroupName() { return this.companyTypeForm.get('SectorGroupName'); }
  get SectorGroupDesc() { return this.companyTypeForm.get('SectorGroupDesc'); }

  ngOnInit() {
    this.getCompaniesType()
  }

  /* Company Type Area */
  getCompaniesType(): void {
    let result:any
    this.assignCompanyService.getCompaniesType().subscribe(companiesType =>{
      result = companiesType;      
      this.companiesType = result.ComapnyType;
    })
  }

  selectCompanyTypeRow(id:any){
    if(id == this.selectedCompanyTypeID){
      this.selectedCompanyTypeID = false;
    }else{
      this.getCompanies(id)      
      this.selectedCompanyTypeID = id;
    }
  }

  submitCompanyTypeForm(){
    console.log("submitted")
  }
  resetCompanyTypeForm(){
    this.companyTypeForm.reset();
    this.addgop=!this.addgop
  }

  /* Comapny Area */
  getCompanies(CompanyTypeID: number){
    let result:any
    let GlobalEnvironmentID = 1
    this.assignCompanyService.getCompanies(CompanyTypeID,GlobalEnvironmentID).subscribe(companies =>{
      result = companies;      
      this.companies = result.GetGlobalEnvironmentCompanybyPropertyId;
    })
  }

  selectCompanyRow(CompanyID:any){    
    if(CompanyID == this.selectedCompanyID){
      this.selectedCompanyID = false;
    }else{
      this.getSubDivisions(CompanyID)      
      this.selectedCompanyID = CompanyID;
    }
  }
 
  /* Sub Division Area */
  getSubDivisions(CompanyID){
    let result:any
    let GlobalEnvironmentID = 1
    this.assignCompanyService.getSubDivisions(CompanyID, GlobalEnvironmentID).subscribe(subdivision =>{
      result = subdivision;      
      this.subdivisions = result.GetGlobalEnvironmentSubDivisionbyCompanyId;      
    })
  }

  selectSubDevisionRow(SubDivisionID:any){
    if(SubDivisionID == this.selectedSubDevisionID){
      this.selectedSubDevisionID = false;
    }else{
      // this.getSubDivisions(SubDivisionID)      
      this.selectedSubDevisionID = SubDivisionID;
    }
  }

}
