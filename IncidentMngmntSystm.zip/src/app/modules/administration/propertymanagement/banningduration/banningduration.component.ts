import { Component, OnInit } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
import Swal from "sweetalert2";
import { BanningmanagementService } from "../../banningmanagement/banningmanagement.service";
import { AnyARecord } from "dns";
import { StorageService } from "../../../../services/storage.service";
import {
  FormGroup,
  FormBuilder,
  FormControl,
  Validators,
  FormArray,
} from "@angular/forms";
import { startWith, map } from "rxjs/operators";
import { UserPermissionService } from "../../../../services/user-permission.service";
import { ToastrService } from "ngx-toastr";
@Component({
  selector: "app-banningduration",
  templateUrl: "./banningduration.component.html",
  styleUrls: ["./banningduration.component.scss"],
})
export class BanningdurationComponent implements OnInit {
  PropertyDetail = null;
  PropertyID = 0;
  PropertyName = "";
  PropertyNumber = "";
  PropertyDescription = "";
  PropertyGoeID = 0;

  AuthToken = null;
  UserData = null;
  UserID = false;

  BanningProtocolList: any = [];
  BanningFormGroup: FormGroup;
  DurationRecords: FormArray;
  CharacteristicRecords: FormArray;
  ProceduralRecords: FormArray;

  /****************************************************************
   * variables accroding to changes me
   */
  _propertyDetail_: any = "";
  _UserData_: any = "";
  _propertyID_: any = "";
  _propertyno_: any = "";
  _selectedProperty_: any = "";
  _SubunitName_: any = "";
  _SubPropertyUnit_: any;
  /**************************************************************** */

  constructor(
    private router: Router,
    private BanningService: BanningmanagementService,
    private formBuilder: FormBuilder,
    private tostre: ToastrService,
    private storage: StorageService
  ) {
    this.PropertyDetail = JSON.parse(this.storage.getData("PropertyDetail"));
    // console.log(this.PropertyDetail)
    /********************************
     * changes for more admix fixes, not changing old functionality adding new to every small changs avoid to new isseues.
     */
    this._propertyDetail_ = JSON.parse(this.storage.getData("PropertyDetail"));
    this._UserData_ = JSON.parse(this.storage.getData("UserData"));

    if (this._propertyDetail_) {
      this._propertyID_ = this._propertyDetail_.PropertyID;
      this._propertyno_ = this._propertyDetail_.PropertyIdentNumber;
      this._selectedProperty_ = this._propertyDetail_.PropertyName;
      this._SubunitName_ = this._propertyDetail_.SubunitName;
    }

    const params = {
      PropertyId: this._propertyID_,
    };

    // this.BanningService.GetCustomFormDetailsByPropertyId(params).subscribe(
    //   (res) => {
    //     if (res.data.getCustomFormDetailsByPropertyId.length != "") {
    //       this._SubPropertyUnit_ =
    //         res.data.getCustomFormDetailsByPropertyId[0].SubPropertyUnit;
    //     }
    //   }
    // );
    /******************************** end */
    if (this.PropertyDetail) {
      this.PropertyID = this.PropertyDetail.PropertyID;
      this.PropertyName = this.PropertyDetail.PropertyName;
      this.PropertyNumber = this.PropertyDetail.PropertyIdentNumber;
      this.PropertyDescription = this.PropertyDetail.PropertyDescription;
      this.PropertyGoeID = this.PropertyDetail.GlobalEnvironmentID;
    }

    if (this.PropertyDetail.Subdivision === "Property Subunit") {
      this._SubPropertyUnit_ =
        this.PropertyDetail.ParentPropertyName +
        " - " +
        this.PropertyDetail.ParentIdentNumber;
    }

    this.checkProperty();

    //... Read User Data ...
    this.AuthToken = this.storage.getData("token");
    this.UserData = JSON.parse(this.storage.getData("UserData"));
    this.UserID = this.UserData[0].UserID;
    if (this.AuthToken == null) {
      this.router.navigate(["/login"]);
    }
  }

  checkProperty() {
    if (this.PropertyID) {
      return true;
    } else {
      this.tostre.error("Please first select a Company.", "", {
        positionClass: "toast-top-right",
      });
      // }).then((result) => {
      this.router.navigate([
        "products/administration/propertymanagement/propertydetail",
      ]);
      //});
      return false;
    }
  }

  BanningProtocolForm: FormGroup;
  submitted = false;
  // convenience getters for easy access to form fields
  get f() {
    return this.BanningProtocolForm.controls;
  }
  get t() {
    return this.f.tickets as FormArray;
  }

  filteredStreets: any;
  DurationName: any = new FormControl();
  streets: any = [];
  DurationList: any = [];

  ngOnInit() {
    this.BanningProtocolForm = this.formBuilder.group({
      BanningProtocolID: [""],
      ProtocolName: [""],
      DurationRecords: new FormArray([]),
      CharacteristicRecords: new FormArray([]),
      ProceduralRecords: new FormArray([]),
    });
    /* this.BanningFormGroup = this.formBuilder.group({
      BanningProtocolID: [''],
      ProtocolName: [''],
      DurationRecords: this.formBuilder.array([this.createDurationRows()]),
      CharacteristicRecords: this.formBuilder.array([this.createCharacteristicRows()]),
      ProceduralRecords: this.formBuilder.array([this.createProceduralRows()]),
    }); */

    this.filteredStreets = this.DurationName.valueChanges.pipe(
      startWith(""),
      map((val: any) => (val.length >= 0 ? this._filter(val) : []))
    );

    this.GetBanningProtocolList();
  }

  _filter(val: any): any[] {
    return this.streets
      .map((x) => x)
      .filter((option) =>
        option.companyName.toLowerCase().includes(val.toLowerCase())
      );
  }

  checkOne(test) {
    this.filteredStreets = this.DurationName.valueChanges.pipe(
      startWith(""),
      map((val: any) => (val.length >= 0 ? this._filter(val) : []))
    );
    test.blur();
  }

  createDurationRows(): FormGroup {
    return this.formBuilder.group({
      DurationTitle: ["", Validators.required],
    });
  }
  addDurationRows() {
    this.DurationRecords = this.BanningFormGroup.get(
      "DurationRecords"
    ) as FormArray;
    this.DurationRecords.push(this.createDurationRows());
  }

  createCharacteristicRows(): FormGroup {
    return this.formBuilder.group({
      BanningCharacteristicTitle: ["", Validators.required],
    });
  }
  addCharacteristicRows() {
    this.CharacteristicRecords = this.BanningFormGroup.get(
      "CharacteristicRecords"
    ) as FormArray;
    this.CharacteristicRecords.push(this.createCharacteristicRows());
  }

  createProceduralRows(): FormGroup {
    return this.formBuilder.group({
      BanningProceduralTitle: ["", Validators.required],
    });
  }
  addProceduralRows() {
    this.ProceduralRecords = this.BanningFormGroup.get(
      "ProceduralRecords"
    ) as FormArray;
    this.ProceduralRecords.push(this.createProceduralRows());
  }

  GetBanningProtocolList() {
    let params = {
      PropertyID: +this.PropertyID,
    };
    this.BanningService.GetBanningProtocolList(params).subscribe((result) => {
      this.BanningProtocolList = result.data.GetBanningProtocolList;
      //console.log(this.BanningProtocolList);

      this.BanningProtocolList.forEach((element: any, i) => {
        // console.log(element)
        //this.DurationList.push(element.DurationList)
        /* insert into table */

        if (element.DurationList.length > 0) {
          let param = {
            BanningProtocolID: element.BanningProtocolID,
            PropertyID: +this.PropertyID,
            // "BanningProtocolDurationID": element.DurationList[0].BanningProtocolDurationID,
            BanningProtocolDurationID:
              element.DurationList[0].BanningDurationID,
            CreatedBy: +this.UserID,
            FromWhere: "pageload",
          };
          this.BanningService.UpdateBanningPropertyProtocol(param).subscribe(
            (result1) => {
              //console.log("result1", result1)
              let data = {
                BanningProtocolID: element.BanningProtocolID,
                PropertyID: +this.PropertyID,
              };
              this.BanningService.GetBanningPropertyProtocolByID(
                data
              ).subscribe((result2) => {
                // console.log("result2", result2)
                let temp = result2.data.GetBanningPropertyProtocolByID[0];
                //this.DurationName = temp.DurationTitle
                this.BanningProtocolList[i].SelectedDurationTitle =
                  temp.DurationTitle;
                //console.log(this.BanningProtocolList);
              });
            }
          );
        }
      });
    });
  }

  SaveBanningRecord() {
    let formData = this.BanningFormGroup.value;
    console.log("formData", formData);
  }

  changeDuration(BanningDurationID, DurationTitle, event, duration) {
    if (!event.isUserInput) return;
    //console.log(duration)
    // console.log(DurationTitle)
    //console.log(duration)
    let param = {
      BanningProtocolID: duration.BanningProtocolID,
      PropertyID: +this.PropertyID,
      // "BanningProtocolDurationID": duration.BanningProtocolDurationID,
      BanningProtocolDurationID: duration.BanningDurationID,
      CreatedBy: +this.UserID,
      FromWhere: "update",
    };
    this.BanningService.UpdateBanningPropertyProtocol(param).subscribe(
      (result1) => {
        // console.log(result1)
      }
    );
  }

  noIput() {
    return false;
  }
}
