import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BanningdurationComponent } from './banningduration.component';

describe('BanningdurationComponent', () => {
  let component: BanningdurationComponent;
  let fixture: ComponentFixture<BanningdurationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BanningdurationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BanningdurationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
