import { AddactivityComponent } from './activities/addactivity/addactivity.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PropertymanagementComponent } from './propertymanagement.component';
import { AddpropertyComponent } from './addproperty/addproperty.component';
import { PropertydetailComponent } from './propertydetail/propertydetail.component';
import { LocationmanagementComponent } from './locationmanagement/locationmanagement.component';
import { PatrolzonemanagementComponent } from './patrolzonemanagement/patrolzonemanagement.component';
import { PropertyprofileComponent } from './propertyprofile/propertyprofile.component';
import { BanningdurationComponent } from './banningduration/banningduration.component';
import { AssetsComponent } from './assets/assets.component';
import { ActivitiesComponent } from './activities/activities.component';
import { ShiftComponent } from './shift/shift.component';
import { AddshiftComponent } from './addshift/addshift.component';
import { AuthGuard } from "./../../../guard/auth.guard";

const routes: Routes = [
  { path: '', canActivate: [ AuthGuard ], redirectTo: 'propertydetail', pathMatch: 'full' },
  { path: 'propertymanagement', canActivate: [ AuthGuard ], component: PropertymanagementComponent },
  { path: 'propertydetail', canActivate: [ AuthGuard ], component: PropertydetailComponent },
  { path: 'propertydetail/addproperty/:id', canActivate: [ AuthGuard ], component: AddpropertyComponent },
  { path: 'propertydetail/addproperty', canActivate: [ AuthGuard ], component: AddpropertyComponent },
  { path: 'locationmgt', canActivate: [ AuthGuard ], component: LocationmanagementComponent },
  { path: 'patrolzonemgt', canActivate: [ AuthGuard ], component: PatrolzonemanagementComponent },
  { path: 'propertyprofile', canActivate: [ AuthGuard ], component: PropertyprofileComponent },
  { path: 'banningduration', canActivate: [ AuthGuard ], component: BanningdurationComponent },
  { path: 'activities', canActivate: [ AuthGuard ], component:ActivitiesComponent },
  { path: 'activities/addactivity', canActivate: [ AuthGuard ],component:AddactivityComponent},
  { path: 'activities/addactivity/:id', canActivate: [ AuthGuard ],component:AddactivityComponent},
  { path: 'assets', canActivate: [ AuthGuard ], component: AssetsComponent },
  { path: 'shift', canActivate: [ AuthGuard ], component: ShiftComponent },
  { path: 'shift/addshift', canActivate: [ AuthGuard ], component: AddshiftComponent },
  { path: 'shift/addshift/:id', canActivate: [ AuthGuard ], component: AddshiftComponent },
 

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PropertymanagementRoutingModule {}
