import { Injectable, ViewChild } from "@angular/core";
// import * as XLSX from 'xlsx';
import * as ExcelJS from "exceljs";
import { saveAs } from "file-saver";
import { environment } from "../../../../../environments/environment";
import * as pdfMake from "pdfmake";
// import { logoBase64 } from "../locationmanagement/brookfieldlogo";
import { logoBase64 } from "src/assets/images/logo/brookfieldlogo";
import pdfFonts from "pdfmake/build/vfs_fonts";
pdfMake.vfs = pdfFonts.pdfMake.vfs;
import { PropertManagementService } from "../propertyManagement.service";
import { defaultSystemPicks } from "./property-default-values";

@Injectable({
  providedIn: "root",
})
export class PropertyDetailService {
  obj = {
    propertyHeadUrl: null,
    propertyDetail: null,
    propertyImage: null,
    assignedCompany: null,
    workgrouplist: null,
    keycontact: null,
    propertyImageBase64: null,
    PropertyLogoBase64: null,
    propertyHeadBase64: null,
  };
  constructor(private propertyManagement: PropertManagementService) {}

  generateFileName(name: string, ext): string {
    return `${name}-${Date.now()}${ext}`;
  }

  async importExcelToExport(Json: any, pickVal: any, bool: boolean) {
    let columsName = [
      "Property Name",
      "Identification Number  (Note: Must be a four digit number)",
      "BusinessType",
      "Property Description",
      "Address1",
      "Address2",
      "Country Name",
      "State Name",
      "City Name",
      "Zip Code",
      "Phone (000-000-0000)",
      "Extension",
      "Business Email",
      "Website",
      "Time Zone",
      "Is DST Observed?",
      "Adjust Time",
      "Company Name",
      "Company Type",
      "Status",
      "Inserted Status",
    ];
    const wb = new ExcelJS.Workbook();

    /**
     * fcous on uploaded sheet
     */
    wb.views = [
      {
        x: 0,
        y: 0,
        width: 10000,
        height: 20000,
        firstSheet: 0,
        activeTab: 1,
        visibility: "visible",
      },
    ];

    const wsIns = wb.addWorksheet("Instructions");
    const ws = wb.addWorksheet("My Properties");
    const wsPick = wb.addWorksheet("SystemPickValues");

    let arr = [];
    columsName.forEach((elem, index) => {
      arr.push({ key: "col " + index, header: " " });
    });
    ws.columns = arr;

    ws.columns.forEach((column) => {
      column.width =
        column.header.length < 12 ? 12 + 15 : column.header.length + 15;
    });
    ws.getRow(3).values = columsName;

    ws.getRow(3).height = 55;
    ws.getCell("A7");
    ws.getRow(3).alignment = {
      vertical: "middle",
      horizontal: "center",
      wrapText: true,
    };
    ws.getCell("A2").font = {
      size: 22,
    };

    ws.getRow(3).font = {
      bold: true,
    };

    let im = wb.addImage({
      base64: logoBase64,
      extension: "png",
    });
    ws.addImage(im, "A1:B1");
    ws.getRow(1).height = 100;
    ws.getRow(2).height = 30;

    ws.getRow(2).values = ["Property Uploading Form"];
    ws.getCell("A2").font = {
      size: 22,
    };
    ws.getRow(3).border = {
      top: { style: "thin", color: { argb: "#000000" } },
      left: { style: "thin", color: { argb: "#000000" } },
      bottom: { style: "thin", color: { argb: "#000000" } },
      right: { style: "thin", color: { argb: "#000000" } },
    };
    if (Json.length === 0) {
      Json.forEach((elem, index) => {
        ws.getRow(index + 4).values = [
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
          "",
        ];
        ws.getRow(index + 4).alignment = {
          wrapText: true,
          horizontal: "justify",
        };
      });
    }
    if (bool === true) {
      Json.forEach((elem, index) => {
        ws.getRow(index + 4).values = [
          elem.PropertyName,
          elem.PropertyIdentNumber,
          elem.BusinessType,
          elem.PropertyDescription,
          elem.Address1,
          elem.Address2,
          elem.CountryName,
          elem.StateName,
          elem.City,
          elem.Zip,
          elem.PhoneNumber,
          elem.Extension,
          elem.BusinessEmail === null || elem.BusinessEmail === undefined
            ? ""
            : elem.BusinessEmail.toString().toLowerCase(),
          // "testing@gmail.com",
          elem.WebSite,
          elem.TimeZone,
          elem.IsDSTObserved,
          elem.AdjustTime,
          elem.CompanyName,
          elem.CompanyType,
          elem.IsActive === true ? "Active" : "InActive",
          elem.Status,
        ];
        ws.getRow(index + 4).alignment = {
          wrapText: true,
          horizontal: "center",
        };
      });
    } else {
      Json.forEach((elem, index) => {
        ws.getRow(index + 4).values = [
          elem.PropertyName,
          elem.PropertyIdentNumber,
          elem.BusinessType,
          elem.PropertyDescription,
          elem.Address1,
          elem.Address2,
          elem.CountryName,
          elem.StateName,
          elem.City,
          elem.Zip,
          elem.PhoneNumber,
          elem.Extension,
          elem.BusinessEmail,
          elem.WebSite,
          elem.TimeZone,
          elem.DSTObserved,
          elem.AdjustTime,
          elem.CompanyName,
          elem.CompanyType,
          elem.IsActive === true ? "Active" : "InActive",
          elem.Status,
        ];
        ws.getRow(index + 4).alignment = {
          wrapText: true,
          horizontal: "center",
        };
      });
    }
    Json.forEach((elem, index) => {
      ws.getCell("M:" + index + 4).hyperlink;
    });
    // ws.getRow(4).values = columsName;
    // ws.getRow(4).alignment = {
    //   wrapText: true,
    //   horizontal: "justify",
    // };
    /** columns decorations */
    this.colorCell(ws, "A3");
    this.colorCell(ws, "B3");
    this.colorCell(ws, "C3");
    this.colorCell(ws, "G3");
    this.colorCell(ws, "H3");
    this.colorCell(ws, "I3");
    this.colorCell(ws, "J3");
    this.colorCell(ws, "O3");
    this.colorCell(ws, "R3");
    this.colorCell(ws, "S3");
    this.colorCell(ws, "T3");
    /** this is system pickvalues */
    let arr1 = [];
    if (bool === true) {
      defaultSystemPicks.forEach((elem, index) => {
        arr1.push({ key: "col " + index, header: " " });
      });
    } else {
      pickVal.forEach((elem, index) => {
        arr1.push({ key: "col " + index, header: " " });
      });
    }
    wsPick.columns = arr1;

    wsPick.columns.forEach((column) => {
      column.width = column.header.length < 12 ? 12 + 15 : 12 + 15;
    });

    if (Json.length === 0 || bool == true) {
      defaultSystemPicks.forEach((element, index) => {
        wsPick.getRow(index + 2).values = element;
        wsPick.getRow(index + 2).alignment = {
          wrapText: true,
        };
      });
    } else {
      pickVal.forEach((element, index) => {
        wsPick.getRow(index + 2).values = [
          element[1] === undefined ? "" : element[1],
          element[2] === undefined ? "" : element[2],
          element[3] === undefined ? "" : element[3],
          element[4] === undefined ? "" : element[4],
          element[5] === undefined ? "" : element[5],
          element[6] === undefined ? "" : element[6],
        ];
        wsPick.getRow(index + 2).alignment = {
          wrapText: true,
        };
      });
    }
    /** end here  */
    /**instructions */
    wsIns.addImage(im, "D1:H1");
    wsIns.getRow(1).height = 100;
    wsIns.getRow(6).height = 50;

    wsIns.getCell("C2:I2").value =
      "Brookfield Properties My Property Spreadsheet";
    wsIns.getCell("C2:I2").font = {
      bold: true,
      size: 15,
      underline: "single",
    };
    wsIns.getRow(2).height = 30;
    /** this is bar header information */
    wsIns.getCell("B5:K5").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: {
        argb: "0xE2EFDA",
      },
    };
    ["B", "C", "D", "E", "F", "G", "H", "I", "J"].forEach((elem, index) => {
      this.colorCell(wsIns, elem + "5");
    });
    ["B", "C", "D", "E", "F", "G", "H", "I", "J"].forEach((elem, index) => {
      this.colorCell(wsIns, elem + "6");
    });

    wsIns.getCell(
      "B5"
    ).value = `Please list the Brookfield Properties, these Properties are customized to represent that`;
    wsIns.getCell(
      "B6"
    ).value = `company’s organizational structure and related positions of oversight. `;
    wsIns.getCell("B6").alignment = {
      vertical: "top",
    };

    /** set Intructions bar */
    wsIns.getCell("B8").value = "Set of Instructions for The Spreadsheet:";
    wsIns.getCell("B8").font = {
      bold: true,
    };
    /** generral information */
    wsIns.getCell("B10").value = "GENERAL INFO:";
    wsIns.getCell("B10").font = {
      bold: true,
    };
    /**general info detial about - */
    wsIns.getCell("B11").value = "-";
    wsIns.getCell("B11").alignment = {
      horizontal: "right",
    };
    wsIns.getCell("C11").value =
      "Please fill in the required fields to upload data into MAXIMUS";

    wsIns.getCell("B13").value = "-";
    wsIns.getCell("B13").alignment = {
      horizontal: "right",
    };
    wsIns.getCell("C13").value =
      "Dropdown value will appear in each cell if there is a selection to be made";

    wsIns.getCell("B16").value = "-";
    wsIns.getCell("B16").alignment = {
      horizontal: "right",
    };
    wsIns.getCell("B17").value = "-";
    wsIns.getCell("B17").alignment = {
      horizontal: "right",
    };
    wsIns.getCell("B19").value = "-";
    wsIns.getCell("B19").alignment = {
      horizontal: "right",
    };

    /** - box color field that are required */
    wsIns.getCell("C16").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: {
        argb: "0xE2EFDA",
      },
    };
    wsIns.getCell("C16").border = {
      top: { style: "thick", color: { argb: "#000000" } },
      left: { style: "thick", color: { argb: "#000000" } },
      bottom: { style: "thick", color: { argb: "#000000" } },
      right: { style: "thick", color: { argb: "#000000" } },
    };

    wsIns.getCell("C17").border = {
      top: { style: "thick", color: { argb: "#000000" } },
      left: { style: "thick", color: { argb: "#000000" } },
      bottom: { style: "thick", color: { argb: "#000000" } },
      right: { style: "thick", color: { argb: "#000000" } },
    };
    wsIns.getCell("C19").border = {
      top: { style: "thin", color: { argb: "#000000" } },
      left: { style: "thin", color: { argb: "#000000" } },
      bottom: { style: "thin", color: { argb: "#000000" } },
      right: { style: "thin", color: { argb: "#000000" } },
    };

    /** D${++} text starts */
    wsIns.getCell("D16").value =
      "Headers in Light Green are Mandatory or Required Fields";
    (wsIns.getCell("D17").value =
      "Headers in White are not Required entry Fields"),
      (wsIns.getCell("D19").value =
        "Headers cells that are include a red triangle at top right provide");
    /**end here  */
    const buf = await wb.xlsx.writeBuffer();
    saveAs(
      new Blob([buf]),
      this.generateFileName("propertyDetailList", ".xlsx")
    );
  }
  colorCell(ws, cn) {
    ws.getCell(cn).fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: {
        argb: "0xEAF1DD",
      },
    };
  }
  /**
   *
   * @param json current json oject that has been searched ad expoprtted
   * @param filename send it file name ...
   */
  async exportToExecl(json: any, filename: string) {
    let columnName = [
      "Property Name",
      "Global Environment ID",
      "Property Description",
      "Subunit Name",
      "Sub Division",
      "Property Identification Number",
      "Environment Name",
      "Address",
      "City",
      "State Name",
      "Zip Code",
      "Property Status",
      "Archived",
      "Assigned Company",
      "Property Subunit ?",
    ];
    let arr = [];
    // let columnsSet = ["A", "B", "C", "D", "E", "F", "G", "H", "I"];
    const wb = new ExcelJS.Workbook();
    const ws = wb.addWorksheet("sheet", {
      properties: { tabColor: { argb: "FF00FF00" } },
    });
    columnName.forEach((elem, i) => {
      arr.push({ key: "col " + i, header: " " });
    });
    ws.columns = arr;
    ws.columns.forEach((column) => {
      column.width =
        column.header.length < 12 ? 12 + 15 : column.header.length + 15;
    });

    let im = wb.addImage({
      base64: logoBase64,
      extension: "png",
    });
    ws.addImage(im, "A1:B1");
    ws.getRow(1).height = 100;
    ws.getRow(2).height = 30;

    json.forEach((element, index) => {
      ws.getRow(index + 4).values = [
        element.PropertyName,
        element.GlobalEnvironmentID,
        element.PropertyDescription,
        element.SubunitName,
        element.Subdivision,
        element.PropertyIdentNumber,
        element.EnvironmentName,
        element.Address1,
        element.City,
        element.StateName,
        element.Zip,
        element.IsActive,
        element.IsArchive === null
          ? ""
          : element.IsArchive === true
          ? "Yes"
          : "No",
        element.AssignedCompany,
        element.IsPropertySubUnit,
      ];
      ws.getRow(index + 4).alignment = {
        wrapText: true,
        horizontal: "justify",
      };
    });
    ws.getRow(2).values = ["Property Exported Data"];
    ws.getCell("A2").font = {
      size: 20,
    };

    ws.getRow(3).values = columnName;

    ws.getRow(3).height = 40;
    ws.getCell("A7");
    ws.getRow(3).alignment = {
      vertical: "middle",
      horizontal: "center",
      wrapText: true,
    };
    ws.getRow(3).font = {
      bold: true,
    };
    ws.getRow(3).border = {
      top: { style: "thin", color: { argb: "#000000" } },
      left: { style: "thin", color: { argb: "#000000" } },
      bottom: { style: "thin", color: { argb: "#000000" } },
      right: { style: "thin", color: { argb: "#000000" } },
    };

    ws.getRow(3).fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "0xE2EFDA" },
    };
    // await ws.protect('the-password', {});
    const buf = await wb.xlsx.writeBuffer();
    saveAs(
      new Blob([buf]),
      this.generateFileName("propertyDetailList", ".xlsx")
    );
  }
  async exportToPdf(PropertyDetail) {
    const propertyDetailSubs = this.propertyManagement
      .getPropertyBYId({ PropertyId: PropertyDetail.PropertyID })
      .subscribe((PropertyDetailList) => {
        this.obj.propertyDetail = PropertyDetailList.getPropertyById;
        const getImage = this.propertyManagement
          .getImageFile({ PropertyId: PropertyDetail.PropertyID })
          .subscribe((propertyImage) => {
            this.obj.propertyImage = propertyImage.listImage;
            const assignedCompanyList = this.propertyManagement
              .GetAssignedPropertyCompanyList({
                PropertyID: +PropertyDetail.PropertyID,
              })
              .subscribe((assignedCompany) => {
                this.obj.assignedCompany =
                  assignedCompany.AssignedPropertyCompanyList;
                const workgroupList = this.propertyManagement
                  .GetAssigedWorkGroupsToProperty({
                    PropertyID: PropertyDetail.PropertyID,
                  })
                  .subscribe((wordkgroup) => {
                    this.obj.workgrouplist =
                      wordkgroup.AssigedWorkGroupsToProperty;

                    const keyContactList = this.propertyManagement
                      .GetPropertyContact({
                        PropertyId: PropertyDetail.PropertyID,
                      })
                      .subscribe((keyContactPerson) => {
                        this.obj.keycontact = keyContactPerson.PropertyContact;

                        /**
                         * unsubscribe the all subscriptions no need at all again
                         */

                        this.initiatePdfExport();

                        propertyDetailSubs.unsubscribe();
                        getImage.unsubscribe();
                        assignedCompanyList.unsubscribe();
                        workgroupList.unsubscribe();
                        keyContactList.unsubscribe();
                      });
                  });
              });
          });
      });

    // let x = await this.toDataUrlBase64('https://www.gravatar.com/avatar/d50c83cc0c6523b4d3f6085295c953e0');
  }
  async initiatePdfExport() {
    const url = location.origin; // url
    const propertyImaeUrl = `${url}/uploadFile/users/`;

    this.checkImageExits();
    console.log(this.obj);
    this.obj.propertyHeadBase64 = await this.toDataUrlBase64(
      this.obj.propertyHeadUrl
    );
    this.obj.propertyImageBase64 = await this.toDataUrlBase64(
      this.obj.propertyImage[0].ImageName
    );
    this.obj.PropertyLogoBase64 = await this.toDataUrlBase64(
      this.obj.propertyImage[1].ImageName
    );

    this.modifyPropertyDetailItems("propertyDetail", [
      "PropertySubUnit",
      "EnvironmentName",
      "IsDSTObserved",
      "PhoneNumber",
    ]);
    this.modifyComapnyItems();
    this.modifyWorkgroupItems();
    this.modifyKeyContact();
    this.pdfConvert();
    console.log(this.obj);
    /** checkinh image exxits */
  }

  modifyPropertyDetailItems(mainObj, key) {
    // for Property sub unit
    if (
      this.obj[mainObj][0][key[0]] === null ||
      this.obj[mainObj][0][key[0]] === "" ||
      this.obj[mainObj][0][key[0]] === undefined
    ) {
      // this.obj[mainObj][0][key[0]] = "No Property Sub Unit Assigned";
      this.obj[mainObj][0][key[0]] = "";
    }
    // goe name
    if (
      this.obj[mainObj][0][key[1]] === null ||
      this.obj[mainObj][0][key[1]] === "" ||
      this.obj[mainObj][0][key[1]] === undefined
    ) {
      this.obj[mainObj][0][key[1]] = "No Global Environment Assigned";
    }
    // this is for IS Observed time yes or no
    this.obj[mainObj][0][key[2]] === true ? "Yes" : "No";
    // Modify Mobile number with -
    if (
      this.obj[mainObj][0][key[3]] === null ||
      this.obj[mainObj][0][key[3]] === "" ||
      this.obj[mainObj][0][key[3]] === undefined
    ) {
      this.obj[mainObj][0][key[3]] = "";
    } else {
      // let r = this.obj[mainObj][0][key[3]];
      // this.obj[mainObj][0][key[3]] = r.slice(0, 3) + "-" + r.slice(3, r.length);
    }
  }

  modifyComapnyItems() {
    let headerColumns: any = [
      [
        "COMPANY/COMPANY SUBDIVISION NAME",
        "COMPANY TYPE RELATIONSHIP",
        "ASSIGNED DATE",
        "ASSIGNED BY",
        "STATUS",
      ],
    ];

    if (this.obj.assignedCompany.length === 0) {
      // this.obj.assignedCompany.push(headerColumns);
      this.obj.assignedCompany = headerColumns;
      return;
    }

    let tempArr = this.obj.assignedCompany;

    tempArr.forEach((elem, index) => {
      headerColumns.push([
        elem.CompanyName,
        elem.CompanyType,
        "",
        elem.AssignedBy,
        elem.IsAssined === 1 ? "Assigned" : "Unassigned",
      ]);
    });
    this.obj.assignedCompany = headerColumns;

    console.log(this.obj);
  }
  modifyWorkgroupItems() {
    let headerColumns: any = [
      ["COMPANY", "COMPANY SUBDIVISION", "WORKGROUP NAME"],
    ];

    if (this.obj.workgrouplist.length === 0) {
      // this.obj.workgrouplist.push(headerColumns);
      this.obj.workgrouplist = headerColumns;
      return;
    }

    let tempArr = this.obj.workgrouplist;

    tempArr.forEach((elem, index) => {
      headerColumns.push([
        elem.CompanyName,
        elem.CompanySubdivision,
        elem.WorkGroupName,
      ]);
      console.log(elem);
    });
    this.obj.workgrouplist = headerColumns;

    console.log(this.obj);
  }
  modifyKeyContact() {
    let headerColumns: any = [
      [
        "NAME",
        "USER ID",
        "POSITION TITLE",
        "USER PROFILE\n/ROLE",
        "COMPANY/\nSUBDIVISION \nCOMPANY TYPE",
        "WORKGROUP/\nPROPERTY",
        "EMAIL ID",
        "CONTACT",
      ],
    ];

    if (this.obj.keycontact.length === 0) {
      // this.obj.keycontact.push(headerColumns);
      this.obj.keycontact = headerColumns;
      return;
    }

    let tempArr = this.obj.keycontact;

    tempArr.forEach((elem, index) => {
      headerColumns.push([
        elem.UserName ? elem.UserName : "",
        elem.UserID ? elem.UserID : "",
        elem.PositionTitle ? elem.PositionTitle : "",
        "",
        elem.CompanySubdivision ? elem.CompanySubdivision : "",
        "",
        "",
        elem.PhoneNumber ? elem.PhoneNumber : "",
      ]);
    });
    this.obj.keycontact = headerColumns;

    console.log(this.obj);
  }

  checkImageExits() {
    let defaultUrl = location.origin;
    const defaultPropertyImageUrl = `${defaultUrl}/assets/images/imagenaBg.png`;
    const propertyImageUrl = `${environment.imagePath}users/`;
    const propertyHeadUrl = `${defaultUrl}/assets/images/icons/property.png`;

    this.obj.propertyHeadUrl = propertyHeadUrl;
    if (this.obj.propertyImage.length === 0) {
      this.obj.propertyImage = [
        { ImageName: defaultPropertyImageUrl },
        { ImageName: defaultPropertyImageUrl },
      ];

      return;
    }
    if (this.obj.propertyImage.length === 1) {
      if (this.obj.propertyImage[0].ImageTypeID === 1) {
        this.obj.propertyImage[0].ImageName = `${propertyImageUrl}${this.obj.propertyImage[0].ImageName}`;
        this.obj.propertyImage.push({ ImageName: defaultPropertyImageUrl });
      }
      if (this.obj.propertyImage[0].ImageTypeID === 2) {
        let temp = this.obj.propertyImage[0];

        this.obj.propertyImage[0] = { ImageName: defaultPropertyImageUrl };

        temp.ImageName = `${propertyImageUrl}${temp.ImageName}`;

        this.obj.propertyImage[1] = temp;
      }
      return;
    }
    if (this.obj.propertyImage.length === 2) {
      this.obj.propertyImage[0].ImageName = `${propertyImageUrl}${this.obj.propertyImage[0].ImageName}`;
      this.obj.propertyImage[1].ImageName = `${propertyImageUrl}${this.obj.propertyImage[1].ImageName}`;

      return;
    }
  }
  toDataUrlBase64(url: string) {
    const toBase64 = fetch(url)
      .then((response) => response.blob())
      .then(
        (blob) =>
          new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve(reader.result);
            reader.onerror = reject;
            reader.readAsDataURL(blob);
          })
      );

    return toBase64;
  }

  pdfConvert() {
    let objRef = this.obj;

    let _pd = this.obj.propertyDetail[0];
    let dd = {
      info: {
        title: `${_pd.PropertyName}`,
        author: `${_pd.PropertyName}`,
        subject: "All Detail of Property and work group and Company",
        keywords: "property management",
        creationDate: `${new Date()}`,
      },
      pageSize: "A3",

      content: [
        {
          alignment: "justify",
          columns: [
            {
              image: this.obj.propertyHeadBase64,
              width: 30,
              height: 30,
              marginTop: 10,
            },
            {
              text: `\n${_pd.PropertyName}\n${
                _pd.PropertySubUnit === "" ? "" : _pd.PropertySubUnit + "\n"
              }This is Global Operation: ${_pd.EnvironmentName}\n\n`,
            },
          ],
        },
        {
          alignment: "left",
          layout: "noBorders",
          table: {
            widths: [500, 180],
            body: [
              [{ text: "IDENTIFIERS", style: "header" }, { text: "" }],

              [
                [
                  {
                    layout: "noBorders",
                    table: {
                      widths: [270, 200],
                      body: [
                        [
                          {
                            text: `\nProperty Name or Property Sub Unit Name`,
                            style: "normal",
                          },
                          {
                            text: `\nProperty or Property Sub Unit ID#`,
                            style: "normal",
                          },
                        ],
                        [
                          {
                            text: `${_pd.PropertyName}`,
                          },
                          {
                            text: `${_pd.PropertyIdentNumber}`,
                          },
                        ],
                      ],
                    },
                  },
                  {
                    text: "\nBusiness Type of Property or Property Sub-unit ",
                    style: "normal",
                  },
                  {
                    text: `${_pd.BusinessType || ""}`,
                  },

                  {
                    alignment: "justify",
                    layout: "noBorders",
                    table: {
                      widths: [490],
                      heights: ["*", 40],
                      body: [
                        [
                          {
                            text: "\nProperty Description",
                            style: "normal",
                          },
                        ],
                        [
                          {
                            text: `${_pd.PropertyDescription}\n\n`,
                          },
                        ],
                      ],
                    },
                  },
                  {
                    text: "PHYSICAL ADDRESS\n\n",
                    style: "header",
                  },
                  {
                    text: "Address 1",
                    style: "normal",
                  },
                  {
                    text: `${_pd.Address1}`,
                  },
                ],
                [
                  {
                    alignment: "center",
                    layout: "noBorders",
                    table: {
                      widths: [180],
                      body: [
                        [{ text: "Property Image Graphic", style: "normal" }],
                        [
                          {
                            image: this.obj.propertyImageBase64,
                            width: 100,
                            height: 100,
                          },
                        ],
                        [{ text: "Property Logo Graphic", style: "normal" }],
                        [
                          {
                            image: this.obj.PropertyLogoBase64,
                            width: 100,
                            height: 100,
                          },
                        ],
                      ],
                    },
                  },
                ],
              ],
            ],
          },
        },
        {
          text: "Address 2",
          style: "normal",
        },
        {
          text: `${_pd.Address2}`,
        },
        {
          text: "\nCountry",
          style: "normal",
        },
        {
          text: `${_pd.CountryName}`,
        },

        {
          alignment: "justify",
          columns: [
            {
              columns: [
                {
                  text: "\nState/Sub-National Designation",
                  style: "normal",
                },
                {
                  text: "\nCity",
                  style: "normal",
                },
                {
                  text: "\nZip Code/Other Code",
                  style: "normal",
                },
              ],
            },
          ],
        },
        {
          alignment: "justify",
          columns: [
            {
              text: `${_pd.CountryName}`,
            },
            {
              text: `${_pd.City}`,
            },
            {
              text: `${_pd.Zip}`,
            },
          ],
        },
        {
          text: "\nGENERAL CONTACT INFORMATION",
          style: "header",
        },
        {
          text: "\nPhone Number",
          style: "normal",
        },
        {
          text:
            _pd.PhoneNumber != "" || undefined
              ? `${_pd.CountryCode}-${_pd.AreaCode}-${_pd.PhoneNumber}-${_pd.Extension}`
              : "",
        },
        {
          text: "\nBusiness Email Address",
          style: "normal",
        },
        {
          text: `${_pd.BusinessEmail}`,
        },
        {
          text: "\nWebsite Address",
          style: "normal",
        },
        {
          text: `${_pd.WebSite}`,
        },
        {
          text: "\n\nASSOCIATIONS\n\n",
          style: "header",
        },
        {
          style: "tableExample",
          layout: "noBorders",
          table: {
            body: [
              [
                {
                  text:
                    "COMPANIES/SUBDIVISIONS – ASSIGN COMPANIES/COMPANIES SUBDIVISIONS\n",
                  style: "normal",
                },
              ],
              [
                {
                  table: {
                    widths: [240, 190, 100, 100, 80],
                    body: [...objRef.assignedCompany],
                  },
                  layout: {
                    hLineWidth: function (i, node) {
                      return i === 0 || i === node.table.body.length
                        ? 0.5
                        : 0.5;
                    },
                    vLineWidth: function (i, node) {
                      return i === 0 || i === node.table.widths.length
                        ? 0.5
                        : 0.5;
                    },
                    hLineColor: function (i, node) {
                      return i === 0 || i === node.table.body.length
                        ? "gray"
                        : "gray";
                    },
                    vLineColor: function (i, node) {
                      return i === 0 || i === node.table.widths.length
                        ? "gray"
                        : "gray";
                    },
                  },
                },
              ],
            ],
          },
        },

        {
          style: "tableExample",
          layout: "noBorders",
          table: {
            body: [
              [
                {
                  text:
                    "\n\nWORKGROUPS TO WHICH THIS PROPERTY/PROPERTY SUB-UNIT BELONGS\n",
                  style: "normal",
                },
              ],
              [
                {
                  table: {
                    headerRows: 1,
                    dontBreakRows: true,
                    keepWithHeaderRows: 1,
                    widths: [242, 242, 242],
                    body: [...objRef.workgrouplist],
                  },
                  layout: {
                    hLineWidth: function (i, node) {
                      return i === 0 || i === node.table.body.length
                        ? 0.5
                        : 0.5;
                    },
                    vLineWidth: function (i, node) {
                      return i === 0 || i === node.table.widths.length
                        ? 0.5
                        : 0.5;
                    },
                    hLineColor: function (i, node) {
                      return i === 0 || i === node.table.body.length
                        ? "gray"
                        : "gray";
                    },
                    vLineColor: function (i, node) {
                      return i === 0 || i === node.table.widths.length
                        ? "gray"
                        : "gray";
                    },
                  },
                },
              ],
            ],
          },
        },
        {
          style: "tableExample",
          layout: "noBorders",
          table: {
            headerRows: 1,
            dontBreakRows: true,
            keepWithHeaderRows: 1,

            body: [
              [
                {
                  text: "\nKEY PERSON",
                  style: "normal",
                },
              ],
              [
                {
                  table: {
                    headerRows: 1,
                    dontBreakRows: true,
                    keepWithHeaderRows: 1,
                    widths: [85.7, 85.7, 85.7, 85.7, 85.7, 85.7, 85.7, 85.7],
                    body: [...objRef.keycontact],
                  },
                  layout: {
                    hLineWidth: function (i, node) {
                      return i === 0 || i === node.table.body.length
                        ? 0.5
                        : 0.5;
                    },
                    vLineWidth: function (i, node) {
                      return i === 0 || i === node.table.widths.length
                        ? 0.5
                        : 0.5;
                    },
                    hLineColor: function (i, node) {
                      return i === 0 || i === node.table.body.length
                        ? "gray"
                        : "gray";
                    },
                    vLineColor: function (i, node) {
                      return i === 0 || i === node.table.widths.length
                        ? "gray"
                        : "gray";
                    },
                  },
                },
              ],
            ],
          },
        },
        {
          text: "\n\nSETTING\n\n",
          style: "header",
        },
        {
          text: "SELECTED TIME ZONE",
          style: "normal",
        },
        {
          text: `${_pd.TimeZoneName || ""}`,
        },
        {
          text: "\nDAYLIGHT SAVING TIME OBSERVED",
          style: "normal",
        },
        {
          text: `${_pd.IsDSTObserved === false ? "No" : "Yes"}`,
        },
        {
          text: "\nADJUSTED TIME",
          style: "normal",
        },
        {
          text: `${_pd.AdjustTime}`,
        },
        {
          text: "\nONBOARDING STATUS",
          style: "normal",
        },
        {
          text: "...",
        },
      ],

      styles: {
        header: {
          fontSize: 15,
          bold: true,
        },

        bigger: {
          fontSize: 13,
          bold: true,
        },
        normal: {
          bold: true,
        },
      },
      defaultStyle: {
        columnGap: 10,
      },
    };

    pdfMake
      .createPdf(dd)
      .download(this.generateFileName(_pd.PropertyName, ".pdf"));
  }
}
