import { Component, OnInit, ViewChild } from "@angular/core";
import { PropertManagementService } from "../propertyManagement.service";
import { FormGroup, FormBuilder, FormControl } from "@angular/forms";
import { Observable } from "rxjs";
import * as ExcelJS from "exceljs";
import { ToastrService } from "ngx-toastr";
import { startWith, map, filter } from "rxjs/operators";
import { DataSharingService } from "../dataSharing.service";
import { PropertyDetailService } from "./propertyDetail.service";
import Swal from "sweetalert2";
import { Router } from "@angular/router";
import { JsToPdfService } from "../myproperty-list/jsToPdf.service";
import { UserPermissionService } from "../../../../services/user-permission.service";
import { StorageService } from "../../../../services/storage.service";
@Component({
  selector: "app-propertydetail",
  templateUrl: "./propertydetail.component.html",
  styleUrls: ["./propertydetail.component.scss"],
})
export class PropertydetailComponent implements OnInit {
  @ViewChild("fileInput", { static: false }) excel: any;
  selectedIndex = -1;
  userID: any;
  isDataFound = false;
  systemPickValues: any = [];
  isAddPropertyBtnShow: boolean = true;
  formControlobj = {
    propertySearch: new FormControl(),
    filterByCountrySearch: new FormControl(),
    filterByGoeSearch: new FormControl(),
    filterByStateSearch: new FormControl(),
    filterByCompanySearch: new FormControl(),
    filterByStatusSearch: new FormControl(),
    filterByIsActive: new FormControl(),
    filterByIsAssigned: new FormControl(),
    filterByIsArchived: new FormControl(),
  };

  /** */
  filtered = {
    propertyFiltered: null,
    filterByCountryFiltered: null,
    filterByGoeFiltered: null,
    filterByStateFiltered: null,
    filterByCompanyFiltered: null,
    filterByStatusFiltered: null,
    filterByIsAssignedFiltered: null,
    filterByIsActiveFiltered: null,
    filterByIsArchiveFiltered: null,
  };

  obj = {
    propertyList: [],
    countryList: [],
    GoeListArray: [],
    StateList: [],
    ComapanyList: [],
    StatusList: [],
    isAssignedList: [],
    isActiveList: [],
    isArchiveList: [],
  };

  // .......
  propertiesList = [];

  /**
   * default all data without search
   */
  propertySearchParam = {
    PropertyID: 0,
    PropertyName: null,
    GOEId: 0,
    ComapnyId: 0,
    CountryId: 0,
    StateId: 0,
    City: null,
    Status: 0,
    IsActive: null,
    IsArchive: 0,
    IsAssignedGOE: null,
    Zip: null,
    Address: null,
    ShortFilter: null,
  };
  default = {
    PropertyID: 0,
    PropertyName: null,
    GOEId: 0,
    ComapnyId: 0,
    CountryId: 0,
    StateId: 0,
    City: null,
    Status: 0,
    IsActive: null,
    IsArchive: 0,
    IsAssignedGOE: null,
    Zip: null,
    Address: null,
    ShortFilter: null,
  };
  downloadSearchParam = {
    PropertyId: 0,
    PropertyName: null,
    GOEId: 0,
    ComapnyId: 0,
    CountryId: 0,
    StateId: 0,
    City: null,
    Status: 0,
    IsActive: null,
    IsArchive: 0,
    IsAssignedGOE: null,
    Zip: null,
    Address: null,
    ShortFilter: null,
  };
  isSubUnitVisible = false;
  downloadToExcel: Array<any> = [];
  inteliTypeFilters: Array<any> = [
    // "propertySearch",
    // "filterByGoeSearch",
    // "filterByCompanySearch"
  ];
  /**
   *
   * @param PropertManagement
   * @param fb
   */
  contactForm: FormGroup;
  alphabets: Array<string> = new Array();
  /**  */

  authToken = null;
  userData = null;
  UserID = null;

  constructor(
    private PropertManagement: PropertManagementService,
    private fb: FormBuilder,
    private dataShare: DataSharingService,
    private jsonToExcel: PropertyDetailService,
    private router: Router,
    private tostre: ToastrService,
    private jstopdf: JsToPdfService,
    public UserPermission: UserPermissionService,
    private storage: StorageService
  ) {
    //... Read User Data ...
    this.authToken = this.storage.getData("token");
    this.userData = JSON.parse(this.storage.getData("UserData"));
    this.UserID = this.userData[0].UserID;
    if (this.authToken == null) {
      this.router.navigate(["/login"]);
    }

    /* check module permission of the user */
    /* if(this.UserPermission.checkPermission("access_my_properties", '','','') == false){           
      this.router.navigate(["/products/list"]);
      this.tostre.warning("You don't have permission to access this module.", "", {
        positionClass: "toast-top-right",
      });       
    } */

    this.contactForm = this.fb.group({
      _prop: [""],
      _cty: [""],
    });
  }

  ngOnInit() {
    this.userID = 0;
    //this.clearValue();
    this.getPropertyList();
    this.getCountryList();
    this.getState();
    this.getGoeList();
    this.getCompanySubDivision();
    this.alphabets = this.generateAlphabate();
    this.dataShare._isDataFound.subscribe((x: any) => {
      if (x === "false") {
        this.isDataFound = false;
      } else if (x === "true") {
        this.isDataFound = true;
      }
    });

    this.getAssignedFilterOption();
    this.getIsActiveFilterOption();
    this.getIsArchiveFilterOption();

    if (this.storage.getData("status") == "updated") {
      this.getPropertySearchList(this.default);
      this.storage.removeData("status");
    }
    if (this.storage.getData("PropertyDetail")) {
      this.isSubUnitVisible = true;
      this.isAddPropertyBtnShow = false;
    } else {
      this.isSubUnitVisible = false;
      this.isAddPropertyBtnShow = true;
    }
    this.isAddPropertyBtnShow = false;
    this.isSubUnitVisible = true;
    this.getPropertySearchList(this.propertySearchParam);
  }

  private _filter(value: any, keyName: string, filterName: string): string[] {
    const filterValue = value.toLowerCase();
    return this.obj[keyName].filter((option) =>
      option[filterName].toLowerCase().includes(filterValue)
    );
  }
  /**
   *
   * @param keyNameFilter of - filtered - after lost
   * @param listFromServer  of - from array of object list the from server -
   * @param keyNameObj of - array of keyname that we want to take -
   * @param formControlKeyName of - from control that has value changes obtain -
   */
  initiate(keyNameFilter, listFromServer, keyNameObj, formControlKeyName) {
    this.filtered[keyNameFilter] = this.formControlobj[
      formControlKeyName
    ].valueChanges.pipe(
      startWith(""),
      //map((value) => this._filter(value, listFromServer, keyNameObj))
      map((value) => {
        let list = [];
        if (this.inteliTypeFilters.includes(formControlKeyName)) {
          list =
            String(value).length >= 1
              ? this._filter(value, listFromServer, keyNameObj)
              : [];
          if (list.length == 1 && list[0][keyNameObj] == value) {
            list = [];
          }
        } else {
          list = this._filter(value, listFromServer, keyNameObj);
        }

        return list;
      })
    );
  }

  getAssignedFilterOption() {
    let array = [
      { value: 1, name: "Assigned" },
      { value: 0, name: "Unassigned" },
    ];
    this.obj.isAssignedList = array;

    this.initiate(
      "filterByIsAssignedFiltered",
      "isAssignedList",
      "name",
      "filterByIsAssigned"
    );
  }
  getIsActiveFilterOption() {
    let array = [
      { value: 1, name: "Active" },
      { value: 0, name: "Inactive" },
    ];
    this.obj.isActiveList = array;

    this.initiate(
      "filterByIsActiveFiltered",
      "isActiveList",
      "name",
      "filterByIsActive"
    );
  }
  getIsArchiveFilterOption() {
    let array = [
      { value: 1, name: "Yes" },
      { value: 0, name: "No" },
    ];
    this.obj.isArchiveList = array;

    this.initiate(
      "filterByIsArchiveFiltered",
      "isArchiveList",
      "name",
      "filterByIsArchived"
    );
  }

  getPropertyList() {
    this.PropertManagement.getPropertyByUser({ UserId: this.userID }).subscribe(
      (x) => {
        this.obj.propertyList = x.getPropertyByUser;
        this.propertiesList = x.getPropertyByUser;

        this.initiate(
          "propertyFiltered",
          "propertyList",
          "ParopertyName",
          "propertySearch"
        );
      }
    );
  }
  getCountryList() {
    this.PropertManagement.getCountry().subscribe((x) => {
      this.obj.countryList = x.getCountry;
      this.initiate(
        "filterByCountryFiltered",
        "countryList",
        "CountryName",
        "filterByCountrySearch"
      );
    });
  }
  getState() {
    this.PropertManagement.getState({ countryId: 0 }).subscribe((x) => {
      this.obj.StateList = x.getState;
      this.initiate(
        "filterByStateFiltered",
        "StateList",
        "StateName",
        "filterByStateSearch"
      );
    });
  }
  getGoeList() {
    this.PropertManagement.getGoeList({ UserId: this.userID }).subscribe(
      (x) => {
        this.obj.GoeListArray = x.geoByUser;

        this.initiate(
          "filterByGoeFiltered",
          "GoeListArray",
          "GlobalEnvironmentName",
          "filterByGoeSearch"
        );
      }
    );
  }
  getCompanySubDivision() {
    this.PropertManagement.getCompanySubDivision({
      UserId: this.userID,
    }).subscribe((x) => {
      this.obj.ComapanyList = x.comapnySubdivision;
      this.initiate(
        "filterByCompanyFiltered",
        "ComapanyList",
        "CompanyORSubdivision",
        "filterByCompanySearch"
      );
    });
  }

  getPropertySearchList(obj) {
    this.downloadSearchParam.PropertyId = obj.PropertyID;
    this.downloadSearchParam.GOEId = obj.GOEId;
    this.downloadSearchParam.ComapnyId = obj.ComapnyId;
    this.downloadSearchParam.CountryId = obj.CountryId;
    this.downloadSearchParam.StateId = obj.StateId;
    this.downloadSearchParam.City = obj.City;
    this.downloadSearchParam.Status = obj.Status;
    this.downloadSearchParam.IsActive = obj.IsActive;
    this.downloadSearchParam.IsArchive = obj.IsArchive;
    this.downloadSearchParam.IsAssignedGOE = obj.IsAssignedGOE;
    this.downloadSearchParam.Zip = obj.Zip;
    this.downloadSearchParam.Address = obj.Address;
    this.downloadSearchParam.ShortFilter = obj.ShortFilter;

    this.PropertManagement.getPropertySearchList(obj).subscribe((x) => {
      this.downloadToExcel = x.propertySearchList;
      this.dataShare.changePropertyParam(obj);

      this.dataShare.changeMessage(x);
    });
  }

  /**
   * selection functinality
   */
  setSelections(key, optKey, opt, evt) {
    if (!evt.isUserInput) return;
    this.propertySearchParam[key] =
      key == "PropertyName"
        ? opt.ParopertyName.split("-")[0].trim()
        : +opt[optKey];
    this.propertySearchParam.ShortFilter = null;
    this.selectedIndex = -1
    this.getPropertySearchList(this.propertySearchParam);
  }

  backSpaceToRemove(objKeyName, assignValue) {
    this.propertySearchParam[objKeyName] = assignValue;

    this.getPropertySearchList(this.propertySearchParam);
  }

  //this.getUpcommingInspection(this.obj);

  onkeyUpSelection(str) {
    if (
      str == "PropertyName" ||
      str == "Zip" ||
      str == "Address" ||
      str == "IsActive" ||
      str == "IsArchive" ||
      str == "IsAssignedGOE"
    ) {
      this.propertySearchParam[str] = null;
    } else {
      this.propertySearchParam[str] = 0;
    }
    this.propertySearchParam.ShortFilter = null;
    this.getPropertySearchList(this.propertySearchParam);
  }
  generateAlphabate(): Array<string> {
    return "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("");
  }
  customSearch(type, elem) {
    if (type == "IsArchive" || type == "IsActive" || type == "IsAssignedGOE") {
      if (elem.value == undefined) elem.value = null;
      else this.propertySearchParam[type] = parseInt(elem.value);
    } else {
      this.propertySearchParam[type] = elem.value;
    }
    this.getPropertySearchList(this.propertySearchParam);
  }

  /**
   *
   * @param event Validate so time can input only number
   */
  numberOnly(event: any): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  /**
   *
   * @param rule
   * @param obj
   */
  okay(rule, obj) {
    if (rule == "all") {
      obj = this.default;
      obj.ShortFilter = null;
    } else {
      obj = this.default;
      obj.ShortFilter = rule;
    }
    this.formControlobj = {
      propertySearch: new FormControl(''),
      filterByCountrySearch: new FormControl(''),
      filterByGoeSearch: new FormControl(''),
      filterByStateSearch: new FormControl(''),
      filterByCompanySearch: new FormControl(''),
      filterByStatusSearch: new FormControl(''),
      filterByIsActive: new FormControl(''),
      filterByIsAssigned: new FormControl(''),
      filterByIsArchived: new FormControl(''),
    }
    this.getPropertySearchList(obj);
  }
  calledToExcel() {
    // this.downloadSearchParam.PropertyId = this.propertySearchParam.PropertyID;
    // this.downloadSearchParam.GOEId = this.propertySearchParam.GOEId;
    // this.downloadSearchParam.ComapnyId = this.propertySearchParam.ComapnyId;
    // this.downloadSearchParam.CountryId = this.propertySearchParam.CountryId;
    // this.downloadSearchParam.StateId = this.propertySearchParam.StateId;
    // this.downloadSearchParam.City = this.propertySearchParam.City;
    // this.downloadSearchParam.Status = this.propertySearchParam.Status;
    // this.downloadSearchParam.IsActive = this.propertySearchParam.IsActive;
    // this.downloadSearchParam.IsArchive = this.propertySearchParam.IsArchive;
    // this.downloadSearchParam.IsAssignedGOE = this.propertySearchParam.IsAssignedGOE;
    // this.downloadSearchParam.Zip = this.propertySearchParam.Zip;
    // this.downloadSearchParam.Address = this.propertySearchParam.Address;
    // this.downloadSearchParam.ShortFilter = this.propertySearchParam.ShortFilter;

    let propertyDownload = this.PropertManagement.getPropertyDownloadSearchList(
      this.downloadSearchParam
    ).subscribe((x) => {
      if (this.downloadToExcel.length === 0) {
        this.jsonToExcel.importExcelToExport([], [], true);
        return;
      }
      if (this.downloadToExcel[0].hasOwnProperty("Status") === true) {
        this.jsonToExcel.importExcelToExport(
          this.downloadToExcel,
          this.systemPickValues,
          false
        );
      } else {
        this.downloadToExcel = x.propSearch;
        this.downloadToExcel.forEach((elem) => {
          // elem.IsActive = elem.IsActive === true ? "Yes" : "No";
          elem.IsPropertySubUnit = elem.IsPropertySubUnit === 0 ? "No" : "Yes";
          delete elem.PropertyID;
        });
        this.jsonToExcel.importExcelToExport(this.downloadToExcel, [], true);
      }
      // propertyDownload.unsubscribe();
    });
  }

  downloadCompanySheet() {
    if (this.storage.getData("PropertyDetail") === null) {
      Swal.fire("Please Select list to export as Pdf detail");
    }
    this.jsonToExcel.exportToPdf(
      JSON.parse(this.storage.getData("PropertyDetail"))
    );
  }
  makeSubunitBtnVisible(data) {
    this.isSubUnitVisible = data;
    if (this.isSubUnitVisible == true) {
      this.isAddPropertyBtnShow = false;
    } else {
      this.isAddPropertyBtnShow = true;
    }
  }

  clearValue() {
    this.storage.removeData("PropertyDetail");
  }
  checkSelected() {
    if (this.storage.getData("PropertyDetail") == null) {
      Swal.fire("Please Select Property From List");
      return;
    }
    let propertyDetail = JSON.parse(this.storage.getData("PropertyDetail"));

    propertyDetail["addPropertySubUnitFlag"] = true;
    this.storage.setData("PropertyDetail", JSON.stringify(propertyDetail));

    this.router.navigateByUrl(
      "/products/administration/propertymanagement/propertydetail/addproperty"
    );
  }

  /**
   *
   * for validation
   */
  validateHeaderExcelImport = [
    "Property Name",
    "Identification Number                                          (Note: Must be a four digit number)",
    "BusinessType",
    "Property Description",
    "Address1",
    "Address2",
    "Country Name",
    "State Name",
    "City Name",
    "Zip Code",
    "Phone (000-000-0000)",
    "Extension",
    "Business Email",
    "Website",
    "Time Zone",
    "Is DSTObserved ?",
    "Adjust Time",
    "Company Name",
    "Company Type",
    "Status",
    "Inserted Status",
  ];
  /***/
  flag = false;
  importToExcel() {
    this.systemPickValues = [];
    if (this.excel.nativeElement.files[0] === null) return;

    /** validate xlsx file */
    if (
      this.excel.nativeElement.files[0].type !==
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" &&
      this.excel.nativeElement.files[0].name.split(".").lastIndexOf("xlsx") < 0
    ) {
      Swal.fire("This not excel file");
      return;
    }
    let wb = new ExcelJS.Workbook();
    let reader: FileReader = new FileReader();
    let propertyImportArr = [];
    reader.readAsArrayBuffer(this.excel.nativeElement.files[0]);
    this.flag = false;
    try {
      reader.onload = () => {
        let buffer: any = reader.result;
        wb.xlsx.load(buffer).then((workbook) => {
          workbook.eachSheet((sheet, id) => {
            // sheet.eachRow((row, rowIndex) => {
            //   if (rowIndex > 3) {
            //     propertyImportArr.push(row.values);
            //   }
            // });
            // this.PropertyImportSend(propertyImportArr);
            if (sheet.name === "Upload Sheet") {
              sheet.eachRow((row, rowIndex) => {
                if (rowIndex === 3) {
                  let checkValidate = this.validation(row.values);

                  if (!checkValidate) {
                    this.flag = true;
                    return;
                  }
                }
                if (rowIndex > 3) {
                  propertyImportArr.push(row.values);
                }
              });
              if (this.flag) {
                this.tostre.error("Not Property Management excel file.", "", {
                  positionClass: "toast-top-right",
                });
                return;
              }
              this.PropertyImportSend(propertyImportArr);
            }
            if (sheet.name === "SystemPickValues") {
              sheet.eachRow((row, rowIndex) => {
                this.systemPickValues.push(row.values);
              });
            }
          });
        });
      };
    } catch (err) {
      Swal.fire("Pleas Import propertymfile");
    }
    reader.onerror = () => {
      Swal.fire("Error in Reading File ");
    };
    /** clearing tha value of element for override that data */
    this.excel.nativeElement.value = "";
  }

  validation(excelHeader): any {
    if (excelHeader[1] !== this.validateHeaderExcelImport[0]) {
      return false;
    }

    return true;
  }

  PropertyImportSend(arr) {
    let importedData = [];
    let userDetail = JSON.parse(this.storage.getData("UserData"))[0].UserID;
    let keys = [
      "PropertyName",
      "PropertyIdentificationNumber",
      "BusinessType",
      "PropertyDescription",
      "Address1",
      "Address2",
      "CountryName",
      "StateName",
      "CityName",
      "ZipCode",
      "PhoneNumber",
      "Extension",
      "BusinessEmail",
      "WebSite",
      "TimeZone",
      "DSTObserved",
      "AdjustTime",
      "CompanyName",
      "CompanyType",
      "PropertyStatus",
      "test",
      "Message",
      "Status",
    ];
    let demo: any = this.defaultImport(userDetail);

    try {
      arr.forEach((elem, i) => {
        demo["RecNo"] = i + 1;
        demo["UserID"] = userDetail;

        keys.forEach((e, index) => {
          if (index == 1) {
            if (
              elem[index + 1] === undefined ||
              elem[index + 1] === undefined
            ) {
              importedData = null;
              let err = new Error();
              err.name = elem[index + 1 - 2];
              err.message = i + 4;
              throw err;
            }
          }
          demo[e] = elem[index + 1] === undefined ? "" : elem[index + 1];
        });

        demo["BusinessEmail"] =
          typeof demo["BusinessEmail"] === "object"
            ? demo["BusinessEmail"].text
            : demo["BusinessEmail"];

        demo["WebSite"] =
          typeof demo["WebSite"] === "object"
            ? demo["WebSite"].text
            : demo["WebSite"];

        importedData.push(demo);

        demo = this.defaultImport(undefined);
      });
    } catch (err) {
      Swal.fire(
        "invalid Identification Number in " +
          err.name +
          " Row number: " +
          err.message
      );
    }
    if (importedData === null) {
      return;
    }

    this.PropertManagement.propertyImportPost({
      propImp: importedData,
    }).subscribe((resData) => {
      let verify: any = this.validateIncomming(resData.propImport[0]);

      let t = this.modifyStateOfList(resData.propImport[0]);

      this.downloadToExcel = t;
      this.dataShare.changeImportedData(t);
      if (!verify) {
        this.tostre.warning(
          "Property not Imported properly.verify you table.",
          "",
          {
            positionClass: "toast-top-right",
          }
        );
      } else {
        this.showValid(
          "Process successfully and please check the table to edit."
        );
      }
    });
  }

  validateIncomming(importedProperty) {
    let flag = true;

    importedProperty.forEach((elem) => {
      if (elem.Status.toLowerCase() === "not inserted") {
        flag = false;
      }
    });

    return flag;
  }

  modifyStateOfList(importProperty) {
    return importProperty.map((elem, index) => {
      return {
        PropertyName: elem.PropertyName,
        Address1: elem.Address1,
        Address2: elem.Address2,
        BusinessEmail: elem.BusinessEmail,
        BusinessType: elem.BusinessType,
        CompanyName: elem.CompanyName,
        CompanyType: elem.CompanyType,
        CountryName: elem.CountryName,
        DSTObserved: elem.DSTObserved,
        Extension: elem.Extension,
        TimeZone: elem.TimeZone,
        WebSite: elem.WebSite,
        PhoneNumber: elem.PhoneNumber,
        AdjustTime: elem.AdjustTime,
        AssignedCompany: 0,
        City: elem.CityName,
        EnvironmentName: null,
        GlobalEnvironmentID: null,
        IsActive: elem.PropertyStatus === "Active" ? true : false,
        IsArchive: null,
        IsPropertySubUnit: 0,
        PropertyDescription: elem.PropertyDescription,
        PropertyID: null,
        PropertyIdentNumber: elem.PropertyIdentificationNumber,
        StateName: elem.StateName,
        Subdivision: "",
        SubunitName: null,
        Zip: elem.ZipCode,
        Status: `${elem.Status} ${elem.Message}`,
      };
    });
  }
  /** default import object of property import */
  defaultImport(u) {
    return {
      PropertyName: "",
      PropertyIdentificationNumber: "",
      BusinessType: "",
      PropertyDescription: "",
      Address1: "",
      Address2: "",
      CountryName: "",
      StateName: "",
      CityName: "",
      ZipCode: "",
      PhoneNumber: "",
      Extension: "",
      BusinessEmail: "",
      WebSite: "",
      TimeZone: "",
      DSTObserved: "",
      AdjustTime: "",
      CompanyName: "",
      CompanyType: "",
      UserID: u === undefined ? "" : u,
      Status: "",
      test: "",
      Message: "",
      PropertyStatus: "",
    };
  }

  // toastr warning/success message
  showInvalid(msg) {
    this.tostre.warning(msg, "", {
      positionClass: "toast-top-right",
    });
  }

  showValid(validMsg) {
    this.tostre.success(validMsg, "", {
      positionClass: "toast-top-right",
    });
  }
}
