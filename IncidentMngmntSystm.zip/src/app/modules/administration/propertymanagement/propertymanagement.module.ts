import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { PropertymanagementRoutingModule } from './propertymanagement-routing.module';
import { PropertymanagementComponent } from './propertymanagement.component';
import { AddpropertyComponent } from './addproperty/addproperty.component';
import { MypropertyListComponent } from './myproperty-list/myproperty-list.component';
import { CommonModule } from '@angular/common';
import { AssignCompanytableComponent } from './assign-companytable/assign-companytable.component';
import { WorkgrouptableComponent } from './workgrouptable/workgrouptable.component';
import { KeycontacttableComponent } from './keycontacttable/keycontacttable.component';
import { AllpersontableComponent } from './allpersontable/allpersontable.component';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { PropertydetailComponent } from './propertydetail/propertydetail.component';
import { LocationmanagementComponent } from './locationmanagement/locationmanagement.component';
import { PatrolzonemanagementComponent } from './patrolzonemanagement/patrolzonemanagement.component';
import { ModeladdbusinesstypeComponent } from './addproperty/modeladdbusinesstype/modeladdbusinesstype.component';
import { JsToPdfService } from "./myproperty-list/jsToPdf.service";
import { ModelcomsubdivisonComponent } from './myproperty-list/modelcomsubdivison/modelcomsubdivison.component';
import { ModelpropsubunitComponent } from './myproperty-list/modelpropsubunit/modelpropsubunit.component'
import { ModelcompanytypeComponent } from './addproperty/modelcompanytype/modelcompanytype.component';
import { PropertyprofileComponent } from './propertyprofile/propertyprofile.component';
import { BanningdurationComponent } from './banningduration/banningduration.component';
import { AssetsComponent } from './assets/assets.component';
import { ActivitiesComponent } from './activities/activities.component';
import { AddactivityComponent } from './activities/addactivity/addactivity.component';
import { ShiftComponent } from './shift/shift.component';
import { AddshiftComponent } from './addshift/addshift.component';
import { SharedMaterialModule } from '../../../shared/shared-material.module';
@NgModule({
  declarations: [
    PropertymanagementComponent,
    AddpropertyComponent,
    MypropertyListComponent,
    AssignCompanytableComponent,
    WorkgrouptableComponent,
    KeycontacttableComponent,
    AllpersontableComponent,
    PropertydetailComponent,
    LocationmanagementComponent,
    PatrolzonemanagementComponent,
    ModeladdbusinesstypeComponent,
    ModelcomsubdivisonComponent,
    ModelpropsubunitComponent,
    ModelcompanytypeComponent,
    PropertyprofileComponent,
    BanningdurationComponent,
    AssetsComponent,
    ActivitiesComponent,
    AddactivityComponent,
    ShiftComponent,
    AddshiftComponent
  ],
  imports: [
    CommonModule,
    PropertymanagementRoutingModule,
    DragDropModule,
    FormsModule,
    ReactiveFormsModule,
    SharedMaterialModule,
    // ModeladdbusinesstypeComponent
    
  ],
  entryComponents: [
    ModeladdbusinesstypeComponent,
    ModelcomsubdivisonComponent,
    ModelpropsubunitComponent,
    ModelcompanytypeComponent
  ],
  providers: [JsToPdfService]
})
export class PropertymanagementModule { }
