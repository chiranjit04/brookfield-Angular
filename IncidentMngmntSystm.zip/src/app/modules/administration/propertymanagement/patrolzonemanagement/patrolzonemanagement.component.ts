import { Component, OnInit, ViewChild } from "@angular/core";
import { Router } from "@angular/router";
import { PatrolService } from "./patrol.service";
import { FormGroup, FormControl, Validators } from "@angular/forms";
import { from } from "rxjs";
import Swal from "sweetalert2";
import { ToastrService } from "ngx-toastr";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
import * as XLSX from "xlsx";
import * as FileSaver from "file-saver";
import { ConstantPool } from "@angular/compiler";
import { UserPermissionService } from "../../../../services/user-permission.service";
import { StorageService } from "../../../../services/storage.service";
import { ServiceService } from "./../../service/service.service";
@Component({
  selector: "app-patrolzonemanagement",
  templateUrl: "./patrolzonemanagement.component.html",
  styleUrls: ["./patrolzonemanagement.component.scss"],
})
export class PatrolzonemanagementComponent implements OnInit {
  PropertyDetail = null;
  PropertyID = 0;
  PropertyName = "";
  PropertyNumber = "";
  PropertyDescription = "";
  idsSelected;
  authToken = null;
  userData = null;
  currentUserID = false;
  panelOpenState = false;
  selectedItem: any = false;

  patrolzonelist: any = [];

  showLoader: boolean;

  patrolZoneImportList: any = [];
  // searchField: boolean = false;

  isShown = false;

  editZoneSubmitted = false;
  addcate2 = false;

  zoneEditable = false;

  ZoneName_: any;
  ZoneDecs_: any;

  uploadfileList: boolean = false;
  patrolImportData: any = [];
  listdata = true;

  exportImportData(): void {
    let data = JSON.parse(JSON.stringify(this.patrolImportData));
    let tempData = [];
    data.forEach(function (item, i) {
      delete item["RecNo"];
      delete item["Status"];
      delete item["Message"];
      tempData.push(item);
    });

    this.PatrolService.exportimportAsExcelFile(tempData);
  }

  exportPatrolList(): void {
    let data = JSON.parse(JSON.stringify(this.patrolzonelist));

    let tempData = [];

    data.forEach(function (item, i) {
      delete item["PropertyID"];
      delete item["MapZonesID"];
      delete item["MapID"];
      delete item["ZoneCoOrdinates"];
      delete item["AssignedBy"];
      delete item["AssignedDate"];
      delete item["IsAllowDelete"];
      if (item["IsActive"] == 1) {
        item["IsActive"] = "Active";
      } else {
        item["IsActive"] = "Inactive";
      }
      tempData.push(item);
    });

    this.PatrolService.exportAsExcelFile(tempData);
  }
  organise(arr) {
    var headers = [], // an Array to let us lookup indicies by group
      objs = [], // the Object we want to create
      i,
      j;
    for (i = 0; i < arr.length; ++i) {
      j = headers.indexOf(arr[i].id); // lookup
      if (j === -1) {
        // this entry does not exist yet, init
        j = headers.length;
        headers[j] = arr[i].id;
        objs[j] = {};
        objs[j].id = arr[i].id;
        objs[j].data = [];
      }
      objs[j].data.push(
        // create clone
        {
          case_worked: arr[i].case_worked,
          note: arr[i].note,
          id: arr[i].id,
        }
      );
    }
    return objs;
  }

  /** Upload Excel start  */

  title = "read-excel-in-angular8";
  storeData: any;
  jsonData: any;
  fileUploaded: File;
  worksheet: any;
  htmlData: any;

  uploadedFile(event) {
    this.fileUploaded = event.target.files[0];
    this.readExcel();
  }
  readExcel() {
    let readFile = new FileReader();

    readFile.onload = (e) => {
      this.storeData = readFile.result;

      // console.log("this.storeData", this.storeData);

      var data = new Uint8Array(this.storeData);

      // console.log("data", data);
      var arr = new Array();

      for (var i = 0; i != data.length; ++i)
        arr[i] = String.fromCharCode(data[i]);

      var bstr = arr.join("");

      var workbook = XLSX.read(bstr, { type: "binary" });

      var first_sheet_name = workbook.SheetNames[1];

      this.worksheet = workbook.Sheets[first_sheet_name];

      var range = XLSX.utils.decode_range(this.worksheet["!ref"]);
      range.s.r = 2; // <-- zero-indexed, so setting to 1 will skip row 0
      this.worksheet["!ref"] = XLSX.utils.encode_range(range);

      // console.log("worksheet======>>>", this.worksheet);

      this.readAsJson();
    };

    readFile.readAsArrayBuffer(this.fileUploaded);
  }

  // Upload Excel End

  /** Read As Json */

  readAsJson() {
    this.jsonData = XLSX.utils.sheet_to_json(this.worksheet, { raw: false });

    // console.log("sheettojson", this.jsonData);

    //this.jsonData = JSON.stringify(this.jsonData);

    var arrofobj = (this.patrolZoneImportList = this.jsonData);

    var result = arrofobj.map(function (el) {
      var o = Object.assign({}, el);
      o.Status = "";
      o.Message = "";
      o.RecNo = "";
      return o;
    });
    let length = Object.keys(result).length;
    // console.log("length", length);

    this.patrolZoneImport(result);
    //this.getPropertyPatrolZoneList(this.PropertyID, 0);
  }

  /* Upload file */
  openFileBrowser(event: any) {
    event.preventDefault();
    let element: HTMLElement = document.getElementById("file") as HTMLElement;
    element.click();
  }

  checkProperty() {
    if (this.PropertyID) {
      return true;
    } else {
      this.tostre.error("Please first select a Company.", "", {
        positionClass: "toast-top-right",
      });
      // }).then((result) => {
      this.router.navigate([
        "products/administration/propertymanagement/propertydetail",
      ]);
      //});
      return false;
    }
  }

  /****************************************************************
   * variables accroding to changes me
   */
  _propertyDetail_: any = "";
  _UserData_: any = "";
  _propertyID_: any = "";
  _propertyno_: any = "";
  _selectedProperty_: any = "";
  _SubunitName_: any = "";
  _SubPropertyUnit_: any;
  /**************************************************************** */

  constructor(
    public router: Router,
    private PatrolService: PatrolService,
    private tostre: ToastrService,
    public UserPermission: UserPermissionService,
    private storage: StorageService,
    private adminService: ServiceService
  ) {
    this.PropertyDetail = JSON.parse(this.storage.getData("PropertyDetail"));
    // console.log(this.PropertyDetail);

    /********************************
     * changes for more admix fixes, not changing old functionality adding new to every small changs avoid to new isseues.
     */
    this._propertyDetail_ = JSON.parse(this.storage.getData("PropertyDetail"));
    this._UserData_ = JSON.parse(this.storage.getData("UserData"));

    if (this._propertyDetail_) {
      this._propertyID_ = this._propertyDetail_.PropertyID;
      this._propertyno_ = this._propertyDetail_.PropertyIdentNumber;
      this._selectedProperty_ = this._propertyDetail_.PropertyName;
      this._SubunitName_ = this._propertyDetail_.SubunitName;
    }

    const params = {
      PropertyId: this._propertyID_,
    };

    if (this._propertyDetail_.Subdivision === "Property Subunit") {
      this._SubPropertyUnit_ =
        this._propertyDetail_.ParentPropertyName +
        " - " +
        this._propertyDetail_.ParentIdentNumber;
    }
    // this.PatrolService.GetCustomFormDetailsByPropertyId(params).subscribe(
    //   (res) => {
    //     if (res.data.getCustomFormDetailsByPropertyId.length != "") {
    //       this._SubPropertyUnit_ =
    //         res.data.getCustomFormDetailsByPropertyId[0].SubPropertyUnit;
    //     }
    //   }
    // );
    /******************************** end */
    if (this.PropertyDetail) {
      this.PropertyID = this.PropertyDetail.PropertyID;
      this.PropertyName = this.PropertyDetail.PropertyName;
      this.PropertyNumber = this.PropertyDetail.PropertyIdentNumber;
      this.PropertyDescription = this.PropertyDetail.PropertyDescription;

      this.storage.setData("PropertyID", this.PropertyDetail.PropertyID);
    }
    //... Read User Data ...
    this.authToken = this.storage.getData("token");
    this.userData = JSON.parse(this.storage.getData("UserData"));
    this.currentUserID = this.userData[0].UserID;
    this.dataSource = new MatTableDataSource();
    this.dataSourceOne = new MatTableDataSource();
  }

  displayedColumns: string[] = [
    "ZoneName",
    "Description",
    "AssignedDate",
    "AssignedBy",
    "IsActive",
  ];
  dataSource = new MatTableDataSource(this.patrolzonelist);

  displayedColumnsOne: string[] = [
    "propertyname",
    "patrolzonename",
    "patrolzonedescription",
    "patrolzonestatus",
    "status",
    "message",
  ];
  dataSourceOne = this.patrolImportData;

  // displayedColumnsOne: string[] = ['PropertyName', 'PatrolZoneName', 'PatrolZoneDescription', 'PatrolZoneStatus', 'Status', 'Message'];
  // dataSourceOne = new MatTableDataSource(this.patrolImportData);

  @ViewChild(MatSort, null) sort: MatSort;
  ngOnInit() {
    if (this.checkProperty()) {
      this.getPropertyPatrolZoneList(this.PropertyID, 0);
      this.dataSource.sort = this.sort;
      this.sort.disableClear = true;
    }
  }

  toggleShow() {
    this.isShown = !this.isShown;
    this.dataSource.filter = "";
    this.patrolSearch.reset();
    this.getPropertyPatrolZoneList(this.PropertyID, 0);
  }

  /**
   *
   * Add Patrol Zone Form
   *
   */

  AddPatrolZone = new FormGroup({
    ZoneName: new FormControl("", [Validators.required]),
    ZoneDesc: new FormControl(""),
  });
  addZoneForm = false;
  get addZone() {
    return this.AddPatrolZone.controls;
  }

  patrolSearch = new FormControl();

  /**
   *
   * Edit Patrol Zone Form
   *
   */

  editPatrolZoneForm = new FormGroup({
    ZoneName: new FormControl("", [Validators.required]),
    Description: new FormControl(""),
    IsActive: new FormControl(""),
  });

  get editZoneForm() {
    return this.editPatrolZoneForm.controls;
  }

  /**
   * Import Patrol Zone List
   *
   */

  newObjArr = [];
  patrolZoneImport(obj) {
    // console.log("obj in the house", obj[0]);
    let matchPatrolZone =
      Object.keys(obj[0]).includes("Patrol Zone Name") &&
      Object.keys(obj[0]).includes("Patrol Zone Status");

    if (matchPatrolZone) {
      this.uploadfileList = true;
      this.listdata = false;
      //this.isShown = false;

      if (obj.length == 0) {
        Swal.fire({
          text: "No Data Found ",
        });
        return;
      }

      for (var i = 0; i < obj.length; i++) {
        let newObj = {
          RecNo: obj[i]["RecNo"],
          PropertyName: obj[i]["Property Name"],
          PatrolZoneName: obj[i]["Patrol Zone Name"],
          PatrolZoneDescription: obj[i]["Description"],
          PatrolZoneStatus: obj[i]["Patrol Zone Status"],
          Status: "",
          Message: "",
        };
        this.newObjArr.push(newObj);
      }
      let passingArray = this.newObjArr;
      // console.log("passingArray", passingArray);
      this.PatrolService.patrolZoneImport(passingArray).subscribe(
        (res) => {
          if (res.statusCode == 200) {
            this.patrolImportData = res.PatrolImport.recordsets[0];
            this.dataSourceOne = new MatTableDataSource(this.patrolImportData);
            this.showValid("Processed successfully. Please check the table.");
          }
        },
        (error) => {
          if (error.status == 500) {
            Swal.fire({
              text: "Import Failed",
            });
          }
        }
      );
    } else {
      this.showInvalid(
        "Uploaded Excel Sheet is Invalid. Please put the right one."
      );
    }
  }

  /**
   *
   * Add Patrol Zone
   */

  addPatrolZone() {
    let postData = this.AddPatrolZone.value;
    this.addZoneForm = true;
    if (this.AddPatrolZone.invalid) {
      return;
    }

    if (postData.ZoneName.trim() == "") {
      Swal.fire({
        text: " Zone Name is required",
      });
      return false;
    }
    const obj = {
      ZoneID: "0",
      "MapID ": "0",
      PropertyID: this.PropertyID,
      ZoneCoOrdinates: "0",
      ZoneName: postData.ZoneName.trim(),
      Description: postData.ZoneDesc,
      UserID: this.currentUserID,
      IsActive: 1,
    };
    // if (postData.ZoneDesc.trim() == "") {
    //   Swal.fire({
    //     text: " Zone Description is required"
    //   })
    //   return false
    // }
    // console.log("obj=============>>>>>", obj);

    if (
      !this.patrolzonelist.find(
        (elem) => obj.ZoneName.trim() == elem.ZoneName.trim()
      )
    ) {
      //console.log("nik=====================>>>>>")

      this.addEditPatrolZone(obj);
    } else {
      // console.log("nik111111=====================>>>>>")
      Swal.fire({
        title: ` ${obj.ZoneName} Zone name already exists`,
      });
    }

    // console.log(obj);
    this.addEditPatrolZone(obj);
    this.addcate2 = !this.addcate2;
  }

  /**
   * Edit Patrol Zone Form
   *
   */
  statusShowSub = false;
  editPatrolZone(data: any) {
    // this.zoneEditable = !this.zoneEditable;
    this.addcate2 = false;
    this.addZoneForm = false;

    this.editPatrolZoneForm.patchValue({
      ZoneName: data.ZoneName,
      Description: data.Description,
      IsActive: data.IsActive,
    });
    // this.ZoneName_ = data.ZoneName
    // this.ZoneDecs_ = data.Description
    // console.log(this.ZoneDecs_)
    // console.log("editPatrolZone", data);
    this.zoneEditable = data.MapZonesID;
    this.statusShowSub = data.IsActive;

    let shadesEl = document.querySelectorAll(".show");
    for (let i = 0; i < shadesEl.length; i++) {
      shadesEl[i].classList.remove("show");
    }
  }

  changePatrolShowStatus(id: any) {
    let element: HTMLElement = document.getElementById(
      "status-patrol-" + id
    ) as HTMLElement;
    element.click();

    // console.log("id", id);
    this.statusShowSub = !this.statusShowSub;
    this.tostre.success(this.adminService.statusMsg);
  }

  /**
   * Close Edit Patrol Zone Form
   *
   */

  closeEditZoneForm() {
    this.addcate2 = !this.addcate2;
    this.zoneEditable = false;
    this.AddPatrolZone.reset();
    this.addZoneForm = false;
    let shadesEl = document.querySelectorAll(".show");
    for (let i = 0; i < shadesEl.length; i++) {
      shadesEl[i].classList.remove("show");
    }
  }

  /**
   * Update Patrol Zone
   * @param data
   * @param value
   */

  updatePatrolZone(data: any, value) {
    this.zoneEditable = data.MapZonesID;

    this.editZoneSubmitted = true;
    if (this.editPatrolZoneForm.invalid) {
      return;
    }

    if (value.ZoneName.trim() == "") {
      Swal.fire({
        text: " Zone Name is required",
      });
      return false;
    }

    // if (value.Description.trim() == "") {
    //   Swal.fire({
    //     text: " Zone Description is required"
    //   })
    //   return false
    // }

    const obj = {
      ZoneID: +data.MapZonesID,
      MapID: 0,
      PropertyID: +this.PropertyID,
      ZoneCoOrdinates: "",
      ZoneName: value.ZoneName.trim(),
      Description: value.Description,
      UserID: +this.currentUserID,
      IsActive: value.IsActive ? 1 : 0,
    };

    //console.log("obj====>>>edit patorl zone ", obj)

    this.addEditPatrolZone(obj);
  }

  /**
   * Add Edit Patrol Zone
   * @param obj
   *
   */

  addEditPatrolZone(obj) {
    this.PatrolService.updateZone(obj).subscribe((res) => {
      this.zoneEditable = false;
      this.getPropertyPatrolZoneList(this.PropertyID, 0);
    });
  }

  /**
   * Get Property Patrol Zone List
   *
   */

  getPropertyPatrolZoneList(PropertyID, Flag) {
    const obj = {
      PropertyID: PropertyID,
      Flag: Flag,
    };
    // console.log("obj==>>", obj);

    let result: any;
    this.showLoader = true;
    this.PatrolService.getPropertyPatrolZoneList(obj).subscribe(
      (res) => {
        result = res;
        this.patrolzonelist = result.GetPropertyPatrolZoneList;

        // console.log("getPropertyPatrolZoneList===>>>>", this.patrolzonelist);
        // this.patrolzonelist = [];
        this.dataSource.data = this.patrolzonelist;
        this.showLoader = false;
        this.dataSource.sort = this.sort;
        this.sort.disableClear = true;
        this.checkSingleList(this.patrolzonelist);
      },
      (err) => {
        this.showLoader = false;
      }
    );
  }

  /**
   * Reset Add Zone Form
   *
   */
  resetAddZoneForm() {
    this.addcate2 = !this.addcate2;
    this.AddPatrolZone.reset();
    this.addZoneForm = false;
  }

  /**
   * Reset Edit Zone Form
   *
   */

  resetEditZoneForm(param: any) {
    // this.addcate2 = !this.addcate2

    this.zoneEditable = false;
    this.editPatrolZoneForm.reset();
    this.editZoneSubmitted = false;
  }

  /**
   * Change Zone Status
   * @param param
   *
   */

  changeStatusMapZones(param) {
    const obj = {
      ZoneID: +param,
    };

    this.PatrolService.changeStatusMapZones(obj).subscribe((res) => {
      let obj1 = this.patrolzonelist.find((o) => o.MapZonesID == obj.ZoneID);
      // console.log(obj1);
      let index = this.patrolzonelist.indexOf(obj1);
      this.patrolzonelist.fill(
        (obj1.IsActive = !obj1.IsActive),
        index,
        index++
      );
      this.tostre.success(this.adminService.statusMsg);
    });
  }
  deleteZone(param) {
    // this.groupEditable = false
    let shadesEl = document.querySelectorAll(".show");
    for (let i = 0; i < shadesEl.length; i++) {
      shadesEl[i].classList.remove("show");
    }

    Swal.fire({
      //title: 'Are you sure you want to delete ?',
      // text: "Are you sure you want to remove this?",
      text: this.adminService.deleteMsg,
      showCancelButton: true,
      confirmButtonText: "Yes",
      cancelButtonText: "No",
    }).then((result) => {
      if (result.value) {
        const obj = {
          headers: new HttpHeaders({
            "Content-Type": "application/json",
          }),
          body: {
            ZoneID: +param,
          },
        };

        this.PatrolService.deletePatrolZone(obj).subscribe((res) => {
          // console.log(res);
          this.getPropertyPatrolZoneList(this.PropertyID, 0);
        });
      }
    });
  }
  /**
   * Filter table
   * @param event
   *
   */
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  gotopatrollist() {
    window.location.reload();
    //this.router.navigate(['products/administration/propertymanagement']);
  }

  disableSpecialChar(event) {
    let k;
    k = event.charCode;
    return (
      (k > 64 && k < 91) ||
      (k > 96 && k < 123) ||
      k == 8 ||
      k == 32 ||
      (k >= 48 && k <= 57)
    );
  }

  clearSearchField() {
    this.patrolSearch.setValue("");
    this.dataSource.filter = "";
  }

  onSelectItem(data: any) {
    if (this.selectedItem == data.MapZonesID) {
      this.selectedItem = !this.selectedItem;
    } else {
      this.selectedItem = data.MapZonesID;
    }
  }

  // toastr warning/success message
  showInvalid(msg) {
    this.tostre.warning(msg, "", {
      positionClass: "toast-top-right",
    });
  }

  showValid(validMsg) {
    this.tostre.success(validMsg, "", {
      positionClass: "toast-top-right",
    });
  }

  private checkSingleList(patZone) {
    if (Array.isArray(patZone)) {
      // debugger;
      // patZone = [patZone[0]];
      // debugger;
      if (patZone.length === 1) {
        this.idsSelected = patZone[0].MapZonesID;
      }
    }
  }
}
