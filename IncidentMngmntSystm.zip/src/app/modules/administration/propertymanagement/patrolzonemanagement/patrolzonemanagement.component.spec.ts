import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PatrolzonemanagementComponent } from './patrolzonemanagement.component';

describe('PatrolzonemanagementComponent', () => {
  let component: PatrolzonemanagementComponent;
  let fixture: ComponentFixture<PatrolzonemanagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PatrolzonemanagementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PatrolzonemanagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
