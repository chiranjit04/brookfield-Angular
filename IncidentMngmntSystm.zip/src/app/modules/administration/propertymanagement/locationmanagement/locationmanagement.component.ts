import { Component, OnInit, ViewChild } from "@angular/core";
import {
  FormGroup,
  FormControl,
  FormBuilder,
  Validators,
} from "@angular/forms";
import Swal from "sweetalert2";
import { Router } from "@angular/router";
import { LocationService } from "./location.service";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";

import * as XLSX from "xlsx";
import * as FileSaver from "file-saver";
import { ToastrService } from "ngx-toastr";
import { UserPermissionService } from "../../../../services/user-permission.service";
import { StorageService } from "../../../../services/storage.service";
import { ServiceService } from "./../../service/service.service";

@Component({
  selector: "app-locationmanagement",
  templateUrl: "./locationmanagement.component.html",
  styleUrls: ["./locationmanagement.component.scss"],
})
export class LocationmanagementComponent implements OnInit {
  addcate = false;
  registerForm: FormGroup;
  addcate2 = false;
  addcate3 = false;
  addcate4 = false;
  addcate5 = false;
  hideTableMain = true;
  showUploadTable = false;

  PropertyDetail = null;
  PropertyID = 0;
  PropertyName = "";
  PropertyNumber = "";
  PropertyDescription = "";
  PropertyGoeID = 0;

  authToken = null;
  userData = null;
  currentUserID = false;

  categoryList = [];
  currentCategory = false;
  categoryEditable = false;

  subCategoryList: any = [];
  selectedSubcategoryID = false;
  subCategoryEditable = false;

  locationList = [];
  locationEmptyList = [];
  selectedLocationID = false;
  locationEditable = false;

  spaceList = [];
  selectedSpaceID = false;
  spaceEditable = false;

  usesAreaList = [];
  selectedSectorID = false;
  usesAreaEditable = false;
  selectedItem: any = false;
  locationDisplay = false;
  LocationList = [];
  UploadedLocationList = [];
  LocationImportList: any = [];
  finalUploadedList: any = [];
  dataSourceOne: MatTableDataSource<any>;
  dataSourceTwo: MatTableDataSource<any>;
  @ViewChild("TableOneSort", { static: false }) tableOneSort: MatSort;
 // @ViewChild(MatSort, { static: true }) sort: MatSort;
  displayedColumnsOne: string[] = [
    "CategoryName",
    "SubCategoryName",
    "LocationName",
    "SpaceName",
    "UsesArea",
    "CreatedDate",
    "Status",
  ];

  displayedColumnsTwo: string[] = [
    "CategoryName",
    "SubCategoryName",
    "LocationName",
    "LocationDescription",
    "LocationStatus",
    "Status",
    "Message",
  ];
  // @ViewChild(MatSort, {static: true}) sort: MatSort;
  // dataSource = new MatTableDataSource();

  // exportPatrolList(): void {

  //   this.locationService.exportAsExcelFile(this.locationList, 'download-patrol-excel');
  // }
  /****************************************************************
   * variables accroding to changes me
   */
  _propertyDetail_: any = "";
  _UserData_: any = "";
  _propertyID_: any = "";
  _propertyno_: any = "";
  _selectedProperty_: any = "";
  _SubunitName_: any = "";
  _SubPropertyUnit_: any;
  /**************************************************************** */
  constructor(
    private formBuilder: FormBuilder,
    public router: Router,
    private locationService: LocationService,
    private alertMsg: ToastrService,
    public UserPermission: UserPermissionService,
    private storage: StorageService,
    private adminService: ServiceService
  ) {
    //... Read User Data ...
    this.authToken = this.storage.getData("token");
    if (this.authToken == null) {
      this.router.navigate(["/login"]);
    }
    this.userData = JSON.parse(this.storage.getData("UserData"));
    this.currentUserID = this.userData[0].UserID;

    this.PropertyDetail = JSON.parse(this.storage.getData("PropertyDetail"));
    /********************************
     * changes for more admix fixes, not changing old functionality adding new to every small changs avoid to new isseues.
     */
    this._propertyDetail_ = JSON.parse(this.storage.getData("PropertyDetail"));
    this._UserData_ = JSON.parse(this.storage.getData("UserData"));

    if (this._propertyDetail_) {
      this._propertyID_ = this._propertyDetail_.PropertyID;
      this._propertyno_ = this._propertyDetail_.PropertyIdentNumber;
      this._selectedProperty_ = this._propertyDetail_.PropertyName;
      this._SubunitName_ = this._propertyDetail_.SubunitName;
    }

    const params = {
      PropertyId: this._propertyID_,
    };

    // this.locationService
    //   .GetCustomFormDetailsByPropertyId(params)
    //   .subscribe((res) => {
    //     if (res.data.getCustomFormDetailsByPropertyId.length != "") {
    //       this._SubPropertyUnit_ =
    //         res.data.getCustomFormDetailsByPropertyId[0].SubPropertyUnit;
    //     }
    //   });
    if (this.PropertyDetail.Subdivision === "Property Subunit") {
      this._SubPropertyUnit_ =
        this.PropertyDetail.ParentPropertyName +
        " - " +
        this.PropertyDetail.ParentIdentNumber;
    }

    /******************************** end */

    if (this.PropertyDetail) {
      this.PropertyID = this.PropertyDetail.PropertyID;
      this.PropertyName = this.PropertyDetail.PropertyName;
      this.PropertyNumber = this.PropertyDetail.PropertyIdentNumber;
      this.PropertyDescription = this.PropertyDetail.PropertyDescription;
      this.PropertyGoeID = this.PropertyDetail.GlobalEnvironmentID;
      //this.storage.removeData("PropertyDetail");
      this.storage.setData("PropertyID", this.PropertyDetail.PropertyID);
    }

    this.dataSourceOne = new MatTableDataSource();
    this.dataSourceTwo = new MatTableDataSource();
  }

  categoryForm = new FormGroup({
    LocationID: new FormControl(""),
    PropertyID: new FormControl(this.PropertyID),
    LocationName: new FormControl("", [Validators.required]),
    Description: new FormControl(""),
    UserID: new FormControl(this.currentUserID),
  });
  categoryFormSubmitted = false;
  get categoryF() {
    return this.categoryForm.controls;
  }

  subCategoryForm = new FormGroup({
    LocationID: new FormControl(""),
    PropertyID: new FormControl(this.PropertyID),
    ParentID: new FormControl(this.currentCategory),
    LocationName: new FormControl("", [Validators.required]),
    Description: new FormControl(""),
    UserID: new FormControl(this.currentUserID),
  });
  submitted2 = false;
  get subCategoryF() {
    return this.subCategoryForm.controls;
  }

  LocationForm = new FormGroup({
    LocationID: new FormControl(""),
    PropertyID: new FormControl(this.PropertyID),
    ParentID: new FormControl(this.currentCategory),
    LocationName: new FormControl("", [Validators.required]),
    Description: new FormControl(""),
    UserID: new FormControl(this.currentUserID),
  });
  submitted3 = false;
  get LocationF() {
    return this.LocationForm.controls;
  }

  SpaceForm = new FormGroup({
    PropertySpaceID: new FormControl(""),
    PropertyID: new FormControl(this.PropertyID),
    LocationID: new FormControl(""),
    SpaceName: new FormControl("", [Validators.required]),
    SpaceDescription: new FormControl(""),
  });
  submitted4 = false;
  get SpaceF() {
    return this.SpaceForm.controls;
  }

  checkProperty() {
    if (this.PropertyID) {
      return true;
    } else {
      this.alertMsg.error("Please first select a Company.", "", {
        positionClass: "toast-top-right",
      });
      // }).then((result) => {
      this.router.navigate([
        "products/administration/propertymanagement/propertydetail",
      ]);
      //});
      return false;
    }
  }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      searchform: [""],
    });

    if (this.checkProperty()) {
      this.GetLocationCategoryList();
      this.GetLocationListByPropertyID(this.PropertyID);
      this.GetPropertySpaceList(this.PropertyID);
      this.getUsesAreaList();
      this.GetLocationList();
    }
  }

  GetLocationList() {
    let data = {
      PropertyID: this.PropertyID,
    };
    this.locationService.GetLocationList(data).subscribe((resp) => {
      this.LocationList = resp.LocationList;
      this.dataSourceOne.data = resp.LocationList;
      this.dataSourceOne.sort = this.tableOneSort;
      this.tableOneSort.disableClear = true;
      // this.dataSource = new MatTableDataSource(resp.LocationList);
      // this.dataSource.sort = this.sort;
    });
  }
  toggleDisplay() {
    this.dataSourceOne.filter = "";
    this.registerForm.patchValue({
      searchform: "",
    });
    this.locationDisplay = !this.locationDisplay;
    this.GetLocationList();
  }

  alltabledataloading() {
    this.registerForm.patchValue({
      searchform: "",
    });
    this.dataSourceOne.filter = "";
    this.GetLocationList();
  }

  /* Category Area */
  GetLocationCategoryList() {
    let PropertyID = this.PropertyID;
    let data = { PropertyID: PropertyID };
    let result: any;
    this.locationService.GetLocationCategoryList(data).subscribe((resp) => {
      result = resp;
      this.categoryList = result.LocationCategoryList;
    });
  }
  selectCategory(data: any) {
    this.addcate = false;
    this.addcate2 = false;
    this.addcate3 = false;
    this.selectedSubcategoryID = false;
    this.selectedLocationID = false;
    if (this.currentCategory == data.LocationID) {
      this.currentCategory = false;
      this.GetLocationListByPropertyID(this.PropertyID);
    } else {
      this.currentCategory = data.LocationID;
      this.GetLocationListByCategoryID(this.currentCategory);
    }
    let categoryID = this.currentCategory ? this.currentCategory : 0;
    this.GetLocationSubCategoryList(this.currentCategory);
  }
  openCategoryForm() {
    /* this.addcate2 = false
    this.addcate3 = false
    this.categoryFormSubmitted = false
    this.categoryForm.reset()  */

    this.resetAll();
    this.addcate = !this.addcate;
    this.categoryForm.patchValue({ LocationID: 0 });
    this.categoryForm.patchValue({ PropertyID: +this.PropertyID });
    this.categoryForm.patchValue({ UserID: +this.currentUserID });
  }
  resetCategoryForm() {
    this.categoryForm.reset();
    this.addcate = false;
  }
  createCategory() {
    this.categoryFormSubmitted = true;
    if (this.categoryForm.invalid) {
      return;
    } else {
      let formData = this.categoryForm.value;
      formData.LocationName = formData.LocationName.trim();

      if (formData.Description)
        formData.Description = formData.Description.trim();

      if (formData.LocationName == "") {
        this.categoryForm.controls["LocationName"].setErrors({ invalid: true });
        return false;
      }

      let result: any;
      this.locationService
        .UpdateLocationCategory(formData)
        .subscribe((resp) => {
          result = resp.UpdateLocationCategory[0];
          if (result.ReturnKey == "CategoryName") {
            this.alertMsg.success(result.ReturnMessage);
          } else if (result.ReturnKey == "ID") {
            let obj = {
              LocationID: result.ReturnMessage,
              LocationName: formData.LocationName,
              LocationDescription: formData.Description,
              IsAllowDelete: 1,
              Status: 1,
            };
            this.categoryList.push(obj);
            this.addcate = !this.addcate;
          }
        });
    }
  }
  editCategory(event, data: any) {
    this.resetAll();
    this.categoryEditable = data.LocationID;
    this.categoryForm.patchValue({ LocationID: +data.LocationID });
    this.categoryForm.patchValue({ PropertyID: +this.PropertyID });
    this.categoryForm.patchValue({ UserID: +this.currentUserID });
    this.categoryForm.patchValue({ LocationName: data.LocationName });
    this.categoryForm.patchValue({ Description: data.LocationDescription });
  }
  updateCategory(data: any) {
    this.categoryFormSubmitted = true;
    if (this.categoryForm.invalid) {
      return;
    } else {
      let formData = this.categoryForm.value;
      formData.LocationName = formData.LocationName.trim();
      formData.Description = formData.Description;
      if (formData.LocationName == "") {
        this.categoryForm.controls["LocationName"].setErrors({ invalid: true });
        return false;
      }

      let result: any;
      this.locationService
        .UpdateLocationCategory(formData)
        .subscribe((resp) => {
          result = resp.UpdateLocationCategory[0];
          if (result.ReturnKey == "CategoryName") {
            this.alertMsg.success(result.ReturnMessage);
          } else if (result.ReturnKey == "ID") {
            let obj = this.categoryList.find(
              (o) => o.LocationID == formData.LocationID
            );
            let index = this.categoryList.indexOf(obj);
            this.categoryList.fill(
              (obj.LocationName = formData.LocationName),
              index,
              index++
            );
            this.categoryList.fill(
              (obj.LocationDescription = formData.Description),
              index,
              index++
            );

            let element: HTMLElement = document.getElementById(
              "closetab-" + formData.LocationID
            ) as HTMLElement;
            element.click();
            setTimeout(() => {
              this.categoryEditable = false;
            }, 300);
            this.categoryFormSubmitted = false;
          }
        });
    }
  }
  closeCategoryEditForm() {
    setTimeout(() => {
      this.categoryEditable = false;
    }, 300);
  }
  deleteCategory(event, data: any) {
    Swal.fire({
      //title: 'Are you sure you want to delete ?',
      // text: "Are you sure you want to delete this?",
      text: this.adminService.deleteMsg,
      showCancelButton: true,
      confirmButtonText: "Yes",
      cancelButtonText: "No",
    }).then((result) => {
      if (result.value) {
        this.locationService
          .DeleteLocation(data.LocationID)
          .subscribe((resp) => {
            if (data.LocationID == this.currentCategory) {
              this.currentCategory = false;
            }
            let obj1 = this.categoryList.find(
              (x) => x.LocationID == data.LocationID
            );
            let index = this.categoryList.indexOf(obj1);
            this.categoryList.splice(index, 1);
          });
        /* let obj1 = this.categoryList.find(x => x.LocationID == data.LocationID);
        let index = this.categoryList.indexOf(obj1);
        this.categoryList.splice(index, 1) */
      }
    });
  }

  /* Sub Category Area */
  GetLocationSubCategoryList(categoryID) {
    this.locationService
      .GetLocationSubCategory(categoryID)
      .subscribe((resp) => {
        this.subCategoryList = resp.LocationSubCategoryList;
      });
  }
  selectSubCategory(data: any) {
    this.addcate2 = false;
    this.addcate3 = false;
    this.selectedLocationID = false;

    if (this.selectedSubcategoryID == data.LocationID) {
      this.selectedSubcategoryID = false;
      this.GetLocationListByCategoryID(this.currentCategory);
    } else {
      this.selectedSubcategoryID = data.LocationID;
      this.GetLocationListByParentID(this.selectedSubcategoryID);
    }
  }
  openSubCategoryForm() {
    if (this.currentCategory) {
      /* this.categoryEditable = false
      let shadesEl = document.querySelectorAll('.show');
      for(let i=0;i<shadesEl.length;i++) {
        shadesEl[i].classList.remove('show');
      }
      this.addcate = false
      this.addcate3 = false
      this.addcate2 = !this.addcate2
      this.subCategoryForm.reset()
      this.submitted2 = false */
      this.resetAll();
      this.addcate2 = !this.addcate2;
      this.subCategoryForm.patchValue({ LocationID: 0 });
      this.subCategoryForm.patchValue({ PropertyID: +this.PropertyID });
      this.subCategoryForm.patchValue({ ParentID: +this.currentCategory });
      this.subCategoryForm.patchValue({ UserID: +this.currentUserID });
    } else {
      // Swal.fire({ text: "" });
      this.alertMsg.error("Please choose a category.");
    }
  }
  resetSubCategoryForm() {
    this.subCategoryForm.reset();
    this.addcate2 = false;
  }
  createSubCategory() {
    this.submitted2 = true;
    if (this.subCategoryForm.invalid) {
      return;
    } else {
      let formData = this.subCategoryForm.value;
      formData.LocationName = formData.LocationName.trim();
      if (formData.Description)
        formData.Description = formData.Description.trim();

      if (formData.LocationName == "") {
        this.subCategoryForm.controls["LocationName"].setErrors({
          invalid: true,
        });
        return false;
      }

      let result: any;
      this.locationService
        .UpdateLocationSubCategory(formData)
        .subscribe((resp) => {
          this.submitted2 = false;
          result = resp.UpdateLocationSubCategory[0];
          if (result.ReturnKey == "SubCategoryName") {
            this.alertMsg.success(result.ReturnMessage);
            // Swal.fire({ text:  });
          } else if (result.ReturnKey == "ID") {
            let obj = {
              LocationID: result.ReturnMessage,
              LocationName: formData.LocationName,
              LocationDescription: formData.Description,
              IsAllowDelete: 1,
              Status: 1,
            };
            this.subCategoryList.push(obj);
            this.addcate2 = !this.addcate2;
            //... disable delete button from category
            let obj1 = this.categoryList.find(
              (o) => o.LocationID == this.currentCategory
            );
            let index = this.categoryList.indexOf(obj1);
            this.categoryList.fill(
              (obj1.IsAllowDelete = false),
              index,
              index++
            );
          }
        });
    }
  }
  editSubCategory(event, data: any) {
    this.resetAll();
    this.subCategoryEditable = data.LocationID;
    this.subCategoryForm.patchValue({ LocationID: +data.LocationID });
    this.subCategoryForm.patchValue({ PropertyID: +this.PropertyID });
    this.subCategoryForm.patchValue({ ParentID: +data.ParentID });
    this.subCategoryForm.patchValue({ UserID: +this.currentUserID });
    this.subCategoryForm.patchValue({ LocationName: data.LocationName });
    this.subCategoryForm.patchValue({ Description: data.LocationDescription });
  }
  closeSubCategoryEditForm() {
    setTimeout(() => {
      this.subCategoryEditable = false;
    }, 300);
  }
  updateSubCategory(data: any) {
    this.submitted2 = true;
    if (this.subCategoryForm.invalid) {
      return;
    } else {
      let formData = this.subCategoryForm.value;
      formData.LocationName = formData.LocationName.trim();
      if (formData.Description)
        formData.Description = formData.Description.trim();

      if (formData.LocationName == "") {
        this.subCategoryForm.controls["LocationName"].setErrors({
          invalid: true,
        });
        return false;
      }

      let result: any;
      this.locationService
        .UpdateLocationSubCategory(formData)
        .subscribe((resp) => {
          this.submitted2 = false;
          result = resp.UpdateLocationSubCategory[0];
          if (result.ReturnKey == "SubCategoryName") {
            this.alertMsg.success(result.ReturnMessage);
            // Swal.fire({ text: result.ReturnMessage });
          } else if (result.ReturnKey == "ID") {
            let obj = this.subCategoryList.find(
              (o) => o.LocationID == formData.LocationID
            );
            let index = this.categoryList.indexOf(obj);
            this.subCategoryList.fill(
              (obj.LocationName = formData.LocationName),
              index,
              index++
            );
            this.subCategoryList.fill(
              (obj.LocationDescription = formData.Description),
              index,
              index++
            );
          }
          let element: HTMLElement = document.getElementById(
            "closetabsc-" + formData.LocationID
          ) as HTMLElement;
          element.click();
          setTimeout(() => {
            this.subCategoryEditable = false;
          }, 300);
        });
    }
  }
  deleteSubCategory(event, data: any) {
    Swal.fire({
      //title: 'Are you sure you want to delete ?',
      // text: "Are you sure you want to delete this ?",
      text: this.adminService.deleteMsg,
      showCancelButton: true,
      confirmButtonText: "Yes",
      cancelButtonText: "No",
    }).then((result) => {
      if (result.value) {
        this.locationService
          .DeleteLocation(data.LocationID)
          .subscribe((resp) => {
            if (data.LocationID == this.selectedSubcategoryID) {
              this.selectedSubcategoryID = false;
            }
            let obj1 = this.subCategoryList.find(
              (x) => x.LocationID == data.LocationID
            );
            let index = this.subCategoryList.indexOf(obj1);
            this.subCategoryList.splice(index, 1);
            //... check if sectorGroup has more sector in sectors list
            let obj2 = this.subCategoryList.find(
              (x) => x.ParentID == data.ParentID
            );
            let index1 = this.subCategoryList.indexOf(obj2);
            //... if not more sector in sectors list then make delete button visible in sector group list
            if (index1 == -1) {
              let obj3 = this.categoryList.find(
                (x) => x.LocationID == data.ParentID
              );
              let index2 = this.categoryList.indexOf(obj3);
              this.categoryList.fill(
                (obj3.IsAllowDelete = 1),
                index2,
                index2++
              );
            }
          });
      }
    });
  }

  /* Location Area */
  GetLocationListByPropertyID(PropertyID: any) {
    this.locationService
      .GetLocationListByPropertyID(PropertyID)
      .subscribe((resp) => {
        this.locationList = resp.LocationListBy;
      });
  }
  GetLocationListByCategoryID(ParentID: any) {
    this.locationService
      .GetLocationListByCategoryID(ParentID)
      .subscribe((resp) => {
        this.locationList = resp.GetLocationListByCategory;
      });
  }
  GetLocationListByParentID(ParentID: any) {
    this.locationService
      .GetLocationListByParentID(ParentID)
      .subscribe((resp) => {
        this.locationList = resp.LocationSubCategoryList;
      });
  }
  openLocationForm() {
    if (this.selectedSubcategoryID) {
      /* this.categoryEditable = false
      this.subCategoryEditable = false
      let shadesEl = document.querySelectorAll('.show');
      for(let i=0;i<shadesEl.length;i++) {
        shadesEl[i].classList.remove('show');
      }
      this.addcate = false
      this.addcate2 = false
      this.addcate3 = !this.addcate3
      this.LocationForm.reset()
      this.submitted3 = false */
      this.resetAll();
      this.addcate3 = !this.addcate3;
      this.LocationForm.patchValue({ LocationID: 0 });
      this.LocationForm.patchValue({ PropertyID: +this.PropertyID });
      this.LocationForm.patchValue({ ParentID: +this.selectedSubcategoryID });
      this.LocationForm.patchValue({ UserID: +this.currentUserID });
    } else {
      // Swal.fire({ text: "" });
      this.alertMsg.error("Please choose a sub category.");
    }
  }
  resetLocationForm() {
    this.LocationForm.reset();
    this.addcate3 = false;
  }
  createLocation() {
    this.submitted3 = true;
    if (this.LocationForm.invalid) {
      return;
    } else {
      let formData = this.LocationForm.value;
      formData.LocationName = formData.LocationName.trim();
      if (formData.Description)
        formData.Description = formData.Description.trim();

      if (formData.LocationName == "") {
        this.LocationForm.controls["LocationName"].setErrors({ invalid: true });
        return false;
      }

      let result: any;
      this.locationService.UpdateLocation(formData).subscribe((resp) => {
        this.submitted3 = false;
        result = resp.UpdateLocation[0];
        if (result.ReturnKey == "LocationName") {
          // Swal.fire({ text: result.ReturnMessage });
          this.alertMsg.warning(result.ReturnMessage);
        } else if (result.ReturnKey == "ID") {
          let obj = {
            LocationID: result.ReturnMessage,
            LocationName: formData.LocationName,
            LocationDescription: formData.Description,
            ParentID: this.selectedSubcategoryID,
            CategoryID: this.currentCategory,
            IsAllowDelete: 1,
            Status: true,
          };
          this.locationList.push(obj);
          this.addcate3 = false;
          //... disable delete button from sub category
          let obj1 = this.subCategoryList.find(
            (o) => o.LocationID == this.selectedSubcategoryID
          );
          let index = this.subCategoryList.indexOf(obj1);
          this.subCategoryList.fill(
            (obj1.IsAllowDelete = !obj1.IsAllowDelete),
            index,
            index++
          );
        }
      });
    }
  }
  selectLocation(data: any) {
    if (this.selectedLocationID == data.LocationID) {
      this.selectedLocationID = false;
    } else {
      this.selectedLocationID = data.LocationID;
    }
  }
  editLocation(event, data: any) {
    this.resetAll();
    this.locationEditable = data.LocationID;
    this.LocationForm.patchValue({ LocationID: +data.LocationID });
    this.LocationForm.patchValue({ PropertyID: +this.PropertyID });
    this.LocationForm.patchValue({ ParentID: +data.ParentID });
    this.LocationForm.patchValue({ LocationName: data.LocationName });
    this.LocationForm.patchValue({ Description: data.LocationDescription });
    this.LocationForm.patchValue({ UserID: +this.currentUserID });
  }
  closeLocationEditForm() {
    setTimeout(() => {
      this.locationEditable = false;
    }, 300);
  }
  updateLocation(data: any) {
    this.submitted3 = true;
    if (this.LocationForm.invalid) {
      return;
    } else {
      let formData = this.LocationForm.value;
      formData.LocationName = formData.LocationName.trim();
      if (formData.Description)
        formData.Description = formData.Description.trim();

      if (formData.LocationName == "") {
        this.LocationForm.controls["LocationName"].setErrors({ invalid: true });
        return false;
      }

      let result: any;
      this.locationService.UpdateLocation(formData).subscribe((resp) => {
        this.submitted3 = false;
        result = resp.UpdateLocation[0];
        if (result.ReturnKey == "LocationName") {
          // Swal.fire({ text: result.ReturnMessage });
          this.alertMsg.success(result.ReturnMessage);
        } else if (result.ReturnKey == "ID") {
          let obj = this.locationList.find(
            (o) => o.LocationID == formData.LocationID
          );
          let index = this.locationList.indexOf(obj);
          this.locationList.fill(
            (obj.LocationName = formData.LocationName),
            index,
            index++
          );
          this.locationList.fill(
            (obj.LocationDescription = formData.Description),
            index,
            index++
          );

          let element: HTMLElement = document.getElementById(
            "closetabl-" + formData.LocationID
          ) as HTMLElement;
          element.click();
          setTimeout(() => {
            this.locationEditable = false;
          }, 300);
        }
      });
    }
  }
  deleteLocation(event, data: any) {
    Swal.fire({
      //title: 'Are you sure you want to delete ?',
      // text: "Are you sure you want to delete this ?",
      text: this.adminService.deleteMsg,
      showCancelButton: true,
      confirmButtonText: "Yes",
      cancelButtonText: "No",
    }).then((result) => {
      if (result.value) {
        this.locationService
          .DeleteLocation(data.LocationID)
          .subscribe((resp) => {
            if (data.LocationID == this.selectedLocationID) {
              this.selectedLocationID = false;
            }
            let obj1 = this.locationList.find(
              (x) => x.LocationID == data.LocationID
            );
            let index = this.locationList.indexOf(obj1);
            this.locationList.splice(index, 1);

            //... check if sectorGroup has more sector in sectors list
            let obj2 = this.locationList.find(
              (x) => x.ParentID == data.ParentID
            );
            let index1 = this.locationList.indexOf(obj2);

            //... if not more sector in sectors list then make delete button visible in sector group list
            if (index1 == -1) {
              let obj3 = this.subCategoryList.find(
                (x) => x.LocationID == data.ParentID
              );
              let index2 = this.subCategoryList.indexOf(obj3);
              this.subCategoryList.fill(
                (obj3.IsAllowDelete = 1),
                index2,
                index2++
              );
            }
          });
      }
    });
  }

  /* Change active/inactive for category, subcategory and location */
  ChangeLocationStatus(data: any) {
    this.locationService
      .ChangeLocationStatus({ LocationID: +data.LocationID })
      .subscribe((resp) => {
        if (resp.status == true) {
          if (data.Status) {
            data.Status = false;
          } else {
            data.Status = true;
          }
        }
       this.alertMsg.success(this.adminService.statusMsg); 
      });
  }

  /*  Space Area */
  GetPropertySpaceList(PropertyID: any) {
    let result: any;
    this.locationService.GetPropertySpaceList(PropertyID).subscribe((resp) => {
      result = resp;
      this.spaceList = result.PropertySpaceList;
    });
  }
  openSpaceForm() {
    this.resetAll();
    this.addcate4 = !this.addcate4;
    this.SpaceForm.patchValue({ PropertySpaceID: 0 });
    this.SpaceForm.patchValue({ PropertyID: +this.PropertyID });
    this.SpaceForm.patchValue({ LocationID: +this.selectedLocationID });
  }
  resetSpaceForm() {
    this.SpaceForm.reset();
    this.addcate4 = false;
  }
  createSpace() {
    this.submitted4 = true;
    if (this.SpaceForm.invalid) {
      return;
    } else {
      let formData = this.SpaceForm.value;
      formData.SpaceName = formData.SpaceName.trim();
      if (formData.SpaceName == "") {
        this.SpaceForm.controls["SpaceName"].setErrors({ invalid: true });
        return false;
      }
      if (formData.SpaceDescription)
        formData.SpaceDescription = formData.SpaceDescription.trim();

      let result: any;
      this.locationService.UpdatePropertySpace(formData).subscribe((resp) => {
        this.submitted4 = false;
        result = resp.UpdatePropertySpace[0];
        if (result.ReturnKey == "Space Name") {
          // Swal.fire({ text: result.ReturnMessage });
          this.alertMsg.success(result.ReturnMessage);
        } else if (result.ReturnKey == "ID") {
          let obj = {
            PropertySpaceID: result.ReturnMessage,
            PropertyID: formData.PropertyID,
            LocationID: formData.LocationID,
            SpaceName: formData.SpaceName,
            SpaceDescription: formData.SpaceDescription,
            IsAllowDelete: 1,
            Status: true,
          };
          this.spaceList.push(obj);
          this.addcate4 = false;
        }
      });
    }
  }
  selectSpace(data: any) {
    if (this.selectedLocationID) {
      if (data.LocationID && data.LocationID != this.selectedLocationID) {
        Swal.fire({
          text:
            "This space is assigned to another location. Do you want to re-assign this ?",
          showCancelButton: true,
          confirmButtonText: "Yes",
          cancelButtonText: "No",
        }).then((result) => {
          if (result.value) {
            this.assignPropertySpace(data, 1);
          }
        });
      } else {
        if (data.LocationID == this.selectedLocationID) {
          this.assignPropertySpace(data, 0);
        } else {
          this.assignPropertySpace(data, 1);
        }
      }
    } else {
      // Swal.fire({
      //   text: "Please first select a location.",
      // });
      this.alertMsg.warning("Please first select a location.");
    }
  }

  assignPropertySpace(data: any, action: any) {
    let finalData = {
      PropertySpaceID: data.PropertySpaceID,
      PropertyID: data.PropertyID,
      LocationID: this.selectedLocationID,
      IsAssign: action,
    };
    this.locationService.assignPropertySpace(finalData).subscribe((resp) => {
      this.GetPropertySpaceList(this.PropertyID);
      /* if(action == 0){
        this.selectedSpaceID = false
      }else{
        this.selectedSpaceID = data.PropertySpaceID
      } */
    });
  }

  editSpace(event, data: any) {
    this.resetAll();
    this.spaceEditable = data.PropertySpaceID;
    this.SpaceForm.patchValue({ PropertySpaceID: data.PropertySpaceID });
    this.SpaceForm.patchValue({ PropertyID: +data.PropertyID });
    this.SpaceForm.patchValue({ LocationID: data.LocationID });
    this.SpaceForm.patchValue({ SpaceName: data.SpaceName });
    this.SpaceForm.patchValue({ SpaceDescription: data.SpaceDescription });
  }
  updateSpace(data: any) {
    this.submitted4 = true;
    if (this.SpaceForm.invalid) {
      return;
    } else {
      let formData = this.SpaceForm.value;
      formData.SpaceName = formData.SpaceName.trim();
      if (formData.SpaceDescription)
        formData.SpaceDescription = formData.SpaceDescription.trim();

      if (formData.SpaceName == "") {
        this.SpaceForm.controls["SpaceName"].setErrors({ invalid: true });
        return false;
      }

      let result: any;
      this.locationService.UpdatePropertySpace(formData).subscribe((resp) => {
        this.submitted4 = false;
        result = resp.UpdatePropertySpace[0];
        if (result.ReturnKey == "Space Name") {
          this.alertMsg.success(result.ReturnMessage);
        } else if (result.ReturnKey == "ID") {
          let obj = this.spaceList.find(
            (o) => o.PropertySpaceID == formData.PropertySpaceID
          );
          let index = this.spaceList.indexOf(obj);
          this.spaceList.fill(
            (obj.SpaceName = formData.SpaceName),
            index,
            index++
          );
          this.spaceList.fill(
            (obj.SpaceDescription = formData.SpaceDescription),
            index,
            index++
          );

          let element: HTMLElement = document.getElementById(
            "closetabS-" + formData.PropertySpaceID
          ) as HTMLElement;
          element.click();
          setTimeout(() => {
            this.spaceEditable = false;
          }, 300);
        }
      });
    }
  }
  closeSpaceEditForm() {
    setTimeout(() => {
      this.spaceEditable = false;
    }, 300);
  }
  deleteSpace(event, data: any) {
    Swal.fire({
      //title: 'Are you sure you want to delete ?',
      // text: "Are you sure you want to delete this ?",
      text: this.adminService.deleteMsg,
      showCancelButton: true,
      confirmButtonText: "Yes",
      cancelButtonText: "No",
    }).then((result) => {
      if (result.value) {
        this.locationService
          .DeletePropertySpace(data.PropertySpaceID)
          .subscribe((resp) => {
            let status = resp.ChangePropertySpaceStatus[0].IsDeleted;
            if (status) {
              let obj1 = this.spaceList.find(
                (x) => x.PropertySpaceID == data.PropertySpaceID
              );
              let index = this.spaceList.indexOf(obj1);
              this.spaceList.splice(index, 1);
            } else {
              // Swal.fire({
              //   text: "An error occured. please try again",
              // });
              this.alertMsg.warning("An error occured. please try again.");
            }
          });
        /*  let obj1 = this.spaceList.find(x => x.PropertySpaceID == data.PropertySpaceID);
        let index = this.spaceList.indexOf(obj1);
        this.spaceList.splice(index, 1)   */
      }
    });
  }

  /* Uses Area section */
  getUsesAreaList() {
    let data = {
      GlobalEnvironmentID: this.PropertyGoeID,
      PropertyID: this.PropertyID,
    };
    let result: any;
    this.locationService.getUsesAreaList(data).subscribe((resp) => {
      result = resp;
      this.usesAreaList = result.UsesAreaList;
    });
  }

  selectUsesArea(data: any) {
    if (this.selectedLocationID) {
      /* if (data.LocationID && data.LocationID != this.selectedLocationID) {
        Swal.fire({
          text:
            "This uses area is assigned to another location. Do you want to re-assigne this ?",
          showCancelButton: true,
          confirmButtonText: "Yes",
          cancelButtonText: "No",
        }).then((result) => {
          if (result.value) {
            this.assignUsesArea(data, 1);
          }
        });
      } else { */
      if (
        data.Location &&
        data.Location.split(",").includes(this.selectedLocationID)
      ) {
        this.assignUsesArea(data, 0);
      } else {
        this.assignUsesArea(data, 1);
      }
      // }
    } else {
      /* if(this.selectedSectorID == data.SectorID){
        this.selectedSectorID = false;        
      }else{
        this.selectedSectorID = data.SectorID;
      } */
      this.alertMsg.warning("Please first select a location.");
    }
  }
  assignUsesArea(data: any, action: any) {
    let finalData = {
      SectorID: +data.SectorID,
      PropertyID: +this.PropertyID,
      LocationID: +this.selectedLocationID,
      IsAssign: action,
    };
    this.locationService.assignUsesArea(finalData).subscribe((resp) => {
      this.getUsesAreaList();
    });
  }

  // downloadLocation() {
  //   let data = [];

  //   this.LocationList.forEach(function (item, i) {
  //     delete item["CategoryID"];
  //     delete item["SubCategoryID"];
  //     delete item["LocationID"];
  //     data.push(item);
  //   });
  //   this.locationService.exportAsExcelFile(data);
  // }

  downloadLocation() {
    let data = [];
    this.LocationList.forEach(function (item, i) {
      delete item["CategoryID"];
      delete item["SubCategoryID"];
      delete item["LocationID"];
      delete item["CreatedDate"];
      // delete item["SpaceName"];
      delete item["PropertyID"];
      // delete item["UsesArea"];
      data.push(item);
    });
    this.locationService.exportAsExcelFile(data);
  }

  downloadUploadedLocation() {
    let newData = [];

    this.UploadedLocationList.forEach(function (item, i) {
      delete item["RecNo"];
      delete item["UserID"];
      delete item["Status"];
      delete item["Message"];

      // delete item["CategoryID"];
      // delete item["SubCategoryID"];
      // delete item["LocationID"];
      newData.push(item);
    });

    this.locationService.exportUploadExcelFile(newData);
  }

  //upload here

  title = "read-excel-in-angular8";
  storeData: any;
  jsonData: any;
  fileUploaded: File;
  worksheet: any;
  htmlData: any;

  uploadedFile(event) {
    this.fileUploaded = event.target.files[0];
    if (!this.validateFile(this.fileUploaded.name)) {
      // Swal.fire({
      //   text: "Selected file format is not supported.",
      // }).then((result) => {
      window.location.reload();
      this.alertMsg.warning("Selected file format is not supported.");
      // this.router.navigate([
      //   "products/administration/propertymanagement/locationmgt",
      // ]);
      // });
      return false;
    }
    this.readExcel();
  }

  validateFile(name: any) {
    var ext = name.substring(name.lastIndexOf(".") + 1);
    if (ext.toLowerCase() == "xlsx") {
      return true;
    } else {
      return false;
    }
  }

  readExcel() {
    let readFile = new FileReader();

    readFile.onload = (e) => {
      this.storeData = readFile.result;

      var data = new Uint8Array(this.storeData);

      var arr = new Array();

      for (var i = 0; i != data.length; ++i)
        arr[i] = String.fromCharCode(data[i]);

      var bstr = arr.join("");

      var workbook = XLSX.read(bstr, { type: "binary" });

      var first_sheet_name = workbook.SheetNames[1];

      this.worksheet = workbook.Sheets[first_sheet_name];

      var range = XLSX.utils.decode_range(this.worksheet["!ref"]);
      range.s.r = 2; // <-- zero-indexed, so setting to 1 will skip row 0
      this.worksheet["!ref"] = XLSX.utils.encode_range(range);

      this.readAsJson(this.currentUserID);
    };

    readFile.readAsArrayBuffer(this.fileUploaded);
  }

  // Upload Excel End

  /** Read As Json */

  readAsJson(currentUserID) {
    this.jsonData = XLSX.utils.sheet_to_json(this.worksheet, { raw: false });

    //this.jsonData = JSON.stringify(this.jsonData);

    var arrofobj = (this.LocationImportList = this.jsonData);

    var result = arrofobj.map(function (el) {
      var o = Object.assign({}, el);
      o.UserID = currentUserID;
      o.Message = "";
      o.RecNo = "";
      return o;
    });
    let length = Object.keys(result).length;

    // this.dataSourceTwo = result;
    this.LocationImport(result);
  }

  /**
   * Import Location List
   *
   */

  newObjArr = [];

  LocationImport(obj) {
    let matchLocation =
      Object.keys(obj[0]).includes("Location Name") &&
      Object.keys(obj[0]).includes("Location Status");

    if (matchLocation) {
      for (var i = 0; i < obj.length; i++) {
        let newObj = {
          RecNo: obj[i]["RecNo"],
          PropertyName: obj[i]["Property Name"],
          CategoryName: obj[i]["Category Name"],
          SubCategoryName: obj[i]["SubCategory Name"],
          LocationName: obj[i]["Location Name"],
          LocationDescription: obj[i]["Location Description"],
          SpaceName:
            obj[i][
              Object.keys(obj[i])[
                Object.keys(obj[i]).findIndex((accu) =>
                  accu.match(/Space Name/g)
                )
              ]
            ],
          PropertyUseArea:
            obj[i]["Property Use Area Name"] || obj[i]["Property Uses Area"],
          LocationStatus: obj[i]["Location Status"],
          UserID: +obj[i]["UserID"],
        };
        this.newObjArr.push(newObj);
      }

      let passingArray = this.newObjArr;

      this.locationService.LocationImport(passingArray).subscribe((res) => {
        this.dataSourceTwo = res.LocationImport.recordset;
        this.UploadedLocationList = res.LocationImport.recordset;
        this.alertMsg.success(
          "Processed Successfully. Please check the table."
        );
        // this.GetLocationList();
      });
    } else {
      this.alertMsg.warning(
        "Uploaded Excel Sheet is Invalid. Please put the right one."
      );
    }
  }

  openFileBrowser(event) {
    this.hideTableMain = false;
    this.showUploadTable = true;
    this.locationDisplay = false;
    // this.dataSourceTwo;

    event.preventDefault();
    let element: HTMLElement = document.getElementById("file") as HTMLElement;
    element.click();
  }

  // ... This is used to reset and close all open forms
  resetAll() {
    let shadesEl = document.querySelectorAll(".show");
    for (let i = 0; i < shadesEl.length; i++) {
      shadesEl[i].classList.remove("show");
    }
    this.categoryEditable = false;
    this.subCategoryEditable = false;
    this.locationEditable = false;
    this.spaceEditable = false;

    this.addcate = false;
    this.addcate2 = false;
    this.addcate3 = false;
    this.addcate4 = false;

    this.categoryFormSubmitted = false;
    this.submitted2 = false;
    this.submitted3 = false;
    this.submitted4 = false;

    this.categoryForm.reset();
    this.subCategoryForm.reset();
    this.LocationForm.reset();
    this.SpaceForm.reset();
  }

  /**
   * Filter table
   * @param event
   *
   */
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSourceOne.filter = filterValue.trim().toLowerCase();
    // console.log(this.dataSourceOne.filteredData)
  }

  cancelUploadView() {
    // this.hideTableMain = true;
    // this.showUploadTable = false;
    window.location.reload();
  }

  onItemSelect(data: any) {
    if (this.selectedItem == data.LocationID) {
      this.selectedItem = !this.selectedItem;
    } else {
      this.selectedItem = data.LocationID;
    }
  }

  /* cname: string="";
  onKeydown(event) {
    
    //var str=event.target.value;
    var str=this.cname;
    var frist=str.charAt(0);
    var last=str.charAt(str.length-1);
    if(this.isLetters(frist)&& this.isLetters(last)){
       //alert(1)
    }
    else{
      this.cname='';
    }
  }
    isLetters(str) {
    
    return /^[a-zA-Z]+$/.test(str);
 } */
  disableSpecialChar(event) {
    return true;
    // let k;
    // k = event.charCode;
    // return (
    //   (k > 64 && k < 91) ||
    //   (k > 96 && k < 123) ||
    //   k == 8 ||
    //   k == 32 ||
    //   (k >= 48 && k <= 57)
    // );
  }
}
