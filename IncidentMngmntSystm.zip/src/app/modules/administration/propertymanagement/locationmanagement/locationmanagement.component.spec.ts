import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LocationmanagementComponent } from './locationmanagement.component';

describe('LocationmanagementComponent', () => {
  let component: LocationmanagementComponent;
  let fixture: ComponentFixture<LocationmanagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LocationmanagementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LocationmanagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
