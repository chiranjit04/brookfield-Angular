import { Injectable } from "@angular/core";
import { Observable, of } from "rxjs";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { environment } from "../../../../../environments/environment";
// import { DatePipe } from "../../../../../../node_modules/@angular/common";
// import * as logoFile from "./brookfieldlogo.js";
import  * as logoFile from "src/assets/images/logo/brookfieldlogo";
import { Workbook } from "exceljs";
import * as fs from "file-saver";
import * as XLSX from "xlsx";

const EXCEL_TYPE =
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8";
const EXCEL_EXTENSION = ".xlsx";

@Injectable({
  providedIn: "root",
})
export class LocationService {
  observable: Observable<any>;
  url: any;
  constructor(private http: HttpClient) {
    this.url = environment.origin + "api/";
    // this.url = 'http://localhost:1601/api/';
  }

  GetLocationCategoryList(data: any) {
    this.observable = this.http.post(
      `${this.url}GetLocationCategoryList`,
      data
    );
    return this.observable;
  }

  UpdateLocationCategory(data: any) {
    this.observable = this.http.post(`${this.url}UpdateLocationCategory`, data);
    return this.observable;
  }

  DeleteLocation(id: any) {
    let data = {
      LocationID: id,
    };
    this.observable = this.http.post(`${this.url}DeleteLocation`, data);
    return this.observable;
  }

  GetLocationSubCategory(categoryID: any) {
    let data = {
      ParentID: categoryID,
    };
    this.observable = this.http.post(
      `${this.url}GetLocationSubCategoryList`,
      data
    );
    return this.observable;
  }

  UpdateLocationSubCategory(data: any) {
    this.observable = this.http.post(
      `${this.url}UpdateLocationSubCategory`,
      data
    );
    return this.observable;
  }

  GetLocationListByPropertyID(PropertyID: any) {
    let data = {
      PropertyID: PropertyID,
    };
    this.observable = this.http.post(
      `${this.url}GetLocationListByPropertyID`,
      data
    );
    return this.observable;
  }
  GetLocationListByCategoryID(ParentID: any) {
    let data = {
      ParentID: ParentID,
    };
    this.observable = this.http.post(
      `${this.url}GetLocationListByCategoryID`,
      data
    );
    return this.observable;
  }
  GetLocationListByParentID(ParentID: any) {
    let data = {
      ParentID: ParentID,
    };
    this.observable = this.http.post(
      `${this.url}GetLocationListByParentID`,
      data
    );
    return this.observable;
  }

  UpdateLocation(data: any) {
    this.observable = this.http.post(`${this.url}UpdateLocation`, data);
    return this.observable;
  }

  GetPropertySpaceList(
    PropertyID: any,
    LocationID: any = 0,
    SpaceName: any = ""
  ) {
    let postData = {
      PropertyID: PropertyID,
      LocationID: LocationID,
      SpaceName: SpaceName,
    };
    this.observable = this.http.post(
      `${this.url}GetPropertySpaceList`,
      postData
    );
    return this.observable;
  }

  UpdatePropertySpace(data: any) {
    this.observable = this.http.post(`${this.url}UpdatePropertySpace`, data);
    return this.observable;
  }

  getUsesAreaList(data: any) {
    this.observable = this.http.post(`${this.url}UsesAreaList`, data);
    return this.observable;
  }

  assignPropertySpace(data: any) {
    this.observable = this.http.post(`${this.url}AssignPropertySpace`, data);
    return this.observable;
  }

  DeletePropertySpace(PropertySpaceID: any) {
    let data = {
      PropertySpaceID: +PropertySpaceID,
    };
    this.observable = this.http.post(`${this.url}DeletePropertySpace`, data);
    return this.observable;
  }

  assignUsesArea(data: any) {
    this.observable = this.http.post(`${this.url}AssignUsesArea`, data);
    return this.observable;
  }

  GetLocationList(data: any) {
    this.observable = this.http.post(`${this.url}GetLocationList`, data);
    return this.observable;
  }

  GetCustomFormDetailsByPropertyId(param) {
    return this.http.post<any>(
      this.url + "GetCustomFormDetailsByPropertyId",
      param
    );
  }

  ChangeLocationStatus(param: any) {
    return this.http.post<any>(this.url + "ChangeLocationStatus", param);
  }

  // Export Location Data
  async exportAsExcelFile(json: any[]) {
    // const title = "Location Exported Data";
    const title = "Location Code Uploading Form";
    const header = [
      "Property Name",
      "Category Name",
      "SubCategory Name",
      "Location Name",
      "Location Description",
      //
      "Space Name",
      "Property Users Area",
      //
      "Location Status",
    ];

    // Create workbook and worksheet
    const workbook = new Workbook();
    const worksheetOne = workbook.addWorksheet("Instructions");
    const worksheet = workbook.addWorksheet("Location Data");
    const worksheetTwo = workbook.addWorksheet("System Pick Values");

    let objectList = [];

    objectList = json.map((ob) => Object.values(ob));
    console.log("term", objectList);

    // Add the Header Image
    worksheet.mergeCells("A1:B1");
    const imageRow = worksheet.getRow(1);
    imageRow.height = 80;

    // Add Image
    const logo = workbook.addImage({
      base64: logoFile.logoBase64,
      extension: "png",
    });

    worksheet.addImage(logo, {
      tl: { col: 0.5, row: 0.5 },
      ext: { width: 350, height: 85 },
    });

    const titleRow = worksheet.addRow([title]);
    titleRow.font = { name: "Calibri", family: 4, size: 16, bold: true };
    worksheet.getRow(2).height = 30;
    worksheet.mergeCells("A2:C2");
    // Add Header Row
    const headerRow = worksheet.addRow(header);

    // Set a specific row height
    headerRow.height = 42.5;

    headerRow.font = { name: "Calibri", family: 4, size: 11, bold: true };
    headerRow.alignment = {
      vertical: "middle",
      horizontal: "center",
    };

    // Cell Style : Fill and Border
    headerRow.eachCell((cell, number) => {
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "0xEAF1DD" },
        bgColor: { argb: "FF0000FF" },
      };
      cell.border = {
        top: { style: "thin" },
        left: { style: "thin" },
        bottom: { style: "thin" },
        right: { style: "thin" },
      };
    });
    // worksheet.addRows(data);
    worksheet.getCell("E3").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "" },
      bgColor: { argb: "" },
    };

    // Add Data and Conditional Formatting
    objectList.forEach((d) => {
      const row = worksheet.addRow(d);
      row.alignment = { horizontal: "center", wrapText: true };
      const qty = row.getCell(4);
    });

    worksheet.getColumn(1).width = 35;
    worksheet.getColumn(2).width = 35;
    worksheet.getColumn(3).width = 35;
    worksheet.getColumn(4).width = 35;
    worksheet.getColumn(5).width = 35;
    worksheet.getColumn(6).width = 35;
    worksheet.getColumn(7).width = 35;
    worksheet.getColumn(8).width = 35;
    worksheet.addRow([]);

    //Worksheet for Instructions Start***********************

    worksheetOne.getColumn(3).width = 13;
    worksheetOne.getColumn(4).width = 13;

    // Add the Header Image
    worksheetOne.mergeCells("D1:H6");
    // Add Image
    const logoOne = workbook.addImage({
      base64: logoFile.logoBase64,
      extension: "png",
    });

    worksheetOne.addImage(logoOne, "D1:H6");
    worksheetOne.addRow([]);

    worksheetOne.getCell("C7").value =
      "Brookfield Properties Location Management Spreadsheet";
    worksheetOne.getCell("C7").font = {
      name: "Calibri",
      family: 4,
      size: 16,
      underline: true,
      bold: true,
    };
    worksheetOne.getRow(7).height = 25;
    
    worksheetOne.addRow([]);
    worksheetOne.addRow([]);

    worksheetOne.getCell("B10").value =
      "Please list the Brookfield Properties, these Properties are customized to represent that company’s organizational structure and related positions of oversight.";
    worksheetOne.getCell("B10").alignment = {
      vertical: "top",
      horizontal: "left",
      wrapText: true,
    };

    worksheetOne.mergeCells("B10", "K13");

    worksheetOne.getCell("B10").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "E2EFD9" },
      bgColor: { argb: "FF0000FF" },
    };

    worksheetOne.getCell("B15").value =
      "Set of Instructions for the Spreadsheet:";
    worksheetOne.getCell("B15").font = {
      name: "Calibri",
      family: 4,
      size: 12,
      bold: true,
    };
    worksheetOne.addRow([]);
    worksheetOne.getCell("B17").value = "GENERAL INFO:";
    worksheetOne.getCell("B23").alignment = { horizontal: "center" };
    worksheetOne.getCell("B17").font = {
      name: "Calibri",
      family: 4,
      size: 12,
      bold: true,
    };
    worksheetOne.getCell("B18").value = "-";
    worksheetOne.getCell("B18").alignment = { horizontal: "right" };
    worksheetOne.getCell("C18").value =
      "Please fill in the required fields to upload data into MAXIMUS.";
    worksheetOne.addRow([]);
    worksheetOne.getCell("B20").value = "-";
    worksheetOne.getCell("B20").alignment = { horizontal: "right" };
    worksheetOne.getCell("C20").value =
      "Dropdown values will appear in each cell if there is a selection to be made,";
    worksheetOne.getCell("C21").value = " otherwise enter appropriate data.";
    worksheetOne.addRow([]);
    worksheetOne.getCell("B23").value = "-";
    worksheetOne.getCell("B23").alignment = { horizontal: "right" };
    worksheetOne.getCell("C23").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "E2EFD9" },
      bgColor: { argb: "FF0000FF" },
    };
    worksheetOne.getCell("C23").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheetOne.getCell("D23").value =
      "Headers in Light Green are Mandatory or Required fields.";
    worksheetOne.getCell("B24").value = "-";
    worksheetOne.getCell("B24").alignment = { horizontal: "right" };
    worksheetOne.getCell("C24").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "" },
      bgColor: { argb: "" },
    };
    worksheetOne.getCell("C24").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheetOne.getCell("D24").value =
      "Headers in White are not Required entry fields.";
    worksheetOne.addRow([]);
    worksheetOne.getCell("B26").value = "-";
    worksheetOne.getCell("B26").alignment = { horizontal: "right" };
    worksheetOne.getCell("C26").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "" },
      bgColor: { argb: "" },
    };
    worksheetOne.getCell("C26").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheetOne.getCell("D26").value =
      "Header cells that include a red triangle at top right provide";
    worksheetOne.getCell("D27").value =
      "information about the field when you mouse over the cell.";

    //Worksheet for Instructions Ends***********************

    //WorkSheet for System Pick Values Starts***********************

    worksheetTwo.getCell("B2").value = "Alfa Group of Retail Stores";
    worksheetTwo.getCell("B3").value = "Bluewater Shopping Centre";
    worksheetTwo.getCell("B4").value = "BROOKFIELD PROPERTIES Sub Unit 2";
    worksheetTwo.getCell("B5").value = "Brookfield Properties Test 1";
    worksheetTwo.getCell("B6").value = "Brookfield Properties Test 2";
    worksheetTwo.getCell("B7").value = "Brookfield Properties Test 3";
    worksheetTwo.getCell("B8").value = "Brookfield Properties Test 4";
    worksheetTwo.getCell("B9").value = "Liverpool ONE";
    worksheetTwo.getCell("B10").value = "Test Property 01";
    worksheetTwo.getCell("B11").value = "The Mall of Celebration";
    worksheetTwo.getCell("C2").value = "Active";
    worksheetTwo.getCell("C3").value = "InActive";

    worksheetTwo.getColumn(2).width = 35;

    //WorkSheet for System Pick Values Ends*************************

    // Generate Excel File with given name
    workbook.xlsx.writeBuffer().then((data: any) => {
      const blob = new Blob([data], {
        type:
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });
      fs.saveAs(blob, "LocationExportData.xlsx");
    });
  }

  //New Upload list Download
  // Export Location Data
  async exportUploadExcelFile(json: any[]) {
    const title = "Location Exported Data";
    const header = [
      "Property Name",
      "Category Name",
      "SubCategory Name",
      "Location Name",
      "Location Description",
      "Location Status",
    ];

    // Create workbook and worksheet
    const workbook = new Workbook();

    const worksheetOne = workbook.addWorksheet("Instructions");
    const worksheet = workbook.addWorksheet("Location Data");
    const worksheetTwo = workbook.addWorksheet("System Pick Values");

    let objectList = [];
    objectList = json.map((ob) => Object.values(ob));

    // Add the Header Image
    worksheet.mergeCells("A1:B1");
    const imageRow = worksheet.getRow(1);
    imageRow.height = 80;

    // Add Image
    const logo = workbook.addImage({
      base64: logoFile.logoBase64,
      extension: "png",
    });

    worksheet.addImage(logo, {
      tl: { col: 0.5, row: 0.5 },
      ext: { width: 350, height: 85 },
    });

    const titleRow = worksheet.addRow([title]);
    titleRow.font = { name: "Calibri", family: 4, size: 16, bold: true };
    worksheet.getRow(2).height = 30;
    worksheet.mergeCells("A2:C2");
    // Add Header Row
    const headerRow = worksheet.addRow(header);

    // Set a specific row height
    headerRow.height = 42.5;

    headerRow.font = { name: "Calibri", family: 4, size: 11, bold: true };
    headerRow.alignment = {
      vertical: "middle",
      horizontal: "center",
    };

    // Cell Style : Fill and Border
    headerRow.eachCell((cell, number) => {
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "E2EFD9" },
        bgColor: { argb: "FF0000FF" },
      };
      cell.border = {
        top: { style: "thin" },
        left: { style: "thin" },
        bottom: { style: "thin" },
        right: { style: "thin" },
      };
    });
    // worksheet.addRows(data);

    worksheet.getCell("E3").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "" },
      bgColor: { argb: "" },
    };

    // Add Data and Conditional Formatting
    objectList.forEach((d) => {
      const row = worksheet.addRow(d);
      row.alignment = { horizontal: "center", wrapText: true };
      const qty = row.getCell(4);
    });

    worksheet.getColumn(1).width = 35;
    worksheet.getColumn(2).width = 35;
    worksheet.getColumn(3).width = 35;
    worksheet.getColumn(4).width = 35;
    worksheet.getColumn(5).width = 35;
    worksheet.getColumn(6).width = 35;
    worksheet.getColumn(7).width = 35;
    worksheet.getColumn(8).width = 35;
    worksheet.addRow([]);

    //Worksheet for Instructions Start***********************

    worksheetOne.getColumn(3).width = 13;
    worksheetOne.getColumn(4).width = 13;

    // Add the Header Image
    worksheetOne.mergeCells("D1:H6");
    // Add Image
    const logoOne = workbook.addImage({
      base64: logoFile.logoBase64,
      extension: "png",
    });

    worksheetOne.addImage(logoOne, "D1:H6");
    worksheetOne.addRow([]);

    worksheetOne.getCell("C7").value =
      "Brookfield Properties Location Management Spreadsheet";
    worksheetOne.getCell("C7").font = {
      name: "Calibri",
      family: 4,
      size: 16,
      underline: true,
      bold: true,
    };
    worksheetOne.getRow(7).height = 25;
    worksheetOne.addRow([]);
    worksheetOne.addRow([]);

    worksheetOne.getCell("B10").value =
      "Please list the Brookfield Properties, these Properties are customized to represent that company’s organizational structure and related positions of oversight.";
    worksheetOne.getCell("B10").alignment = {
      vertical: "top",
      horizontal: "left",
      wrapText: true,
    };

    worksheetOne.mergeCells("B10", "K13");

    worksheetOne.getCell("B10").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "E2EFD9" },
      bgColor: { argb: "FF0000FF" },
    };

    worksheetOne.getCell("B15").value =
      "Set of Instructions for the Spreadsheet:";
    worksheetOne.getCell("B15").font = {
      name: "Calibri",
      family: 4,
      size: 12,
      bold: true,
    };
    worksheetOne.addRow([]);
    worksheetOne.getCell("B17").value = "GENERAL INFO:";
    worksheetOne.getCell("B23").alignment = { horizontal: "center" };
    worksheetOne.getCell("B17").font = {
      name: "Calibri",
      family: 4,
      size: 12,
      bold: true,
    };
    worksheetOne.getCell("B18").value = "-";
    worksheetOne.getCell("B18").alignment = { horizontal: "right" };
    worksheetOne.getCell("C18").value =
      "Please fill in the required fields to upload data into MAXIMUS.";
    worksheetOne.addRow([]);
    worksheetOne.getCell("B20").value = "-";
    worksheetOne.getCell("B20").alignment = { horizontal: "right" };
    worksheetOne.getCell("C20").value =
      "Dropdown values will appear in each cell if there is a selection to be made,";
    worksheetOne.getCell("C21").value = " otherwise enter appropriate data.";
    worksheetOne.addRow([]);
    worksheetOne.getCell("B23").value = "-";
    worksheetOne.getCell("B23").alignment = { horizontal: "right" };
    worksheetOne.getCell("C23").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "E2EFD9" },
      bgColor: { argb: "FF0000FF" },
    };
    worksheetOne.getCell("C23").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheetOne.getCell("D23").value =
      "Headers in Light Green are Mandatory or Required fields.";
    worksheetOne.getCell("B24").value = "-";
    worksheetOne.getCell("B24").alignment = { horizontal: "right" };
    worksheetOne.getCell("C24").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "" },
      bgColor: { argb: "" },
    };
    worksheetOne.getCell("C24").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheetOne.getCell("D24").value =
      "Headers in White are not Required entry fields.";
    worksheetOne.addRow([]);
    worksheetOne.getCell("B26").value = "-";
    worksheetOne.getCell("B26").alignment = { horizontal: "right" };
    worksheetOne.getCell("C26").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "" },
      bgColor: { argb: "" },
    };
    worksheetOne.getCell("C26").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheetOne.getCell("D26").value =
      "Header cells that include a red triangle at top right provide";
    worksheetOne.getCell("D27").value =
      "information about the field when you mouse over the cell.";

    //Worksheet for Instructions Ends***********************

    //WorkSheet for System Pick Values Starts***********************

    worksheetTwo.getCell("B2").value = "Alfa Group of Retail Stores";
    worksheetTwo.getCell("B3").value = "Bluewater Shopping Centre";
    worksheetTwo.getCell("B4").value = "BROOKFIELD PROPERTIES Sub Unit 2";
    worksheetTwo.getCell("B5").value = "Brookfield Properties Test 1";
    worksheetTwo.getCell("B6").value = "Brookfield Properties Test 2";
    worksheetTwo.getCell("B7").value = "Brookfield Properties Test 3";
    worksheetTwo.getCell("B8").value = "Brookfield Properties Test 4";
    worksheetTwo.getCell("B9").value = "Liverpool ONE";
    worksheetTwo.getCell("B10").value = "Test Property 01";
    worksheetTwo.getCell("B11").value = "The Mall of Celebration";
    worksheetTwo.getCell("C2").value = "Active";
    worksheetTwo.getCell("C3").value = "InActive";

    worksheetTwo.getColumn(2).width = 35;

    // Generate Excel File with given name
    workbook.xlsx.writeBuffer().then((data: any) => {
      const blob = new Blob([data], {
        type:
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });
      fs.saveAs(blob, "LocationExportData.xlsx");
    });
  }

  //

  LocationImport(obj) {
    try {
      console.log("Location service hitting");
      return this.http.post<any>(`${this.url}LocationImport`, obj);
    } catch (error) {
      throw error;
    }
  }
}
