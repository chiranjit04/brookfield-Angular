import { Component, OnInit, ViewChild } from "@angular/core";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { DataSharingService } from "../dataSharing.service";
import { PropertManagementService } from "../propertyManagement.service";
import { StorageService } from "../../../../services/storage.service";
import { UserPermissionService } from "src/app/services/user-permission.service";
@Component({
  selector: "app-keycontacttable",
  templateUrl: "./keycontacttable.component.html",
  styleUrls: ["./keycontacttable.component.scss"],
})
export class KeycontacttableComponent implements OnInit {
  constructor(
    private data: DataSharingService,
    private propertyManagement: PropertManagementService,
    private storage: StorageService,
    public UserPermission: UserPermissionService
  ) {}

  isDataFound = false;
  displayedColumns: string[] = [
    "keycontactname",
    "keycontactuserid",
    "keycontactposition",
    "ProfileName",
    "keycontactcompany",
    "PropertyORWorkGroup",
    "keycontactEmail",
    "keycontactconc",
    "keycontactaction",
  ];
  dataSource = new MatTableDataSource([]);

  @ViewChild(MatSort, { static: false }) sort: MatSort;

  ngOnInit() {
    this.data.keyContactStream.subscribe((x: any) => {
      console.log("my changed ", x);

      if (this.storage.getData("PropertyDetail") != null && x != "keyContact") {
        this.dataSource = new MatTableDataSource(x.PropertyContact);
        if (x.PropertyContact.length == 0) {
          this.isDataFound = true;
        } else {
          this.isDataFound = false;
        }
      }
    });
  }
  removeContact(element) {
    this.propertyManagement
      .UpdatePropertyContact({
        PropertyContactId: element.PropertyContactId,
        PropertyId: +element.PropertyId,
        UserId: element.UserID,
        IsAssigned: 0,
      })
      .subscribe((x) => {
        this.propertyManagement
          .GetPropertyContact({
            PropertyId: +element.PropertyId,
          })
          .subscribe((x) => {
            this.dataSource = new MatTableDataSource(x.PropertyContact);

            this.propertyManagement
              .GetPropertyAllPerson({ PropertyId: +element.PropertyId })
              .subscribe((x) => {
                this.data.changeAllKeyPersionMessage({
                  allData: x,
                  PropertyId: +element.PropertyId,
                });
              });
          });
      });
  }
}
