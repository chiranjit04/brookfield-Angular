import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KeycontacttableComponent } from './keycontacttable.component';

describe('KeycontacttableComponent', () => {
  let component: KeycontacttableComponent;
  let fixture: ComponentFixture<KeycontacttableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KeycontacttableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KeycontacttableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
