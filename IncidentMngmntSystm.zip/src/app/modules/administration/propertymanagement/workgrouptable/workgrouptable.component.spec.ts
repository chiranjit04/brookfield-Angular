import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WorkgrouptableComponent } from './workgrouptable.component';

describe('WorkgrouptableComponent', () => {
  let component: WorkgrouptableComponent;
  let fixture: ComponentFixture<WorkgrouptableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WorkgrouptableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WorkgrouptableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
