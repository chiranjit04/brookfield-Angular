import { Component, OnInit, ViewChild } from "@angular/core";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { DataSharingService } from "../dataSharing.service";
import { Router, ActivatedRoute } from '@angular/router';
import { StorageService } from '../../../../services/storage.service';

@Component({
  selector: "app-workgrouptable",
  templateUrl: "./workgrouptable.component.html",
  styleUrls: ["./workgrouptable.component.scss"]
})
export class WorkgrouptableComponent implements OnInit {
  constructor(private data: DataSharingService, private route: ActivatedRoute,private storage: StorageService) { }
  isDataFound = false;
  displayedColumns: string[] = [
    // "workgroupComp",
    // "workgroupCompsub",
    // "workgroupCompname"
    "CompanyName",
    "CompanySubdivision",
    "WorkGroupName"
  ];
  dataSource;

  @ViewChild(MatSort, { static: true }) sort: MatSort;

  ngOnInit() {

    const propertyID = this.route.snapshot.paramMap.get("id");
    if (propertyID) {
      this.data.workGroupStream.subscribe((x: any) => {
        if (typeof x == "string") return;
        if (this.storage.getData("PropertyDetail") != null && x != "workGroupStream") {
          this.dataSource = new MatTableDataSource(x);
          this.dataSource.sort = this.sort
          if (x.length == 0) {
            this.isDataFound = true;
          }
          else {
            this.isDataFound = false;
          }
        }
      });
    }
  }
}
