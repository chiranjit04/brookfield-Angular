import {
  Component,
  OnInit,
  ViewChild,
  OnDestroy,
  Output,
  EventEmitter,
} from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { DataSharingService } from "../dataSharing.service";
import { Router } from "@angular/router";
import { PropertManagementService } from "../propertyManagement.service";
import { JsToPdfService } from "./jsToPdf.service";
import Swal from "sweetalert2";
import { ModelcomsubdivisonComponent } from "./modelcomsubdivison/modelcomsubdivison.component";
import { ModelpropsubunitComponent } from "./modelpropsubunit/modelpropsubunit.component";
import { Subscription } from "rxjs/internal/Subscription";
import { ToastrService } from "ngx-toastr";
import { UserPermissionService } from "../../../../services/user-permission.service";
import { StorageService } from "../../../../services/storage.service";
import { PropertyDetailService } from "../propertydetail/propertyDetail.service";
import { ThrowStmt } from "@angular/compiler";
import { ServiceService } from "./../../service/service.service";

const ELEMENT_DATA: any = [
  {
    PropertyName: "",
    Subdivision: "",
    PropertyIdentNumber: "",
    EnvironmentName: "",
    Address1: "",
    City: "",
    StateName: "",
    Zip: "",
    IsActive: "",
    status: "",
  },
];

@Component({
  selector: "app-myproperty-list",
  templateUrl: "./myproperty-list.component.html",
  styleUrls: ["./myproperty-list.component.scss"],
})
export class MypropertyListComponent implements OnInit, OnDestroy {
  PropertyDetail = null;
  userData: any = null;
  defaultPropery: any = false;
  tempPropertyList: any = [];

  active: boolean = true;
  childMessage: string;
  selectedRowIndent: false;
  propertyParam: any;
  dataShareSubscribe: Subscription;
  displayedColumns: string[] = [
    "PropertyName",
    "Subdivision",
    "PropertyIdentNumber",
    "EnvironmentName",
    "Address1",
    "StateName",
    "Zip",
    "companies",
    "Property",
    "IsActive",
  ];

  constructor(
    private dataShare: DataSharingService,
    private route: Router,
    private propertyService: PropertManagementService,
    private jstopdf: JsToPdfService,
    private tostre: ToastrService,
    public dialog: MatDialog,
    public UserPermission: UserPermissionService,
    private storage: StorageService,
    public exportService: PropertyDetailService,
    private adminService: ServiceService
  ) {}

  propertydataSource = new MatTableDataSource();
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  @Output() isSelectedEvent: EventEmitter<any> = new EventEmitter();
  ngOnInit() {
    this.dataShareSubscribe = this.dataShare.currentMessage.subscribe(
      (x: any) => {
        /* if (this.displayedColumns.indexOf("status") > 0) {
          this.displayedColumns.pop();
          this.displayedColumns.push("IsActive");
          this.hello = false;
          this.active = true;
        } */
        this.selectedRowIndent = false;
        this.childMessage = x;

        this.tempPropertyList = x.propertySearchList;
        this.propertydataSource = new MatTableDataSource(x.propertySearchList);
        this.singleDefaultSelcte(x.propertySearchList);
        if (x != "messageSource") {
          if (this.propertydataSource.data.length == 0) {
            this.dataShare.checkDataFound("true");
          } else {
            this.dataShare.checkDataFound("false");
          }
        }
        this.propertydataSource.sort = this.sort;
        this.sort.disableClear = true;
        this.dataShare.propertyParameter.subscribe((x: any) => {
          this.propertyParam = x;
          this.selectedRowIndent = false;

          /* ------- Set property active if it is in storage or from user property --- */
          if (this.storage.getData("PropertyDetail") != "undefined") {
            this.PropertyDetail = JSON.parse(
              this.storage.getData("PropertyDetail")
            );
            if (this.PropertyDetail) {
              this.selectedRowIndent = this.PropertyDetail.PropertyID;
              if (this.tempPropertyList) {
                let obj = this.tempPropertyList.find(
                  (x) => x.PropertyID == this.selectedRowIndent
                );
                if (obj != undefined) {
                  this.storage.setData("PropertyDetail", JSON.stringify(obj));
                }
              }
            } else {
              this.userData = JSON.parse(this.storage.getData("UserData"));
              if (this.userData) {
                this.selectedRowIndent = this.userData[0].PropertyID;
              }
              // set user's property as selected and in storage
              if (this.tempPropertyList) {
                let obj = this.tempPropertyList.find(
                  (x) => x.PropertyID == this.selectedRowIndent
                );
                // console.log("obj", obj)
                if (obj != undefined) {
                  this.storage.setData("PropertyDetail", JSON.stringify(obj));
                }
              }
            }
          }
          /* ----------------------------- */
        });
      }
    );

    this.dataShare.importedDataStream.subscribe((x: any) => {
      if (typeof x === "string") return;
      this.selectedRowIndent = false;

      this.displayedColumns.pop();
      this.displayedColumns.push("status");
      this.hello = true;
      this.active = false;

      this.propertydataSource = new MatTableDataSource(x);
      this.propertydataSource.sort = this.sort;
      this.sort.disableClear = true;
    });
  }

  ngOnDestroy() {
    this.dataShareSubscribe.unsubscribe();
  }

  viewcomsubdiv(element) {
    const dialogRef = this.dialog.open(ModelcomsubdivisonComponent, {
      width: "400px",
      panelClass: "my-dialog-container-class2",
      data: { propertyID: element.PropertyID },
    });
    dialogRef.afterClosed().subscribe((result) => {});
  }

  viewpropunit(element) {
    const dialogRef = this.dialog.open(ModelpropsubunitComponent, {
      width: "400px",
      panelClass: "my-dialog-container-class2",
      data: { propertyID: element.PropertyID },
    });
    dialogRef.afterClosed().subscribe((result) => {});
  }
  selectedRow(e, event) {
    //event.stopPropagation();
    /* if (this.selectedRowIndent == null) {
      Swal.fire("please Select Row");
      return;
    }
    if (this.storage.getData("PropertyDetail") == null) {
      Swal.fire("Please Select row");
    }
    let selectedObject = JSON.parse(this.storage.getData("PropertyDetail"));
    if (selectedObject.PropertyID !== e.PropertyID) {
      this.setLocalStorage(e);
    } */
    // this.selectedRowIndent = e.PropertyID;
    this.setLocalStorage(e);
    this.route.navigate([
      "/products/administration/propertymanagement/propertydetail/addproperty/" +
        e.PropertyID,
    ]);
  }

  selectProperty(row) {
    if (this.selectedRowIndent == row.PropertyID) {
      this.selectedRowIndent = false;
      this.isSelectedEvent.emit(false);
      // this.storage.removeData("PropertyDetail");
    } else {
      this.selectedRowIndent = row.PropertyID;
      this.setLocalStorage(row);
    }
  }

  setLocalStorage(e) {
    if (e.Subdivision === "Property") {
      this.isSelectedEvent.emit(true);
    } else {
      this.isSelectedEvent.emit(false);
    }
    this.storage.setData("PropertyDetail", JSON.stringify(e));
    localStorage.setItem("PropertyDetail", JSON.stringify(e));
  }
  setActiveOrDeactive(e, evt) {
    //evt.stopPropagation();
    let sts = e.IsActive ? "deactivate" : "activate";
    // Swal.fire({
    //   text: "Are you sure you want to " + sts + " property?",
    //   showCancelButton: true,
    //   width: "30%",
    //   confirmButtonColor: "#3085d6",
    //   cancelButtonColor: "#d33",
    //   confirmButtonText: "Yes",
    // }).then((result) => {
    //   if (result.value) {
    //     this.propertyService
    //       .ChangePropertyStatus({ PropertyId: e.PropertyID })
    //       .subscribe((x) => {
    //         this.propertyService
    //           .getPropertySearchList(this.propertyParam)
    //           .subscribe((x) => {
    //             this.propertydataSource = new MatTableDataSource(
    //               x.propertySearchList
    //             );
    //           });
    //       });
    //   }
    // });
    this.propertyService
      .ChangePropertyStatus({ PropertyId: e.PropertyID })
      .subscribe((x) => {
        this.tostre.success(this.adminService.statusMsg);
        if (e.IsActive) {
          e.IsActive = false;
        } else {
          e.IsActive = true;
        }
        // this.propertyService
        //   .getPropertySearchList(this.propertyParam)
        //   .subscribe((x) => {
        //     this.propertydataSource = new MatTableDataSource(
        //       x.propertySearchList
        //     );
        //   });
      });
  }
  Archive(id) {
    this.propertyService
      .setArchiveProperty({ PropertyId: +id.PropertyID })
      .subscribe((x) => {
        if (x.statusCode == 200) {
          Swal.fire("Property archived successfully.");
          this.propertyService
            .getPropertySearchList(this.propertyParam)
            .subscribe((x) => {
              this.propertydataSource = new MatTableDataSource(
                x.propertySearchList
              );
            });
        } else {
          Swal.fire("Property didn't Archive.");
        }
      });
  }
  deleteProperty(propertyObj, event) {
    event.stopPropagation();
    Swal.fire({
      text: this.adminService.deleteMsg,
      showCancelButton: true,
      width: "30%",
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes",
      cancelButtonText: "No",
    }).then((result) => {
      if (result.value) {
        event.stopPropagation();
        this.propertyService
          .DeletePropertyById({
            PropertyId: propertyObj.PropertyID,
          })
          .subscribe((x) => {
            if (x.statusCode == 200) {
              this.propertyService
                .getPropertySearchList(this.propertyParam)
                .subscribe((x) => {
                  this.propertydataSource = new MatTableDataSource(
                    x.propertySearchList
                  );
                });
              this.dataShare.changeDeleteMessage(propertyObj);
            } else {
              this.tostre.error("Property didn t delete.", "", {
                positionClass: "toast-top-right",
              });

              //Swal.fire("Property didn't delete.");
            }
          });
      }
    });
  }
  deleteProperty1(propertyObj, event) {
    event.stopPropagation();
    Swal.fire({
      // text: "Are you sure you want to delete property?",
      text: this.adminService.deleteMsg,
      showCancelButton: true,
      width: "30%",
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes",
      cancelButtonText: "No",
    }).then((result) => {
      if (result.value) {
        event.stopPropagation();
        this.propertyService
          .DeletePropertyById({
            PropertyId: propertyObj.PropertyID,
          })
          .subscribe((x) => {
            if (x.statusCode == 200) {
              this.propertyService
                .getPropertySearchList(this.propertyParam)
                .subscribe((x) => {
                  this.propertydataSource = new MatTableDataSource(
                    x.propertySearchList
                  );
                });
              this.dataShare.changeDeleteMessage(propertyObj);
            } else {
              Swal.fire("Property didn't delete.");
            }
          });
      }
    });
  }
  hello = false;
  clickonAdd() {
    this.hello = true;
    this.displayedColumns.push("status");
  }
  clickonRem() {
    this.hello = false;
    this.displayedColumns.pop();
  }

  private singleDefaultSelcte(propObj: any) {
    if (Array.isArray(propObj)) {
      if (propObj.length === 1) {
        this.selectProperty(propObj[0]);
        this.selectedRowIndent = propObj[0].PropertyID;
      }
    }
  }
}
