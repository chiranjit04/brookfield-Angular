import { Injectable } from "@angular/core";
import pdfmake from "pdfmake/build/pdfmake";
import pdfFonts from "pdfmake/build/vfs_fonts";
Injectable({
  providedIn: "root"
});

export class JsToPdfService {
  constructor() {
    pdfmake.vfs = pdfFonts.pdfMake.vfs;
  }
  /**
   *
   * @param _detail
   * @param _value
   * @param _header
   */
  toPdf(_detail, _value, _header) {
    // let doc = new jsPDF("l", "pt", [2500, 700]);
    // // From HTML
    // doc.autoTable({ html: ".table" });
    // // From Javascript
    // let finalY = doc.previousAutoTable.finalY;
    // doc.text(_detail, 14, finalY + 15);
    // doc.autoTable({
    //   startY: finalY + 20,
    //   head: [_header],
    //   body: [_value]
    // });
    // return doc;
    const documentDefinition = {
      content: "This is an sample PDF printed with pdfMake"
    };

    pdfmake.createPdf(this.documentStructure("")).download("hello.pdf");
    // pdfmake.createPdf(documentDefinition).open();
  }
  documentStructure(obj): any {
    let documentdef = {
      // content: [
      //   {
      //     text: obj.HeaderName,
      //     style: "header",
      //     text :
      //   }
      // ]
    };
    return documentdef;
  }
}
