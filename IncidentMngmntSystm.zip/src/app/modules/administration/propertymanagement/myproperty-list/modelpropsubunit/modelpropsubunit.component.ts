import { Component, OnInit, Inject } from '@angular/core';
import { PropertManagementService } from '../../propertyManagement.service';
import { MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-modelpropsubunit',
  templateUrl: './modelpropsubunit.component.html',
  styleUrls: ['./modelpropsubunit.component.scss']
})
export class ModelpropsubunitComponent implements OnInit {
  subunitObj: any;
  propertyID: any;
  constructor(private propertyService: PropertManagementService,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit() {
    this.propertyID=this.data.propertyID;
    this.getPropertySubdivisionbybyPropertyId(this.propertyID);
  }

  getPropertySubdivisionbybyPropertyId(propertyID) {
    let param = {
      "PropertyId": propertyID
    }
    this.propertyService.getPropertySubdivisionbybyPropertyId(param).subscribe((x: any) => {
      if(x.statusCode==200)
      this.subunitObj = x.getPropertySubdivisionbybyPropertyId;
      console.log(x);
    });
  }
}
