import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModelpropsubunitComponent } from './modelpropsubunit.component';

describe('ModelpropsubunitComponent', () => {
  let component: ModelpropsubunitComponent;
  let fixture: ComponentFixture<ModelpropsubunitComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModelpropsubunitComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModelpropsubunitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
