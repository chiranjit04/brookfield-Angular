import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MypropertyListComponent } from './myproperty-list.component';

describe('MypropertyListComponent', () => {
  let component: MypropertyListComponent;
  let fixture: ComponentFixture<MypropertyListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MypropertyListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MypropertyListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
