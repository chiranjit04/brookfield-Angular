import { Component, OnInit, Inject } from '@angular/core';
import { PropertManagementService } from '../../propertyManagement.service';
import { MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-modelcomsubdivison',
  templateUrl: './modelcomsubdivison.component.html',
  styleUrls: ['./modelcomsubdivison.component.scss']
})
export class ModelcomsubdivisonComponent implements OnInit {
  subdivionObj: any;
  propertyID: any;
  constructor(private propertyService: PropertManagementService,
    @Inject(MAT_DIALOG_DATA) public data: any) { }
  ngOnInit() {
    this.propertyID = this.data.propertyID;
    this.getCompanySubdivisionbyPropertyId(this.propertyID);
  }

  getCompanySubdivisionbyPropertyId(propertyID) {
    let param = {
      "PropertyId": propertyID
    }
    this.propertyService.getCompanySubdivisionbyPropertyId(param).subscribe((x: any) => {
      if(x.statusCode==200)
      this.subdivionObj = x.getCompanySubdivisionbyPropertyId;
      console.log(x);
    });
  }
}
