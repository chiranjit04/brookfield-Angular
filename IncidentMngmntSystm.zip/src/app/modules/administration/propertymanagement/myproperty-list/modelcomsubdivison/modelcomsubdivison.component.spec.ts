import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModelcomsubdivisonComponent } from './modelcomsubdivison.component';

describe('ModelcomsubdivisonComponent', () => {
  let component: ModelcomsubdivisonComponent;
  let fixture: ComponentFixture<ModelcomsubdivisonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModelcomsubdivisonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModelcomsubdivisonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
