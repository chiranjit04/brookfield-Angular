import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from "rxjs";
@Injectable({
  providedIn: 'root'
})
export class PropertyprofileService {
  url: string;

  constructor(private http: HttpClient) {
    this.url = environment.origin;
  }

  GetCustomFormListByPropertyId(param: any): Observable<any> {
    return this.http.post<any>(this.url + 'api/GetCustomFormListByPropertyId', param);
  }

  GetCustomFormDetailsByPropertyId(param)
  {
    return this.http.post<any>(this.url + 'api/GetCustomFormDetailsByPropertyId', param);
  }

  GetPropertyProfileDetails(param :any): Observable<any>{
    return this.http.post<any>(this.url + 'api/GetPropertyProfileDetails', param);
  }

  getCustomFormElementList(param: any): Observable<any> {
    return this.http.post<any>(this.url + 'api/GetCustomFormElementList', param);
  } 

  addCustomFormElementAnswer(param: any): Observable<any> {
    return this.http.post<any>(this.url + 'api/UpdatePropertyProfile', param);
  }


    GetPropertyProfileAnswer(param: any): Observable<any> {
      return this.http.post<any>(this.url + 'api/GetPropertyProfileAnswer', param);
    }

    UpdatePropertyProfileLog(param: any): Observable<any> {
      return this.http.post<any>(this.url + 'api/UpdatePropertyProfileLog', param);
    }

    // GetPropertyProfileDetails

}
