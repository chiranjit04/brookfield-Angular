import { Component, OnInit, Inject, EventEmitter, Output } from "@angular/core";
import Swal from "sweetalert2";
import { Router } from "@angular/router";
import { PropertyprofileService } from "./propertyprofile.service";
import { ToastrService } from "ngx-toastr";
import { FormGroup, FormBuilder, FormArray, Validators } from "@angular/forms";
import {
  MAT_DIALOG_DATA,
  MatDialogRef,
  MatCheckboxChange,
} from "@angular/material";
import { environment } from "src/environments/environment";
declare var require: any;
const FileSaver = require("file-saver");
import * as pdfMake from "pdfmake";
import { saveAs } from "file-saver";
import pdfFonts from "pdfmake/build/vfs_fonts";
import { StorageService } from "../../../../services/storage.service";
pdfMake.vfs = pdfFonts.pdfMake.vfs;
import { logoBase64 } from "../locationmanagement/brookfieldlogo";
import { UserPermissionService } from "../../../../services/user-permission.service";

@Component({
  selector: "app-propertyprofile",
  templateUrl: "./propertyprofile.component.html",
  styleUrls: ["./propertyprofile.component.scss"],
})
export class PropertyprofileComponent implements OnInit {
  _customFormElementList: any;
  favoriteSeason: string;
  timeList: any[];
  submitted = false;
  incidentExtrainfo: FormGroup;
  items: FormArray;
  dispatchIncidentID = 0;
  private file2: File = null;
  userData: any;
  answer = [];
  checkBoxItems = [];
  msg = "Record Form Created Successfully.";
  _selectedProperty: any;
  propertyDetail: any;
  propertyID = 0;
  getcustomelementlist: any = [];
  PropertyIdentNumber: any;
  SubPropertyUnit: any;
  CustomFormGroupId: any;
  Frequency: any;
  NextUpdateDateTime: any;
  selectedid: any;
  savebutton: boolean;
  PropertyProfileId = 0;
  updtaebutton: boolean;
  UserData: any;
  TimeZoneOffset: any;
  value: any;
  fileToUpload: File = null;
  vaulable: boolean;
  base64textString: string;
  work: void;
  formData: FormData;
  fil: any;
  file: any;
  fd: FormData;
  filename: any;
  filenames = "";
  propertyno: any;
  formtitle = "Property General Details";
  SubunitName: any;
  showLoader: boolean;
  getCustomFormDetailsByPropertyId: any;
  datas: boolean;
  currentdate: string;
  subprop = "This is a Property Sub-unit of Property";

  constructor(
    public router: Router,
    private formBuilder: FormBuilder,
    private ProfileService: PropertyprofileService,
    private tostre: ToastrService,
    private storage: StorageService,
    public UserPermission: UserPermissionService
  ) {
    this.propertyDetail = JSON.parse(this.storage.getData("PropertyDetail"));
    this.UserData = JSON.parse(this.storage.getData("UserData"));

    console.log("TimeZoneOffset", this.TimeZoneOffset);
    if (this.propertyDetail) {
      this.propertyID = this.propertyDetail.PropertyID;
      this.propertyno = this.propertyDetail.PropertyIdentNumber;
      this._selectedProperty = this.propertyDetail.PropertyName;
      this.SubunitName = this.propertyDetail.SubunitName;
    }

    const params = {
      PropertyId: this.propertyID,
    };

    if (this.propertyDetail.Subdivision === "Property Subunit") {
      this.SubPropertyUnit =
        this.propertyDetail.ParentPropertyName +
        " - " +
        this.propertyDetail.ParentIdentNumber;
    }
    this.ProfileService.GetCustomFormDetailsByPropertyId(params).subscribe(
      (res) => {
        this.getCustomFormDetailsByPropertyId =
          res.data.getCustomFormDetailsByPropertyId;
        if (res.data.getCustomFormDetailsByPropertyId.length != "") {
          this.PropertyIdentNumber =
            res.data.getCustomFormDetailsByPropertyId[0].PropertyIdentNumber;
          this.SubPropertyUnit =
            res.data.getCustomFormDetailsByPropertyId[0].SubPropertyUnit;
          this.CustomFormGroupId =
            res.data.getCustomFormDetailsByPropertyId[0].CustomFormGroupId;
          this.Frequency =
            res.data.getCustomFormDetailsByPropertyId[0].Frequency;
          this.NextUpdateDateTime =
            res.data.getCustomFormDetailsByPropertyId[0].NextUpdateDateTime;

          const paramss = {
            PropertyId: this.propertyID,
            CustomFormGroupId: this.CustomFormGroupId,
          };

          this.ProfileService.GetCustomFormListByPropertyId(paramss).subscribe(
            (res) => {
              this.getcustomelementlist =
                res.data.getCustomFormListByPropertyId;
              console.log("lakh", this.getcustomelementlist);
            }
          );
        }
      }
    );
  }

  ngOnInit() {
    if (this.checkProperty()) {
    }

    this.incidentExtrainfo = this.formBuilder.group({
      items: this.formBuilder.array([]),
      PropertyProfileId: [""],
      CustomFormTypeId: [""],
      PropertyId: [""],
      CustomFormGroupId: [""],
      CustomFormId: [""],
      FormElementId: [""],
      FormElementDetailsId: [""],
      Answer: [""],
      IsAnswered: [""],
      IsDeleted: [""],
      files: [""],
      download: [""],
    });
  }

  createItem(element): FormGroup {
    return this.formBuilder.group({
      CustomFormElementId: [element.CustomFormElementId],
      ElementTypeId: [element.ElementTypeId],
      IsMandatory: [element.IsMandatory],
      ElementName: [element.ElementName],
      CustomElementName: [element.CustomElementName],
      Numberofcharacter: [element.numberofcharacter],
      Time: "",
      files: "",
      Answer: [
        element.Answer,
        [element.IsMandatory ? Validators.required : null],
      ],
      IsAnswered: "",
      download: [""],
    });
  }

  addItem(): void {
    this.items = this.incidentExtrainfo.get("items") as FormArray;
    this._customFormElementList.forEach((element) => {
      if (element.ElementTypeId == 7) {
        if (element.CustomElementName[0] != undefined) {
          let index = parseInt(element.CustomElementName[0]) + 1;
          element.Answer = element.CustomElementName[index];
        } else {
          element.Answer = "";
        }
      } else {
        element.Answer = "";
      }
      this.items.push(this.createItem(element));
    });
  }

  // getCustomFormElementList(formID) {
  //   const param = {
  //     CustomFormID: formID
  //   }
  //   this.ProfileService.getCustomFormElementList(param).subscribe((x: any) => {
  //     if (x.statusCode == 200) {
  //       this._customFormElementList = x.CustomFormElementList;
  //       this.addItem();
  //     }
  //     console.log(x);
  //   });
  // }
  datasave() {
    this.datas = true;
  }

  get getFormArray() {
    return this.incidentExtrainfo.get("items") as FormArray;
  }
  count = 0;
  takeid(id) {
    this.showLoader = true;
    if (this.datas == true) {
      this.updateCustomFormAnswers(3);
      this.datas = false;
    }
    this.getFormArray.controls.splice(0);
    setTimeout(() => {
      this.updtaebutton = false;
      this.savebutton = false;
      this.submitted = false;
      this.selectedid = id;
      const params2 = {
        CustomFormID: this.selectedid,
      };
      this.ProfileService.getCustomFormElementList(params2).subscribe((res) => {
        this.getFormArray.controls.splice(0);
        this.count++;
        if (res.statusCode == 200) {
          this._customFormElementList = res.CustomFormElementList;
          this.formtitle = res.CustomFormElementList[0].Title;

          this.addItem();
          if (res.CustomFormElementList.length != 0) {
            this.savebutton = true;
            this.updtaebutton = false;
          }
          const gparams2 = {
            CustomFormId: this.selectedid,
            PropertyId: this.propertyID,
            CustomFormGroupId: this.CustomFormGroupId,
          };
          this.ProfileService.GetPropertyProfileAnswer(gparams2).subscribe(
            (x: any) => {
              console.log("promis", x);
              if (x.status == true) {
                let records = x.data.getPropertyProfileAnswer[0];
                console.log("records", records);

                this.items = this.incidentExtrainfo.get("items") as FormArray;
                records.forEach((element) => {
                  let index = this.items.value.findIndex(
                    (x) => x.CustomFormElementId == element.FormElementId
                  );
                  if (index != -1) {
                    if (
                      this.items.controls[index].get("ElementTypeId").value == 6
                    ) {
                      if (element.Answer != "") {
                        let time = element.Answer.split("||");
                        if (time.length == 2) {
                          let dt = new Date(time[0]).toISOString();
                          this.items.controls[index].patchValue({ Answer: dt });
                          this.items.controls[index].patchValue({
                            Time: time[1],
                          });
                        }
                      }
                    } else if (
                      this.items.controls[index].get("ElementTypeId").value == 7
                    ) {
                      if (element.Answer == "") {
                      } else if (element.Answer == null) {
                      } else {
                        this.items.controls[index].patchValue({
                          Answer: element.Answer,
                        });
                        console.log("checkind", this.checkBoxItems);
                      }
                    } else if (
                      this.items.controls[index].get("ElementTypeId").value == 9
                    ) {
                      if (element.Answer != "") {
                        this.vaulable = true;
                        // this.items.controls[index].patchValue({ Answer: element.Answer });
                        let file = element.Answer.split("/");
                        const url = environment.imagePath;
                        let dwn = url + element.Answer;
                        console.log("dwn", dwn);
                        this.items.controls[index].patchValue({
                          files: file[2],
                        });
                        this.items.controls[index].patchValue({
                          download: dwn,
                        });
                      }
                    } else {
                      this.items.controls[index].patchValue({
                        Answer: element.Answer,
                      });
                    }
                  }
                });
                if (x.data.getPropertyProfileAnswer[0].length != 0) {
                  this.updtaebutton = true;
                  this.savebutton = false;
                }
              }
            }
          );
        }
      });
      setTimeout(() => {
        this.showLoader = false;
      }, 3500);
    }, 500);
    // },2000)
  }

  certifylist = [];
  Certifyallupdated() {
    this.showLoader = true;
    if (this.getCustomFormDetailsByPropertyId.length != 0) {
      this.getcustomelementlist.forEach((element) => {
        this.certifylist.push({
          PropertyId: this.propertyID,
          CustomFormGroupId: this.CustomFormGroupId,
          CustomFormId: element.CustomFormId,
        });
      });
    } else {
      this.showLoader = false;
    }
    if (this.certifylist.length == 0) {
      this.tostre.error("Property Profile Records List Empty.");
      this.showLoader = false;
    } else {
      this.ProfileService.UpdatePropertyProfileLog(this.certifylist).subscribe(
        (res) => {
          if (res.status == true) {
            this.tostre.success("Certify all updated  successfully.");
            const params = {
              PropertyId: this.propertyID,
            };
            this.ProfileService.GetCustomFormDetailsByPropertyId(
              params
            ).subscribe((res) => {
              if (res.status == true) {
                setTimeout(() => {
                  this.showLoader = false;
                }, 3000);
                this.PropertyIdentNumber =
                  res.data.getCustomFormDetailsByPropertyId[0].PropertyIdentNumber;
                this.SubPropertyUnit =
                  res.data.getCustomFormDetailsByPropertyId[0].SubPropertyUnit;
                this.CustomFormGroupId =
                  res.data.getCustomFormDetailsByPropertyId[0].CustomFormGroupId;
                this.Frequency =
                  res.data.getCustomFormDetailsByPropertyId[0].Frequency;
                this.NextUpdateDateTime =
                  res.data.getCustomFormDetailsByPropertyId[0].NextUpdateDateTime;
                this.updateCustomFormAnswers(2);
              }
            });
          }
          this.certifylist = [];
        }
      );
    }
  }

  handleFileInput(files: FileList) {
    this.fileToUpload = files.item(0);
  }

  // openFile(event) {
  //   console.log('event',event);
  //   this.vaulable=false;
  //   let fileList: FileList = event.target.files;
  //   if (fileList.length > 0) {
  //     let file: File = fileList[0];
  //     let formData: FormData = new FormData();
  //     formData.append('uploadFile', file, file.name);

  //     console.log('formdata',formData)
  //   }
  // }

  openFile(event) {
    console.log("workq", event);
    this.vaulable = false;
    var files = event.target.files;
    var file = files[0];
    this.filename = files[0].name;
    console.log("filename", this.filename);
    if (files && file) {
      var reader = new FileReader();

      reader.onload = this.handleFile.bind(this);

      reader.readAsBinaryString(file);
    }
  }

  handleFile(event) {
    var binaryString = event.target.result;
    this.base64textString = btoa(binaryString);
    console.log(btoa(binaryString));
  }

  checkProperty() {
    if (this.propertyID) {
      return true;
    } else {
      this.tostre.error("Please first select a Company.", "", {
        positionClass: "toast-top-right",
      });
      // }).then((result) => {
      this.router.navigate([
        "products/administration/propertymanagement/propertydetail",
      ]);
      //});
      return false;
    }
  }

  /**
   *
   * @param event Validate so time can input only number
   */
  numberOnly(event: any): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  noenter(event: any): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    return false;
  }

  getTime() {
    this.TimeZoneOffset = this.UserData[0].TimeZoneOffset;
    console.log("lakhantime", this.TimeZoneOffset);
    const now = this.calcTime(this.TimeZoneOffset);
    var timeList = [];
    for (let i = 0; i < 20; i++) {
      now.setMinutes(now.getMinutes() - 1);
      const time =
        ("0" + now.getHours()).slice(-2) +
        "" +
        ("0" + now.getMinutes()).slice(-2);
      timeList.push(time);
    }
    this.timeList = timeList;
  }

  calcTime(offset) {
    // create Date object for current location
    let date = new Date();
    // convert to msec
    // add local time zone offset
    // get UTC time in msec
    let utc = date.getTime() + date.getTimezoneOffset() * 60000;

    // create new Date object for different city
    // using supplied offset
    let propertyDate = new Date(utc + 3600000 * offset);
    return propertyDate;
  }

  changeFile(event) {
    this.value = event.target.files;
    console.log("eventtarget", this.value);
  }

  answer1 = [];
  checkboxChange(event: MatCheckboxChange, index) {
    console.log("index", index);
    this.items = this.incidentExtrainfo.get("items") as FormArray;
    if (event.checked == true) {
      console.log("lakhanm");
      let array = this.items.controls[index].value.Answer
        ? this.items.controls[index].value.Answer.split(",")
        : [];
      if (array.length != 0) {
        this.answer = this.items.controls[index].value.Answer.split(",");
      } else {
        this.answer = [];
      }
      this.answer.push(event.source.value.trim());
      let y = this.incidentExtrainfo
        .get("items")
        ["controls"][index]["controls"]["Answer"].setValue(
          this.answer.join(",")
        );
      console.log(y);
      debugger;
      // this.incidentExtrainfo.get("items")[index];
    } else {
      this.answer = this.items.controls[index].value.Answer
        ? this.items.controls[index].value.Answer.trim().split(",")
        : [];
      this.answer.forEach((element, indexs) => {
        if (element.trim() === event.source.value.trim()) {
          console.log("element", element);
          this.answer.splice(indexs, 1);

          let y = this.incidentExtrainfo
            .get("items")
            ["controls"][index]["controls"]["Answer"].setValue(
              this.answer.join(",")
            );
          console.log(y);
          // this.incidentExtrainfo
          //   .get("items")
          //   ["controls"][index]["controls"]["Answer"].setValue(this.answer);
        }
      });

      // let findIndex = this.answer.indexOf(event.source.value,0);
      // console.log("findIndex",findIndex);
      // console.log("event.source.value",event.source.value);
      // if (findIndex > -1) {
      //   console.log("lakhanl");
      //   this.answer.splice(findIndex, 1);
      // }
    }
    const array3 = [];
    let array2 = this.answer;
    let array1 = this.items.controls[index].value.CustomElementName;
    array1.forEach((element, index) => {
      array2.forEach((element1, index1) => {
        if (element.trim() == element1.trim()) {
          array3.push(element);
        }
      });
    });
    console.log("array3", array3);
    console.log("this.answer", this.answer);
    this.items.value[index].Answer = array3.join(",");
    // this.items.controls[index].Answer = this.answer.join(',');
    // this.items.controls[index].patchValue({ Answer: this.answer.join(',') });
    console.log(this.items.controls[index].value);
  }

  finallist = [];
  clicked1 = false;
  //  sabt=false;

  checkMandatoryAreFilled() {
    let bool: boolean = true;
    let index = null;
    // this.incidentExtrainfo.value.items.forEach((elem) => {
    //   debugger;
    //   if (elem.IsMandatory && !elem.Answer) {
    //     bool = false;
    //   }
    // });
    for (let i in this.incidentExtrainfo.value.items) {
      if (
        this.incidentExtrainfo.value.items[i].IsMandatory &&
        !this.incidentExtrainfo.value.items[i].Answer
      ) {
        bool = false;
        index = +i;
        break;
      }
    }

    if (bool) {
      this.incidentExtrainfo.get("Answer").setValue("true");
    }
  }
  updateCustomFormAnswers(n) {
    /** check all mandaoty feilds are saved or not */
    // this.checkMandatoryAreFilled();
    // debugger;
    this.submitted = true;
    if (n == 1) {
      this.showLoader = true;
    }
    if (this.incidentExtrainfo.invalid) {
      this.tostre.error("Plese fill mandatory fields.");
      this.showLoader = false;
    }
    if (this.incidentExtrainfo.valid) {
      this.incidentExtrainfo.value.items.forEach((element) => {
        console.log("arrayitem", this.incidentExtrainfo.value.items);
        if (element.ElementTypeId == 9) {
          element.Answer =
            "data" +
            ":" +
            "image" +
            "/" +
            "jpeg" +
            ";" +
            "base64" +
            "," +
            this.base64textString;
          this.filenames = this.filename;
        } else {
          this.filenames = "";
        }
        this.finallist.push({
          PropertyProfileId: 0,
          CustomFormTypeId: 3,
          PropertyId: this.propertyID,
          CustomFormGroupId: this.CustomFormGroupId,
          CustomFormId: this.selectedid,
          FormElementId: element.CustomFormElementId,
          FormElementDetailsId: element.CustomFormElementId,
          Answer:
            element.ElementTypeId != 6
              ? element.Answer
              : element.Answer + "||" + element.Time,
          IsAnswered:
            element.Answer != null || element.Answer != "" ? true : false,
          IsDeleted: false,
          filename: this.filenames,
        });
      });
      this.clicked1 = true;
      console.log("finallog", this.finallist);
      this.ProfileService.addCustomFormElementAnswer(this.finallist).subscribe(
        (res) => {
          if (res.status == true) {
            console.log("workgroup", this.PropertyProfileId);

            const params = {
              PropertyId: this.propertyID,
              CustomFormGroupId: this.CustomFormGroupId,
            };

            this.ProfileService.GetCustomFormListByPropertyId(params).subscribe(
              (res) => {
                this.getcustomelementlist =
                  res.data.getCustomFormListByPropertyId;
                console.log(this.getcustomelementlist);
              }
            );

            if (n == 1) {
              setTimeout(() => {
                this.showLoader = false;
              }, 3000);
              if (this.updtaebutton == true) {
                this.tostre.success("Record updated successfully.");
              } else {
                this.tostre.success("Record saved successfully.");
              }
              this.updtaebutton = true;
            }
            if (n == 3) {
              this.tostre.success("Record saved successfully.");
              this.updtaebutton = true;
            }

            this.savebutton = false;
            this.clicked1 = false;
            this.finallist = [];
          }
        }
      );
    } else {
      return;
    }
  }

  download(pdfUrl: string, pdfName: string) {
    //const pdfUrl = './assets/sample.pdf';
    //const pdfName = 'your_pdf_file';
    FileSaver.saveAs(pdfUrl, pdfName);
  }

  // GetPropertyProfileAnswer(incidentID: any) {
  //   const param = {
  //     CustomFormId: incidentID
  //   }

  // }

  // openFile(event,index){
  //   console.log('workq',event);
  //   this.vaulable=false;
  //   var files = event.target.files;
  //   var file = files[0];
  //   var filename=files[0].name;
  //   if(filename=='')
  //   {
  //     this.items.controls[index].patchValue({ filename: '' });
  //   }
  //   else
  //   {
  //   this.items.controls[index].patchValue({ filename: filename });
  //   }
  //   console.log("filename",this.filename)
  //   if (files && file) {
  //     var reader = new FileReader();

  //     reader.onload =this.handleFile.bind(this,index);

  //     reader.readAsBinaryString(file);
  // }

  // }

  // handleFile(event,index) {
  //  var binaryString = event.target.result;
  //         var base64textString= btoa(binaryString);
  //         var records='data'+':'+'image'+'/'+'jpeg'+';'+'base64'+','+base64textString;
  //         this.items.controls[index].patchValue({ Answer: records });
  // }

  exportToPdf() {
    const obj1 = {
      PropertyId: this.propertyID,
      CustomFormGroupId: this.CustomFormGroupId,
    };
    const obj = {
      PropertyId: this.propertyID,
    };

    this.ProfileService.GetPropertyProfileDetails(obj1).subscribe((res) => {
      this.ProfileService.GetCustomFormDetailsByPropertyId(obj).subscribe(
        (res1) => {
          if (res.data.getPropertyProfileDetails[0].length != 0) {
            this.convertPdf(res, res1);
            this.tostre.success("Downloaded Successfully.");
          } else {
            this.tostre.error("Property Profile Sheet is Empty.");
          }
        }
      );
    });
  }

  async convertPdf(obj1, obj2) {
    let obj = obj1.data.getPropertyProfileDetails[0];
    console.log("lakhan", obj);
    console.log("sharma", obj2);
    let parserQuest = [];
    let parserQuest1 = [];
    let d = new Date();
    this.currentdate =
      d.getMonth() + 1 + "/" + d.getDate() + "/" + d.getFullYear();

    let PropertyDetails = obj2.data.getCustomFormDetailsByPropertyId[0];

    console.log("PropertyDetails-->>", PropertyDetails);

    // let y = obj.forEach((elem, index) => {
    //   elem.Name$ = elem.CustomFormAnswer[0].LastModifiedBy === undefined ? '' : elem.CustomFormAnswer[0].LastModifiedBy
    // })

    let x = obj.map((elem, index) => {
      return [
        {
          margin: [-34, 0, 0, 2],
          layout: {
            hLineWidth: function (i, node) {
              return i === 0 || i === node.table.body.length ? 1.5 : 1.5;
            },
            vLineWidth: function (i, node) {
              return i === 0 || i === node.table.widths.length ? 1.5 : 1.5;
            },
            hLineColor: function (i, node) {
              return i === 0 || i === node.table.body.length
                ? "lightgrey"
                : "lightgrey";
            },
            vLineColor: function (i, node) {
              return i === 0 || i === node.table.widths.length
                ? "lightgrey"
                : "lightgrey";
            },
          },
          style: {
            borderColor: "grey",
          },
          table: {
            widths: [572],
            body: [
              [
                {
                  layout: "noBorders",
                  table: {
                    widths: [320, 190],
                    body: [
                      [
                        {
                          text: elem.Title,
                          style: {
                            fontSize: 13,
                          },
                          margin: [28, 0, 0, 0],
                        },
                        {
                          text: `Last Update: ${elem.LastModifiedDate} By: ${elem.LastModifiedBy}`,
                          style: {
                            color: "grey",
                          },
                          margin: [60, 2, -60, 0],
                        },
                      ],
                    ],
                  },
                },
              ],
              [
                elem.CustomFormAnswer.map((elem1, index1) => {
                  if (elem1.ElementTypeId == 5) {
                    if (elem1.Answer != "" && elem1.Answer != null) {
                      let d = new Date(elem1.Answer);
                      let d1 =
                        d.getMonth() +
                        1 +
                        "/" +
                        d.getDate() +
                        "/" +
                        d.getFullYear();
                      elem1.Answer = d1;
                    } else {
                      elem1.Answer = elem1.Answer;
                    }
                  } else if (elem1.ElementTypeId == 6) {
                    if (elem1.Answer != "" && elem1.Answer != null) {
                      let time = elem1.Answer.split("||");
                      let d = new Date(time[0]);
                      let d1 =
                        d.getMonth() +
                        1 +
                        "/" +
                        d.getDate() +
                        "/" +
                        d.getFullYear() +
                        "," +
                        time[1];
                      elem1.Answer = d1;
                    } else {
                      elem1.Answer = elem1.Answer;
                    }
                  } else if (elem1.ElementTypeId == 9) {
                    if (elem1.Answer != "" && elem1.Answer != null) {
                      let file = elem1.Answer.split("/");
                      if (file[0] == "data" + ":" + "image") {
                        elem1.Answer = "";
                      }
                      elem1.Answer = file[2];
                    } else {
                      elem1.Answer = elem1.Answer;
                    }
                  } else if (elem1.ElementTypeId == 7) {
                    if (elem1.Answer != "" && elem1.Answer != null) {
                      let check = elem1.Answer.split(",");
                      elem1.Answer = check.join(", ");
                    }
                  } else {
                    elem1.Answer = elem1.Answer;
                  }
                  return {
                    layout: "noBorders",
                    table: {
                      widths: [490],
                      body: [
                        [
                          {
                            text: elem1.ElementName,
                            style: {
                              bold: true,
                              fontSize: 10,
                            },
                            margin: [28, 5, 0, 0],
                          },
                        ],
                        [
                          {
                            text: elem1.Answer,
                            style: {},
                            margin: [34, 0, 0, 0],
                          },
                        ],
                      ],
                    },
                  };
                }),
              ],
            ],
          },
        },
      ];
    });

    let urlPath = environment.origin;
    if (
      PropertyDetails.ImagePath === "" ||
      PropertyDetails.ImagePath === undefined ||
      PropertyDetails.ImagePath === null
    ) {
      urlPath = `${location.origin}/assets/images/imagenaBg.png`;
      // urlPath = `https://i.picsum.photos/id/866/200/200.jpg`;
    } else {
      urlPath = environment.imagePath + "users/" + PropertyDetails.ImageName;
    }
    // console.log("urlPath====>>>", urlPath);

    let propertyImageBase64 = await this.toDataUrlBase64(urlPath);
    // console.log("propertyImageBase64-->", propertyImageBase64)

    //  console.log("parserQuest", parserQuest)
    // console.log("parserQuest1", parserQuest1)

    var dd = {
      pageSize: "A4",
      // info: {
      //   // title: `${this.obj.companyDetail.CompanyName}`,
      //   // author: `${this.obj.companyDetail.CompanyName}`,
      //   subject: "All Detail of Company and work group and Company",
      //   keywords: "Company Management",
      //   creationDate: `${new Date()}`,
      // },
      content: [
        {
          alignment: "justify",
          columns: [
            {
              image: logoBase64,
              width: 150,
              height: 50,
            },
          ],
        },
        {
          text: "\n",
        },
        {
          canvas: [
            {
              type: "line",
              x1: 0,
              y1: 0,
              x2: 500,
              y2: 0,
              lineWidth: 1,
              lineColor: "lightgrey",
            },
          ],
        },
        {
          text: "\n",
        },
        {
          layout: "noBorders",
          table: {
            widths: [120, 300, 150, 150],
            body: [
              [
                {
                  image: propertyImageBase64,
                  width: 110,
                  height: 70,
                  margin: [0, 0, 0, 6],
                },
                {
                  layout: "noBorders",
                  table: {
                    widths: [500],
                    body: [
                      [
                        {
                          text: `${PropertyDetails.PropertyName} - ${PropertyDetails.PropertyIdentNumber} `,
                          style: { bold: true, fontSize: 20 },
                        },
                      ],
                      [
                        {
                          text: `${
                            PropertyDetails.SubPropertyUnit == null
                              ? ""
                              : this.subprop +
                                ": " +
                                PropertyDetails.SubPropertyUnit
                          }`,
                          style: { bold: true, fontSize: 12 },
                        },
                        // {
                        //   text: `${PropertyDetails.SubPropertyUnit==null?'Subunit':''}`,
                        //   visibility:[]
                        // },
                      ],
                      // [
                      //   {
                      //     text: `PROPERTY ID- `,
                      //     color: "grey",
                      //     bold: true,
                      //     fontSize: 10
                      //   },
                      // ],
                      [
                        {
                          layout: "noBorders",
                          table: {
                            widths: [180, 150],
                            height: [80],
                            body: [
                              // [

                              //   {
                              //     text: `Update Frequency: ${PropertyDetails.Frequency}`,
                              //     color: "#181818",
                              //     bold: true,
                              //     fontSize: 10,
                              //     margin: [292, 2, -292, 0],
                              //     },

                              // ],
                              [
                                {
                                  text: `Generated on: ${this.currentdate}`,
                                  color: "#181818",
                                  bold: true,
                                  fontSize: 10,
                                  margin: [305, 30, -305, -4],
                                },
                              ],
                            ],
                          },
                        },
                      ],
                    ],
                  },
                },
              ],
            ],
          },
        },
        {
          layout: "noBorders",
          table: {
            body: [...x],
          },
        },
      ],

      styles: {
        header: {},
        bigger: {
          fontSize: 12,
          bold: true,
        },
        normal: {
          bold: true,
        },
      },
      defaultStyle: {
        columnGap: 10,
        fontSize: 9,
      },
      colorFont: {
        bold: true,
        color: "#0x153AB",
      },
    };

    pdfMake
      .createPdf(dd)
      .download(this.generateFilename("PropertyProfileSheet", ".pdf"));
    // pdfMake.createPdf(dd).open();
    // created with actual name of property name / compant name of pdf Maker.
  }
  public generateFilename(propertyName: string, extension: string): string {
    return `${
      propertyName === "" || propertyName === undefined || propertyName === null
        ? "defaultAssignPropertyProfile"
        : propertyName
    }-${Date.now()}.${extension}`;
  }

  toDataUrlBase64(url: string) {
    const toBase64 = fetch(url)
      .then((response) => response.blob())
      .then(
        (blob) =>
          new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve(reader.result);
            reader.onerror = reject;
            reader.readAsDataURL(blob);
          })
      );

    return toBase64;
  }
}
