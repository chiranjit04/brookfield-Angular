import { TestBed } from '@angular/core/testing';

import { PropertyprofileService } from './propertyprofile.service';

describe('PropertyprofileService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PropertyprofileService = TestBed.get(PropertyprofileService);
    expect(service).toBeTruthy();
  });
});
