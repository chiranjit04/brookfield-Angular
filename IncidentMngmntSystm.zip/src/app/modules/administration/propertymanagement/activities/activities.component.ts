import { Component, OnInit, ViewChild } from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { DataSharingService } from "../dataSharing.service";
import { ActivityService } from "./activity.service";
import { Router, ActivatedRoute } from "@angular/router";
import { PropertManagementService } from "../propertyManagement.service";
import { ToastrService } from "ngx-toastr";
import * as XLSX from "xlsx";
// import { JsToPdfService } from "../jsToPdf.service";
import Swal from "sweetalert2";
import { StorageService } from "../../../../services/storage.service";
import { UserPermissionService } from "../../../../services/user-permission.service";
import { ServiceService } from "./../../service/service.service";

export interface PeriodicElement {
  column1: string;
  column2: string;
  column3: string;
  column4: string;
  column5: string;
  column6: string;
  column7: string;
  column8: string;
  column9: string;
  column10: string;
}

const ELEMENT_DATA: any = [];

@Component({
  selector: "app-activities",
  templateUrl: "./activities.component.html",
  styleUrls: ["./activities.component.scss"],
})
export class ActivitiesComponent implements OnInit {
  PropertyDetail = null;

  /****************************************************************
   * variables accroding to changes me
   */
  _propertyDetail_: any = "";
  _UserData_: any = "";
  _propertyID_: any = "";
  _propertyno_: any = "";
  _selectedProperty_: any = "";
  _SubunitName_: any = "";
  _SubPropertyUnit_: any;
  /**************************************************************** */

  /** Upload Excel start  */

  title = "read-excel-in-angular8";
  storeData: any;
  jsonData: any;
  fileUploaded: File;
  worksheet: any;
  htmlData: any;
  currentUserID: any;
  uploadedList: any = [];
  activityList: any = [];
  showUploadedList: any = false;

  constructor(
    private dataShare: DataSharingService,
    private route: Router,
    private propertyService: PropertManagementService,
    private tostre: ToastrService,
    // private jstopdf: JsToPdfService,
    public dialog: MatDialog,
    private storage: StorageService,
    public UserPermission: UserPermissionService,
    private activityService: ActivityService,
    private adminService: ServiceService
  ) {
    this.PropertyDetail = JSON.parse(this.storage.getData("PropertyDetail"));
    if (this.PropertyDetail) {
      this.PropertyID = this.PropertyDetail.PropertyID;
    }

    /********************************
     * changes for more admix fixes, not changing old functionality adding new to every small changs avoid to new isseues.
     */
    this._propertyDetail_ = JSON.parse(this.storage.getData("PropertyDetail"));
    this._UserData_ = JSON.parse(this.storage.getData("UserData"));

    if (this._propertyDetail_) {
      this._propertyID_ = this._propertyDetail_.PropertyID;
      this._propertyno_ = this._propertyDetail_.PropertyIdentNumber;
      this._selectedProperty_ = this._propertyDetail_.PropertyName;
      this._SubunitName_ = this._propertyDetail_.SubunitName;
    }

    if (this.PropertyDetail.Subdivision === "Property Subunit") {
      this._SubPropertyUnit_ =
        this.PropertyDetail.ParentPropertyName +
        " - " +
        this.PropertyDetail.ParentIdentNumber;
    }

    const params = {
      PropertyId: this._propertyID_,
    };

    /******************************** end */
  }
  PropertyID: any = 0;
  displayedColumns: string[] = [
    "ActivityName",
    "IncidentSubject",
    "Location",
    "CreatedDate",
    "CreatedBy",
    "Duration",
    "StartDateTime",
    "EndDateTime",
    "Status",
    "Action",
  ];

  displayedColumnsOne: string[] = [
    "PropertyName",
    "ActivityName",
    "ActivityDescription",
    "IncidentSubject",
    "LocationName",
    "PatrolZoneName",
    "StartTime",
    "EndTime",
    "Duration",
    "Status",
    "Message",
  ];
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  dataSource = new MatTableDataSource();
  dataSourceOne = new MatTableDataSource();


  ngOnInit() {
    if (this.checkProperty()) {
    }
    this.getactivitylist();
    // this.dataSource.sort = this.sort;
    
  }

  getactivitylist() {
    let param = {
      PropertyID: this.PropertyID,
      // "ActivityName": null
    };
    this.propertyService.getactivitylist(param).subscribe((x: any) => {
      this.dataSource = new MatTableDataSource(x.data.getActivityList);
      // console.log(x.data.getActivityList);
      this.dataSource.sort = this.sort;
      this.sort.disableClear = true;
      this.activityList = x.data.getActivityList;

    });
  }

  editActivity(activityObj, event) {
    this.route.navigate([
      "/products/administration/propertymanagement/activities/addactivity/" +
        activityObj.ActivityID,
    ]);
  }

  deleteActivity(event, activityObj) {
    event.stopPropagation();
    Swal.fire({
      // text: "Are you sure you want to delete activity?",
      text: this.adminService.deleteMsg,
      showCancelButton: true,
      width: "30%",
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes",
      cancelButtonText: "No",
    }).then((result) => {
      if (result.value) {
        // event.stopPropagation();
        let param = {
          ActivityID: +activityObj.ActivityID,
        };
        this.propertyService
          .deleteactivity(activityObj.ActivityID)
          .subscribe((x) => {
            // console.log(x);
            if (x) {
              this.getactivitylist();
              // Swal.fire("Activity deleted successfully.");
              // this.tostre.success("Activity deleted successfully.", "", {
              //   positionClass: "toast-top-right",
              // });
            } else {
              Swal.fire("Activity didn't deleted successfully.");
            }
          });
      }
    });
  }
  updatecloneactivity() {
    if (this._ActivityID == 0) {
      this.tostre.error("Please select activity.", "", {
        positionClass: "toast-top-right",
      });
      return;
    }
    let param = {
      ActivityID: this._ActivityID,
      CreatedBy: 1,
    };
    this.propertyService.updatecloneactivity(param).subscribe((x: any) => {
      this.getactivitylist();
      this.tostre.success("The Record has been saved successfully.", "", {
        positionClass: "toast-top-right",
      });
      // Swal.fire({ text: "Clone Activity created successfully." });
    });
  }
  selectedActivityID: any = false;
  _ActivityID: any = 0;
  selectedRow(event, e) {
    if (this.selectedActivityID == e.ActivityID) {
      this.selectedActivityID = false;
      this._ActivityID = 0;
    } else {
      this.selectedActivityID = e.ActivityID;
      this._ActivityID = e.ActivityID;
    }
  }

  checkProperty() {
    if (this.PropertyID) {
      return true;
    } else {
      this.tostre.error("Please first select a Company.", "", {
        positionClass: "toast-top-right",
      });
      this.route.navigate([
        "products/administration/propertymanagement/propertydetail",
      ]);

      return false;
    }
  }
  applyFilterProperty(event: Event) {
    let filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  onClose() {
    window.location.reload();
  }

  //Upload excel sheet
  openFileBrowser(event: any) {
    event.preventDefault();
    let element: HTMLElement = document.getElementById("file") as HTMLElement;
    element.click();
  }

  uploadedFile(event) {
    this.fileUploaded = event.target.files[0];
    this.readExcel();
  }
  readExcel() {
    let readFile = new FileReader();

    readFile.onload = (e) => {
      this.storeData = readFile.result;

      var data = new Uint8Array(this.storeData);

      var arr = new Array();

      for (var i = 0; i != data.length; ++i)
        arr[i] = String.fromCharCode(data[i]);

      var bstr = arr.join("");

      var workbook = XLSX.read(bstr, { type: "binary" });

      var first_sheet_name = workbook.SheetNames[1];

      this.worksheet = workbook.Sheets[first_sheet_name];

      var range = XLSX.utils.decode_range(this.worksheet["!ref"]);
      range.s.r = 2; // <-- zero-indexed, so setting to 1 will skip row 0
      this.worksheet["!ref"] = XLSX.utils.encode_range(range);

      this.readAsJson(+this.currentUserID);
    };

    readFile.readAsArrayBuffer(this.fileUploaded);
  }

  // Upload Excel End

  /** Read As Json */

  readAsJson(currentUserID) {
    this.jsonData = XLSX.utils.sheet_to_json(this.worksheet, { raw: false });
    //this.jsonData = JSON.stringify(this.jsonData);

    var arrofobj = this.jsonData;
    // this.patrolZoneImportList = this.jsonData

    var result = arrofobj.map(function (el) {
      var o = Object.assign({}, el);
      o.UserID = +currentUserID;
      // o.Status = "";
      o.Message = "";
      o.RecNo = "";
      return o;
    });
    let length = Object.keys(result).length;

    this.activityImport(result);
    // this.getPropertyPatrolZoneList(this.PropertyID, 0);
  }
  newObjArr = [];
  activityImport(obj) {
    // console.log("obj====final hit to service --->>>>", obj);
    // console.log("obj is here", obj);
    let matchProfile =
      Object.keys(obj[0]).includes("Activity Name") &&
      Object.keys(obj[0]).includes("Property Name");
    // console.log("test", matchProfile);

    if (matchProfile) {
      this.showUploadedList = true;
      if (obj.length == 0) {
        Swal.fire({
          text: "No Data Found ",
        });
        return;
      }

      for (var i = 0; i < obj.length; i++) {
        let newObj = {
          RecNo: obj[i].RecNo,
          PropertyName: obj[i]["Property Name"],
          ActivityName: obj[i]["Activity Name"],
          ActivityDescription: obj[i]["Activity Description"],
          IncidentSubject: obj[i]["Incident Subject"],
          LocationName: obj[i]["Location Name"],
          PatrolZoneName: obj[i]["Patrol Zone Name"],
          StartTime: obj[i]["Start Time"],
          EndTime: obj[i]["End Time"],
          Duration: obj[i]["Duration"],
          ActivityStatus: obj[i]["Status"],
          UserID: this.currentUserID,
          Status: null,
          Message: "",
        };
        // console.log(obj[i]);
        // console.log("what a game", newObj);
        this.newObjArr.push(newObj);
      }
      let passingArray = this.newObjArr;
      // console.log("passing array", passingArray);
      let result: any;
      this.activityService.activityLibraryImport(passingArray).subscribe(
        (res) => {
          result = res;
          if (res) {
            // console.log("Uploaded list", result.data.ActivityLibraryImport);
            this.dataSourceOne = new MatTableDataSource(
              result.data.ActivityLibraryImport
            );
            this.dataSourceOne.sort = this.sort;
            this.sort.disableClear = true;
            this.uploadedList = result.data.ActivityLibraryImport;
            // this.uploadedListForDnld = result.data.AssetImport
            this.tostre.success(
              "Processed successfully. Please check the table."
            );
          }
        },
        (error) => {
          if (error.status == 500) {
            Swal.fire({
              text: "Import Failed",
            });
          }
        }
      );
    } else {
      this.tostre.warning(
        "Uploaded Excel Sheet is Invalid. Please put the right one."
      );
    }
  }

  //Download Excel Sheet

  exportImportData(): void {
    let data = JSON.parse(JSON.stringify(this.activityList));
    let tempData = [];
    // console.log("downloaded data", data);
    data.forEach(function (item, i) {
      delete item.RecNo;
      delete item.ActivityID;
      delete item.CreatedBy;
      delete item.CreatedDate;
      delete item.IncidentSubjectID;
      delete item.IsDuplicate;
      delete item.PropertyID;
      tempData.push(item);
    });
    // tempData.forEach(data => {
    //   data.IsActive = data.IsActive ? "Active" : "Inactive"
    //   data.ShiftTypeID = data.ShiftTypeID == "1" ? "Regular" : data.ShiftTypeID == "2" ? "After" : "Before"
    // })
    // console.log("what data is going for download", tempData)
    this.activityService.exportAsExcelFile(tempData);
  }

  exportData(): void {
    // console.log("po", this.uploadedList);
    let data = JSON.parse(JSON.stringify(this.uploadedList));
    let tempData = [];
    // console.log("downloaded dataF", data);
    data.forEach(function (item, i) {
      delete item.RecNo;
      tempData.push(item);
    });
    // tempData.forEach(data => {
    //   data.Status = data.Status ? "Active" : "Inactive"
    // })
    // console.log("what data is going for download", tempData);
    this.activityService.exportExcelFile(tempData);
  }
}
