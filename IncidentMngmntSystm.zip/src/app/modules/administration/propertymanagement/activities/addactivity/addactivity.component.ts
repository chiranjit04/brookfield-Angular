import {Component, OnInit, ViewChild} from '@angular/core';
import { MatDialog } from "@angular/material/dialog";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { DataSharingService } from "../../dataSharing.service";
import { Router,ActivatedRoute } from "@angular/router";
import { PropertManagementService } from "../../propertyManagement.service";
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { startWith, map, windowWhen } from 'rxjs/operators';
import Swal from "sweetalert2";
import { ToastrService } from 'ngx-toastr';
import { IfStmt } from '@angular/compiler';
import { parse } from 'path';
import { parseInt } from 'lodash';
import { StorageService } from '../../../../../services/storage.service';
import { ServiceService } from "./../../../service/service.service";
@Component({
  selector: 'app-addactivity',
  templateUrl: './addactivity.component.html',
  styleUrls: ['./addactivity.component.scss']
})
export class AddactivityComponent implements OnInit {
  catagorySubject: any;
  PropertyDetail = null;
  PropertyID:any=0;
  PropertyName:any='';
  _propertyno_:any='';
  addActivityForm:FormGroup;
  subjects: any;
  typeofpatrols = [
    {name:'Foot patrol', id:1},
    {name:'T3 Patrol', id:2},
    {name:'Foot patrol', id:3},
    {name:'Golf Cart Patrol', id:4},
  ]

  patrolzones = [
    {id:1, name:'Patrol Zone 1A'},
    {id:2, name:'Patrol Zone 2B'},
    {id:3, name:'Patrol Zone 3C'},
    {id:4, name:'Patrol Zone 4D'},
  ]

  constructor(  private route: Router,
               private propertyService: PropertManagementService,private formBuilder: FormBuilder,
               // private jstopdf: JsToPdfService,
                private ActivatedRoute: ActivatedRoute,
                public dialog: MatDialog,
                private tostre: ToastrService,
                private storage: StorageService,
                private adminService: ServiceService
              ) {
                  this.PropertyDetail = JSON.parse(this.storage.getData("PropertyDetail"));
                  if (this.PropertyDetail) {
                  this.PropertyID=this.PropertyDetail.PropertyID;
                  this.PropertyName = this.PropertyDetail.PropertyName;
                  this._propertyno_ = this.PropertyDetail.PropertyIdentNumber;
                  }
                  this.addActivityForm = this.formBuilder.group({
                  //_EndTime: new FormControl('', [Validators.required]),
                  catClear: new FormControl(''),
                  _ActivityName: new FormControl(''),
                  _ActivityDes: new FormControl(''),
                  _StartTime: new FormControl(''),
                  _EndTime: new FormControl(''),
                  _Duration: new FormControl(''),
                  SearchByType: new FormControl(''),
                  SearchByName: new FormControl(''),
                  allcat: new FormControl(''),
                  subcat: new FormControl(''),
                })
                  var snapshot = ActivatedRoute.snapshot;
                  this.getActivitySubjects('');
                 // this.ActivityISCICategories();
                  this.GetActivePatrolZoneList();
                  this.getactivitylist();
                  this.GetLocationCodeByCatagory();
                  this.GetCategoryName()
     }

     selectedItem = null;

     public batches = [
       {name: 'Regular', month: 'September 1', time: '10:30 AM - 5:00 PM' , slots: '20/25', color: 'blue'  },
       {name: 'Weekend', month: 'September 10', time: '10:30 AM - 5:00 PM' , slots: '15/25', color: 'red'  },
       {name: 'Weekend', month: 'August 10', time: '12:30 AM - 8:00 PM' , slots: '21/25', color: 'red'  },
     ];

  ngOnInit() {
    const ActivityID = this.ActivatedRoute.snapshot.paramMap.get("id");
    if(ActivityID){
      this.selectActivity(ActivityID)
    }
  }


  onClick(item) {
    this.selectedItem = item;
  }

  buttonLocPatrol:any='location';
  ActivityISCICategories() {
    const body = {
      ParentID: 0
    };
    this.propertyService.getActivityISCICategory(body).subscribe((res: any) => {
      console.log(res)
      this.catagorySubject = res.data.getActivityISCICategory;

    });
  }
  GetCategoryName() {
    const body = {
      PropertyID:this.PropertyID
    };
    this.propertyService.GetCategoryName(body).subscribe((res: any) => {

      this.catagorySubject = res.data.GetCategoryName[0];

    });
  }




  catName:any='';
  _SelectedCalID:any=false
  getActivitySubjects(catId) {
    this._SelectedCalID=catId
    let formData = this.addActivityForm.value;

        var catname = formData.catClear;
        //this.catName=catname.substring(0, catname.length-8);;
        this.catName=catname.substring(0, 14);;
         this.IsCatBlank=this.catName==''?true:false;;

    const body = {
      ParentID: 0,
      PropertyId:this.PropertyID
    };
    if (catId) {
      body.ParentID = catId;
    }
    this.propertyService.GetActivityISCISubject(body).subscribe((res: any) => {
      this.subjects = res.data.getActivityISCISubject;

    });
  }

  ActivityListTemp:any;
  IsSearchByType:any=false;
  selectedCatSearchID:any=false
  SearchActivityByType(catId){
   this.selectedCatSearchID=catId
    this.addActivityForm.patchValue({SearchByName: ''});
    this.addActivityForm.patchValue({_ActivityName: ''});
    this.addActivityForm.patchValue({_ActivityDes: ''});
    this.addActivityForm.patchValue({_StartTime: ''});
    this.addActivityForm.patchValue({_EndTime: ''});
    this.addActivityForm.patchValue({_Duration: ''});
    this.SelectedLocations=[];
    this.SelectedMapZonesID=[];
    this.ISCICategoryID=0;
    this.ActivityID=0;
    this.IsSearchByType=true;
    this.ActivityListTemp=[];
    this.IsRecordFoundTemp=false;
    const body = {
      ParentID: 0,
      PropertyId:this.PropertyID
    };
    if (catId) {
      body.ParentID = catId;
    }
    this.propertyService.GetActivityISCISubject(body).subscribe((res: any) => {
      var i;
      var j;
      let subjects = res.data.getActivityISCISubject;
      if(this.ActivityListNew){
        for (i = 0; i < subjects.length; i++) {
          //  let obj =  this.ActivityList.filter(x => x.IncidentSubject == subjects[i].ISCICategoryName);
            let obj =  this.ActivityListNew.filter(x => x.IncidentSubject == subjects[i].ISCICategoryName);
            if(obj.length>0){
              for (j = 0; j < obj.length; j++) {
                this.ActivityListTemp.push(obj[j]);
                this.IsRecordFoundTemp=true;
              }
            }
          }
      }


      if(this.ActivityListOld){
        var i1;
        var j1;
        for (i1 = 0; i1 < subjects.length; i1++) {
          let obj =  this.ActivityListOld.filter(x => x.IncidentSubject == subjects[i1].ISCICategoryName);
          if(obj.length>0){
            for (j1 = 0; j1 < obj.length; j1++) {
              this.ActivityListTemp.push(obj[j1]);
              this.IsRecordFoundTemp=true;
            }
          }
        }
      }




    });

   // this.IsRecordFoundTemp=this.ActivityListTemp.length>0?true:false;

  }

  IsMsgShow:any=false;
  ShowInfo(){
    this.IsMsgShow=true;
  }
  HideInfo(){
    this.IsMsgShow=false;
  }
  checkIfBankSearch(){
    this.IsSearchByBoth=false;
    this.IsSearchByType=false;
  }


  AllLocations: any;
  ActivityList:any;
  ActivityListOld:any;
  ActivityListNew:any;
  ActivityList1:any;
  GetActivePatrolZoneList() {
    const body = {
      PropertyID:this.PropertyID
    };

    this.propertyService.GetActivePatrolZoneList(body).subscribe((res: any) => {
      this.AllLocations = res.data.getActivePatrolZoneList;
    });
  }

  IsPatrol:any=true;
  allLocation(prntID, ptrlZone) {


   const ptrl = {
        PropertyID:this.PropertyID
      };
    if (ptrlZone === 'petrolzone') {
     // this.SelectedLocations=[];
      this.IsPatrol=true;
      this.propertyService.GetActivePatrolZoneList(ptrl).subscribe((res: any) => {
        this.AllLocations = res.data.getActivePatrolZoneList;
      });
    } else if (ptrlZone === 'onlyLocation') {
     // this.SelectedMapZonesID=[];
      this.IsPatrol=false;
      const body = {
        Level: '2',
        ParentID: '0',
        PropertyID:this.PropertyID
    };
    if (prntID) {
      body.ParentID = prntID;
    }
      this.propertyService.GetLocationCodeByLevel(body).subscribe((res: any) => {
        this.AllLocations = res.GetLocationCodeByLevel;
      });
    }
  }


  checkIfBank(input, subjectRef) {
    if (input === 'subject' && subjectRef.value === '') {
      this.IsCatBlank=true;
      this.getActivitySubjects('');
    }
  }

  IsCatBlank:any=true;
  ClearCategory(){
    this._SelectedCalID=false
    this.IsCatBlank=true;
    this.addActivityForm.patchValue({catClear: ''});
    this.getActivitySubjects('');
  }

  ClearLocFiltter(){
    this.allLocation('','onlyLocation');
    this.subCatagory=[];
    this.addActivityForm.patchValue({allcat: ''});
    this.addActivityForm.patchValue({subcat: ''});
  }
  Clearsubcat(){
    this.AllLocations = [];
    this.addActivityForm.patchValue({subcat: ''});
  }
  ClearCategorySearch(){
    this.selectedCatSearchID=false
    this.addActivityForm.patchValue({SearchByType: ''});
    this.addActivityForm.patchValue({SearchByName: ''});
    this.IsSearchByBoth=false;
    this.IsSearchByType=false;
  }
 ClearCategorySearchName(){
  this.SearchByVal=false
     this.IsRecordFoundTemp=this.ActivityListTemp.length>0?true:false
    if(this.IsSearchByBoth){
      this.IsSearchByBoth=false;
      this.IsSearchByType=true;
    }
    else
    this.IsSearchByType=false;
  this.addActivityForm.patchValue({SearchByName: ''});
  }




  ISCICategoryID :any=0;
  SelectedSubID:any=[];
  subjectClick(SID){
     this.ISCICategoryID=SID;
    if(!this.IsFristdvType && this.ActivityID==0){


      const index = this.SelectedSubID.indexOf(SID);
        if (index > -1) {
          this.SelectedSubID.splice(index, 1);
        }
        else{
          this.SelectedSubID.push(SID);
        }
      }
      if(this.IsFristdvType || this.ActivityID!=0){
      this.SelectedSubID=[];
      this.SelectedSubID.push(SID);
    }


  }

  SelectedMapZonesID:any=[];
  PatrolClick(SID){

    this.SelectedLocations=[];
    if(this.IsFristdvType && this.ActivityID==0){
      const index = this.SelectedMapZonesID.indexOf(SID);
      if (index > -1) {
        this.SelectedMapZonesID.splice(index, 1);
      }
      else{
        this.SelectedMapZonesID.push(SID);
      }
    }
    if(!this.IsFristdvType || this.ActivityID!=0){

      this.SelectedMapZonesID=[];
      this.SelectedMapZonesID.push(SID);
    }

  }

  SelectedLocations:any=[];
  LocationClick(SID){
    if(this.IsFristdvType && this.ActivityID==0){
      const index = this.SelectedLocations.indexOf(SID);
      if (index > -1) {
        this.SelectedLocations.splice(index, 1);
      }
      else{
        this.SelectedLocations.push(SID);
      }
    }
    if(!this.IsFristdvType || this.ActivityID!=0){
      this.SelectedLocations=[];
      this.SelectedLocations.push(SID);
    }
  // this.LocationIds+=SID+',';
  // this.SelectedLocations = this.LocationIds.split(',');

  }

  CreateActivty(){
        this.IsSearchByType=false;
        let SubjectIDs=''
        let LocationIDs=''
        let ZoneIDs=''
        if(this.SelectedSubID.length==0 ){
          this.tostre.error('Please select a subject.', '', {
            positionClass: 'toast-top-right'
          });
          return;
        }
        if(this.SelectedMapZonesID.length==0 && this.SelectedLocations.length==0){
          this.tostre.error('Please select patrol zone or location.', '', {
            positionClass: 'toast-top-right'
          });
          return;
        }

        this.SelectedSubID.forEach(function(entry) {
          SubjectIDs+=entry+',';
        });

        if(this.IsPatrol){
            this.SelectedMapZonesID.forEach(function(entry) {
              ZoneIDs+=entry+',';
            });
        }
        else{
            this.SelectedLocations.forEach(function(entry) {
              LocationIDs+=entry+',';
            });
        }

        let param= {
          "ActivityID": 0,
          "PropertyID":this.PropertyID,
          "CategoryIDs": SubjectIDs.replace(/,\s*$/, ""),//this.ISCICategoryID
          "LocationIDs": LocationIDs.replace(/,\s*$/, ""),
          "ZoneIDs": ZoneIDs.replace(/,\s*$/, ""),
          "CreatedBy": 1
      }
        this.propertyService.updateactivity(param).subscribe((x: any) => {
          this.tostre.success('The Record has been saved successfully.', '', {
            positionClass: 'toast-top-right'
          });

          this.getactivitylist();
        });
  }
  IsSearchByBoth :any=false;
  ActivityListTempBoth:any=[];
  SearchByVal :any=false;
  applyFilterProperty(event: Event) {
    this.addActivityForm.patchValue({_ActivityName: ''});
    this.addActivityForm.patchValue({_ActivityDes: ''});
    this.addActivityForm.patchValue({_StartTime: ''});
    this.addActivityForm.patchValue({_EndTime: ''});
    this.addActivityForm.patchValue({_Duration: ''});
    this.ActivityID=0;
    this.SelectedLocations=[];
    this.SelectedMapZonesID=[];
    this.ISCICategoryID=0;
     let filterValue = (event.target as HTMLInputElement).value;
     filterValue = filterValue.trim().toLowerCase();
     this.SearchByVal=filterValue
     this.IsRecordFoundTemp=false;
     this.IsRecordFoundBoth=false;

     if(filterValue!='' ){
      let formData = this.addActivityForm.value;
      var type = formData.SearchByType;

      this.IsSearchByBoth=type!=""?true:false;
      this.IsSearchByType=true;

      if(!this.IsSearchByBoth){
          this.ActivityListTemp=[];
          if(this.ActivityListNew){
            var i;
            var j;
            let obj =  this.ActivityListNew.filter(x => x.ActivityName.toLowerCase().includes(filterValue));
          //  let obj =  this.ActivityList.filter(x => x.ActivityName.toLowerCase().includes(filterValue));
            if(obj.length>0){
              for (j = 0; j < obj.length; j++) {
                this.ActivityListTemp.push(obj[j]);
                this.IsRecordFoundTemp=true;
               // this.IsRecordFoundBoth=false;
              }
            }
          }
          if(this.ActivityListOld){
            var i;
            var j1;
            let obj =  this.ActivityListOld.filter(x => x.ActivityName.toLowerCase().includes(filterValue));
          //  let obj =  this.ActivityList.filter(x => x.ActivityName.toLowerCase().includes(filterValue));
            if(obj.length>0){
              for (j1 = 0; j1 < obj.length; j1++) {
                this.ActivityListTemp.push(obj[j1]);
                this.IsRecordFoundTemp=true;
               // this.IsRecordFoundBoth=false;
              }
            }
          }
      }
      else{

          var i;
          var j;
          this.ActivityListTempBoth=[];
          let obj =  this.ActivityListTemp.filter(x => x.ActivityName.toLowerCase().includes(filterValue));
          if(obj.length>0){
            for (j = 0; j < obj.length; j++) {
              this.ActivityListTempBoth.push(obj[j]);
              this.IsRecordFoundBoth=true;
             // this.IsRecordFoundTemp=false;
            }
          }


      }


     }
   else{
    this.IsRecordFoundTemp=this.ActivityListTemp.length>0?true:false
    if(this.IsSearchByBoth){
      this.IsSearchByBoth=false;
      this.IsSearchByType=true;
    }
    else
    this.IsSearchByType=false;
   }
  //  this.IsRecordFoundTemp=this.ActivityListTemp.length>0?true:false;
  //  this.IsRecordFoundBoth=this.ActivityListTempBoth.length>0?true:false;
  }
  IsRecordFound:any=false;
  IsRecordFoundTemp:any=false;
  IsRecordFoundBoth:any=false;

_IsEditPatrol:any=true;
  getactivitylist(){
    let param = {
      "PropertyID":this.PropertyID
	    // "ActivityName": null
    }
    this.propertyService.getactivitylist(param).subscribe((x: any) => {

      this.ActivityList = x.data.getActivityList ;
      this.ActivityListOld =[];
      this.ActivityListNew==[];
      let GetIDOnPageLoad = JSON.parse(this.storage.getData("GetIDOnPageLoad"));
      if(this.ActivityList.length>0){
          this.IsRecordFound=true;

          if(GetIDOnPageLoad=='' || GetIDOnPageLoad==null){
            if(this.ActivityList.length==1 ){
              this.ActivityListNew = this.ActivityList;
              this.storage.setData("LastActivityID", JSON.stringify(0));
            }
            else{
              this.ActivityListOld = this.ActivityList;
              var last_element = this.ActivityList[0];
              this.LastActivityID=parseInt(last_element.ActivityID);+1
              this.storage.setData("LastActivityID", JSON.stringify(this.LastActivityID));
            }
            this.storage.setData("GetIDOnPageLoad", JSON.stringify('GetIDOnPageLoad'));
          }
          else{
            this.LastActivityID=parseInt(JSON.parse(this.storage.getData("LastActivityID")));
            if(this.ActivityList.length==1 ){
                if(this.LastActivityID){
                  this.ActivityListOld = this.ActivityList;
                }
                this.ActivityListNew = this.ActivityList;
            }
            else{
                  if(this.LastActivityID){
                  let obj= this.ActivityList.find(x=> x.ActivityID == this.LastActivityID);
                  if(obj){
                  let index = this.ActivityList.indexOf(obj);
                  if(index>0){
                  var last_element = this.ActivityList[index-1];
                  this.LastActivityID=parseInt(last_element.ActivityID);
                  let temp= this.ActivityList;
                  this.ActivityListNew=temp.splice(0,index);
                  this.ActivityListOld=temp;
                  }
                  else{
                   this.ActivityListOld = this.ActivityList;
                  }
                }
            }
          else{
            this.ActivityListNew = this.ActivityList;
          }


          }

          }
      }
      else
      this.IsRecordFound=false;
    });
  }


  IsAddedAbove:any=false;
  LastActivityID:any=0;
  ActivityID:any=0;
  selectActivity(ID){
    this.SelectedLocations=[];
    this.SelectedMapZonesID=[];
    this.SelectedSubID=[];
    this.addActivityForm.patchValue({catClear: ''});
    this.getActivitySubjects('');

    if(this.ActivityID!=ID){
      this.ActivityID=ID;
          let param = {
            "ActivityID":this.ActivityID
          }
          this.propertyService.getactivitybyactivityid(param).subscribe((x: any) => {
          let data =x.data.getActivityByActivityID;
          this.ActivityID=data[0].ActivityID;

          this.addActivityForm.patchValue({_ActivityName: data[0].ActivityName});
          this.addActivityForm.patchValue({_ActivityDes: data[0].ActivityDescription});
          this.addActivityForm.patchValue({_StartTime: data[0].StartTime});
          this.addActivityForm.patchValue({_EndTime: data[0].EndTime});
          this.addActivityForm.patchValue({_Duration: data[0].Duration});
          //IncidentSubject
          this.ISCICategoryID=0;
          let obj= this.subjects.find(x=> x.ISCICategoryName == data[0].IncidentSubject);

          this.ISCICategoryID=obj?obj.ISCICategoryID:0;
          this.SelectedSubID.push(this.ISCICategoryID);
          if(data[0].LocationName){
            this.IsPatrol=false;
            this.allLocation('','onlyLocation');
            this.SelectedLocations.push(data[0].LocationID);
          }

          if(data[0].PatrolZoneName){
            this.IsPatrol=true;
            this.allLocation('','petrolzone');
            this.SelectedMapZonesID.push(data[0].PatrolZoneID);
          }
     });
    }
    else{

      this.ClearText();
    }

  }

  SetTime(id){
    let formData = this.addActivityForm.value;
    var _StartTime = formData._StartTime;
    var _EndTime = formData._EndTime;
    var _Duration = formData._Duration;
    var IsCal=true;
    console.log(id)
        if(id=='_StartTime'){
          if(_StartTime.length==4){
            var FirstTwoCharacter = _StartTime.substring(0, 2);
            var LastTwoCharacter = _StartTime.substring(2, 4);
            if (FirstTwoCharacter > 23){
              IsCal=false;
              this.tostre.error('Please enter proper hours.', '', {
                positionClass: 'toast-top-right'
              });
              this.addActivityForm.patchValue({_StartTime: ''});
            }
            if (LastTwoCharacter > 59){
              IsCal=false;
              this.tostre.error('Please enter proper minutes.', '', {
                positionClass: 'toast-top-right'
              });
              this.addActivityForm.patchValue({_StartTime: ''});
            }
          }

        }

        if(id=='_EndTime'){
          if(_EndTime.length==4){
            var FirstTwoCharacter = _EndTime.substring(0, 2);
            var LastTwoCharacter = _EndTime.substring(2, 4);
            if (FirstTwoCharacter > 23){
              IsCal=false;
              this.tostre.error('Please enter proper hours.', '', {
                positionClass: 'toast-top-right'
              });
              this.addActivityForm.patchValue({_EndTime: ''});
            }
            if (LastTwoCharacter > 59){
              IsCal=false;
              this.tostre.error('Please enter proper minutes.', '', {
                positionClass: 'toast-top-right'
              });
              this.addActivityForm.patchValue({_EndTime: ''});
            }
          }
        }
        if(id=='_Duration'){

        }
        if(IsCal){
          if((_StartTime.length==4)&&(_EndTime.length==4)){
            this.StartEndDurationTimeCal();
          }
          else{
            this.addActivityForm.patchValue({_Duration: ''});
          }

        }

  }


   StartEndTimeCal(id) {
    let formData = this.addActivityForm.value;
    var txtPatrolDuration = formData._Duration;
    var ActivityStartDateTime = formData._StartTime;
    var ActivityEndDateTime =formData._EndTime;

    var ActivityStartDateTimeFirstTwoCharacter = 0;
    var ActivityStartDateTimeLastTwoCharacter = 0;
    var ActivityEndDateTimeFirstTwoCharacter = 0;
    var ActivityEndDateTimeLastTwoCharacter = 0;
    var startTimeMin = 0;
    var endTimeMin = 0;

    if (ActivityStartDateTime.length == 4) {
        ActivityStartDateTimeFirstTwoCharacter = ActivityStartDateTime.substring(0, 2);
        ActivityStartDateTimeLastTwoCharacter = ActivityStartDateTime.substring(2, 4);
        startTimeMin = (ActivityStartDateTimeFirstTwoCharacter * 60) +ActivityStartDateTimeLastTwoCharacter;
    }
    if (ActivityEndDateTime.length == 4) {
        ActivityEndDateTimeFirstTwoCharacter = ActivityEndDateTime.substring(0, 2);
        ActivityEndDateTimeLastTwoCharacter = ActivityEndDateTime.substring(2, 4);
        endTimeMin = (ActivityEndDateTimeFirstTwoCharacter * 60) + ActivityEndDateTimeLastTwoCharacter;
    }
    if (id == "_StartTime") {
        if (ActivityStartDateTime != "" && ActivityStartDateTime != "0" && ActivityStartDateTime.length == 4) {
            if (ActivityEndDateTime != "" && ActivityEndDateTime.length == 4) {
              let dur=endTimeMin-startTimeMin;
              this.addActivityForm.patchValue({_Duration: dur});
            }
            if (ActivityEndDateTime == "" && txtPatrolDuration != "" && txtPatrolDuration != "0") {
               // $("#txtEndTime").val(MinToHourMin(parseInt(startTimeMin) + parseInt($("#txtPatrolDuration").val())));
                let endtime=this.MinToHourMin(startTimeMin+ parseInt(formData._Duration))
                this.addActivityForm.patchValue({_EndTime: endtime});
            }
        }
    }
    if (id == "_EndTime") {
        if (formData._EndTime != "" && formData._EndTime != "0" && formData._EndTime.length == 4) {
            if (formData._StartTime != "" && formData._StartTime.length == 4) {
               // $("#txtPatrolDuration").val(parseInt(endTimeMin) - parseInt(startTimeMin));
                let dur=endTimeMin-startTimeMin;
                this.addActivityForm.patchValue({_Duration: dur});
            }
            if (formData._StartTime == "" && formData._Duration != "" && formData._Duration != "0") {
               // $("#txtStartTime").val(MinToHourMin(parseInt(endTimeMin) - parseInt($("#txtPatrolDuration").val())));
                let time=this.MinToHourMin(endTimeMin-parseInt(formData._Duration))
                this.addActivityForm.patchValue({_StartTime: time});

            }
        }
    }
    if (id == "_Duration") {
        if (formData._Duration != "" && formData._Duration != "0") {
            if (formData._EndTime != "" && formData._EndTime.length == 4 && formData._StartTime == "") {

              let time=this.MinToHourMin(endTimeMin-parseInt(formData._Duration))
              this.addActivityForm.patchValue({_StartTime: time});
               // $("#txtStartTime").val(MinToHourMin(parseInt(endTimeMin) - parseInt($("#txtPatrolDuration").val())));
            }
            if (formData._StartTime != "" && formData._StartTime.length == 4 && formData._EndTime == "") {
               // $("#txtEndTime").val(MinToHourMin(parseInt(startTimeMin) + parseInt($("#txtPatrolDuration").val())));
                let time=this.MinToHourMin(startTimeMin+parseInt(formData._Duration))
                this.addActivityForm.patchValue({_EndTime: time});
            }
            if (formData._StartTime != "" && formData._StartTime.length == 4 && formData._EndTime != "" && formData._EndTime.length == 4) {
               // $("#txtPatrolDuration").val(parseInt(endTimeMin) - parseInt(startTimeMin));
                let dur=endTimeMin-startTimeMin;
                this.addActivityForm.patchValue({_Duration: dur});
            }
        }
        else {
            if (formData._StartTime != "" && formData._StartTime.length == 4 && formData._EndTime != "" && formData._EndTime.length == 4) {
               //$("#txtPatrolDuration").val(parseInt(endTimeMin) - parseInt(startTimeMin));
                let dur=endTimeMin-startTimeMin;
                this.addActivityForm.patchValue({_Duration: dur});
            }
        }
    }

}
StartEndDurationTimeCal() {

  // var txtPatrolDuration = $("#txtPatrolDuration").val();
  // var ActivityStartDateTime = $("#txtStartTime").val();
  // var ActivityEndDateTime = $("#txtEndTime").val();
  let formData = this.addActivityForm.value;
  var txtPatrolDuration = formData._Duration;
  var ActivityStartDateTime = formData._StartTime;
  var ActivityEndDateTime =formData._EndTime;



  var ActivityStartDateTimeFirstTwoCharacter = ActivityStartDateTime.substring(0, 2);
  var ActivityStartDateTimeLastTwoCharacter = ActivityStartDateTime.substring(2, 4);

  var ActivityEndDateTimeFirstTwoCharacter = ActivityEndDateTime.substring(0, 2);
  var ActivityEndDateTimeLastTwoCharacter = ActivityEndDateTime.substring(2, 4);

  if (ActivityStartDateTime != "" && ActivityEndDateTime != "") {
      if (ActivityEndDateTime != '0')
          if (ActivityEndDateTime < ActivityStartDateTime) {
            this.tostre.error('End time should be greater then Start time.', '', {
              positionClass: 'toast-top-right'
            });

            this.addActivityForm.patchValue({_EndTime: ''});
          }
          else {

              var Hour = parseInt(ActivityEndDateTimeFirstTwoCharacter) - parseInt(ActivityStartDateTimeFirstTwoCharacter);
              var Minutes = parseInt(ActivityEndDateTimeLastTwoCharacter) - parseInt(ActivityStartDateTimeLastTwoCharacter);

              if (isNaN(Minutes)) {
                  Minutes = 0;
              }
              var minutes = Hour * 60;
              var totalduration = minutes + Minutes;
              this.addActivityForm.patchValue({_Duration: totalduration});
             // $("#txtPatrolDuration").val(totalduration);
              if (totalduration.toString() != '0' || totalduration.toString() != '00' || totalduration.toString() != '') {
                  // var textMsg = JsResources.Resources.MinuteDuration;
                  // textMsg = textMsg.substr(2);
                  // $("#MinuteDuration").text(totalduration + textMsg);
              }
              else{}
                 // $("#MinuteDuration").text(JsResources.Resources.MinuteDuration);
          }
  }
  else {

      var durationStartTimeDivide = txtPatrolDuration / 60;
      var durationStartTimeReminder = txtPatrolDuration % 60;
      if (durationStartTimeDivide.toString().indexOf('.') != -1) {
          var splitTimeDivide = durationStartTimeDivide.toString().split('.')[0];
          var length1 = splitTimeDivide.toString().length;
          if (length1 == 1) {
              splitTimeDivide = "0" + splitTimeDivide;
          }
          else {

          }
      }
      else {
          var length1 = durationStartTimeDivide.toString().length;
          if (length1 == 1) {
              splitTimeDivide = "0" + durationStartTimeDivide.toString();
          }
          else {

          }
      }
      var length1 = durationStartTimeReminder.toString().length;
      if (length1 == 1) {
       // durationStartTimeReminder = "0" + durationStartTimeReminder.toString();
        var durationStartTimeReminder1 = "0" + durationStartTimeReminder.toString();
      }
      else {
      }
      splitTimeDivide = splitTimeDivide + durationStartTimeReminder1.toString();

      if (ActivityStartDateTime == "") {
          if (ActivityEndDateTime != "" && txtPatrolDuration != "") {
              ActivityEndDateTimeFirstTwoCharacter = ActivityEndDateTimeFirstTwoCharacter * 60;
              var TimeSplit = parseInt(ActivityEndDateTimeFirstTwoCharacter) + parseInt(ActivityEndDateTimeLastTwoCharacter);
              if (txtPatrolDuration.toString().length == 3 || txtPatrolDuration.toString().length == 4) {
                  if (txtPatrolDuration.toString().length == 3) {
                      txtPatrolDuration = "0" + txtPatrolDuration.toString();
                  }
                  var PatrolDurationFirstTwoCharacter = txtPatrolDuration.substring(0, 2);
                  var PatrolDurationLastTwoCharacter = txtPatrolDuration.substring(2, 4);
                  PatrolDurationFirstTwoCharacter = PatrolDurationFirstTwoCharacter * 60;
                  txtPatrolDuration = parseInt(PatrolDurationFirstTwoCharacter) + parseInt(PatrolDurationLastTwoCharacter);
              }
              TimeSplit = TimeSplit - parseInt(txtPatrolDuration);
              var TimeSplitDiv = TimeSplit / 60;
              var TimeDivide = TimeSplitDiv.toString().split('.')[0];
              var TimeSplitMod = TimeSplit % 60;
              var TotalStartTime = TimeDivide.toString() + TimeSplitMod.toString();
              if (TotalStartTime.includes("-")) {
                this.tostre.error('Start time greater than 23', '', {
                  positionClass: 'toast-top-right'
                });

                  this.addActivityForm.patchValue({_StartTime: ''});
              }
              else {
                  if (TotalStartTime.toString().length == 3 || TotalStartTime.toString().length == 2) {
                      TotalStartTime = "0" + TotalStartTime.toString();
                  }
                  this.addActivityForm.patchValue({_StartTime: TotalStartTime});
                 // $("#txtStartTime").val(TotalStartTime);


                  TotalStartTime = formData._StartTime;
                  if (TotalStartTime.toString().length == 3) {
                      TotalStartTime = TotalStartTime.toString() + "0";
                    //  $("#txtStartTime").val(TotalStartTime);
                    this.addActivityForm.patchValue({_StartTime: TotalStartTime});
                  }
              }

          }
          else {
          }
      }

      if (ActivityEndDateTime == "") {
          if (ActivityStartDateTime != "" && txtPatrolDuration != "") {

              var endtime = parseInt(splitTimeDivide) + parseInt(ActivityStartDateTime);
              var endtime1='';
              if (endtime.toString().length == 3) {
                endtime1 = "0" + endtime.toString();
              }
              else {

              }
              this.addActivityForm.patchValue({_EndTime: endtime1});
            //  $("#txtEndTime").val(endtime);
          let  Endtime1 = formData._EndTime;
             // Endtime = $("#txtEndTime").val();
              var FirstTwoCharacter = Endtime1.substring(0, 2);
              var LastTwoCharacter = Endtime1.substring(2, 4);
              if (LastTwoCharacter > 59) {
                  var TimeDivide1;
                  var Endtimeplus;
                  var EndTimeDivide = LastTwoCharacter / 60;
                  var EndTimeReminder = LastTwoCharacter % 60;
                  if (EndTimeDivide.toString().indexOf('.') != -1) {
                    TimeDivide1 = EndTimeDivide.toString().split('.')[0];
                      var length11 = TimeDivide1.toString().length;
                      if (length1 == 1) {
                        TimeDivide1 = "0" + TimeDivide.toString();
                      }
                      else {
                      }
                  }
                  else {
                      var length12 = EndTimeDivide.toString().length;
                      if (length12 == 1) {
                        TimeDivide1 = "0" + EndTimeDivide.toString();
                      }
                      else {
                      }
                  }
                  Endtimeplus = parseInt(FirstTwoCharacter) + parseInt(TimeDivide1);
                  var length13 = EndTimeReminder.toString().length;
                  var EndTimeReminder1='';
                  if (length13 == 1) {
                      EndTimeReminder1 = "0" + EndTimeReminder.toString();
                  }
                  else {
                  }
                  Endtimeplus = Endtimeplus.toString() + EndTimeReminder1;

                  if (Endtimeplus.toString().length == 3) {
                      Endtimeplus = "0" + Endtimeplus.toString();
                  }
                  this.addActivityForm.patchValue({_EndTime: Endtimeplus});
                 // $("#txtEndTime").val(Endtimeplus);
              }
              else {
                this.addActivityForm.patchValue({_EndTime: Endtime1});
                 // $("#txtEndTime").val(Endtime);
              }
          }
          else {
          }
      }
  }
}



  MinToHourMin(startAllMin) {
    var hours = Math.floor(startAllMin / 60);
   var  hours1 = hours < 10 && hours > -1 ? '0' + hours.toString() : hours;
    var minutes = startAllMin % 60;
   var minutes1 = minutes < 10 && minutes > -1 ? '0' + minutes.toString() : minutes;
    return hours1.toString() + minutes1.toString();
}


  deleteActivity(event,activityObj) {
    event.stopPropagation();
    Swal.fire({
      // text: "Are you sure you want to delete activity?",
      text: this.adminService.deleteMsg,
      showCancelButton: true,
      width: "30%",
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes",
      cancelButtonText: "No",
    }).then((result) => {
      if (result.value) {

       // event.stopPropagation();
       let param = {
        "ActivityID":+activityObj.ActivityID
      }
        this.propertyService.deleteactivity( activityObj.ActivityID )
          .subscribe((x) => {
             if (x) {

              if(this.LastActivityID){

                var last_element = this.ActivityListOld[0];
                if(last_element && activityObj.ActivityID==last_element.ActivityID)
                {
                  if(this.ActivityListOld.length==1 ){
                    this.storage.setData("LastActivityID", JSON.stringify(0));
                  }
                  else{
                    var new_last_element = this.ActivityListOld[1];
                    this.LastActivityID=new_last_element.ActivityID
                    this.storage.setData("LastActivityID", JSON.stringify(new_last_element.ActivityID));
                  }

                }
              }

               this.getactivitylist();
              //  this.tostre.success('Activity deleted successfully.', '', {
              //   positionClass: 'toast-top-right'
              // });

            //  this.dataShare.changeDeleteMessage(propertyObj);
            } else {
              this.tostre.error('Activity didnt delete', '', {
                positionClass: 'toast-top-right'
              });

            }
          });
      }
    });
  }



  updateactivity(){
    this.IsSearchByType=false;
    let LocationIDs=''
        let ZoneIDs=''
        if(this.ActivityID==0 ){
          this.tostre.error('Please select a activity.', '', {
            positionClass: 'toast-top-right'
          });


          return;
        }
        if(this.SelectedSubID.length==0 ){
          this.tostre.error('Please select a subject.', '', {
            positionClass: 'toast-top-right'
          });

          return;
        }
        if(this.SelectedMapZonesID.length==0 && this.SelectedLocations.length==0){
          this.tostre.error('Please select patrol zone or location.', '', {
            positionClass: 'toast-top-right'
          });

          return;
        }
        let formData = this.addActivityForm.value;
        let starttime=formData._StartTime;
        let endttime=formData._EndTime;
        if(parseInt(formData._StartTime)==parseInt(formData._EndTime)){
          this.tostre.error('Start time and end time is same .', '', {
            positionClass: 'toast-top-right'
          });
         return;
        }
        console.log(starttime)
        // if(starttime && endttime){
        //   if((starttime.toString.length!=4)||(endttime.toString.length!=4)){
        //     this.tostre.error('Please enter proper start/end time', '', {
        //       positionClass: 'toast-top-right'
        //     });
        //    return;
        //   }
        // }
        if(this.IsPatrol){
            // this.SelectedMapZonesID.forEach(function(entry) {
            //   ZoneIDs+=entry+',';
            // });
            ZoneIDs=this.SelectedMapZonesID[0];
        }
        else{
            // this.SelectedLocations.forEach(function(entry) {
            //   LocationIDs+=entry+',';
            // });
            LocationIDs=this.SelectedLocations[0];
        }

        var startMonth = formData._startDate;
        let param= {
          "ActivityID": +this.ActivityID,
          "PropertyID":this.PropertyID,
          "CategoryIDs": +this.ISCICategoryID,
          "LocationIDs": LocationIDs,
          "ZoneIDs": ZoneIDs,
          "ActivityName": formData._ActivityName,
          "ActivityDescription": formData._ActivityDes,
          "StartDateTime": formData._StartTime,
          "EndDateTime": formData._EndTime,
          "Duration": +formData._Duration,
          "CreatedBy": 1
      }
     this.propertyService.updateactivity(param).subscribe((x: any) => {

      this.ClearText();
      this.getactivitylist();

      this.tostre.success('The Record has been save successfully.', '', {
        positionClass: 'toast-top-right'
      });


     });
   }

   ClearText(){
    this.SelectedSubID=[];
    this.SelectedLocations=[];
    this.SelectedMapZonesID=[];
    this.ISCICategoryID=0;
    this.ActivityID=0;
    this.addActivityForm.patchValue({_ActivityName: ''});
    this.addActivityForm.patchValue({_ActivityDes: ''});
    this.addActivityForm.patchValue({_StartTime: ''});
    this.addActivityForm.patchValue({_EndTime: ''});
    this.addActivityForm.patchValue({_Duration: ''});
   }
  IsFristdvType:any=true;
   ChangePos(){
    this.SelectedSubID=[];
    this.SelectedLocations=[];
    this.SelectedMapZonesID=[];
    this.ISCICategoryID=0;
     if(this.IsFristdvType){
      this.IsFristdvType=false;
        let elem=document.getElementById("dvLoc");
        elem.parentNode.insertBefore(elem,elem.parentNode.firstChild);
      }
    else{
      this.IsFristdvType=true;
      let elem=document.getElementById("dvType");
      elem.parentNode.insertBefore(elem,elem.parentNode.firstChild);
    }

     let elembtn=document.getElementById("dvbtn");
     elembtn.parentNode.insertBefore(elembtn,elembtn.parentElement.children[1]);
   }

   numberOnly(event: any): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  locationCatagory:any;
  subCatagory:any;
  GetLocationCodeByCatagory() {
    const body = {
      Level: '0',
      ParentID: '0',
      PropertyID: this.PropertyID
    };
    this.propertyService.GetLocationCodeByLevel(body).subscribe((res: any) => {
      console.log(res.GetLocationCodeByLevel);
      this.locationCatagory = res.GetLocationCodeByLevel;
    });
  }

  getSubCatagory(LocationId) {
    const subCatid = (document.getElementById('subCatId')  as HTMLInputElement);
    const body = {
      Level: '1',
      ParentID: LocationId,
      PropertyID: this.PropertyID
  };
    this.propertyService.GetLocationCodeByLevel(body).subscribe((res: any) => {
    console.log(res.GetLocationCodeByLevel);
    this.subCatagory = res.GetLocationCodeByLevel;
    if (this.subCatagory) {
      subCatid.value = '';
      this.AllLocations = [];
    }
  });
  }

  // getSubCatagory(LocationId, subLoc) {
  //   const subCatid = (document.getElementById('subCatId')  as HTMLInputElement);
  //   const body = {
  //     Level: '1',
  //     ParentID: LocationId,
  //     PropertyID: this.propertyID
  // };
  //   this.propertyService.GetLocationCodeByLevel(body).subscribe((res: any) => {
  //   console.log(res.GetLocationCodeByLevel);
  //   this.subCatagory = res.GetLocationCodeByLevel;
  //   if (this.subCatagory) {
  //     subCatid.value = '';
  //     this.AllLocations = [];
  //   }
  // });
  // }

 // this.storage.setData("LastActivityID", JSON.stringify(e));

}
