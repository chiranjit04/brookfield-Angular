import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
import { environment } from "../../../../../environments/environment";
import { Observable } from "rxjs";
// import * as logoFile from "../../propertymanagement/patrolzonemanagement/brookfieldlogo1";
import  * as logoFile from "src/assets/images/logo/brookfieldlogo";
import { Workbook } from "exceljs";
import * as fs from "file-saver";

@Injectable({
  providedIn: 'root'
})
export class ActivityService {
  Url: any;
  returnVariable: Observable<any>;

  constructor(private http: HttpClient) {
    this.Url = environment.localOrigin;
    // this.Url = 'http://localhost:1601/api/';
  }

  swap(input: any, index_A: any, index_B: any) {
    let temp = input[index_A];

    input[index_A] = input[index_B];
    input[index_B] = temp;
  }

  activityLibraryImport(obj) {
    console.log("working service")
    //const param = { CompanyID: 1, UserID: 1 };
    this.returnVariable = this.http.post(this.Url + "properymanagement/ActivityLibraryImport", obj);
    return this.returnVariable;
  }

  //Download Excel
  async exportAsExcelFile(json: any[]) {
    const title = "Shift Exported Data";
  
    const header = [
      "Property Name",
      "Activity Name",
      "Activity Description",
      "Incident Subject",
      "Location Name",
      "Patrol Zone Name",
      "Start Time",
      "End Time",
      "Duration",
      "Status"
    ];

    // Create workbook and worksheet
    const workbook = new Workbook();
    const worksheetOne = workbook.addWorksheet("Instructions");
    const worksheet = workbook.addWorksheet("Activities Library Data");
    const worksheetTwo = workbook.addWorksheet("System Pick Values");

    let objectList = [];
   
    objectList = json.map((ob) => Object.values(ob));
    console.log("Object list", objectList);
 
    // Add the Header Image
    worksheet.mergeCells("A1:B1");
    const imageRow = worksheet.getRow(1);
    imageRow.height = 80;

    // Add Image
    const logo = workbook.addImage({
      base64: logoFile.logoBase64,
      extension: "png",
    });

    worksheet.addImage(logo, {
      tl: { col: 0.5, row: 0.5 },
      ext: { width: 350, height: 85 },
    });
    const titleRow = worksheet.addRow([title]);
    titleRow.font = { name: "Calibri", family: 4, size: 16, bold: true };
    worksheet.mergeCells("A2:C2");
    worksheet.getRow(2).height = 30;
    // Add Header Row
    const headerRow = worksheet.addRow(header);

    // Set a specific row height
    headerRow.height = 42.5;

    headerRow.font = { name: "Calibri", family: 4, size: 11, bold: true };
    headerRow.alignment = {
      vertical: "middle",
      horizontal: "center",
    };

    // Cell Style : Fill and Border
    headerRow.eachCell((cell, number) => {
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "0xEAF1DD" },
        bgColor: { argb: "FF0000FF" },
      };
      cell.border = {
        top: { style: "thin" },
        left: { style: "thin" },
        bottom: { style: "thin" },
        right: { style: "thin" },
      };
    });
     worksheet.getCell("C3").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "FFFFFFFF" },
      bgColor: { argb: "FFFFFFFF" },
    };
    worksheet.getCell("D3").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "FFFFFFFF" },
      bgColor: { argb: "FFFFFFFF" },
    };
    worksheet.getCell("E3").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "FFFFFFFF" },
      bgColor: { argb: "FFFFFFFF" },
    };
    // worksheet.addRows(data);

    // Add Data and Conditional Formatting
    objectList.forEach((d) => {
       this.swap(d, 4, 8);
       this.swap(d, 3, 4);
       this.swap(d, 2, 3);
       this.swap(d, 7, 9);
      //  this.swap(d, 5, 6);
      const row = worksheet.addRow(d);
      row.alignment = { horizontal: "center", wrapText: true };
      const qty = row.getCell(4);
    });

    worksheet.getColumn(1).width = 30;
    worksheet.getColumn(2).width = 30;
    worksheet.getColumn(3).width = 30;
    worksheet.getColumn(4).width = 30;
    worksheet.getColumn(5).width = 30;
    worksheet.getColumn(6).width = 30;
    worksheet.getColumn(7).width = 30;
    worksheet.getColumn(8).width = 30;
    worksheet.getColumn(9).width = 30;
    worksheet.getColumn(10).width = 30;


    worksheet.addRow([]);

    worksheetOne.getColumn(3).width = 13;
    worksheetOne.getColumn(4).width = 13;

    // Add the Header Image
    worksheetOne.mergeCells("D1:H6");
    // Add Image
    const logoOne = workbook.addImage({
      base64: logoFile.logoBase64,
      extension: "png",
    });

    worksheetOne.addImage(logoOne, "D1:H6");
    worksheetOne.addRow([]);
    worksheetOne.getCell("C7").value =
      "Brookfield Properties Activities Library Spreadsheet";
    worksheetOne.getCell("C7").font = {
      name: "Calibri",
      family: 4,
      size: 16,
      underline: true,
      bold: true,
    };
    worksheetOne.getRow(7).height = 25;

    worksheetOne.addRow([]);
    worksheetOne.addRow([]);

    worksheetOne.getCell("B10").value =
      "Please list the Brookfield Properties, these Properties are customized to represent that company’s organizational structure and related positions of oversight.";
    worksheetOne.getCell("B10").alignment = {
      vertical: "top",
      horizontal: "left",
      wrapText: true,
    };

    worksheetOne.mergeCells("B10", "K13");

    worksheetOne.getCell("B10").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "C9DEC9" },
      bgColor: { argb: "FF0000FF" },
    };

    worksheetOne.getCell("B15").value =
      "Set of Instructions for the Spreadsheet:";
    worksheetOne.getCell("B15").font = {
      name: "Calibri",
      family: 4,
      size: 12,
      bold: true,
    };
    worksheetOne.addRow([]);
    worksheetOne.getCell("B17").value = "GENERAL INFO:";
    worksheetOne.getCell("B23").alignment = { horizontal: "center" };
    worksheetOne.getCell("B17").font = {
      name: "Calibri",
      family: 4,
      size: 12,
      bold: true,
    };
    worksheetOne.getCell("B18").value = "-";
    worksheetOne.getCell("B18").alignment = { horizontal: "right" };
    worksheetOne.getCell("C18").value =
      "Please fill in the required fields to upload data into MAXIMUS.";
    worksheetOne.addRow([]);
    worksheetOne.getCell("B20").value = "-";
    worksheetOne.getCell("B20").alignment = { horizontal: "right" };
    worksheetOne.getCell("C20").value =
      "Dropdown values will appear in each cell if there is a selection to be made,";
    worksheetOne.getCell("C21").value = " otherwise enter appropriate data.";
    worksheetOne.addRow([]);
    worksheetOne.getCell("B23").value = "-";
    worksheetOne.getCell("B23").alignment = { horizontal: "right" };
    worksheetOne.getCell("C23").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "C9DEC9" },
      bgColor: { argb: "FF0000FF" },
    };
    worksheetOne.getCell("C23").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheetOne.getCell("D23").value =
      "Headers in Light Green are Mandatory or Required fields.";
    worksheetOne.getCell("B24").value = "-";
    worksheetOne.getCell("B24").alignment = { horizontal: "right" };
    worksheetOne.getCell("C24").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "" },
      bgColor: { argb: "" },
    };
    worksheetOne.getCell("C24").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheetOne.getCell("D24").value =
      "Headers in White are not Required entry fields.";
    worksheetOne.addRow([]);
    worksheetOne.getCell("B26").value = "-";
    worksheetOne.getCell("B26").alignment = { horizontal: "right" };
    worksheetOne.getCell("C26").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "" },
      bgColor: { argb: "" },
    };
    worksheetOne.getCell("C26").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheetOne.getCell("D26").value =
      "Header cells that include a red triangle at top right provide";
    worksheetOne.getCell("D27").value =
      "information about the field when you mouse over the cell.";

    worksheetOne.addRow([]);

    //Worksheet for System Pick Values
    worksheetTwo.getCell("C2").value = "Active";
    worksheetTwo.getCell("C3").value = "InActive";

    // Generate Excel File with given name
    workbook.xlsx.writeBuffer().then((data: any) => {
      const blob = new Blob([data], {
        type:
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });
      fs.saveAs(blob, "ActivitiesLibrary.xlsx");
    });
  }


   async exportExcelFile(json: any[]) {
    const title = "Shift Exported Data";
  
    const header = [
      "Property Name",
      "Activity Name",
      "Activity Description",
      "Incident Subject",
      "Location Name",
      "Patrol Zone Name",
      "Start Time",
      "End Time",
      "Duration",
      "Activity Status",
      "Status",
      "Message"
    ];

    // Create workbook and worksheet
    const workbook = new Workbook();
    const worksheetOne = workbook.addWorksheet("Instructions");
    const worksheet = workbook.addWorksheet("Activities Library Data");
    const worksheetTwo = workbook.addWorksheet("System Pick Values");

    let objectList = [];
   
    objectList = json.map((ob) => Object.values(ob));
    console.log("Object list", objectList);
 
    // Add the Header Image
    worksheet.mergeCells("A1:B1");
    const imageRow = worksheet.getRow(1);
    imageRow.height = 80;

    // Add Image
    const logo = workbook.addImage({
      base64: logoFile.logoBase64,
      extension: "png",
    });

    worksheet.addImage(logo, {
      tl: { col: 0.5, row: 0.5 },
      ext: { width: 350, height: 85 },
    });
    const titleRow = worksheet.addRow([title]);
    titleRow.font = { name: "Calibri", family: 4, size: 16, bold: true };
    worksheet.mergeCells("A2:C2");
    worksheet.getRow(2).height = 30;
    // Add Header Row
    const headerRow = worksheet.addRow(header);

    // Set a specific row height
    headerRow.height = 42.5;

    headerRow.font = { name: "Calibri", family: 4, size: 11, bold: true };
    headerRow.alignment = {
      vertical: "middle",
      horizontal: "center",
    };

    // Cell Style : Fill and Border
    headerRow.eachCell((cell, number) => {
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "0xEAF1DD" },
        bgColor: { argb: "FF0000FF" },
      };
      cell.border = {
        top: { style: "thin" },
        left: { style: "thin" },
        bottom: { style: "thin" },
        right: { style: "thin" },
      };
    });
     worksheet.getCell("C3").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "FFFFFFFF" },
      bgColor: { argb: "FFFFFFFF" },
    };
    worksheet.getCell("D3").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "FFFFFFFF" },
      bgColor: { argb: "FFFFFFFF" },
    };
    worksheet.getCell("E3").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "FFFFFFFF" },
      bgColor: { argb: "FFFFFFFF" },
    };
    // worksheet.addRows(data);

    // Add Data and Conditional Formatting
    objectList.forEach((d) => {
        this.swap(d, 10, 11);
        this.swap(d, 11, 12);
      //  this.swap(d, 2, 3);
      //  this.swap(d, 7, 9);
      //  this.swap(d, 5, 6);
      const row = worksheet.addRow(d);
      row.alignment = { horizontal: "center", wrapText: true };
      const qty = row.getCell(4);
    });

    worksheet.getColumn(1).width = 30;
    worksheet.getColumn(2).width = 30;
    worksheet.getColumn(3).width = 30;
    worksheet.getColumn(4).width = 30;
    worksheet.getColumn(5).width = 30;
    worksheet.getColumn(6).width = 30;
    worksheet.getColumn(7).width = 30;
    worksheet.getColumn(8).width = 30;
    worksheet.getColumn(9).width = 30;
    worksheet.getColumn(10).width = 30;
    worksheet.getColumn(11).width = 30;
    worksheet.getColumn(12).width = 40;


    worksheet.addRow([]);

    worksheetOne.getColumn(3).width = 13;
    worksheetOne.getColumn(4).width = 13;

    // Add the Header Image
    worksheetOne.mergeCells("D1:H6");
    // Add Image
    const logoOne = workbook.addImage({
      base64: logoFile.logoBase64,
      extension: "png",
    });

    worksheetOne.addImage(logoOne, "D1:H6");
    worksheetOne.addRow([]);
    worksheetOne.getCell("C7").value =
      "Brookfield Properties Activities Library Spreadsheet";
    worksheetOne.getCell("C7").font = {
      name: "Calibri",
      family: 4,
      size: 16,
      underline: true,
      bold: true,
    };
    worksheetOne.getRow(7).height = 25;

    worksheetOne.addRow([]);
    worksheetOne.addRow([]);

    worksheetOne.getCell("B10").value =
      "Please list the Brookfield Properties, these Properties are customized to represent that company’s organizational structure and related positions of oversight.";
    worksheetOne.getCell("B10").alignment = {
      vertical: "top",
      horizontal: "left",
      wrapText: true,
    };

    worksheetOne.mergeCells("B10", "K13");

    worksheetOne.getCell("B10").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "C9DEC9" },
      bgColor: { argb: "FF0000FF" },
    };

    worksheetOne.getCell("B15").value =
      "Set of Instructions for the Spreadsheet:";
    worksheetOne.getCell("B15").font = {
      name: "Calibri",
      family: 4,
      size: 12,
      bold: true,
    };
    worksheetOne.addRow([]);
    worksheetOne.getCell("B17").value = "GENERAL INFO:";
    worksheetOne.getCell("B23").alignment = { horizontal: "center" };
    worksheetOne.getCell("B17").font = {
      name: "Calibri",
      family: 4,
      size: 12,
      bold: true,
    };
    worksheetOne.getCell("B18").value = "-";
    worksheetOne.getCell("B18").alignment = { horizontal: "right" };
    worksheetOne.getCell("C18").value =
      "Please fill in the required fields to upload data into MAXIMUS.";
    worksheetOne.addRow([]);
    worksheetOne.getCell("B20").value = "-";
    worksheetOne.getCell("B20").alignment = { horizontal: "right" };
    worksheetOne.getCell("C20").value =
      "Dropdown values will appear in each cell if there is a selection to be made,";
    worksheetOne.getCell("C21").value = " otherwise enter appropriate data.";
    worksheetOne.addRow([]);
    worksheetOne.getCell("B23").value = "-";
    worksheetOne.getCell("B23").alignment = { horizontal: "right" };
    worksheetOne.getCell("C23").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "C9DEC9" },
      bgColor: { argb: "FF0000FF" },
    };
    worksheetOne.getCell("C23").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheetOne.getCell("D23").value =
      "Headers in Light Green are Mandatory or Required fields.";
    worksheetOne.getCell("B24").value = "-";
    worksheetOne.getCell("B24").alignment = { horizontal: "right" };
    worksheetOne.getCell("C24").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "" },
      bgColor: { argb: "" },
    };
    worksheetOne.getCell("C24").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheetOne.getCell("D24").value =
      "Headers in White are not Required entry fields.";
    worksheetOne.addRow([]);
    worksheetOne.getCell("B26").value = "-";
    worksheetOne.getCell("B26").alignment = { horizontal: "right" };
    worksheetOne.getCell("C26").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "" },
      bgColor: { argb: "" },
    };
    worksheetOne.getCell("C26").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheetOne.getCell("D26").value =
      "Header cells that include a red triangle at top right provide";
    worksheetOne.getCell("D27").value =
      "information about the field when you mouse over the cell.";

    worksheetOne.addRow([]);

    //Worksheet for System Pick Values
    worksheetTwo.getCell("C2").value = "Active";
    worksheetTwo.getCell("C3").value = "InActive";

    // Generate Excel File with given name
    workbook.xlsx.writeBuffer().then((data: any) => {
      const blob = new Blob([data], {
        type:
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });
      fs.saveAs(blob, "ActivitiesLibrary.xlsx");
    });
  }

}
