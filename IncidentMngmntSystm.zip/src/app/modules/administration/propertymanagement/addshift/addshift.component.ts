import {Component, OnInit, ViewChild} from '@angular/core';
import { MatDialog } from "@angular/material/dialog";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { DataSharingService } from "../dataSharing.service";
import { Router,ActivatedRoute } from "@angular/router";
import { PropertManagementService } from "../propertyManagement.service";
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
// import { JsToPdfService } from "../jsToPdf.service";
import { ToastrService } from 'ngx-toastr';
import Swal from "sweetalert2";
import { StorageService } from '../../../../services/storage.service';
import { ServiceService } from "./../../service/service.service";
@Component({
  selector: 'app-addshift',
  templateUrl: './addshift.component.html',
  styleUrls: ['./addshift.component.scss']
})
export class AddshiftComponent implements OnInit {
  PropertyDetail = null;
  PropertyID:any=0;
  PropertyName:any='';
  _propertyno_:any='';
  addShiftForm:FormGroup;
  constructor(
    private dataShare: DataSharingService,
    private route: Router,
    private propertyService: PropertManagementService,
    private formBuilder: FormBuilder,
    private ActivatedRoute: ActivatedRoute,
    public dialog: MatDialog,
    private tostre: ToastrService,
    private storage: StorageService,
    private adminService: ServiceService
  ) {
    this.PropertyDetail = JSON.parse(this.storage.getData("PropertyDetail"));
    if (this.PropertyDetail) {
      this.PropertyID=this.PropertyDetail.PropertyID;
      this.PropertyName=this.PropertyDetail.PropertyName;
      this._propertyno_ = this.PropertyDetail.PropertyIdentNumber;
    }
    this.addShiftForm = this.formBuilder.group({
       
      _Durations: new FormControl(''), 
      _Periods: new FormControl(''), 
      _ShiftName: new FormControl('',[Validators.required]), 
    //  _ShiftName: new FormControl(''), 
      _StartTime:  new FormControl('',[Validators.required]), 
      _EndTime:  new FormControl('',[Validators.required]), 
      _ShiftNameSearch: new FormControl(''), 
      status :new FormControl(''), 
    })
    this.GetShiftDuration();
   this.GetShiftList();
   
  }
  get addShiftFormV() {
    return this.addShiftForm.controls;
  }
  ngOnInit() {
    const ShiftID = this.ActivatedRoute.snapshot.paramMap.get("id");
    if(ShiftID){

      this.GetShiftByID(ShiftID)
    }
    
  }
  submitted = false;
  _SearchShiftID:any=0;
  ShiftID:any=0;
  _status:any='';
 
  GetShiftByID(ID){
  this.IsEdit=true;
  if(this.ShiftID==ID){
      this.IsEdit=false;
      this.ShiftID=0;
      this.addShiftForm.patchValue({_ShiftName: ''});    
      this.addShiftForm.patchValue({_StartTime: ''});    
      this.addShiftForm.patchValue({_EndTime: ''});    
      this.ShiftTypeID=1;
      this.IsActive=true;
      this.IsTypeShow=false;
      this.ShiftDurations='0'
  }
  else{
      
        let param = {
          "ShiftID": ID,
          "PropertyID":this.PropertyID
        }
        this.propertyService.GetShiftList(param).subscribe((x: any) => {
          let data=x.data.GetShiftList[0] 
          this.ShiftID=ID;
          this.addShiftForm.patchValue({_ShiftName: data.ShiftName});    
          this.addShiftForm.patchValue({_StartTime: data.StartTime});    
          this.addShiftForm.patchValue({_EndTime: data.EndTime});    

        // this.addShiftForm.patchValue({_Periods: data.StartTime});   
          this.IsTypeShow=data.ShiftTypeID==1?false:true;
          this.selectedOne=data.ShiftTypeID==1?true:false;
          this.selectedTwo=data.ShiftTypeID==2?true:false;
          this.selectedThree=data.ShiftTypeID==3?true:false;
          this.ShiftTypeID=this.selectedOne?1:this.selectedTwo?2:3;

          this.DurationCalculation(data.StartTime,data.EndTime)

        //  let obj=this.durationList.find(x=> x.Duration == data.Duration);
        //  this.addShiftForm.patchValue({_Durations: data.Duration});  
          // this.ShiftDurationsID=obj.ShiftDurationsID;
          // let ShiftDurationsID=obj.ShiftDurationsID;
          // if(ShiftDurationsID==1){
          //   this.ShiftDurations=4;
          // }
          // else if(ShiftDurationsID==2){
          //   this.ShiftDurations=6;
          // }
          // else if(ShiftDurationsID==3){
          //   this.ShiftDurations=8;
          // }
          // else if(ShiftDurationsID==4){
          //   this.ShiftDurations=10;
          // }
          // else if(ShiftDurationsID==5){
          //   this.ShiftDurations=12;
          // }
          // else if(ShiftDurationsID==6){
          //   this.ShiftDurations=16;
          // }
          // else{
          //   this.ShiftDurations=0;
          // }
          this.IsActive=data.IsActive;
        });
      }
  
  }

  IsRecordFound:any=false;
  shiftList:any;
  GetShiftList(){
    let param = {
      "ShiftID":0,
      "PropertyID":this.PropertyID
    }
    this.propertyService.GetShiftList(param).subscribe((x: any) => {
      this.shiftList = x.data.GetShiftList ;
      this.IsSearchByType=false
      this._status = null;
      this.addShiftForm.patchValue({"status": 'null'});
      this.ShiftDurationsID=false;
      this.addShiftForm.patchValue({_Durations: ''});
      this._SearchName=false;
      this.addShiftForm.patchValue({_ShiftNameSearch: ''});
      this.TimePeriod=false;
      this.addShiftForm.patchValue({_Periods: ''});
      if(this.shiftList.length>0){
           this.IsRecordFound=true;
      }
      else
      this.IsRecordFound=false;
      console.log( this.shiftList )
    });
  }


  durationList:any;
  GetShiftDuration(){
    this.propertyService.GetShiftDuration().subscribe((x: any) => {
      console.log('duration')
      console.log(x)
      this.durationList = x.data.GetShiftDuration ;
    });
  }
 
  checkIfDurationBlank(input, DRef, subCat) {
    if (input === 'Duration' && DRef.value === '') {
      this.ShiftDurationsID=0;
      this.ShiftDurations=0;
    }
  }
  ShiftDurationsID:any=0;
  ShiftDurations:any=0;
  SelectShiftDurationsID(ShiftDurationsID){

      this.ShiftDurationsID=ShiftDurationsID;
      if(ShiftDurationsID==1){
        this.ShiftDurations=4;
      }
      else if(ShiftDurationsID==2){
        this.ShiftDurations=6;
        
      }
      else if(ShiftDurationsID==3){
        this.ShiftDurations=8;
      }
      else if(ShiftDurationsID==4){
        this.ShiftDurations=10;
      }
      else if(ShiftDurationsID==5){
        this.ShiftDurations=12;
      }
      else if(ShiftDurationsID==6){
        this.ShiftDurations=16;
      }
      else{
        this.ShiftDurations=0;
      }
  }


  TimePeriod:any=0;
  SelectTimePeriod(TimePeriod){
  this.TimePeriod=TimePeriod;
  let hrs=TimePeriod.substring(0, 2);
  let min=TimePeriod.substring(2, 4);

  let startTime=TimePeriod;
  let startHrs=parseInt(hrs)+this.ShiftDurations;

  if(startHrs>23){
    startHrs=startHrs-24;
  }
  let endTime=(startHrs<10?'0'+startHrs:startHrs)+min;


  this.addShiftForm.patchValue({_ShiftName: startTime+'-'+endTime+' hrs'});
  this.addShiftForm.patchValue({_StartTime: startTime});
  this.addShiftForm.patchValue({_EndTime: endTime});

  // this.addShiftForm.patchValue({_ShiftName: TimePeriod+' hrs'});
  // this.addShiftForm.patchValue({_StartTime: TimePeriod.substring(0, 4)});
  // this.addShiftForm.patchValue({_EndTime: TimePeriod.substring(5, 9)});

  }
  changeStatus(event:any){
    this.ClearEditMode();
    this.ShiftDurationsID=false;
    this.addShiftForm.patchValue({_Durations: ''});
    this._SearchName=false;
    this.addShiftForm.patchValue({_ShiftNameSearch: ''});
    this.TimePeriod=false;
    this.addShiftForm.patchValue({_Periods: ''});

    this.IsSearchByType=true;
    this.shiftListTemp=[];
    if(event.value == '1'){
      this._status = 1;
      this.addShiftForm.patchValue({"status": 1});
      this.shiftListTemp=  this.shiftList.filter(x => x.IsActive==true);
    } if(event.value == '3'){
      this._status = 3;
      this.addShiftForm.patchValue({"status": 3});
      this.shiftListTemp=  this.shiftList.filter(x => x.IsActive==false);
    }
    if(event.value == '2'){
      this._status = 2;
      this.addShiftForm.patchValue({"status": 2});
      this.shiftListTemp=  this.shiftList;
    }
  }


  SearchByName(event: Event) {
    this.ClearEditMode();
    this._status = null;
    this.addShiftForm.patchValue({"status": 'null'});
    this.TimePeriod=false;
    this.addShiftForm.patchValue({_Periods: ''});
    this.ShiftDurationsID=false;
    this.addShiftForm.patchValue({_Durations: ''});
    let filterValue = (event.target as HTMLInputElement).value;
    filterValue = filterValue.trim().toLowerCase();
    this._SearchName=filterValue
    if(filterValue!=''){
        this.IsSearchByType=true;
        this.shiftListTemp=[];
        var i;
        var j;
        let obj =  this.shiftList.filter(x => x.ShiftName.toLowerCase().includes(filterValue));
        if(obj.length>0){
            for (j = 0; j < obj.length; j++) {
            this.shiftListTemp.push(obj[j]);
        }
     }
    }
    else{
    this._SearchName=false;
    this.IsSearchByType=false;
    }

}
  SelectTimePeriodFillter(TimePeriod){
    this.ClearEditMode();
    this._status = null;
    this.addShiftForm.patchValue({"status": 'null'});
    this.TimePeriod=TimePeriod;
    this.ShiftDurationsID=false;
    this._SearchName=false;
    this.addShiftForm.patchValue({_Durations: ''});
    this.addShiftForm.patchValue({_ShiftNameSearch: ''});
    
    var timeFrom = TimePeriod.substring(0, 4);
    var timeTo = TimePeriod.substring(5, 9);
  //  if(LastTwoCharacter=='00'){
  //   timeTo=FirstTwoCharacter+'29'
  //  }
  //  if(LastTwoCharacter=='30'){
  //   timeTo=FirstTwoCharacter+'59'
  //  }

    if(timeFrom!=''){
     this.IsSearchByType=true;
     this.shiftListTemp=[];
     var i;
       var j;
     let obj =  this.shiftList.filter(x => x.StartTime>=parseInt(timeFrom)&&  x.StartTime<=parseInt(timeTo));
     if(obj.length>0){
       for (j = 0; j < obj.length; j++) {
         this.shiftListTemp.push(obj[j]);
       }
     }
    }
    else{
    this.IsSearchByType=false;
    }
  }
  SelectTimeDurationFillter(ShiftDurationsID){
    this.ClearEditMode();
    this._status = null;
    this.addShiftForm.patchValue({"status": 'null'});
    this.ShiftDurationsID=ShiftDurationsID;
    this.TimePeriod=false;
    this._SearchName=false;
    this.addShiftForm.patchValue({_Periods: ''});
    this.addShiftForm.patchValue({_ShiftNameSearch: ''});
   
    let  filterValue = ShiftDurationsID//.trim().toLowerCase();
    if(filterValue!=''){
     this.IsSearchByType=true;
     this.shiftListTemp=[];
     var i;
       var j;
     let obj =  this.shiftList.filter(x => x.Duration==filterValue);
     if(obj.length>0){
       for (j = 0; j < obj.length; j++) {
         this.shiftListTemp.push(obj[j]);
       }
     }
    }
    else{
    this.IsSearchByType=false;
    }
  }
  ClearSearchPeriod(){
    this.addShiftForm.patchValue({_Periods: ''});
    this.IsSearchByType=false;
    this.TimePeriod=false;
   // this.ShiftDurationsID=false;
  }
  ClearSearchDuration(){
    this.addShiftForm.patchValue({_Durations: ''});
    this.IsSearchByType=false;
   // this.TimePeriod=false;
    this.ShiftDurationsID=false;
  }

  ClearSearchName(){
    this.addShiftForm.patchValue({_ShiftNameSearch: ''});    
    this.IsSearchByType=false;
  }
  checkIfPeriodsBlank(input, TPRef, subCat) {
    if (input === 'Period' && TPRef.value === '') {
      this.TimePeriod=0;
      this.addShiftForm.patchValue({_ShiftName: ''});
      this.addShiftForm.patchValue({_StartTime: ''});
      this.addShiftForm.patchValue({_EndTime: ''});
    }
  }


  deleteShift(event,Obj) {
    event.stopPropagation();
    Swal.fire({
      // text: "Are you sure you want to delete shift?",
      text: this.adminService.deleteMsg,
      showCancelButton: true,
      width: "30%",
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes",
      cancelButtonText: "No",
    }).then((result) => {
      if (result.value) {
        
       // event.stopPropagation();
       let param = {
        "ShiftID":+ Obj.ShiftID
      }
      this.propertyService.DeleteShift(param)
      .subscribe((x) => {
        console.log(x)
         if (x) {
           this.GetShiftList();
           this.ClearEditMode()
          //Swal.fire("Shift deleted successfully.");
          // this.tostre.success('Shift deleted successfully.', '', {
          //   positionClass: 'toast-top-right'
          // });
        } else {
          Swal.fire("Shift didn't delete.");
        }
      });
  }
    });
  }
  IsActive:any=true;
  IsEdit:any=false;
  ActiveClick(){
  this.IsActive=this.IsActive?false:true;
  }
  SaveShift(){
    // if(this.TimePeriod==0){
    //   Swal.fire({text: 'Please select time period.'});
    //   return;
    // }
    let formData = this.addShiftForm.value;

    
    let starthrs=formData._StartTime.substring(0, 2);
    let endthrs=formData._EndTime.substring(0, 2);
    let starttime=formData._StartTime;
    let endttime=formData._EndTime;

    this.submitted = true
    if (this.addShiftForm.invalid) {
      this.tostre.error('Please fill all the mandatory fields.', '', {
        positionClass: 'toast-top-right'
      });
      return;
    }
    if((starttime.length!=4)||(endttime.length!=4)){
      this.tostre.error('Please enter proper start/end time', '', {
        positionClass: 'toast-top-right'
      });
     return;
    }
    if((parseInt(starthrs)>parseInt(endthrs)) && (this.selectedOne)){
      this.tostre.error('Please select type.', '', {
        positionClass: 'toast-top-right'
      });
     return;
    }
    if(parseInt(formData._StartTime)==parseInt(formData._EndTime)){
      this.tostre.error('Start time and end time is same .', '', {
        positionClass: 'toast-top-right'
      });
     return;
    }

    let param= {
      "ShiftID": this.ShiftID,
      "ShiftName": formData._ShiftName,
      "StartTime": formData._StartTime,
      "EndTime": formData._EndTime,
      "DurationID":0,// this.ShiftDurationsID,
      "TimePeriod":'',// this.TimePeriod,
      "PropertyID": this.PropertyID,
      "IsActive": this.IsActive,
      "ShiftTypeID":this.ShiftTypeID,
      "UserID": 1
  }
    this.propertyService.InsertUpdateShift(param).subscribe((x: any) => {
    //  Swal.fire({text: 'Shift saved successfully.'});
    this.tostre.success('The Record has been saved successfully.', '', {
      positionClass: 'toast-top-right'
    });
      this.submitted = false
      this.GetShiftList();
      this.ClearEditMode();
      // below code for clear fillter
    
    
    });
  }
  ClearEditMode(){
    this.IsEdit=false;
    this.ShiftID=0;
    this.addShiftForm.patchValue({_ShiftName: ''});    
    this.addShiftForm.patchValue({_StartTime: ''});    
    this.addShiftForm.patchValue({_EndTime: ''});    
    // this.addShiftForm.patchValue({_Periods:'' }); 
    // this.addShiftForm.patchValue({_Durations:'' }); 
    this.ShiftTypeID=1;
    this.IsActive=true;
    this.IsTypeShow=false;
    this.ShiftDurations='0'
  }
  AddNewShift(){
    this.ClearEditMode();
  }
  setActiveOrDeactive(e, evt) {
    evt.stopPropagation();
    let sts = e.IsActive ? "Inactivate" : "Activate";
    this.propertyService
          .ChangeShiftStatus({ ShiftID: e.ShiftID })
          .subscribe((x) => {
            this.GetShiftList();
            this.tostre.success('The Record has been saved successfully.', '', {
              positionClass: 'toast-top-right'
            });
          });
    // Swal.fire({
    //   text: "Are you sure you want to " + sts + " shift?",
    //   showCancelButton: true,
    //   width: "30%",
    //   confirmButtonColor: "#3085d6",
    //   cancelButtonColor: "#d33",
    //   confirmButtonText: "Yes",
    // }).then((result) => {
    //   if (result.value) {
    //     this.propertyService
    //       .ChangeShiftStatus({ ShiftID: e.ShiftID })
    //       .subscribe((x) => {
    //         this.GetShiftList()
    //       });
    //   }
    // });
  }



  TimePeriodList:any = [    
    {   TimePeriod:'0000-0759',TimePeriodVal:'0000-0759 hrs'},
    {   TimePeriod:'0800-1559',TimePeriodVal:'0800-1559 hrs'},
    {   TimePeriod:'1600-2359',TimePeriodVal:'1600-2359 hrs'},
    {   TimePeriod:'1000-1759',TimePeriodVal:'1000-1759 hrs'},
    {   TimePeriod:'1200-1959',TimePeriodVal:'1200-1959 hrs'},
    {   TimePeriod:'1400-2159',TimePeriodVal:'1400-2159 hrs'},
    {   TimePeriod:'1600-2359',TimePeriodVal:'1600-2359 hrs'},
];

TimePeriodList1:any = [    
  {   TimePeriod:	'0000' },
  {   TimePeriod:	'0030' },
  {   TimePeriod:	'0100' },
  {   TimePeriod:	'0130' },
  {   TimePeriod:	'0200' },
  {   TimePeriod:	'0230' },
  {   TimePeriod:	'0300' },
  {   TimePeriod:	'0330' },
  {   TimePeriod:	'0400' },
  {   TimePeriod:	'0430' },
  {   TimePeriod:	'0500' },
  {   TimePeriod:	'0530' },
  {   TimePeriod:	'0600' },
  {   TimePeriod:	'0630' },
  {   TimePeriod:	'0700' },
  {   TimePeriod:	'0730' },
  {   TimePeriod:	'0800' },
  {   TimePeriod:	'0830' },
  {   TimePeriod:	'0900' },
  {   TimePeriod:	'0930' },
  {   TimePeriod:	'1000' },
  {   TimePeriod:	'1030' },
  {   TimePeriod:	'1100' },
  {   TimePeriod:	'1130' },
  {   TimePeriod:	'1200' },
  {   TimePeriod:	'1230' },
  {   TimePeriod:	'1300' },
  {   TimePeriod:	'1330' },
  {   TimePeriod:	'1400' },
  {   TimePeriod:	'1430' },
  {   TimePeriod:	'1500' },
  {   TimePeriod:	'1530' },
  {   TimePeriod:	'1600' },
  {   TimePeriod:	'1630' },
  {   TimePeriod:	'1700' },
  {   TimePeriod:	'1730' },
  {   TimePeriod:	'1800' },
  {   TimePeriod:	'1830' },
  {   TimePeriod:	'1900' },
  {   TimePeriod:	'1930' },
  {   TimePeriod:	'2000' },
  {   TimePeriod:	'2030' },
  {   TimePeriod:	'2100' },
  {   TimePeriod:	'2130' },
  {   TimePeriod:	'2200' },
  {   TimePeriod:	'2230' },
  {   TimePeriod:	'2300' },
  {   TimePeriod:	'2330' },
 
];
selectedThree:any=false;
selectedTwo:any=false;
selectedOne:any=true;
ShiftTypeID:any=1;
SelectType(type){
  if(type==2){
    this.selectedTwo=this.selectedTwo?false:true;
    this.selectedThree=false;
  }
  if(type==3){
    this.selectedThree=this.selectedThree?false:true;
    this.selectedTwo=false;
  }
  if(!this.selectedTwo && !this.selectedThree){
    this.selectedOne=true;
  }
  else
  this.selectedOne=false;
  this.ShiftTypeID=this.selectedOne?1:this.selectedTwo?2:3;
 // this.IsTypeShow=parseInt(_StartTime)>parseInt(_EndTime)?true:false;
}
IsSearchByType:any=false;
shiftListTemp:any;
_SearchName:any;


numberOnly(event: any): boolean {
  const charCode = (event.which) ? event.which : event.keyCode;
  if (charCode > 31 && (charCode < 48 || charCode > 57)) {
    return false;
  }
  return true;
}

SetTime(id){
  let formData = this.addShiftForm.value;
  var _StartTime = formData._StartTime;
  var _EndTime = formData._EndTime;
  var _ShiftName = formData._ShiftName;
      if(id=='_StartTime'){
        if(_StartTime.length==4){
          var FirstTwoCharacter = _StartTime.substring(0, 2);
          var LastTwoCharacter = _StartTime.substring(2, 4);
          if (FirstTwoCharacter > 23){
           // Swal.fire({text: 'Please enter proper hours'});
            this.tostre.error('Please enter proper hours.', '', {
              positionClass: 'toast-top-right'
            });
            this.addShiftForm.patchValue({_StartTime: ''}); 
          }
          if (LastTwoCharacter > 59){
            this.tostre.error('Please enter proper minutes.', '', {
              positionClass: 'toast-top-right'
            });
           // Swal.fire({text: 'Please enter proper minutes'});
            this.addShiftForm.patchValue({_StartTime: ''});  
          }
        }

      }
      
      if(id=='_EndTime'){
        if(_EndTime.length==4){
          var FirstTwoCharacter = _EndTime.substring(0, 2);
          var LastTwoCharacter = _EndTime.substring(2, 4);
          if (FirstTwoCharacter > 23){
            this.tostre.error('Please enter proper hours.', '', {
              positionClass: 'toast-top-right'
            });
            this.addShiftForm.patchValue({_EndTime: ''}); 
          }
          if (LastTwoCharacter > 59){
            this.tostre.error('Please enter proper minutes.', '', {
              positionClass: 'toast-top-right'
            });
            this.addShiftForm.patchValue({_EndTime: ''});  
          }
        }
      }
      if(_StartTime.length==4 && _EndTime.length==4){
    // alert(_ShiftName)
        this.IsTypeShow=parseInt(_StartTime)>parseInt(_EndTime)?true:false;
        if(_ShiftName==""){
          this.addShiftForm.patchValue({_ShiftName: _StartTime+'-'+_EndTime+' hrs Shift'});
         
        }
        this.DurationCalculation(_StartTime,_EndTime)
        // else
        // this.addShiftForm.patchValue({_ShiftName:''});
      }


}
DurationCalculation(startTime,endtime){

  if(startTime.length==4 && endtime.length==4){
          var startHrs = startTime.substring(0, 2);
          var startMin = startTime.substring(2, 4);
          let startTotMin=(parseInt(startHrs)*60)+parseInt(startMin);
        
          var endHrs = endtime.substring(0, 2);
          var endMin = endtime.substring(2, 4);
          let endTotMin=(parseInt(endHrs)*60)+parseInt(endMin);
       
          if(parseInt(startTime)<parseInt(endtime)){
          let DiffInMin=endTotMin-startTotMin;
          var hours = Math.floor(DiffInMin / 60);  
          var minutes = DiffInMin % 60;
          var hrs=hours<10?'0'+hours:hours.toString()
          var minut=minutes<10?'0'+minutes:minutes
          this.ShiftDurations= hrs.toString()+ minut.toString(); 
         }
         if(parseInt(endtime)<parseInt(startTime)){
           let m=1440-startTotMin
          let DiffInMin=m+endTotMin;
          var hours = Math.floor(DiffInMin / 60);  
          var minutes = DiffInMin % 60;
          var hrs=hours<10?'0'+hours:hours.toString()
          var minut=minutes<10?'0'+minutes:minutes
          this.ShiftDurations= hrs.toString()+ minut.toString(); 
         }
       }
       else
   this.ShiftDurations='0'
 }
GoToTable(){
  this.route.navigate([
    "products/administration/propertymanagement/shift",
  ]);
}




IsTypeShow:any=false;
CheckIsTypeShow(){

}




}
