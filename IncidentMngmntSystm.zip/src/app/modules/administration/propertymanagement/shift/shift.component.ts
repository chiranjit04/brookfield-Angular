import { Component, OnInit, ViewChild } from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import * as XLSX from "xlsx";
import { DataSharingService } from "../dataSharing.service";
import { Router, ActivatedRoute } from "@angular/router";
import { PropertManagementService } from "../propertyManagement.service";
import { StorageService } from "../../../../services/storage.service";
// import { JsToPdfService } from "../jsToPdf.service";
import Swal from "sweetalert2";
import { ToastrService } from "ngx-toastr";
import { UserPermissionService } from "../../../../services/user-permission.service";
import { ServiceService } from "./../../service/service.service";

export interface PeriodicElement {
  shiftname: string;
  starttime: string;
  endtime: string;
  duration: string;
  type: string;
  action: string;
}

const ELEMENT_DATA: any = [
  {
    ShiftName: "",
    StartTime: "",
    EndTime: "",
    Duration: "",
    ShiftTypeID: "",
    action: "",
  },
];

@Component({
  selector: "app-shift",
  templateUrl: "./shift.component.html",
  styleUrls: ["./shift.component.scss"],
})
export class ShiftComponent implements OnInit {
  displayedColumns: string[] = [
    "ShiftName",
    "StartTime",
    "EndTime",
    "Duration",
    "ShiftTypeID",
    "action",
  ];
  displayedColumnsOne: string[] = [
    "PropertyName",
    "ShiftName",
    "StartTime",
    "EndTime",
    "Duration",
    "ShiftType",
    "ShiftStatus",
    "Status",
    "Message",
  ];

  dataSource = new MatTableDataSource(ELEMENT_DATA);
  dataSourceOne = new MatTableDataSource();

  /****************************************************************
   * variables accroding to changes me
   */
  _propertyDetail_: any = "";
  _UserData_: any = "";
  _propertyID_: any = "";
  _propertyno_: any = "";
  _selectedProperty_: any = "";
  _SubunitName_: any = "";
  _SubPropertyUnit_: any;
  /**************************************************************** */

  @ViewChild(MatSort, { static: false }) sort: MatSort;
  PropertyDetail = null;
  PropertyID: any = 0;
  PropertyName: any = "";
  uploadfileList: any = false;
  selectedItem: any = false;

  /** Upload Excel start  */

  title = "read-excel-in-angular8";
  storeData: any;
  jsonData: any;
  fileUploaded: File;
  worksheet: any;
  htmlData: any;
  currentUserID: any;
  shiftList: any = [];
  uploadedList: any = [];

  constructor(
    private dataShare: DataSharingService,
    private route: Router,
    private propertyService: PropertManagementService,
    // private jstopdf: JsToPdfService,
    public dialog: MatDialog,
    private tostre: ToastrService,
    private storage: StorageService,
    public UserPermission: UserPermissionService,
    private adminService: ServiceService
  ) {
    this.PropertyDetail = JSON.parse(this.storage.getData("PropertyDetail"));
    if (this.PropertyDetail) {
      // console.log(this.PropertyDetail);
      this.PropertyID = this.PropertyDetail.PropertyID;
      this.PropertyName = this.PropertyDetail.PropertyName;
    }

    /********************************
     * changes for more admix fixes, not changing old functionality adding new to every small changs avoid to new isseues.
     */
    this._propertyDetail_ = JSON.parse(this.storage.getData("PropertyDetail"));
    this._UserData_ = JSON.parse(this.storage.getData("UserData"));
    this.currentUserID = this._UserData_[0].UserID;

    if (this._propertyDetail_) {
      this._propertyID_ = this._propertyDetail_.PropertyID;
      this._propertyno_ = this._propertyDetail_.PropertyIdentNumber;
      this._selectedProperty_ = this._propertyDetail_.PropertyName;
      this._SubunitName_ = this._propertyDetail_.SubunitName;
    }

    if (this._propertyDetail_.Subdivision === "Property Subunit") {
      this._SubPropertyUnit_ =
        this._propertyDetail_.ParentPropertyName +
        " - " +
        this._propertyDetail_.ParentIdentNumber;
    }

    const params = {
      PropertyId: this._propertyID_,
    };

    // this.propertyService
    //   .GetCustomFormDetailsByPropertyId(params)
    //   .subscribe((res) => {
    //     if (res.data.getCustomFormDetailsByPropertyId.length != "") {
    //       this._SubPropertyUnit_ =
    //         res.data.getCustomFormDetailsByPropertyId[0].SubPropertyUnit;
    //     }
    //   });
    /******************************** end */
  }
  ngOnInit() {
    if (this.checkProperty()) {
      this.GetShiftList();
    }
  }
  checkProperty() {
    if (this.PropertyID) {
      return true;
    } else {
      this.tostre.error("Please first select a Company.", "", {
        positionClass: "toast-top-right",
      });
      this.route.navigate([
        "products/administration/propertymanagement/propertydetail",
      ]);

      return false;
    }
  }
  GetShiftList() {
    let param = {
      ShiftID: 0,
      PropertyID: this.PropertyID,
    };
    this.propertyService.GetShiftList(param).subscribe((x: any) => {
      // console.log(x);
      this.shiftList = x.data.GetShiftList;
      this.dataSource = new MatTableDataSource(x.data.GetShiftList);
      this.dataSource.sort = this.sort;
      this.sort.disableClear = true;
    });
  }

  deleteShift(event, Obj) {
    event.stopPropagation();
    Swal.fire({
      // text: "Are you sure you want to delete shift?",
      text: this.adminService.deleteMsg,
      showCancelButton: true,
      width: "30%",
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes",
      cancelButtonText: "No",
    }).then((result) => {
      if (result.value) {
        // event.stopPropagation();
        let param = {
          ShiftID: +Obj.ShiftID,
        };
        this.propertyService.DeleteShift(param).subscribe((x) => {
          // console.log(x);
          if (x) {
            this.GetShiftList();
            // Swal.fire("Shift deleted successfully.");
            // this.tostre.success("Shift deleted successfully.", "", {
            //   positionClass: "toast-top-right",
            // });
          } else {
            Swal.fire("Shift didn't delete.");
          }
        });
      }
    });
  }

  editShift(event, Obj) {
    this.route.navigate([
      "/products/administration/propertymanagement/shift/addshift/" + Obj.ShiftID,
    ]);
  }
  applyFilterProperty(event: Event) {
    let filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  //Upload excel sheet
  openFileBrowser(event: any) {
    event.preventDefault();
    let element: HTMLElement = document.getElementById("file") as HTMLElement;
    element.click();
  }

  uploadedFile(event) {
    // this.uploadTableShow = true;
    // this.OriginalTableNotShow = true;
    // this.isShown = true;
    this.fileUploaded = event.target.files[0];
    this.readExcel();
  }
  readExcel() {
    let readFile = new FileReader();

    readFile.onload = (e) => {
      this.storeData = readFile.result;

      var data = new Uint8Array(this.storeData);

      var arr = new Array();

      for (var i = 0; i != data.length; ++i)
        arr[i] = String.fromCharCode(data[i]);

      var bstr = arr.join("");

      var workbook = XLSX.read(bstr, { type: "binary" });

      var first_sheet_name = workbook.SheetNames[1];

      this.worksheet = workbook.Sheets[first_sheet_name];

      var range = XLSX.utils.decode_range(this.worksheet["!ref"]);
      range.s.r = 2; // <-- zero-indexed, so setting to 1 will skip row 0
      this.worksheet["!ref"] = XLSX.utils.encode_range(range);

      this.readAsJson(+this.currentUserID);
    };

    readFile.readAsArrayBuffer(this.fileUploaded);
  }

  // Upload Excel End

  /** Read As Json */

  readAsJson(currentUserID) {
    this.jsonData = XLSX.utils.sheet_to_json(this.worksheet, { raw: false });
    //this.jsonData = JSON.stringify(this.jsonData);

    var arrofobj = this.jsonData;
    // this.patrolZoneImportList = this.jsonData

    var result = arrofobj.map(function (el) {
      var o = Object.assign({}, el);
      o.UserID = +currentUserID;
      // o.Status = "";
      o.Message = "";
      o.RecNo = "";
      return o;
    });
    let length = Object.keys(result).length;

    this.shiftImport(result);
    // this.getPropertyPatrolZoneList(this.PropertyID, 0);
  }
  newObjArr = [];
  shiftImport(obj) {
    // console.log("obj====final hit to service --->>>>", obj);
    // console.log("obj is here", obj);
    let matchProfile =
      Object.keys(obj[0]).includes("Shift Name") &&
      Object.keys(obj[0]).includes("Shift Type");
    // console.log("test", matchProfile);

    if (matchProfile) {
      this.uploadfileList = true;
      // this.onscreenList = false;
      if (obj.length == 0) {
        Swal.fire({
          text: "No Data Found ",
        });
        return;
      }

      for (var i = 0; i < obj.length; i++) {
        let newObj = {
          RecNo: obj[i].RecNo,
          PropertyName: obj[i]["Property Name"],
          ShiftName: obj[i]["Shift Name"],
          StartTime: obj[i]["Start Time"],
          EndTime: obj[i]["End Time"],
          Duration: obj[i]["Duration"],
          ShiftType: obj[i]["Shift Type"],
          ShiftStatus: obj[i]["Shift Status"],
          UserID: +obj[i].UserID,
          Status: obj[i]["Status"],
          Message: "",
        };
        // console.log(obj[i]);
        // console.log("what a game", newObj);
        this.newObjArr.push(newObj);
      }
      let passingArray = this.newObjArr;
      // console.log("passing array", passingArray);
      let result: any;
      this.propertyService.ShiftImport(passingArray).subscribe(
        (res) => {
          result = res;
          if (res) {
            // console.log("Uploaded list", result.data.ShiftImport);
            this.dataSourceOne = new MatTableDataSource(
              result.data.ShiftImport
            );
            this.dataSourceOne.sort = this.sort;
            this.sort.disableClear = true;
            this.uploadedList = result.data.ShiftImport;
            // this.uploadedListForDnld = result.data.AssetImport
            this.tostre.success(
              "Processed successfully. Please check the table."
            );
          }
        },
        (error) => {
          if (error.status == 500) {
            Swal.fire({
              text: "Import Failed",
            });
          }
        }
      );
    } else {
      this.tostre.warning(
        "Uploaded Excel Sheet is Invalid. Please put the right one."
      );
    }
  }

  onClose() {
    window.location.reload();
  }

  onSelectedItem(data: any) {
    if (this.selectedItem == data.ShiftID) {
      this.selectedItem = !this.selectedItem;
    } else {
      this.selectedItem = data.ShiftID;
    }
  }

  //Download Excel Sheet

  exportImportData(): void {
    let data = JSON.parse(JSON.stringify(this.shiftList));
    let tempData = [];
    // console.log("downloaded data", data);
    data.forEach(function (item, i) {
      delete item.RecNo;
      delete item.PropertyID;
      delete item.ShiftID;
      tempData.push(item);
    });
    tempData.forEach((data) => {
      data.IsActive = data.IsActive ? "Active" : "Inactive";
      data.ShiftTypeID =
        data.ShiftTypeID == "1"
          ? "Regular"
          : data.ShiftTypeID == "2"
          ? "After"
          : "Before";
    });
    // console.log("what data is going for download", tempData);
    this.propertyService.exportAsExcelFile(tempData);
  }

  exportUploadData(): void {
    let data = JSON.parse(JSON.stringify(this.uploadedList));
    let tempData = [];
    // console.log("downloaded dataF", data);
    data.forEach(function (item, i) {
      delete item.RecNo;
      delete item.UserID;
      tempData.push(item);
    });
    // tempData.forEach(data => {
    //   data.Status = data.Status ? "Active" : "Inactive"
    // })
    // console.log("what data is going for download", tempData);
    this.propertyService.exportExcelFile(tempData);
  }
}
