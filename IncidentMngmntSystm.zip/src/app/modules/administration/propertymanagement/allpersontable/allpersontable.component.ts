import { Component, OnInit, ViewChild } from "@angular/core";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { UserPermissionService } from "src/app/services/user-permission.service";
import { DataSharingService } from "../dataSharing.service";
import { PropertManagementService } from "../propertyManagement.service";
export interface keycontact {
  keycontactname: string;
  keycontactuserid: string;
  keycontactposition: string;
  keycontactcompany: string;
  keycontactsubdiv: string;
  keycontacttype: string;
  keycontactconc: string;
  keycontactaction: string;
}

const eleDataallperson: keycontact[] = [];

@Component({
  selector: "app-allpersontable",
  templateUrl: "allpersontable.component.html",
  styleUrls: ["allpersontable.component.scss"],
})
export class AllpersontableComponent implements OnInit {
  constructor(
    private data: DataSharingService,
    private propertyManagement: PropertManagementService,
    public UserPermission: UserPermissionService
  ) {}

  displayedColumnsallperson: string[] = [
    "keycontactname",
    "keycontactuserid",
    "keycontactposition",
    "ProfileName",
    "keycontactcompany",
    "PropertyORWorkGroup",
    "keycontactEmail",
    "keycontactconc",
    "keycontactaction",
  ];
  idsData;
  testData;
  dataSourceallperson = new MatTableDataSource(eleDataallperson);

  @ViewChild(MatSort, { static: true }) sort: MatSort;

  ngOnInit() {
    this.dataSourceallperson.sort = this.sort;
    this.data.allKeyPersionStream.subscribe((x: any) => {
      console.log("from me", x);
      if (typeof x == "string") return;
      this.idsData = x;
      this.dataSourceallperson = new MatTableDataSource(
        x.allData.GetPropertyAllPerson
      );
      this.dataSourceallperson.sort = this.sort;
      this.keyContactPerson(x.allData.GetPropertyAllPerson[0]);
    });
  }
  getToKeyContact(element) {
    console.log(element, this.idsData.PropertyId);
    this.propertyManagement
      .UpdatePropertyContact({
        PropertyContactId: 0,
        PropertyId: +element.PropertyId,
        UserId: +element.UserID,
        IsAssigned: 1,
      })
      .subscribe((x) => {
        this.keyContactPerson(element);
      });
  }
  keyContactPerson(element) {
    if (element == undefined) return;
    this.propertyManagement
      .GetPropertyContact({
        PropertyId: +element.PropertyId,
      })
      .subscribe((x) => {
        this.data.changeKeyContactMessage(x);
        this.testData = x.PropertyContact;
      });
  }
  setActive(element) {
    if (this.testData == null || undefined) return;
    return this.testData.find((elem) => elem.UserID == element.UserID) ==
      undefined
      ? "fas fa-circle inactive-icon"
      : "fas fa-circle active-icon";
  }
}
