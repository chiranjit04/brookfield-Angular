import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllpersontableComponent } from './allpersontable.component';

describe('AllpersontableComponent', () => {
  let component: AllpersontableComponent;
  let fixture: ComponentFixture<AllpersontableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllpersontableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllpersontableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
