import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";

@Injectable({
  providedIn: "root",
})
export class DataSharingService {
  private messageSource = new BehaviorSubject("messageSource");
  private companytableSource = new BehaviorSubject("default Message");
  private companyAssignedList = new BehaviorSubject("default message");
  private allKeyPersionList = new BehaviorSubject("default Subject");
  private keyContactList = new BehaviorSubject("keyContact");
  private changeWorkgroupList = new BehaviorSubject("workGroupStream");
  private deleteChangeList = new BehaviorSubject("default message");
  private subUnitName = new BehaviorSubject("default message");
  private propertyParam = new BehaviorSubject("default message");
  private isDataFound = new BehaviorSubject("isDataFound");
  private importedData = new BehaviorSubject("noImportedData");

  companyCurrentMessage = this.companytableSource.asObservable();
  currentMessage = this.messageSource.asObservable();
  companyAssignedListStream = this.companyAssignedList.asObservable();
  allKeyPersionStream = this.allKeyPersionList.asObservable();
  keyContactStream = this.keyContactList.asObservable();
  workGroupStream = this.changeWorkgroupList.asObservable();
  deleteChangeStream = this.deleteChangeList.asObservable();
  propertyParameter = this.propertyParam.asObservable();
  subUnitNameStream = this.subUnitName.asObservable();
  _isDataFound = this.isDataFound.asObservable();
  importedDataStream = this.importedData.asObservable();

  constructor() {}

  changeMessage(message: string) {
    this.messageSource.next(message);
  }
  changeCompanyMessage(message: any) {
    this.companytableSource.next(message);
  }
  changeCompanyAssignMessage(message: any) {
    this.companyAssignedList.next(message);
  }
  changeAllKeyPersionMessage(message: any) {
    this.allKeyPersionList.next(message);
  }
  changeKeyContactMessage(message: any) {
    this.keyContactList.next(message);
  }
  changeWorkGroupMessage(message: any) {
    this.changeWorkgroupList.next(message);
  }
  changeDeleteMessage(message: any) {
    this.deleteChangeList.next(message);
  }
  changeSubunit(message: any) {
    this.subUnitName.next(message);
  }
  changePropertyParam(message: any) {
    this.propertyParam.next(message);
  }
  checkDataFound(message: any) {
    this.isDataFound.next(message);
  }
  changeImportedData(message: any) {
    this.importedData.next(message);
  }
}
