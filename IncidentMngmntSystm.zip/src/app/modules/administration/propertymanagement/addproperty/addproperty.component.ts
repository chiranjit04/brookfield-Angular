import {
  Component,
  OnInit,
  HostListener,
  ElementRef,
  Renderer2,
  ViewChild,
} from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import {
  FormControl,
  FormGroup,
  FormBuilder,
  Validators,
} from "@angular/forms";
import { startWith, map, windowWhen } from "rxjs/operators";
import { AddPropertyService } from "./addPropert.service";
import { PropertManagementService } from "../propertyManagement.service";
import { DataSharingService } from "../dataSharing.service";
import { Router, ActivatedRoute } from "@angular/router";
import { ModeladdbusinesstypeComponent } from "./modeladdbusinesstype/modeladdbusinesstype.component";
import { AddPropertyFunctionality } from "./addPropertyFunctionality.service";
import Swal from "sweetalert2";
import { environment } from "../../../../../environments/environment";
import { ModelcompanytypeComponent } from "./modelcompanytype/modelcompanytype.component";
import { ToastrService } from "ngx-toastr";
import { StorageService } from "../../../../services/storage.service";
import { MatAutocompleteTrigger } from "@angular/material";
import { UserPermissionService } from "src/app/services/user-permission.service";
@Component({
  selector: "app-addproperty",
  templateUrl: "./addproperty.component.html",
  styleUrls: ["./addproperty.component.scss"],
})
export class AddpropertyComponent implements OnInit {
  submitted = false;
  notChange = false;
  _validWeb = true;
  _validEmail = true;
  _isPrimary = false;
  /** */
  UserData: any;
  countryCode: any = "+1";
  holdIds = {
    propertyId: null,
    propertySubId: null,
    businessId: null,
    countryId: null,
    stateId: null,
    cityId: null,
  };
  editProperty: any = false;
  listArray = {
    businessList: [],
    propertyList: [],
    countryList: [],
    stateList: [],
    cityList: [],
    countryCodeList: [],
    companySubDivisionList: [],
    companyTypeList: [],
    companyTimeList: [],
  };
  filterObj = {
    businessFilter: null,
    propertyFilter: null,
    countryFilter: null,
    stateFilter: null,
    cityFilter: null,
    countryCodeFilter: null,
    companySubDivFilter: null,
    companyTypeFilter: null,
    companyTimeFilter: null,
  };
  /**  */
  companyParam = {
    companySubDiv: null,
    CompanyTypeID: null,
  };
  companyArray: any = [];
  propertyCompany = {
    PropertyCompanyId: 0,
    PropertyId: 0,
    CompanyId: 0,
    CompanyTypeId: 0,
    UserId: null, // default because user id is 1 here login time
    IsActive: 0,
  };
  propJson;
  adTime: any;
  timeZone: number = 0;
  filteredOptions: any;
  /**headers */
  showHeader: boolean = false;
  showGoeName: string = "";
  showGOENo: string = "";
  showPropertyName: string = "";
  showPropertySubUnit: string = "";
  showButtonCancel = false;
  /*** */
  private file: File;
  private file2: File;
  addPropertyFormGroup: FormGroup;
  propertyname: any;
  assignedObject: any;
  showPropertySubUnit1: string;
  CountryID: any;
  constructor(
    private addProperty: AddPropertyService,
    private AddPropertyFormBuilder: FormBuilder,
    private propertyManagementService: PropertManagementService,
    private router: Router,
    private route: ActivatedRoute,
    public dialog: MatDialog,
    private renderer: Renderer2,
    private data: DataSharingService,
    private addProFunc: AddPropertyFunctionality,
    private tostre: ToastrService,
    private storage: StorageService,
    public UserPermission: UserPermissionService
  ) {
    this.createAddPropertyForm();
  }
  disabled = false;
  changeFile() {}
  /** */
  ngOnInit() {
    this.editProperty = false;
    this.route.paramMap.subscribe((params) => {
      this.showPropertySubUnit1 = params.get("p1");
      this.showHeader = true;
    });

    this.propJson = this.storage.getData("PropertyDetail");
    this.UserData = JSON.parse(this.storage.getData("UserData"))[0];
    const propertyID = this.route.snapshot.paramMap.get("id");
    if (propertyID != undefined) {
      this.editProperty = true;
      this.showButtonCancel = true;
      this.holdIds.propertyId = propertyID;
      this.getPropertyDetailsByID(propertyID);
    }
    this.getBusinessType();
    this.getCountry();
    this.getProperty();
    this.getCompanySubDiv();
    this.getCompanyType();
    this.getTimeZone();
    this.storage.setData("status", "updated");
  }

  /** */
  createAddPropertyForm() {
    const reg =
      "^(?!mailto:)(?:(?:http|https|ftp)://)(?:\\S+(?::\\S*)?@)?(?:(?:(?:[1-9]\\d?|1\\d\\d|2[01]\\d|22[0-3])(?:\\.(?:1?\\d{1,2}|2[0-4]\\d|25[0-5])){2}(?:\\.(?:[0-9]\\d?|1\\d\\d|2[0-4]\\d|25[0-4]))|(?:(?:[a-z\\u00a1-\\uffff0-9]+-?)*[a-z\\u00a1-\\uffff0-9]+)(?:\\.(?:[a-z\\u00a1-\\uffff0-9]+-?)*[a-z\\u00a1-\\uffff0-9]+)*(?:\\.(?:[a-z\\u00a1-\\uffff]{2,})))|localhost)(?::\\d{2,5})?(?:(/|\\?|#)[^\\s]*)?$";
    const email = "(^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$)";
    this.addPropertyFormGroup = this.AddPropertyFormBuilder.group({
      _nameOfProperty: new FormControl("", [Validators.required]),
      _businessType: new FormControl(""),
      _propertyDecs: new FormControl(""),
      _address1: new FormControl(""),
      _address2: new FormControl(""),
      _propertySubUnit: new FormControl("", [Validators.required]),
      _propertySubUnitID: new FormControl(0),
      _country: new FormControl(""),
      _state: new FormControl(""),
      _city: new FormControl(""),
      _zipCode: new FormControl(""),
      _countryCode: new FormControl(""),
      _areaCode: new FormControl(""),
      _phoneNumber: new FormControl(""),
      _extension: new FormControl(""),
      _businessEmail: new FormControl(
        "",
        Validators.compose([Validators.pattern(email)])
      ),
      _website: new FormControl(
        "",
        Validators.compose([Validators.pattern(reg)])
      ),
      _companySubDivision: new FormControl(""),
      _companyType: new FormControl(""),
      _companyTimeZone: new FormControl(""),
      _propertyPhoto: new FormControl(null),
      _companyStatus: new FormControl("Active"),
      _IsActive: new FormControl(1),
      _IsArchive: new FormControl(0),
      _TimeZoneID: new FormControl(""),
      _IsDSTObserved: new FormControl(""),
      __AdjustTime: new FormControl(""),
    });
  }

  /** */
  initiate(_filterObj, _fControlName, arrName, objKeyName) {
    this.filterObj[_filterObj] = this.addPropertyFormGroup.controls[
      _fControlName
    ].valueChanges.pipe(
      startWith(""),
      map((value) => this._filter(value, arrName, objKeyName))
    );
  }

  private _filter(value: string, arrName: any, objKeyName: any) {
    const filterValue = (value || "").toLowerCase();
    return this.listArray[arrName].filter((name: any) =>
      name[objKeyName].toLowerCase().includes(filterValue)
    );
  }
  /**
   *
   */
  getBusinessType() {
    this.addProperty.getBusinessType().subscribe((x) => {
      this.listArray.businessList = x.getBusinessType;

      this.initiate(
        "businessFilter",
        "_businessType",
        "businessList",
        "BusinessType"
      );
    });
  }
  getCountry() {
    this.addProperty.getCountry().subscribe((x) => {
      this.listArray.countryList = x.getCountry;
      x.getCountry.forEach((element) => {
        if (element.IsSelected == 1) {
          this.CountryID = element.CountryID;
          this.holdIds["countryId"] = element.CountryID;
          this.addPropertyFormGroup.patchValue({
            _country: element.CountryName,
          });
          this.getState(element.CountryID);
          // this.getCity(element.CountryID, 0, "");
        }
      });

      this.initiate("countryFilter", "_country", "countryList", "CountryName");
    });
  }
  getState(atr) {
    this.holdIds["countryId"] = atr;
    this.addProperty.getState({ countryId: atr }).subscribe((x) => {
      this.listArray.stateList = x.getState;
      let stateNameBind = this.listArray.stateList.find(
        (accu) =>
          accu.StateName === this.addPropertyFormGroup.get("_state").value
      );
      if (stateNameBind) {
        this.getCity(0, stateNameBind.StateId, { isUserInput: true });
      }

      this.initiate("stateFilter", "_state", "stateList", "StateName");
    });
  }
  getCity(atr, stateID, event) {
    if (!event.isUserInput) return;
    this.listArray.cityList = [];
    this.addProperty
      .getCity({ countryId: this.CountryID, stateId: stateID })
      .subscribe((x) => {
        this.listArray.cityList = x.getCity;
        //console.log(x.getCity);
        this.initiate("cityFilter", "_city", "cityList", "CityName");
      });
  }
  removeCity() {
    this.listArray.cityList = [];
    this.initiate("cityFilter", "_city", "cityList", "CityName");
    this.addPropertyFormGroup.patchValue({ _city: "" });
  }
  getProperty() {
    this.propertyManagementService
      .getPropertyByUser({ UserId: +this.UserData.UserID })
      .subscribe((x) => {
        this.listArray.propertyList = x.getPropertyByUser.slice(0, 4);
        this.initiate(
          "propertyFilter",
          "_nameOfProperty",
          "propertyList",
          "ParopertyName"
        );
      });
  }
  getCompanySubDiv() {
    this.propertyManagementService
      .getCompanySubDivision({ UserId: +this.UserData.UserID })
      .subscribe((x) => {
        this.listArray.companySubDivisionList = x.comapnySubdivision;

        this.initiate(
          "companySubDivFilter",
          "_companySubDivision",
          "companySubDivisionList",
          "CompanyORSubdivision"
        );
      });
  }
  getCompanyType() {
    this.addProperty
      .getCompanyType({ UserId: +this.UserData.UserID })
      .subscribe((x) => {
        this.listArray.companyTypeList = x.getComapnyTypeByUserId;
        this.initiate(
          "companyTypeFilter",
          "_companyType",
          "companyTypeList",
          "CompanyType"
        );
      });
  }

  setCompanyValue(type, opt, optKey, event) {
    if (!event.isUserInput) return;
    this.companyParam[type] = +opt[optKey];
  }
  getCompanyById(propertyId) {
    if (this.companyArray.length != 0) {
      this.companyArray.forEach((element) => {
        this.propertyCompany.PropertyCompanyId = 0;
        this.propertyCompany.CompanyId = element.companySubDiv;
        this.propertyCompany.CompanyTypeId = element.CompanyTypeID;
        this.propertyCompany.PropertyId = propertyId;
        this.propertyCompany.UserId = this.UserData.UserID;
        this.propertyCompany.IsActive = 1;
        this.propertyManagementService
          .updatePropertyCompany(this.propertyCompany)
          .subscribe((x) => {});
      });
    }
  }

  /**
   * image reader file
   * @param file
   * @param elem
   */
  openFile(event, elem, type) {
    if (type == "file1") {
      this.file = event && event.target.files.item(0);
    }
    if (type == "file2") {
      this.file2 = event && event.target.files.item(0);
    }

    this.addProFunc.ImageReader(event, elem);
  }
  setIds(keyName, id, evt) {
    if (!evt.isUserInput) return;

    this.holdIds[keyName] = id;
  }
  getPropertyId() {
    let f = this.storage.getData("PropertyDetail");
    if (f == null) {
      return 0;
    } else {
      if (JSON.parse(f).addPropertySubUnitFlag != undefined) {
        return 0;
      }
      return JSON.parse(f).PropertyID;
      // let propertyObj = JSON.parse(f);

      // if (!propertyObj.addPropertySubUnitFlag) {
      //   return 0;
      // } else {
      //   return propertyObj.PropertyID;
      // }
    }
  }
  getPropertyIdForSub() {
    let f = this.storage.getData("PropertyDetail");

    if (f == null) {
      return 0;
    } else {
      if (JSON.parse(f).addPropertySubUnitFlag != undefined) {
        return JSON.parse(f).PropertyID;
      }
      // return JSON.parse(f).PropertyID;
      // let propertyObj = JSON.parse(f);

      // if (!propertyObj.addPropertySubUnitFlag) {
      //   return 0;
      // } else {
      //   return propertyObj.PropertyID;
      // }
    }
  }
  getPropertyname(name) {
    if (name == null) {
      return null;
    } else {
      return (name = name.split("-")[0].trim());
    }
  }
  onSubmit() {
    this.submitted = true;
    /*   if (this.addPropertyFormGroup.invalid || this.addPropertyFormGroup.getRawValue()._propertySubUnit == null || undefined) {
        Swal.fire('Please Provide Id Number');
        return;
      } */
    let _ = this.addPropertyFormGroup.value;
    let obj = {
      PropertyID: this.getPropertyId(),
      PropertyName:
        this.getPropertyname(
          _._nameOfProperty.charAt(0).toUpperCase() + _._nameOfProperty.slice(1)
        ) || "",
      PropertySubUnitID: this.getPropertyIdForSub(), //_._propertySubUnitID,
      BusinessTypeID: this.holdIds.businessId || 0,
      PropertyDesc: _._propertyDecs,
      PropertyImageName: "",
      PropertyImagePath: null,
      PropertyImageTypeID: 1,
      PhoneNumber:
        _._phoneNumber == "" || _._phoneNumber == null || _._phoneNumber == null
          ? ""
          : _._phoneNumber.split("-").join().replace(/,/g, ""),
      PropertyAddress1: _._address1 || "",
      PropertyAddress2: _._address2 || "",
      CountryID: this.holdIds.countryId || 0,
      StateID: this.holdIds.stateId || 0,
      CityName: _._city || "",
      ZipCode: _._zipCode || "",
      CountryCode: _._countryCode || 1,
      AreaCode: _._areaCode || "",
      Extension: _._extension,
      BusinessEmail: _._businessEmail || "",
      WebSite: _._website || "",
      PropertyIdentNumber: this.addPropertyFormGroup.getRawValue()
        ._propertySubUnit,
      TimeZoneID: _._TimeZoneID,
      IsDSTObserved: _._IsDSTObserved || 0,
      AdjustTime: _.__AdjustTime || 0,
      PropertyLogoName: "",
      PropertyLogoPath: null,
      PropertyLogoTypeID: 2,
      // IsActive: (_._IsActive == true ? 1 : 0) || 1,
      // IsArchive: (_._IsArchive == true ? 1 : 0) || 0,
      IsActive: Number.isInteger(+_._IsActive) ? _._IsActive : 1,
      IsArchive: Number.isInteger(+_._IsArchive) ? _._IsArchive : 0,
    };
    console.log(obj);
    if (obj.PropertyName == "" || obj.PropertyIdentNumber == "") {
      // this.tostre.error(
      //   "Please Provide Property Name & Property Subunit ID #",
      //   "",
      //   {
      //     positionClass: "toast-top-right",
      //   }
      // );
      return;
    }

    if (
      this.listArray.countryList.find(
        (x) => x.CountryName == this.addPropertyFormGroup.get("_country").value
      ) == undefined &&
      this.addPropertyFormGroup.get("_country").value != ""
    ) {
      this.tostre.error("Country not exists.", "", {
        positionClass: "toast-top-right",
      });
      return;
    }

    if (
      this.addPropertyFormGroup.get("_state").value &&
      !this.listArray.stateList.find(
        (x) => x.StateName == this.addPropertyFormGroup.get("_state").value
      )
      // this.addPropertyFormGroup.get("_state").value != ""
    ) {
      this.tostre.error("State/Subnational Designation not exists.", "", {
        positionClass: "toast-top-right",
      });
      return;
    }

    if (
      this.listArray.cityList.find(
        (x) => x.CityName == this.addPropertyFormGroup.get("_city").value
      ) == undefined &&
      this.addPropertyFormGroup.get("_city").value != ""
    ) {
      this.tostre.error("City not exists.", "", {
        positionClass: "toast-top-right",
      });
      return;
    }
    /**
     * test value
     */
    let payload = new FormData();

    if (this.file != null) {
      payload.append(
        "_propertyPhoto",
        this.file,
        Date.now() + "propertyPhoto.jpg"
      );
    }
    if (this.file2 != null) {
      payload.append(
        "_propertyLogo",
        this.file2,
        Date.now() + 1 + "propertyLogo.jpg"
      );
    }
    Object.keys(obj).forEach((key: string) => {
      payload.append(key, obj[key]);
    });

    /**
     *
     */

    this.addProperty.updateProperty(payload).subscribe((x) => {
      let temp = false;
      if (!this.propJson) {
        this.file = null;
        this.file2 = null;
        this.setImage("setDefault");
      }
      if (this.propJson) {
        if (JSON.parse(this.propJson).addPropertySubUnitFlag) {
          temp = true;
          this.addProFunc.updatePropertyIdWithSubUnit(this.propJson, x, obj);
          this.addPropertyFormGroup.patchValue({ _nameOfProperty: "" });
          this.addPropertyFormGroup.patchValue({ _propertySubUnit: "" });
          // return;
        }
      }

      // this.addPropertyOper.updatePropertyIdWithSubUnit();
      if (
        x.updateProperty[0].ReturnMessage.match(/\b(\w*already\w*)\b/g) != null
      ) {
        // Swal.fire(
        //   obj.PropertyName +
        //     " Already Exists...\nChoose Different Property Name"
        // );
        this.tostre.warning(
          `${obj.PropertyName} Already Exists Choose Different Property Name`,
          "",
          {
            positionClass: "toast-top-right",
          }
        );
        return;
      }

      if (!this.storage.getData("PropertyDetail") || temp) {
        if (x.statusCode == 200) {
          this.addPropertyFormGroup.patchValue({ _nameOfProperty: "" });
          this.addPropertyFormGroup.patchValue({ _propertySubUnit: "" });
          this.tostre.success("The Record has been saved successfully.", "", {
            positionClass: "toast-top-right",
          });
          this.getCompanyById(x.updateProperty[0].ReturnMessage);
          this.addProFunc.setAddPropertyCurrent(x);
          this.addPropertyFormGroup.reset();
          this.router.navigateByUrl(
            "products/administration/propertymanagement/propertydetail"
          );
        } else {
          this.tostre.error("Data Not Saved Something Went Wrong!", "", {
            positionClass: "toast-top-right",
          });
        }
      } else {
        if (x.statusCode == 200) {
          this.getCompanyById(this.getPropertyId());

          this.tostre.success("The Record has been saved successfully.", "", {
            positionClass: "toast-top-right",
          });
          this.storage.setData("status", "updated");
          this.router.navigateByUrl(
            "products/administration/propertymanagement/propertydetail"
          );
        } else {
          this.tostre.error("Data Not Saved Something Went Wrong!", "", {
            positionClass: "toast-top-right",
          });
        }
      }
    });
  }
  //
  get check() {
    return this.addPropertyFormGroup.controls;
  }
  /**
   * set previous Value
   *
   */
  phoneNumber(_phoneNum) {
    try {
      _phoneNum = _phoneNum.split("") || "";
      let x =
        _phoneNum
          .slice(0, _phoneNum.length / 2)
          .join()
          .replace(/,/g, "") +
        "-" +
        _phoneNum
          .slice(_phoneNum.length / 2, _phoneNum.length)
          .join()
          .replace(/,/g, "");
      return x == "-" ? "" : x;
    } catch (error) {
      return "";
    }
  }

  setImage(id) {
    if (id === "setDefault") {
      const photoRef = this.renderer.selectRootElement("#propertyPhoto", true);

      const photoLogoRef = this.renderer.selectRootElement(
        "#propertyLogo",
        true
      );

      const url = `${environment.origin}`;

      this.renderer.setAttribute(
        photoRef,
        "src",
        `${url}/assets/images/imagenaBg.png`
      );
      this.renderer.setAttribute(
        photoLogoRef,
        "src",
        `${url}/assets/images/imagenaBg.png`
      );
      return;
    }
    this.propertyManagementService
      .getImageFile({ PropertyId: +id })
      .subscribe((propertyList) => {
        if (!propertyList || !propertyList.listImage.length) {
          return;
        }

        const { listImage } = propertyList;

        const photoRef = this.renderer.selectRootElement(
          "#propertyPhoto",
          true
        );

        const photoLogoRef = this.renderer.selectRootElement(
          "#propertyLogo",
          true
        );

        const url = `${environment.imagePath}users/`;

        listImage.forEach((img) => {
          const imgRef = img.ImageTypeID === 1 ? photoRef : photoLogoRef;
          this.renderer.setAttribute(imgRef, "src", `${url}${img.ImageName}`);
        });
      });
  }

  addbusinesstype(): void {
    const dialogRef = this.dialog.open(ModeladdbusinesstypeComponent, {
      width: "400px",
      panelClass: "my-dialog-container-class2",
    });

    dialogRef.afterClosed().subscribe((result) => {
      this.getBusinessType();
    });
  }

  addcompanytype(): void {
    const dialogRef = this.dialog.open(ModelcompanytypeComponent, {
      width: "400px",
      panelClass: "my-dialog-container-class2",
      data: { userID: this.UserData.UserID },
    });
    dialogRef.afterClosed().subscribe((result) => {
      this.getCompanyType();
    });
  }
  showAllList(id) {
    this.propertyManagementService
      .GetAssignedPropertyCompanyList({ PropertyID: +this.holdIds.propertyId })
      .subscribe((x) => {
        this.data.changeCompanyAssignMessage(x);

        this.propertyManagementService
          .GetPropertyAllPerson({ PropertyId: +id })
          .subscribe((x) => {
            this.data.changeAllKeyPersionMessage({
              allData: x,
              PropertyId: +id,
            });
          });
        this.propertyManagementService
          .GetPropertyContact({ PropertyId: +id })
          .subscribe((x) => {
            this.data.changeKeyContactMessage(x);
          });
      });

    this.getWorkGroupDetail(id);
  }
  getWorkGroupDetail(id) {
    this.propertyManagementService
      .GetAssigedWorkGroupsToProperty({
        PropertyID: +id,
      })
      .subscribe((x) => {
        this.data.changeWorkGroupMessage(x.AssigedWorkGroupsToProperty);
      });
  }
  /**
   * set dash on property managementyphone number
   */

  setDash(event, elem) {
    return event.keyCode == 8
      ? ""
      : elem.value.length > 2 && elem.value.length < 4
      ? (elem.value = elem.value + "-")
      : elem.value;
  }
  propName: any = "";
  getPropertyDetailsByID(propertyID) {
    const param = {
      PropertyId: propertyID,
    };
    this.propertyManagementService
      .getPropertyBYId(param)
      .subscribe((x: any) => {
        if (x.statusCode == 200) {
          //console.log("edit section value",x);
          const propertyObj = x.getPropertyById[0];
          this.propertyname = propertyObj.PropertyName;
          this.showHeader = true;
          this.showPropertyName = propertyObj.PropertyName;

          if (propertyObj.EnvironmentName == null) {
            this.showGoeName = "No Global Operations Environment assigned.";
          } else {
            this.showGoeName = propertyObj.EnvironmentName + " - ";
          }
          if (propertyObj.PropertySubUnit == null) {
            this.showPropertySubUnit = "";
            this._isPrimary = true;
          } else {
            this._isPrimary = false;
            this.showPropertyName = propertyObj.PropertyName;
            this.showPropertySubUnit =
              "This is a Property Sub-unit of Property:" +
              propertyObj.PropertySubUnit +
              "-" +
              propertyObj.PropertySubUnitIdentNumber;
          }
          this.showGOENo = propertyObj.GOENo;
          this.holdIds.businessId = propertyObj.BusinessTypeId;
          this.holdIds.propertyId = propertyID;
          this.holdIds.countryId = propertyObj.CountryID;
          this.holdIds.stateId = propertyObj.StateID;
          /** making first time of listed data form company lsit */
          this.setImage(propertyID);
          this.showAllList(propertyID);
          this.getWorkGroupDetail(propertyID);
          this.addPropertyFormGroup.patchValue({
            _nameOfProperty: propertyObj.PropertyName || "",
            _businessType: propertyObj.BusinessType,
            _propertyDecs: propertyObj.PropertyDescription,
            _address1: propertyObj.Address1,
            _address2: propertyObj.Address2,
            _propertySubUnit: propertyObj.PropertyIdentNumber,
            _propertySubUnitID: propertyObj.ParentID,
            _phoneNumber: this.phoneNumber(propertyObj.PhoneNumber),
            _country: propertyObj.CountryName,
            _state: propertyObj.StateName,
            _city: propertyObj.City,
            _zipCode: propertyObj.Zip,
            _countryCode: propertyObj.CountryCode,
            _areaCode: propertyObj.AreaCode,
            _extension: propertyObj.Extension,
            _businessEmail: propertyObj.BusinessEmail,
            _website: propertyObj.WebSite,
            _companySubDivision: "",
            _companyType: "",
            _companyTimeZone: propertyObj.TimeZoneName,
            _propertyPhoto: null,
            _companyStatus: "Active",
            _IsActive: propertyObj.IsActive ? 1 : 0,
            _IsArchive: propertyObj.IsArchive ? 1 : 0,
            _TimeZoneID: propertyObj.TimeZoneID,
            __AdjustTime: propertyObj.AdjustTime,
          });
          /**
           * for state name
           */

          if (propertyObj.IsDSTObserved) {
            this.addPropertyFormGroup.patchValue({ _IsDSTObserved: 1 });
          } else {
            this.addPropertyFormGroup.patchValue({ _IsDSTObserved: 0 });
          }

          if (propertyObj.IsActive) {
            this.addPropertyFormGroup.patchValue({ _companyStatus: "Active" });
          } else if (!propertyObj.IsActive) {
            this.addPropertyFormGroup.patchValue({
              _companyStatus: "InActive",
            });
          } else if (propertyObj.IsArchive) {
            this.addPropertyFormGroup.patchValue({
              _companyStatus: "Archived",
            });
          }
        }
      });
  }

  autoGenerate() {
    this.propertyManagementService.getAutoGenerate().subscribe((x) => {
      // reading again because when adding sub-unit it add proprty flg nned to be true
      this.propJson = this.storage.getData("PropertyDetail");
      if (this.propJson != null) {
        if (JSON.parse(this.propJson).addPropertySubUnitFlag == null) {
          this.tostre.error(
            "This Property's Id generated\nNot Allowed to set Again",
            "",
            {
              positionClass: "toast-top-right",
            }
          );
          return;
        }
      }
      this.addPropertyFormGroup.patchValue({
        _propertySubUnit: x.randomNumber[0].PropertyIdentyNumber,
      });
    });
  }
  referToPage() {
    this.storage.setData("status", "updated");
    this.router.navigateByUrl(
      "products/administration/propertymanagement/propertydetail"
    );
  }
  onNavigate() {
    if (
      this.addPropertyFormGroup.get("_website").value != "" &&
      this.check._website.invalid == false
    ) {
      window.open(this.addPropertyFormGroup.get("_website").value, "_blank");
    } else {
      this.tostre.warning("Please enter right website");
    }
  }

  /**
   *
   * @param event Validate so time can input only number
   */
  numberOnly(event: any): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  addAssignRows() {
    if (!(this.listArray.companyTypeList || []).length) {
      this.tostre.error("Company Type not exists.", "", {
        positionClass: "toast-top-right",
      });
      return;
    }
    if (
      this.listArray.companyTypeList.find(
        (x) =>
          x.CompanyType == this.addPropertyFormGroup.get("_companyType").value
      ) == undefined
    ) {
      this.tostre.error("Company Type not selected.", "", {
        positionClass: "toast-top-right",
      });
      return;
    }

    let day = new Date();
    if (
      this.addPropertyFormGroup.get("_companySubDivision").value != null &&
      this.addPropertyFormGroup.get("_companyType").value != null
    ) {
      const currentDate =
        ("0" + (day.getMonth() + 1)).slice(-2) +
        "/" +
        ("0" + day.getDate()).slice(-2) +
        "/" +
        day.getFullYear();
      const companyTypeProp = {
        companySubDiv: this.companyParam.companySubDiv,
        CompanyTypeID: this.companyParam.CompanyTypeID,
        CompanyType: this.addPropertyFormGroup.get("_companyType").value,
        CompanyName: this.addPropertyFormGroup.get("_companySubDivision").value,
        AssignedBy: this.storage.getData("username"),
        AssignedDate: currentDate,
        isActive: 1,
      };
      this.companyArray.push(companyTypeProp);
      this.assignedObject = companyTypeProp;
      // this.data.changeCompanyMessage(companyTypeProp);

      this.addPropertyFormGroup.patchValue({
        _companySubDivision: "",
        _companyType: "",
      });
    }
  }

  getTimeZone() {
    this.addProperty.getTimeZone().subscribe((x: any) => {
      this.listArray.companyTimeList = x.GetTimeZone;
      this.initiate(
        "companyTimeFilter",
        "_companyTimeZone",
        "companyTimeList",
        "TimeZoneName"
      );
    });
  }

  setTimeZone(option) {
    this.addPropertyFormGroup.patchValue({ _TimeZoneID: option.TimeZoneID });
  }

  createSubunit() {
    // this.showPropertySubUnit  =this.propertyname;

    let propertyDetail = JSON.parse(this.storage.getData("PropertyDetail"));
    propertyDetail["addPropertySubUnitFlag"] = true;
    this.storage.setData("PropertyDetail", JSON.stringify(propertyDetail));
    // this.router.navigateByUrl(
    //   "/products/administration/propertymanagement/addproperty"
    // );

    // this.isAddingSubunitInExixts = true
    // this.addsubunitExists = false

    const photoRef = this.renderer.selectRootElement("#propertyPhoto", true);

    const photoLogoRef = this.renderer.selectRootElement("#propertyLogo", true);

    photoRef.src = "./assets/images/imagenaBg.png";
    photoLogoRef.src = "./assets/images/imagenaBg.png";

    this.editProperty = false;
    this.addPropertyFormGroup.reset();

    this.addPropertyFormGroup.patchValue({
      _country: "",

      _state: "",
      _city: "",
    });
    this.tostre.success("Please Add Property Sub-unit", "", {
      positionClass: "toast-top-right",
    });

    // this.router.navigate([
    //   "/products/administration/propertymanagement/addproperty",
    //   { p1: this.showPropertyName },
    // ]);
  }
  /**
   * under development
   */
  // isAddingSubunitInExixts : boolean = false
  // addsubunitExists : boolean = true

  onValChange() {
    let propertyStatus = this.addPropertyFormGroup.get("_companyStatus").value;
    if (propertyStatus == "Active") {
      this.addPropertyFormGroup.patchValue({ _IsActive: 1, _IsArchive: 0 });
    } else if (propertyStatus == "InActive") {
      this.addPropertyFormGroup.patchValue({ _IsActive: 0, _IsArchive: 0 });
    } else if (propertyStatus == "Archived") {
      this.addPropertyFormGroup.patchValue({ _IsActive: 0, _IsArchive: 1 });
    }
  }

  disableSpecialChar(event) {
    let k;
    k = event.charCode;
    return (
      (k > 64 && k < 91) ||
      (k > 96 && k < 123) ||
      k == 8 ||
      k == 32 ||
      (k >= 48 && k <= 57)
    );
  }

  focusFunction(event) {
    if (event.target.value != "") {
      if (
        this.listArray.countryList.find(
          (x) =>
            x.CountryName == this.addPropertyFormGroup.get("_country").value
        ) == undefined
      ) {
        this.tostre.error("Country not exists.", "", {
          positionClass: "toast-top-right",
        });
        return;
      }
    }
  }
  stopInput() {
    // return false;
  }

  openPanel() {
    this.initiate(
      "companyTimeFilter",
      "_companyTimeZone",
      "companyTimeList",
      "TimeZoneName"
    );
  }
}
