import { Component, OnInit, Input, Inject } from '@angular/core';
import { AddPropertyService } from '../addPropert.service';
import Swal from 'sweetalert2';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-modelcompanytype',
  templateUrl: './modelcompanytype.component.html',
  styleUrls: ['./modelcompanytype.component.scss']
})
export class ModelcompanytypeComponent implements OnInit {

  _companyTypeList: any;

  _companyType: any = '';
  constructor(private addProperty: AddPropertyService, private tostre: ToastrService,
    public dialogRef: MatDialogRef<ModelcompanytypeComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit() {
    console.log(this.data);
  }

  updateCompanyType(companyName) {

    if (companyName.value.length == 0) {
      this.tostre.error('Please Enter Company Type.', '', {
        positionClass: 'toast-top-right'
      });
     // Swal.fire({ html: "Please Enter Company Type 1", timer: 2000 });
      return;
    }

    if (this._companyType != '') {
      const param = {
        CompanyTypeID: 0,
        CompanyTypeName: this._companyType.trim()
      }
      this.addProperty.updateCompanyType(param).subscribe((x: any) => {

        if (x.updateCompanyType[0].ReturnMessage == this._companyType + " already exists.")
          Swal.fire({ html: "Company Type already exists.", timer: 2000 });
        else
          Swal.fire({ html: "Company Type Added Successfully.", timer: 2000 });
        this.close();
      });
    }
  }

  showAll() {
    const param = {
      UserId: parseInt(this.data.userID)
    }
    this.addProperty.getCompanyType(param).subscribe((x: any) => {
      console.log(x);
      this._companyTypeList = x.getComapnyTypeByUserId;
    });
  }

  close() {
    this.dialogRef.close();
  }


}
