import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModeladdbusinesstypeComponent } from './modeladdbusinesstype.component';

describe('ModeladdbusinesstypeComponent', () => {
  let component: ModeladdbusinesstypeComponent;
  let fixture: ComponentFixture<ModeladdbusinesstypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModeladdbusinesstypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModeladdbusinesstypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
