import { Component, OnInit } from "@angular/core";
import { AddPropertyService } from "../addPropert.service";
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA
} from "@angular/material/dialog";
import Swal from "sweetalert2";
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: "app-modeladdbusinesstype",
  templateUrl: "./modeladdbusinesstype.component.html",
  styleUrls: ["./modeladdbusinesstype.component.scss"]
})
export class ModeladdbusinesstypeComponent implements OnInit {
  constructor(
    private addProperty: AddPropertyService,private tostre: ToastrService,
    public dialogRef: MatDialogRef<ModeladdbusinesstypeComponent>
  ) { }
  arrayObj = {
    listItems: [],
    matchingArray: []
  };

  ngOnInit() {
    this.getBusinessType("matchingArray");
  }
  getBusinessType(keyname) {
    this.addProperty.getBusinessType().subscribe(x => {
      this.arrayObj[keyname] = x.getBusinessType;
    });
  }
  SaveBusiness(elem) {
    console.log(elem.value.length);
    if (elem.value.trim() == "") {
      this.tostre.error('Please Enter Business Type.', '', {
        positionClass: 'toast-top-right'
      });
      //Swal.fire({ html: "Please Enter Business Type", timer: 2000 });
      return;
    }

  
    if ( this.arrayObj.matchingArray.find( x => x.BusinessType.trim() == elem.value.trim()) != undefined) {
      this.tostre.error('Already Exists.', '', {
        positionClass: 'toast-top-right'
      });
      
     // Swal.fire({ html: "Already Exists", timer: 2000 });
      return;
    }
    else{
      this.addProperty
      .saveNewBusinessType({
        BusinessTypeID: 0,
        BusinessTypeName: elem.value
      })
      .subscribe(x => {
        Swal.fire({ html: "Business Type Added Successfully.", timer: 2000 });
        //this.getBusinessType("listItems");
        this.dialogRef.close()
      });
    }
   
  }

}
