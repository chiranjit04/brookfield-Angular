import { Injectable } from "@angular/core";
import { PropertManagementService } from "../propertyManagement.service";
import { AddPropertyService } from "./addPropert.service";
import Swal from "sweetalert2";
import { DataSharingService } from "../dataSharing.service";
import { StorageService } from "../../../../services/storage.service";
import { ToastrService } from "ngx-toastr";
import { Router } from "@angular/router";
@Injectable({
  providedIn: "root",
})
export class AddPropertyFunctionality {
  constructor(
    private propManagementService: PropertManagementService,
    private addProperty: AddPropertyService,
    private dataShare: DataSharingService,
    private storage: StorageService,
    private toaster: ToastrService,
    private router: Router
  ) {}
  ImageReader(file, elem) {
    console.log(elem);
    var input = file.target;

    var reader = new FileReader();
    reader.onload = function () {
      var dataURL = reader.result;
      elem.src = dataURL;
    };
    reader.readAsDataURL(input.files[0]);
    return;
  }
  public updatePropertyIdWithSubUnit(json, newId, updateObj) {
    let _propObj = JSON.parse(json);
    console.log(_propObj);
    this.propManagementService
      .getPropertyBYId({
        PropertyId: newId.updateProperty[0].ReturnMessage, //+_propObj.PropertyID,
      })
      .subscribe((x) => {
        let f = x.getPropertyById[0];
        // f.PropertySubUnit = +newId.updateProperty[0].ReturnMessage;
        // f.PropertyName = _propObj.PropertyName;
        // f.PropertyID = +_propObj.PropertyID;

        // Object.defineProperty(f, "PropertySubUnit", {
        //   value: +newId.updateProperty[0].ReturnMessage
        // });
        // Object.defineProperty(f, "PropertyName", {
        //   value: _propObj.PropertyName
        // });
        // Object.defineProperty(f, "PropertyID", {
        //   value: +_propObj.PropertyID
        // });
        let obj = {
          PropertyID: +newId.updateProperty[0].ReturnMessage,
          PropertyName: updateObj.PropertyName, //_propObj.PropertyName,
          PropertySubUnitID: +_propObj.PropertyID,
          BusinessTypeID: f.BusinessTypeId,
          PropertyDesc: f.PropertyDescription,
          PropertyImageName: "",
          PropertyImagePath: null,
          PropertyImageTypeID: f.ImageTypeID,
          PhoneNumber: f.PhoneNumber,
          PropertyAddress1: f.Address1,
          PropertyAddress2: f.Address2,
          CountryID: f.CountryID,
          StateID: f.StateID,
          CityName: f.City,
          ZipCode: f.Zip,
          CountryCode: f.CountryCode,
          AreaCode: f.AreaCode,
          Extension: f.Extension,
          BusinessEmail: f.BusinessEmail,
          WebSite: f.WebSite,
          PropertyIdentNumber: f.PropertyIdentNumber,
          TimeZoneID: f.TimeZoneID,
          IsDSTObserved: f.IsDSTObserved,
          AdjustTime: f.AdjustTime,
          PropertyLogoName: "",
          PropertyLogoPath: null,
          PropertyLogoTypeID: 2,
          IsActive: 1,
        };
        console.log(obj);

        this.addProperty.updateProperty(obj).subscribe((res) => {
          if (
            newId.updateProperty[0].ReturnMessage.split(" ").indexOf(
              "already"
            ) > 0
          ) {
            // Swal.fire("Already Exists Please Choose Another Name");
            this.toaster.warning(
              "Already Exists Please Choose Another Name",
              "",
              {
                positionClass: "toast-top-right",
              }
            );
            return;
          }
          // Swal.fire("Property Sub Unit Added");
          this.toaster.success("Property Sub Unit Added", "", {
            positionClass: "toast-top-right",
          });

          this.dataShare.changeSubunit("success");
          this.router.navigateByUrl(
            "products/administration/propertymanagement/propertydetail"
          );
        });
      });
  }
  public setAddPropertyCurrent(id) {
    let setObj = {
      PropertyID: "2",
      PropertyName: "file over something",
      GlobalEnvironmentID: 1,
      PropertyDescription: null,
      Subdivision: "bye bye",
      PropertyIdentNumber: "1245",
      EnvironmentName: "Brookfield Properties Retail Environment",
      Address1: null,
      City: null,
      StateName: null,
      Zip: null,
      IsActive: true,
    };

    this.propManagementService
      .getPropertyBYId({
        PropertyId: +id.updateProperty[0].ReturnMessage,
      })
      .subscribe((h) => {
        let setObj = {
          PropertyID: "30116",
          PropertyName: "456788",
          GlobalEnvironmentID: null,
          PropertyDescription: "rtgrth",
          Subdivision: null,
          PropertyIdentNumber: "5055",
          EnvironmentName: null,
          Address1: "hrh",
          City: "Beaux Arts",
          StateName: "Aguascalientes",
          Zip: "hrhyhy",
          IsActive: null,
          addPropertySubUnitFlag: true,
        };

        setObj.PropertyID = h.getPropertyById[0].PropertyID;
        setObj.PropertyName = h.getPropertyById[0].PropertyName;
        setObj.GlobalEnvironmentID = h.getPropertyById[0].GlobalEnvironmentID;
        setObj.PropertyDescription = h.getPropertyById[0].PropertyDescription;
        setObj.Subdivision = "";
        setObj.PropertyIdentNumber = h.getPropertyById[0].PropertyIdentNumber;
        setObj.EnvironmentName = h.getPropertyById[0].EnvironmentName;
        setObj.Address1 = h.getPropertyById[0].Address1;
        setObj.City = h.getPropertyById[0].City;
        setObj.StateName = h.getPropertyById[0].StateName;
        setObj.Zip = h.getPropertyById[0].Zip;
        setObj.IsActive = h.getPropertyById[0].IsActive;

        this.storage.setData("PropertyDetail", JSON.stringify(setObj));
        this.dataShare.changeSubunit("button1");
      });
  }
}
