import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { environment } from "../../../../../environments/environment";
import { Observable } from "rxjs";
import { retry } from "rxjs/operators";
@Injectable({
  providedIn: "root"
})
export class AddPropertyService {
  _LocalUrl: string;
  constructor(private http: HttpClient) {
    this._LocalUrl = environment.localOrigin;
  }

  /**
   * get propertyByUser
   */
  // getPropertyByUser(param: { UserId: number }): Observable<any> {
  //   return this.http.post<any>(this._LocalUrl + "getPropertyByUser", param);
  // }
  // getProperty(): Observable<any> {
  //   return this.http.get<any>(this._LocalUrl + "Getproperty");
  // }
  // getCountry() {
  //   return this.http.get<any>(this._LocalUrl + "getCountry");
  // }
  // getState(param: any) {
  //   return this.http.post<any>(this._LocalUrl + "getState", param);
  // }
  // getPropertySearchList(param: any): Observable<any> {
  //   return this.http.post<any>(this._LocalUrl + "propertySearchList", param);
  // }
  // getGoeList(param): Observable<any> {
  //   return this.http.post<any>(this._LocalUrl + "getGoeByUser", param);
  // }
  // getCompanySubDivision(param: any): Observable<any> {
  //   return this.http.post<any>(this._LocalUrl + "GetComapnySubdivision", param);
  // }
  getBusinessType(): Observable<any> {
    return this.http.get<any>(this._LocalUrl + "getBusinessType");
  }
  getCountry(): Observable<any> {
    return this.http.get<any>(this._LocalUrl + "getCountry");
  }
  getState(param: any): Observable<any> {
    return this.http.post<any>(this._LocalUrl + "getState", param);
  }
  getCity(param: any): Observable<any> {
    return this.http.post<any>(this._LocalUrl + "getCity", param);
  }
  updateProperty(param: any): Observable<any> {
    return this.http.post<any>(this._LocalUrl + "updateProperty", param);
  }
  getCompanyType(param: any): Observable<any> {
    return this.http.post<any>(
      this._LocalUrl + "GetComapnyTypeByUserId",
      param
    );
  }
  getPropertyCompanyById(param: any): Observable<any> {
    return this.http.post<any>(
      this._LocalUrl + "getPropertyCompanyById",
      param
    );
  }
  saveNewBusinessType(param: any): Observable<any> {
    return this.http.post<any>(this._LocalUrl + "updateBusinessType", param);
  }
  getAutoGenerate(): Observable<any> {
    return this.http.get<any>(this._LocalUrl + "GetPropertyIdentyNumber");
  }
  getTimeZone(): Observable<any> {
    return this.http.get<any>(this._LocalUrl + "getTimeZone");
  }
  updateCompanyType(param:any): Observable<any> {
    return this.http.post<any>(this._LocalUrl + "updateCompanyType", param);
  }
}
