import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PropertymanagementComponent } from './propertymanagement.component';

describe('PropertymanagementComponent', () => {
  let component: PropertymanagementComponent;
  let fixture: ComponentFixture<PropertymanagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PropertymanagementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PropertymanagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
