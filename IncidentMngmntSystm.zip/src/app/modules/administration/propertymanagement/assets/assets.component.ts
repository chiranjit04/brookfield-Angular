import { FlatTreeControl } from "@angular/cdk/tree";
import { Component, OnInit } from "@angular/core";
import {
  MatTreeFlatDataSource,
  MatTreeFlattener,
} from "@angular/material/tree";
import { AssetsService } from "./assets.service";
import { FormGroup, FormBuilder, FormArray, Validators } from "@angular/forms";
import { ToastrService } from "ngx-toastr";
import {
  MAT_DIALOG_DATA,
  MatDialogRef,
  MatCheckboxChange,
} from "@angular/material";
import { environment } from "src/environments/environment";
declare var require: any;
const FileSaver = require("file-saver");
import * as pdfMake from "pdfmake";
import { saveAs } from "file-saver";
import pdfFonts from "pdfmake/build/vfs_fonts";
import Swal from "sweetalert2";
import { Router } from "@angular/router";
import { StorageService } from "../../../../services/storage.service";
pdfMake.vfs = pdfFonts.pdfMake.vfs;
interface FoodNode {
  name: string;
  children?: FoodNode[];
  AssetGroupId: string;
  CustomFormId: string;
  AssetRecordAssignmentId: string;
  length: string;
  ref: string;
}

// const TREE_DATA: FoodNode[] = [
//   {
//     name: "AED",
//     children: [{ name: "AED-1" }, { name: "Banana" }, { name: "Fruit loops" }],
//   },
//   {
//     name: "Fruit",
//     children: [{ name: "Apple" }, { name: "Banana" }, { name: "Fruit loops" }],
//   },
// ];
interface ExampleFlatNode {
  expandable: boolean;
  // noofaed: string;
  level: number;
  // AssetGroupId:string;
  // CustomFormId:string;
  // AssetRecordAssignmentId:string;
  // Title:string;
  // Answer:string;
}

@Component({
  selector: "app-assets",
  templateUrl: "./assets.component.html",
  styleUrls: ["./assets.component.scss"],
})
export class AssetsComponent implements OnInit {
  incidentExtrainfo: FormGroup;
  items: FormArray;
  answer = [];
  filename: any;
  filenames = "";
  private _transformer = (node: FoodNode, level: number) => {
    return {
      expandable: !!node.children && node.children.length > 0,
      name: node.name,
      level: level,
      // AssetGroupId:node.AssetGroupId,
      // CustomFormId:node.CustomFormId,
      // AssetRecordAssignmentId:node.AssetRecordAssignmentId
    };
  };

  treeControl = new FlatTreeControl<ExampleFlatNode>(
    (node) => node.level,
    (node) => node.expandable
  );

  treeFlattener = new MatTreeFlattener(
    this._transformer,
    (node) => node.level,
    (node) => node.expandable,
    (node) => node.children
  );

  dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);
  propertyDetail: any;
  UserData: any;
  propertyID: any;
  propertyno: any;
  _selectedProperty: any;
  SubunitName: any;
  assetsformgroup: any;
  _customFormElementList: any;
  formtitle: any;
  fileToUpload: File;
  vaulable: boolean;
  base64textString: string;
  TimeZoneOffset: any;
  timeList: any[];
  value: any;
  itemOpen: any;
  CustomFormGroupId: any;
  selectedid: any;
  UserID: any;
  SubPropertyUnit: any;
  AssetFormDetailsproperty: any;
  subunitvariable: boolean;
  AssetGroupId: any;
  savebutton = false;
  PropertyName1: any;
  PropertyIdentNumber: any;
  customformid: any;
  updtaebutton = false;
  submitted = false;
  clicked1 = false;
  showLoader: boolean;
  Hvrclck1: any;
  Hvrclck: any;
  childid = 0;
  PropertyName: any;
  formtitlename = "ASSETS GENERAL DETAILS";
  statuspickvalue = [
    { name: "Fully Functional" },
    { name: "Functional Not Optimal" },
    { name: "Not Functional" },
  ];

  iconPath: any;

  /****************************************************************
   * variables accroding to changes me
   */
  _propertyDetail_: any = "";
  _UserData_: any = "";
  _propertyID_: any = "";
  _propertyno_: any = "";
  _selectedProperty_: any = "";
  _SubunitName_: any = "";
  _SubPropertyUnit_: any;
  /**************************************************************** */
  constructor(
    private AssetsService: AssetsService,
    private formBuilder: FormBuilder,
    private tostre: ToastrService,
    public router: Router,
    private storage: StorageService
  ) {
    this.propertyDetail = JSON.parse(this.storage.getData("PropertyDetail"));
    this.UserData = JSON.parse(this.storage.getData("UserData"));
    /********************************
     * changes for more admix fixes, not changing old functionality adding new to every small changs avoid to new isseues.
     */
    this._propertyDetail_ = JSON.parse(this.storage.getData("PropertyDetail"));
    this._UserData_ = JSON.parse(this.storage.getData("UserData"));

    if (this._propertyDetail_) {
      this._propertyID_ = this._propertyDetail_.PropertyID;
      this._propertyno_ = this._propertyDetail_.PropertyIdentNumber;
      this._selectedProperty_ = this._propertyDetail_.PropertyName;
      this._SubunitName_ = this._propertyDetail_.SubunitName;
    }

    if (this.propertyDetail != null && (this.propertyDetail.Subdivision === "Property Subunit")) {
      this._SubPropertyUnit_ =
        this.propertyDetail.ParentPropertyName +
        " - " +
        this.propertyDetail.ParentIdentNumber;
    }

    const params = {
      PropertyId: this._propertyID_,
    };

    // this.AssetsService.GetCustomFormDetailsByPropertyId(params).subscribe(
    //   (res) => {
    //     if (res.data.getCustomFormDetailsByPropertyId.length != "") {
    //       this._SubPropertyUnit_ =
    //         res.data.getCustomFormDetailsByPropertyId[0].SubPropertyUnit;
    //     }
    //   }
    // );
    /******************************** end */
    this.iconPath = `${environment.imagePath}`;

    if (this.UserData) {
      this.UserID = this.UserData[0].UserID;
    }
    if (this.propertyDetail) {
      this.propertyID = this.propertyDetail.PropertyID;
      this.propertyno = this.propertyDetail.PropertyIdentNumber;
      this._selectedProperty = this.propertyDetail.PropertyName;
      // this.SubunitName = this.propertyDetail.SubunitName;
    }

    const param1 = {
      AssetGroupID: 3,
      PropertyID: 1,
      IsAssined: 1,
    };
    this.AssetsService.UpdateAssetGroupProperty(param1).subscribe((res) => {
      // console.log("hello");
    });

    this.GetAssetCustomFormDetailsByPropertyId();
  }
  hasChild = (_: number, node: ExampleFlatNode) => node.expandable;
  ngOnInit() {
    if (this.checkProperty()) {
    }

    this.incidentExtrainfo = this.formBuilder.group({
      items: this.formBuilder.array([]),
      PropertyProfileId: [""],
      CustomFormTypeId: [""],
      PropertyId: [""],
      CustomFormGroupId: [""],
      CustomFormId: [""],
      FormElementId: [""],
      FormElementDetailsId: [""],
      Answer: [""],
      IsAnswered: [""],
      IsDeleted: [""],
      files: [""],
      download: [""],
    });
  }

  ref: any;
  globalid: any;
  GetAssetRecordAnswerr(id) {
    this.globalid = id;
    this.showLoader = true;
    this.submitted = false;
    // console.log("idddddddddddddddddd", id);
    if (id.level == 0) {
      this.Hvrclck = id.name.ref.CustomFormId;
      this.takecustomformId(id);
      this.childid = 0;
    } else {
      this.formtitlename = id.name.name;
      (this.customformid = id.name.ref1),
        (this.Hvrclck = id.name.ref.AssetRecordAssignmentId);
      this.childid = id.name.ref.AssetRecordAssignmentId;
      this.getFormArray.controls.splice(0);
      const param = {
        CustomFormID: id.name.ref1,
      };
      this.AssetsService.GetCustomFormElementList(param).subscribe((res) => {
        if (res.statusCode == 200) {
          this._customFormElementList = res.CustomFormElementList;
          this.addItem();

          const param = {
            PropertyId: this.propertyID,
            AssetGroupId: this.AssetGroupId,
            CustomFormId: id.name.ref1,
            AssetRecordAssignmentId: id.name.ref.AssetRecordAssignmentId,
          };
          this.AssetsService.GetAssetRecordAnswer(param).subscribe((res) => {
            let records = res.data.GetAssetRecordAnswer[0];
            this.items = this.incidentExtrainfo.get("items") as FormArray;
            records.forEach((element) => {
              let index = this.items.value.findIndex(
                (x) => x.CustomFormElementId == element.FormElementId
              );
              if (index != -1) {
                if (
                  this.items.controls[index].get("ElementTypeId").value == 6
                ) {
                  if (element.Answer != "") {
                    let time = element.Answer.split("||");
                    if (time.length == 2) {
                      let dt = new Date(time[0]).toISOString();
                      this.items.controls[index].patchValue({ Answer: dt });
                      this.items.controls[index].patchValue({ Time: time[1] });
                    }
                  }
                } else if (
                  this.items.controls[index].get("ElementTypeId").value == 7
                ) {
                  if (element.Answer == "") {
                  } else if (element.Answer == null) {
                  } else {
                    this.items.controls[index].patchValue({
                      Answer: element.Answer,
                    });
                  }
                } else if (
                  this.items.controls[index].get("ElementTypeId").value == 9
                ) {
                  if (element.Answer != "") {
                    this.vaulable = true;
                    let file = element.Answer.split("/");
                    const url = environment.imagePath;
                    let dwn = url + element.Answer;
                    // console.log("dwn", dwn);
                    this.items.controls[index].patchValue({ files: file[2] });
                    this.items.controls[index].patchValue({ download: dwn });
                    // this.items.controls[index].patchValue({
                    //   Answer: element.Answer,
                    // });
                  }
                } else {
                  this.items.controls[index].patchValue({
                    Answer: element.Answer,
                  });
                }
              }
            });
            // console.log("res-recordanswer", res);
          });
          this.showLoader = false;
        }
      });
    }
  }

  get getFormArray() {
    return this.incidentExtrainfo.get("items") as FormArray;
  }

  takecustomformId(id) {
    this.globalid = id;
    this.savebutton = true;
    this.showLoader = true;
    this.submitted = false;
    // console.log("thatddd", id);
    this.getFormArray.controls.splice(0);
    this.customformid = id.name.ref.CustomFormId;
    this.Hvrclck = id.name.ref.CustomFormId;
    this.childid = 0;
    const param = {
      CustomFormID: id.name.ref.CustomFormId,
    };
    this.AssetsService.GetCustomFormElementList(param).subscribe((res) => {
      if (res.statusCode == 200) {
        this._customFormElementList = res.CustomFormElementList;
        this.formtitlename = res.CustomFormElementList[0].Title;
        this.addItem();
        this.items = this.incidentExtrainfo.get("items") as FormArray;
        this.items.controls.forEach((ele, index) => {
          if (this.items.controls[index].get("ElementTypeId").value == 10) {
            this.items.controls[index].patchValue({
              Answer: id.name.name,
            });
          }
        })
        this.showLoader = false;
      }
    });
  }

  createItem(element): FormGroup {
    return this.formBuilder.group({
      CustomFormElementId: [element.CustomFormElementId],
      ElementTypeId: [element.ElementTypeId],
      IsMandatory: [element.IsMandatory],
      ElementName: [element.ElementName],
      CustomElementName: [element.CustomElementName],
      Numberofcharacter: [element.numberofcharacter],
      Time: "",
      files: "",
      Answer: [element.Answer, element.IsMandatory ? Validators.required : ""],
      IsAnswered: "",
      download: [""],
    });
  }

  addItem(): void {
    this.items = this.incidentExtrainfo.get("items") as FormArray;
    this._customFormElementList.forEach((element) => {
      if (element.ElementTypeId == 7) {
        if (element.CustomElementName[0] != undefined) {
          let index = parseInt(element.CustomElementName[0]) + 1;
          element.Answer = element.CustomElementName[index];
        } else {
          element.Answer = "";
        }
      } else {
        element.Answer = "";
      }
      this.items.push(this.createItem(element));
    });
  }
  handleFileInput(files: FileList) {
    this.fileToUpload = files.item(0);
  }

  openFile(event) {
    // console.log("workq", event);
    this.vaulable = false;
    var files = event.target.files;
    var file = files[0];
    this.filename = files[0].name;
    // console.log("filename", this.filename);
    if (files && file) {
      var reader = new FileReader();

      reader.onload = this.handleFile.bind(this);

      reader.readAsBinaryString(file);
    }
  }

  handleFile(event) {
    var binaryString = event.target.result;
    this.base64textString = btoa(binaryString);
    // console.log(btoa(binaryString));
  }

  /**
   *
   * @param event Validate so time can input only number
   */
  numberOnly(event: any): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  noenter(event: any): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    return false;
  }

  deletechild(event, id) {
    event.stopPropagation();
    Swal.fire({
      text: "Are you sure you want to delete?",
      showCancelButton: true,
      width: "30%",
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes",
      cancelButtonText: "No",
    }).then((result) => {
      if (result.value) {
        const param = {
          AssetRecordAssignmentId: id.name.ref.AssetRecordAssignmentId,
        };
        this.AssetsService.DeleteAsseetRecord(param).subscribe((res) => {
          this.GetAssetCustomFormListByPropertyId();
          if (res.data.DeleteAsseetRecord == 1) {
            this.tostre.success("Record Deleted successfully.");
          }
        });
      } else if (result.dismiss === Swal.DismissReason.cancel) {
      }
    });
  }

  GetAssetCustomFormDetailsByPropertyId() {
    const param = {
      PropertyId: this.propertyID,
    };
    this.AssetsService.GetAssetCustomFormDetailsByPropertyId(param).subscribe(
      (res) => {
        this.AssetFormDetailsproperty = res.data.AssetFormDetails[0];
        this.PropertyName1 = res.data.AssetFormDetails[0].PropertyName;
        this.PropertyIdentNumber =
          res.data.AssetFormDetails[0].PropertyIdentNumber;
        this.AssetGroupId = res.data.AssetFormDetails[0].AssetGroupId;
        this.GetAssetCustomFormListByPropertyId();
        if (
          res.data.AssetFormDetails[0].SubPropertyUnit == null ||
          res.data.AssetFormDetails[0].SubPropertyUnit == ""
        ) {
          this.subunitvariable = false;
        } else {
          this.subunitvariable = true;
          this.SubPropertyUnit = res.data.AssetFormDetails[0].SubPropertyUnit;
        }
      }
    );
  }

  checkI(joker) {
    // this.itemOpen = 0
    // for (let i of this.dataSource.data) {
    //   if (i.name.ref.CustomFormId === joker.name.ref.CustomFormId) {
    //     if(this.itemOpen === 0) {
    //     }else {
    //       this.itemOpen++;
    //     }
    //      break;
    //  }else {
    //      for (let j of i.children) {
    //       this.itemOpen++;
    //     }
    //   }
    // console.log(this.itemOpen)
    //  this.treeControl.expand(this.treeControl.dataNodes[this.itemOpen]);
    // }
  }
  GetAssetCustomFormListByPropertyId() {
    const param2 = {
      PropertyId: this.propertyID,
      AssetGroupId: this.AssetGroupId,
    };
    this.AssetsService.GetAssetCustomFormListByPropertyId(param2).subscribe(
      (res2) => {
        this.assetsformgroup = res2.data.GetAssetCustomFormListByPropertyId;
        let arr = [];
        this.assetsformgroup.forEach((elem, index) => {
          arr.push({
            name: {
              ref: elem,
              name: elem.Title,
              ref2: elem.AssetRecordByFormId.length,
              ref3: elem.AssetRecordByFormId.length,
              ref4: index + 1 + ".",
              IconName: elem.IconName,
            },

            children: elem.AssetRecordByFormId.map((elem1, index1) => {
              return {
                name: {
                  name: elem1.Answer,
                  ref: elem1,
                  ref1: elem.CustomFormId,
                  ref5: index + 1 + "." + (index1 + 1),
                  IconName: elem1.ImageName,
                },
              };
            }),
          });
        });

        this.dataSource.data = arr;
        // if(this.dataSource.data)
        // {
        // if (this.itemOpen) {
        //    this.treeControl.expand(this.treeControl.dataNodes[this.itemOpen]);

        //     let idsNum = this.dataSource.data[0].children[ this.dataSource.data[0].children.length - 1].name.ref.AssetRecordAssignmentId
        //     console.log(idsNum , this.dataSource.data)
        //     let elem = document.querySelector('#color' + idsNum)
        //     elem.style.backgroundColor = "blue";
        // }
        // }
        // console.log("this.dataSource.data", this.dataSource.data);
      }
    );
  }

  getTime() {
    this.TimeZoneOffset = this.UserData[0].TimeZoneOffset;
    // console.log("lakhantime", this.TimeZoneOffset);
    const now = this.calcTime(this.TimeZoneOffset);
    var timeList = [];
    for (let i = 0; i < 20; i++) {
      now.setMinutes(now.getMinutes() - 1);
      const time =
        ("0" + now.getHours()).slice(-2) +
        "" +
        ("0" + now.getMinutes()).slice(-2);
      timeList.push(time);
    }
    this.timeList = timeList;
  }

  calcTime(offset) {
    // create Date object for current location
    let date = new Date();
    // convert to msec
    // add local time zone offset
    // get UTC time in msec
    let utc = date.getTime() + date.getTimezoneOffset() * 60000;

    // create new Date object for different city
    // using supplied offset
    let propertyDate = new Date(utc + 3600000 * offset);
    return propertyDate;
  }

  checkProperty() {
    if (this.propertyID) {
      return true;
    } else {
      this.tostre.error("Please first select a Company.", "", {
        positionClass: "toast-top-right",
      });
      // }).then((result) => {
      this.router.navigate([
        "products/administration/propertymanagement/propertydetail",
      ]);
      //});
      return false;
    }
  }

  changeFile(event) {
    this.value = event.target.files;
    // console.log("eventtarget", this.value);
  }
  download(pdfUrl: string, pdfName: string) {
    //const pdfUrl = './assets/sample.pdf';
    //const pdfName = 'your_pdf_file';
    FileSaver.saveAs(pdfUrl, pdfName);
  }

  answer1 = [];
  checkboxChange(event: MatCheckboxChange, index) {
    // console.log("index", index);
    this.items = this.incidentExtrainfo.get("items") as FormArray;
    if (event.checked == true) {
      // console.log("lakhanm");
      let array = this.items.controls[index].value.Answer
        ? this.items.controls[index].value.Answer.split(",")
        : [];
      if (array.length != 0) {
        this.answer = this.items.controls[index].value.Answer.split(",");
      } else {
        this.answer = [];
      }
      this.answer.push(event.source.value.trim());
    } else {
      this.answer = this.items.controls[index].value.Answer
        ? this.items.controls[index].value.Answer.trim().split(",")
        : [];
      this.answer.forEach((element, index) => {
        if (element.trim() === event.source.value.trim()) {
          // console.log("element", element);
          this.answer.splice(index, 1);
        }
      });

      // let findIndex = this.answer.indexOf(event.source.value,0);
      // console.log("findIndex",findIndex);
      // console.log("event.source.value",event.source.value);
      // if (findIndex > -1) {
      //   console.log("lakhanl");
      //   this.answer.splice(findIndex, 1);
      // }
    }
    const array3 = [];
    let array2 = this.answer;
    let array1 = this.items.controls[index].value.CustomElementName;
    array1.forEach((element, index) => {
      array2.forEach((element1, index1) => {
        if (element.trim() == element1.trim()) {
          array3.push(element);
        }
      });
    });
    // console.log("array3", array3);
    // console.log("this.answer", this.answer);
    // this.items.value[index].Answer = array3.join(",");
    // this.items.controls[index].Answer = this.answer.join(',');
    this.items.controls[index].patchValue({ Answer: this.answer.join(",") });
    // console.log(this.items.controls[index].value);
  }

  finallist = [];
  UpdateAssetRecords() {
    this.submitted = true;
    // console.log("incidentextrainfo", this.incidentExtrainfo.value);
    if (this.incidentExtrainfo.invalid) {
      // this.tostre.warning("Plese fill mandatory fields.");
      // console.log("workfill");
      // this.showLoader=false;
    }
    if (this.incidentExtrainfo.valid) {
      this.showLoader = true;
      this.incidentExtrainfo.value.items.forEach((element) => {
        // console.log("arrayitem", this.incidentExtrainfo.value.items);
        if (element.ElementTypeId == 9) {
          element.Answer =
            "data" +
            ":" +
            "image" +
            "/" +
            "jpeg" +
            ";" +
            "base64" +
            "," +
            this.base64textString;
          this.filenames = this.filename;
        } else {
          this.filenames = "";
        }
        this.finallist.push({
          CustomFormTypeId: 6,
          PropertyId: +this.propertyID,
          AssetGroupId: this.AssetGroupId,
          CustomFormId: this.customformid,
          FormElementId: element.CustomFormElementId,
          FormElementDetailsId: element.CustomFormElementId,
          Answer:
            element.ElementTypeId != 6
              ? element.Answer
              : element.Answer + "||" + element.Time,
          IsAnswered:
            element.Answer != null || element.Answer != "" ? true : false,
          IsDeleted: false,
          filename: this.filenames,
          UserId: +this.UserID,
          AssetRecordAssignmentId: +this.childid,
        });
      });

      // this.clicked1=true;
      // console.log("finallog", this.finallist);
      this.AssetsService.UpdateAssetRecords(this.finallist).subscribe((res) => {
        this.finallist = [];
        this.GetAssetCustomFormListByPropertyId();
        this.tostre.success("Record saved successfully.");
        this.showLoader = false;
        if (this.globalid.level == 0) {
          // console.log("which");
          this.getFormArray.controls.splice(0);
          this.takecustomformId(this.globalid);
        }
        //  this.incidentExtrainfo.reset(["Answer"]);
        if (res.status == true) {
          // console.log('workgroup',this.PropertyProfileId);
          //   const params = {
          //     PropertyId: this.propertyID,
          //     CustomFormGroupId:this.CustomFormGroupId
          //   }
          // this.ProfileService.GetCustomFormListByPropertyId(params).subscribe(res => {
          //   this.getcustomelementlist=res.data.getCustomFormListByPropertyId;
          //   console.log(this.getcustomelementlist);
          // });
          // if(n==1)
          // {
          //   setTimeout(() => {
          //     this.showLoader=false;
          //   },3000)
          //     if(this.updtaebutton==true)
          //     {
          //       this.tostre.success("Record updated successfully.");
          //     }
          //     else
          //     {
          //       this.tostre.success("Record saved successfully.");
          //     }
          //     this.updtaebutton=true;
          //   }
          //   if(n==3)
          //   {
          //     this.tostre.success("Record saved successfully.");
          //     this.updtaebutton=true;
          //   }
          // this.savebutton=false;
          // this.clicked1=false;
        }
      });
    }
  }
}
