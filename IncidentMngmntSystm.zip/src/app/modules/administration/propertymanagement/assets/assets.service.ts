import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { environment } from "src/environments/environment";
import { Observable } from "rxjs";
@Injectable({
  providedIn: "root",
})
export class AssetsService {
  url: string;

  constructor(private http: HttpClient) {
    this.url = environment.origin;
  }

  UpdateAssetGroupProperty(param: any): Observable<any> {
    return this.http.post<any>(
      this.url + "api/assetManagement/UpdateAssetGroupProperty",
      param
    );
  }

  UpdateAssetRecords(param: any): Observable<any> {
    return this.http.post<any>(
      this.url + "api/assetManagement/UpdateAssetRecords",
      param
    );
  }
  GetAssetCustomFormListByPropertyId(param: any): Observable<any> {
    return this.http.post<any>(
      this.url + "api/assetManagement/GetAssetCustomFormListByPropertyId",
      param
    );
  }

  GetCustomFormElementList(param: any): Observable<any> {
    return this.http.post<any>(
      this.url + "api/GetCustomFormElementList",
      param
    );
  }

  GetAssetCustomFormDetailsByPropertyId(param: any): Observable<any> {
    return this.http.post<any>(
      this.url + "api/assetManagement/GetAssetCustomFormDetailsByPropertyId",
      param
    );
  }

  GetAssetRecordAnswer(param: any): Observable<any> {
    return this.http.post<any>(
      this.url + "api/assetManagement/GetAssetRecordAnswer",
      param
    );
  }

  DeleteAsseetRecord(param: any): Observable<any> {
    return this.http.post<any>(
      this.url + "api/assetManagement/DeleteAsseetRecord",
      param
    );
  }

  GetCustomFormDetailsByPropertyId(param) {
    return this.http.post<any>(
      this.url + "api/GetCustomFormDetailsByPropertyId",
      param
    );
  }

  // this.api is the updatecustomform
  // GetPropertyProfileDetails
}
