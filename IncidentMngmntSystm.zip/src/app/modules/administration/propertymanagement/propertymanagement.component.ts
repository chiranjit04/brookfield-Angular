import { Component, OnInit , OnDestroy } from "@angular/core";
import { PropertManagementService } from "./propertyManagement.service";
import { FormGroup, FormBuilder, FormControl } from "@angular/forms";
import { Observable } from "rxjs";
import { startWith, map, filter } from "rxjs/operators";
import { DataSharingService } from "./dataSharing.service";
import { StorageService } from '../../../services/storage.service';
@Component({
  selector: "app-propertymanagement",
  templateUrl: "./propertymanagement.component.html",
  styleUrls: ["./propertymanagement.component.scss"]
})
export class PropertymanagementComponent implements OnInit,OnDestroy {
  constructor(private storageService : StorageService) {}
  ngOnInit() {

  }
  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    console.log("destroy workds")
    this.storageService.removeData("PropertyDetail")
  }
}
