import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignCompanytableComponent } from './assign-companytable.component';

describe('AssignCompanytableComponent', () => {
  let component: AssignCompanytableComponent;
  let fixture: ComponentFixture<AssignCompanytableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssignCompanytableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignCompanytableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
