import {
  Component,
  OnInit,
  ViewChild,
  Input,
  OnChanges,
  SimpleChanges,
} from "@angular/core";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource, MatTable } from "@angular/material/table";
import { DataSharingService } from "../dataSharing.service";
import { Router, ActivatedRoute } from "@angular/router";
import { PropertManagementService } from "../propertyManagement.service";
import Swal from "sweetalert2";
import { StorageService } from "../../../../services/storage.service";
import { UserPermissionService } from "src/app/services/user-permission.service";
// const companyTypeOrDiv: any = [
//   {
//     assignCompanyName: "",
//     assignCompanyType: "",
//     assignCompanyassined: "",
//     assignCompanyassinedBy: "H",
//     assignCompanyaction: ""
//   }
// ];
@Component({
  selector: "app-assign-companytable",
  templateUrl: "./assign-companytable.component.html",
  styleUrls: ["./assign-companytable.component.scss"],
})
export class AssignCompanytableComponent implements OnInit {
  properid: string;
  companyTypeOrDiv: any = [];
  dataSource: MatTableDataSource<any>;
  @ViewChild(MatTable, { static: false }) table: MatTable<any>;
  @ViewChild("TableOneSort", { static: false }) tableOneSort: MatSort;
  displayedColumns: string[] = [
    // "assignCompanyName",
    // "assignCompanyType",
    // "assignCompanyassined",
    // "assignCompanyassinedBy",
    // "assignCompanyaction"
    "CompanyName",
    "CompanyType",
    "AssignedDate",
    "AssignedBy",
    "assignCompanyaction",
  ];
  constructor(
    private propertyManagementService: PropertManagementService,
    private data: DataSharingService,
    private route: ActivatedRoute,
    private storage: StorageService,
    public UserPermission: UserPermissionService
  ) {
    this.dataSource = new MatTableDataSource();
  }

  ngOnInit() {
    const propertyID = this.route.snapshot.paramMap.get("id");
    this.properid = propertyID;
    if (propertyID) {
      this.data.companyAssignedListStream.subscribe((x: any) => {
        if (this.storage.getData("PropertyDetail") != null) {
          // this.dataSource.data.push(x);
          // this.table.renderRows();
          if (x.AssignedPropertyCompanyList) {
            this.dataSource.data = x.AssignedPropertyCompanyList;
            this.dataSource.sort = this.tableOneSort;
          }
        }
      });
    }
  }

  @Input()
  set assignRows(assignObject: any) {
    if (assignObject) {
      assignObject.IsActive = 1;
      this.dataSource.data.push(assignObject);
      this.dataSource.data = this.dataSource.data;
      this.table.renderRows();
    }
  }

  activated(id1) {
    Swal.fire({
      text: "Are you sure you want to Change Status?",
      showCancelButton: true,
      width: "30%",
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes",
      cancelButtonText: "No",
    }).then((result) => {
      if (result.value) {
        const params = {
          PropertyCompanyID: id1,
        };

        this.propertyManagementService
          .ChangePropertyCompanyStatus(params)
          .subscribe((res2) => {
            if (res2.status == true) {
              const params1 = {
                PropertyID: this.properid,
              };
              this.propertyManagementService
                .GetAssignedPropertyCompanyList(params1)
                .subscribe((x) => {
                  // if (typeof x == "string") return;
                  // this.dataSource.data.push(x);
                  // this.table.renderRows();
                  this.dataSource.data = x.AssignedPropertyCompanyList;
                  this.dataSource.sort = this.tableOneSort;
                });
            }
          });
      }
    });
  }
}
