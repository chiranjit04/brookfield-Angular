import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignpropertyprofileComponent } from './assignpropertyprofile.component';

describe('AssignpropertyprofileComponent', () => {
  let component: AssignpropertyprofileComponent;
  let fixture: ComponentFixture<AssignpropertyprofileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssignpropertyprofileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignpropertyprofileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
