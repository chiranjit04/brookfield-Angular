import { TestBed } from '@angular/core/testing';

import { AssignpropertyprofileService } from './assignpropertyprofile.service';

describe('AssignpropertyprofileService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AssignpropertyprofileService = TestBed.get(AssignpropertyprofileService);
    expect(service).toBeTruthy();
  });
});
