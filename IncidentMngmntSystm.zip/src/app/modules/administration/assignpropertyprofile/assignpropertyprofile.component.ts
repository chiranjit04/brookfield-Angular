import { Component, OnInit, ViewChild } from "@angular/core";
import { AssignpropertyprofileService } from "./assignpropertyprofile.service";
import { FormGroup, FormControl, Validators } from "@angular/forms";
import Swal from "sweetalert2";
import * as XLSX from "xlsx";
import { ToastrService } from "ngx-toastr";
import { MatSort, MatSortable } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { Router } from "@angular/router";
import { CdkDragDrop, moveItemInArray } from "@angular/cdk/drag-drop";
import { __core_private_testing_placeholder__ } from "@angular/core/testing";
import { map, startWith } from "rxjs/operators";
import * as pdfMake from "pdfmake";
import { saveAs } from "file-saver";
import pdfFonts from "pdfmake/build/vfs_fonts";
import { environment } from "../../../../environments/environment";
pdfMake.vfs = pdfFonts.pdfMake.vfs;
import { logoBase64 } from "../propertymanagement/locationmanagement/brookfieldlogo";
import { Observable } from "rxjs";
import { UserPermissionService } from "../../../services/user-permission.service";
import { StorageService } from "../../../services/storage.service";
import { ServiceService } from "./../service/service.service";

@Component({
  selector: "app-assignpropertyprofile",
  templateUrl: "./assignpropertyprofile.component.html",
  styleUrls: ["./assignpropertyprofile.component.scss"],
})
export class AssignpropertyprofileComponent implements OnInit {
  currentdate: string;
  /** Upload Excel start  */

  title = "read-excel-in-angular8";
  storeData: any;
  jsonData: any;
  fileUploaded: File;
  worksheet: any;
  htmlData: any;

  profilelist: any;
  uploadTableShow: any = false;
  OriginalTableNotShow: any = false;
  selectedItem: any = false;

  drop(event: CdkDragDrop<string[]>) {
    moveItemInArray(
      this.customformlist,
      event.previousIndex,
      event.currentIndex
    );
  }
  applyFilter: any;
  GlobalEnvironmentID = 0;
  GlobalEnvironmentName = "";
  GOENumber = "";
  GlobalEnvironmentDetails = null;

  customformgrouplist: any;
  customformlist: any;
  propertylist: any;
  userData = null;
  currentUserID: any;

  addcate2 = false;
  RecordFormGroupEditable = false;
  isShown = false;

  selectedCustomFormGroupId = false;

  statusShowSub = false;
  selectedCustomFormId = false;
  assignprofilelist: any;
  selectedPropertyId: false;
  value2 = 0;
  streets: any[] = [];
  filteredStreets: Observable<any>;
  subprop = "This is a Property Sub-unit of Property";
  propertystreets: any[] = [];
  propertyfilteredStreets: Observable<any>;
  propertyProfileDetails: any;
  AssignPropertyFilters = {
    CustomFormGroupId: "",
    PropertyID: "",
  };

  authToken = null;

  constructor(
    private tostre: ToastrService,
    private AssignpropertyprofileService: AssignpropertyprofileService,
    public router: Router,
    public UserPermission: UserPermissionService,
    private storage: StorageService,
    private adminService: ServiceService
  ) {
    //... Read User Data ...
    this.authToken = this.storage.getData("token");
    this.userData = JSON.parse(this.storage.getData("UserData"));
    if (this.authToken == null) {
      this.router.navigate(["/login"]);
    }

    /* check module permission of the user */
    if (
      this.UserPermission.checkPermission(
        "access_assign_property_profile_forms",
        "",
        "",
        ""
      ) == false
    ) {
      this.router.navigate(["/products/list"]);
      this.tostre.warning(
        "You don't have permission to access this module.",
        "",
        {
          positionClass: "toast-top-right",
        }
      );
    }

    this.GlobalEnvironmentDetails = JSON.parse(
      this.storage.getData("GlobalEnvironmentDetails")
    );
    if (this.GlobalEnvironmentDetails) {
      //this.groupData = this.organise(this.exportreport);
      this.GlobalEnvironmentID = this.GlobalEnvironmentDetails.GlobalEnvironmentId;
      this.GlobalEnvironmentName = this.GlobalEnvironmentDetails.GlobalEnvironmentName;
      this.GOENumber = this.GlobalEnvironmentDetails.GOENo;
    }

    this.currentUserID = this.userData[0].UserID;
  }

  displayedColumns: string[] = [
    "PropertyName",
    "PropertyID",
    "PropertyType",
    "ParentProperty",
    "EnvironmentName",
    "FormGroupTitle",
    "UpdateStatus",
    "UpdatedDate",
    "UpdatedBy",
    "Frequency",
    "action",
  ];

  displayedColumnsOne: string[] = [
    "GOETitle",
    "FormGroupTitle",
    "FormGroupDescription",
    "FrequencyTitle",
    "RecordFormTitle",
    "PropertyName",
    "Status",
    "Message",
  ];
  // dataSource = new MatTableDataSource(this.assignprofilelist);
  dataSource = new MatTableDataSource();
  dataSourceOne = new MatTableDataSource();
  @ViewChild(MatSort, null) sort: MatSort;

  ngOnInit() {
    if (this.checkGoe()) {
      this.AssignPropertyFilters = {
        CustomFormGroupId: "",
        PropertyID: "",
      };
      this.getCustomFormGroup(this.GlobalEnvironmentID);
      this.GetCustomFormListByGoeId(0, this.GlobalEnvironmentID);
      this.GetPropertyByGoeId(0, this.GlobalEnvironmentID);
      this.storage.removeData("AssignPropertyProfileFilter");
      this.CustomFormGroupScreenView(this.GlobalEnvironmentID, 0, 0);
      this.dataSource.sort = this.sort;
      this.dataSourceOne.sort = this.sort;

    }
  }

  selectedFrequency;
  data: any = [
    { id: 1, name: "No Mandatory Update Required" },
    { id: 2, name: "Daily" },
    { id: 3, name: "Weekly" },
    { id: 4, name: "Bi-weekly" },
    { id: 5, name: "Monthly" },
    { id: 6, name: "Quarterly" },
    { id: 7, name: "Biannually" },
    { id: 8, name: "Yearly" },
  ];

  /**
   *
   * Add Custom Record Group Form
   *
   */

  AddCustomGroupForm = new FormGroup({
    Title: new FormControl("", [Validators.required]),
    Description: new FormControl(""),
  });
  addCustomGForm = false;
  get addCGF() {
    return this.AddCustomGroupForm.controls;
  }

  /**
   *
   * Edit Custom Record Group Form
   *
   */

  editCustomGForm = new FormGroup({
    Title: new FormControl("", [Validators.required]),
    Description: new FormControl(""),
    IsActive: new FormControl(""),
    frequencyValue: new FormControl(""),
  });
  editCustomGF = false;
  get editCGF() {
    return this.editCustomGForm.controls;
  }

  resetEditCustomRecordGroup() {
    this.editCustomGForm.reset();
  }

  formGroupControl = new FormControl();
  propertyControl = new FormControl();
  /**
   * Get Custom Form Group List
   * @param GoeID
   */

  getCustomFormGroup(GoeID) {
    const obj = {
      GlobalEnvironmentId: +this.GlobalEnvironmentID,
    };
    let result: any;
    this.AssignpropertyprofileService.GetCustomFormGroup(obj).subscribe(
      (res) => {
        result = res;
        this.customformgrouplist = result.data.getCustomFormGroup;
        this.streets = [];
        for (let i = 0; i < this.customformgrouplist.length; i++) {
          const arr = this.customformgrouplist[i].Title;
          this.streets.push({
            CustomFormGroupId: this.customformgrouplist[i].CustomFormGroupId,
            Title: this.customformgrouplist[i].Title,
          });
        }
        this.filteredStreets = this.formGroupControl.valueChanges.pipe(
          startWith(""),
          map((val: any) => (val.length >= 0 ? this._filter(val) : []))
          // map((val: any) => this._filter(val))
        );

        // console.log("customformgrouplist", this.customformgrouplist)
      }
    );
  }
  _filter(val: any): any[] {
    return this.streets
      .map((x) => x)
      .filter((option) =>
        option.Title.toLowerCase().includes(val.toLowerCase())
      );
  }

  /**
   * Filter form by Custom Form Group
   * @param value1
   */
  customformgroupid = 0;
  filterform(value) {
    // this.getCustomFormGroup(this.GlobalEnvironmentID)

    // console.log("value customformgroupid", value);
    this.customformgroupid = value;

    this.storage.setData(
      "AssignPropertyProfileFilter",
      JSON.stringify({
        CustomFormGroupId: this.customformgroupid,
        PropertyId: this.propertyid,
      })
    );

    this.filterAssignpropertyList();
  }

  /**
   * Change Custom Form Group Filter
   * @param CustomFormGroupId
   * @param Title
   * @param event
   * @param Obj
   */
  changeCustomFormGroup(CustomFormGroupId, Title, event, Obj) {
    if (!event.isUserInput) return;
    if (CustomFormGroupId != "") {
      this.customformgroupid = CustomFormGroupId;
      this.filterAssignpropertyList();
    }
    //else {
    //   this.dataSource = new MatTableDataSource(this.workgroupList);
    // }
  }

  checkProfileGroup() {
    this.filteredStreets = this.formGroupControl.valueChanges.pipe(
      startWith(""),
      // map((val: any) => this._filter(val))
      map((val: any) => (val.length >= 0 ? this._filter(val) : []))
    );
  }

  propertyid = 0;
  filterProperty(value) {
    // console.log("value propertyid", value);
    this.propertyid = value;

    this.storage.setData(
      "AssignPropertyProfileFilter",
      JSON.stringify({
        CustomFormGroupId: this.customformgroupid,
        PropertyId: this.propertyid,
      })
    );

    this.filterAssignpropertyList();
  }

  filterAssignpropertyList() {
    const obj = {
      GlobalEnvironmentId: this.GlobalEnvironmentID,
      CustomFormGroupId: this.customformgroupid,
      PropertyId: this.propertyid,
    };

    this.CustomFormGroupScreenView(
      this.GlobalEnvironmentID,
      obj.CustomFormGroupId,
      obj.PropertyId
    );
  }

  /**
   * Get Custom Form List
   * @param GoeID
   *
   */

  GetCustomFormListByGoeId(CustomFormGroupId, GoeID) {
    const obj = {
      GlobalEnvironmentId: +GoeID,
      CustomFormGroupId: CustomFormGroupId,
    };

    let result: any;
    this.AssignpropertyprofileService.GetCustomFormListByGoeId(obj).subscribe(
      (res) => {
        result = res;
        this.customformlist = result.data.getCustomFormListByGoeId;
        // console.log("this.customformlist", this.customformlist);
      }
    );
  }

  /**
   * Get Property List
   * @param GoeID
   *
   */

  GetPropertyByGoeId(CustomFormGroupId, GoeID) {
    const obj = {
      CustomFormGroupId: CustomFormGroupId,
      GlobalEnvironmentID: +GoeID,
    };
    this.propertystreets = [];
    let result: any;
    this.AssignpropertyprofileService.GetPropertyByGoeId(obj).subscribe(
      (res) => {
        result = res;
        this.propertylist = result.data.getPropertyByGoeId;

        for (let i = 0; i < this.propertylist.length; i++) {
          const arr = this.propertylist[i].PropertyName;
          this.propertystreets.push({
            PropertyID: this.propertylist[i].PropertyID,
            PropertyName: this.propertylist[i].PropertyName,
          });
        }
        this.propertyfilteredStreets = this.propertyControl.valueChanges.pipe(
          startWith(""),
          map((val: any) => (val.length >= 0 ? this._filterProperty(val) : []))
          // map((val: any) => this._filterProperty(val))
        );
      }
    );
  }

  _filterProperty(val: any): any[] {
    return this.propertystreets
      .map((x) => x)
      .filter((option) =>
        option.PropertyName.toLowerCase().includes(val.toLowerCase())
      );
  }

  checkProperty() {
    this.propertyfilteredStreets = this.propertyControl.valueChanges.pipe(
      startWith(""),
      map((val: any) => (val.length >= 0 ? this._filterProperty(val) : []))
    );
    // test.blur();
  }
  /**
   * Update Custom Form Group
   * @param GoeID
   *
   */

  UpdateCustomFormGroup(obj) {
    this.AssignpropertyprofileService.UpdateCustomFormGroup(obj).subscribe(
      (res) => {
        // console.log(res);
        this.addcate2 = false;
        this.RecordFormGroupEditable = false;
        this.getCustomFormGroup(this.GlobalEnvironmentID);
      }
    );
  }

  /**
   * Reset Custom Record Group Form
   *
   */
  resetCustomRecordGroup() {
    this.addcate2 = !this.addcate2;
    this.AddCustomGroupForm.reset();
    this.addCustomGForm = false;
  }

  /**
   * Add Custom Record Group Form
   *
   */

  addCustomRecordGroup() {
    let postData = this.AddCustomGroupForm.value;
    this.addCustomGForm = true;
    //console.log("data", postData)

    if (this.AddCustomGroupForm.invalid) {
      return;
    }

    if (postData.Title.trim() == "") {
      this.tostre.success(" Title is required");
      // Swal.fire({
      //   text:
      // })
      return false;
    }
    const obj = {
      CustomFormGroupId: 0,
      Title: postData.Title.trim(),
      Description: postData.Description,
      FrequencyId: 0,
      GlobalEnvironmentId: +this.GlobalEnvironmentID,
      UserId: +this.currentUserID,
      IsActive: 1,
    };

    if (
      !this.customformgrouplist.find(
        (elem) => obj.Title.trim() == elem.Title.trim()
      )
    ) {
      this.UpdateCustomFormGroup(obj);
    } else {
      this.tostre.success(`${obj.Title} Title already exists`);
      // Swal.fire({
      //   title: ` ${obj.Title} Title already exists`
      // });
    }

    //console.log(obj)
    // this.addEditPatrolZone(obj)
    //this.addcate2 = !this.addcate2
  }

  closeEditCustomGroupForm() {
    this.addcate2 = !this.addcate2;
    this.RecordFormGroupEditable = false;
    this.AddCustomGroupForm.reset();
    this.addCustomGForm = false;
    let shadesEl = document.querySelectorAll(".show");
    for (let i = 0; i < shadesEl.length; i++) {
      shadesEl[i].classList.remove("show");
    }
  }

  checkGoe() {
    if (this.GlobalEnvironmentID) {
      return true;
    } else {
      // Swal.fire({
      //   text: "Please first select a Global Operations Environment.",
      // }).then((result) => {
      //   this.router.navigate(["products/administration/goe/mygoe"]);
      //   //}
      // });
      this.tostre.error(
        "Please first select a Global Operations Environment.",
        "",
        {
          positionClass: "toast-top-right",
        }
      );
      return false;
    }
  }

  toggleShow() {
    this.isShown = !this.isShown;

    if (this.storage.getData("AssignPropertyProfileFilter")) {
      let AssignPropertyProfileFilter = JSON.parse(
        this.storage.getData("AssignPropertyProfileFilter")
      );
      let selectedGroupId = AssignPropertyProfileFilter.CustomFormGroupId;
      let selectedPId = AssignPropertyProfileFilter.PropertyId;
      this.CustomFormGroupScreenView(
        this.GlobalEnvironmentID,
        selectedGroupId,
        selectedPId
      );
    } else {
      this.CustomFormGroupScreenView(this.GlobalEnvironmentID, 0, 0);
      //this.GetPropertyByGoeId(0, this.GlobalEnvironmentID);
    }
  }

  /**
   * Edit CustomGroupForm
   * @param data
   */

  editCustomGroupForm(data) {
    this.selectedCustomFormGroupId = data.CustomFormGroupId;
    this.addcate2 = false;
    // console.log("editCustomGroupForm", data);
    this.editCustomGForm.patchValue({
      Title: data.Title,
    });
    this.editCustomGForm.patchValue({
      Description: data.Description,
      IsActive: data.IsActive,

      frequencyValue: data.Frequency,
    });
    this.frequency = data.FrequencyID;

    this.statusShowSub = data.IsActive;
  }
  /**
   * Select CustomForm Group
   * @param CustomFormGroupId
   *
   */
  customFormGroupSelected(CustomFormGroupId) {
    // console.log("selectedID", CustomFormGroupId);
    this.addcate2 = false;

    if (this.selectedCustomFormGroupId == CustomFormGroupId) {
      this.selectedCustomFormGroupId = false;
      this.selectedPropertyId = false;
      //this.selectedCustomFormId = false
    } else {
      this.selectedCustomFormGroupId = CustomFormGroupId;
      this.GetCustomFormListByGoeId(
        CustomFormGroupId,
        this.GlobalEnvironmentID
      );
      this.GetPropertyByGoeId(CustomFormGroupId, this.GlobalEnvironmentID);
    }
  }
  frequency: any;
  getfrequency(id) {
    this.frequency = id;
  }

  /**
   * Update CustomRecord Group
   * @param data
   * @param value
   */
  updateCustomRecordGroup(data, value) {
    if (
      !value.frequencyValue &&
      !this.data.find((elem) => value.frequencyValue == elem.name)
    ) {
      this.tostre.success(`Invalid Frequency`);
      // Swal.fire({
      //   text: `Invalid Frequency`
      // })

      return false;
    }
    if (value.frequencyValue == "") {
      this.frequency = 0;
    }
    this.editCustomGF = true;
    if (this.editCustomGForm.invalid) {
      if (value.Title.trim() == "") {
        // console.log("nihl");
        this.tostre.success("Title is required");
        // Swal.fire({
        //   text: "Title is required"
        // })
        return false;
      }
      return false;
    }

    // if (value.Description.trim() == "") {
    //   Swal.fire({
    //     text: " Zone Description is required"
    //   })
    //   return false
    // }

    const obj = {
      CustomFormGroupId: data.CustomFormGroupId,
      Title: value.Title.trim(),
      Description: value.Description,
      FrequencyId: +this.frequency,
      GlobalEnvironmentId: +this.GlobalEnvironmentID,
      UserId: +this.currentUserID,
      IsActive: value.IsActive ? 1 : 0,
    };

    // console.log("obj====>>>edit custom group form", obj);

    // if (!this.customformgrouplist.find(

    //   elem => obj.Title.trim() == elem.Title.trim())) {

    //   this.UpdateCustomFormGroup(obj)

    // }
    // else {

    //   Swal.fire({
    //     title: ` ${obj.Title} Title already exists`
    //   });
    // }

    this.UpdateCustomFormGroup(obj);
  }
  /**
   * Change CustomRecordGroup status
   * @param CustomFormGroupId
   */

  changeCustomRecordGroupstatus(CustomFormGroupId) {
    const obj = {
      CustomFormGroupId: +CustomFormGroupId,
    };

    this.AssignpropertyprofileService.UpdateStatusCustomFormGroup(
      obj
    ).subscribe((res) => {
      let obj1 = this.customformgrouplist.find(
        (o) => o.CustomFormGroupId == obj.CustomFormGroupId
      );

      let index = this.customformgrouplist.indexOf(obj1);
      this.customformgrouplist.fill(
        (obj1.IsActive = !obj1.IsActive),
        index,
        index++
      );
      this.tostre.success(this.adminService.statusMsg);
    });
  }

  changeCustomRecordStatus(id: any) {
    let element: HTMLElement = document.getElementById(
      "status-customrg-" + id
    ) as HTMLElement;
    element.click();

    // console.log("id", id);
    this.statusShowSub = !this.statusShowSub;
  }

  /**
   * Select Custom Form
   * @param data
   *
   */
  customFormSelected(data) {
    if (this.selectedCustomFormGroupId) {
      this.assignCustomFormToCustomFormGroup(data);
    } else {
      this.tostre.success("Please Select Property Record Form Group First");
      // Swal.fire({
      //   text: "Please Select Property Record Form Group First",
      // });
    }
  }
  /**
   * Assign CustomForm To CustomFormGroup
   * @param data
   *
   */

  assignCustomFormToCustomFormGroup(data) {
    const obj = {
      CustomFormGroupId: this.selectedCustomFormGroupId,
      CustomFormId: data.CustomFormId,
      IsAssined: data.IsAssigned ? 0 : 1,
      displayOrder: 0,
    };

    this.AssignpropertyprofileService.AssignCustomFormToCustomFormGroup(
      obj
    ).subscribe((res) => {
      this.GetCustomFormListByGoeId(
        obj.CustomFormGroupId,
        this.GlobalEnvironmentID
      );
    });
  }

  /**
   * Custom FormGroup ScreenView
   * @param data
   *
   */
  CustomFormGroupScreenView(
    GlobalEnvironmentId,
    CustomFormGroupId,
    PropertyId
  ) {
    const obj = {
      GlobalEnvironmentId: +GlobalEnvironmentId,
      CustomFormGroupId: +CustomFormGroupId,
      PropertyId: +PropertyId,
    };

    let result: any;
    this.AssignpropertyprofileService.CustomFormGroupScreenView(obj).subscribe(
      (res) => {
        result = res;
        this.assignprofilelist = result.data.CustomFormGroupScreenView;
        this.dataSource = new MatTableDataSource(this.assignprofilelist);
        this.dataSource.sort = this.sort;
        this.sort.disableClear = true;
      }
    );
  }

  /**
   * Assign Property To CustomFormGroup
   * @param data
   *
   */

  assignPropertyToCustomFormGroup(data) {
    const obj = {
      CustomFormGroupId: this.selectedCustomFormGroupId,
      AssignedPropertyId: data.PropertyID,
      IsAssined: data.IsAssigned ? 0 : 1,
    };

    this.AssignpropertyprofileService.AssignPropertyToCustomFormGroup(
      obj
    ).subscribe((res) => {
      this.GetPropertyByGoeId(obj.CustomFormGroupId, this.GlobalEnvironmentID);
    });
  }

  /**
   * Delete Custom Form Group
   * @param CustomFormGroupId
   *
   */

  deletecustomFormGroup(CustomFormGroupId) {
    const obj = {
      CustomFormGroupId: +CustomFormGroupId,
    };
    Swal.fire({
      // text: "Are you sure you want to remove this ?",
      text: this.adminService.deleteMsg,
      showCancelButton: true,
      confirmButtonText: "Yes",
      cancelButtonText: "No",
    }).then((result) => {
      if (result.value) {
        this.AssignpropertyprofileService.DeleteCustomFormGroup(obj).subscribe(
          (res) => {
            // console.log(res);

            this.getCustomFormGroup(this.GlobalEnvironmentID);
          }
        );
      }
    });
  }

  propertySelected(data) {
    let postData = {
      CustomFormGroupId: this.selectedCustomFormGroupId,
      AssignedPropertyId: data.PropertyID,
      IsAssined: data.IsAssigned ? 0 : 1,
    };
    // console.log("data", data);
    // console.log("postData", postData);
    if (this.selectedCustomFormGroupId) {
      if (data.IsAssignedtoCustomFormGroup == 1) {
        this.AssignpropertyprofileService.AssignPropertyToCustomFormGroup(
          postData
        ).subscribe((resp) => {
          this.GetPropertyByGoeId(
            this.selectedCustomFormGroupId,
            this.GlobalEnvironmentID
          );
        });
      } else if (data.IsAssigned == 1) {
        this.AssignpropertyprofileService.AssignPropertyToCustomFormGroup(
          postData
        ).subscribe((res) => {
          this.GetPropertyByGoeId(
            this.selectedCustomFormGroupId,
            this.GlobalEnvironmentID
          );
        });
      } else {
        Swal.fire({
          //title: 'Are you sure you want to delete ?',
          text:
            "This property is assigned to other group. Do you want to assign this ?",
          showCancelButton: true,
          confirmButtonText: "Yes",
          cancelButtonText: "No",
        }).then((result) => {
          if (result.value) {
            let result: any;
            this.AssignpropertyprofileService.AssignPropertyToCustomFormGroup(
              postData
            ).subscribe((resp) => {
              result = resp;
              this.GetPropertyByGoeId(
                this.selectedCustomFormGroupId,
                this.GlobalEnvironmentID
              );
            });
          }
        });
      }
    } else {
      this.tostre.success("Please Select Property Record Form Group First");
      // Swal.fire({
      //   text: "Please Select Property Record Form Group First",
      // });
    }
  }

  onselectedItem(data: any) {
    // CustomFormGroupId
    if (this.selectedItem == data.PropertyID) {
      this.selectedItem = !this.selectedItem;
    } else {
      // CustomFormGroupId
      this.selectedItem = data.PropertyID;
    }
  }

  /**
   * Export Property Profile Sheet
   * @param profileObj
   */

  exportToPdf(profileObj) {
    // console.log("profile", profileObj);
    const obj1 = {
      PropertyId: +profileObj.PropertyID,
      CustomFormGroupId: +profileObj.CustomFormGroupId,
    };
    const obj = {
      PropertyId: +profileObj.PropertyID,
    };

    this.AssignpropertyprofileService.GetPropertyProfileDetails(obj1).subscribe(
      (res) => {
        this.AssignpropertyprofileService.GetCustomFormDetailsByPropertyId(
          obj
        ).subscribe((res1) => {
          if (res.data.getPropertyProfileDetails[0].length != 0) {
            this.convertPdf(res, res1);
            this.tostre.success("Downloaded Successfully.");
          } else {
            this.tostre.warning("Property Profile Sheet is Empty.");
          }
        });
      }
    );
  }

  async convertPdf(obj1, obj2) {
    let obj = obj1.data.getPropertyProfileDetails[0];
    // console.log("lakhan", obj);
    // console.log("sharma", obj2);
    let parserQuest = [];
    let parserQuest1 = [];
    let d = new Date();
    this.currentdate =
      d.getMonth() + 1 + "/" + d.getDate() + "/" + d.getFullYear();

    let PropertyDetails = obj2.data.getCustomFormDetailsByPropertyId[0];

    // console.log("PropertyDetails-->>", PropertyDetails);

    // let y = obj.forEach((elem, index) => {
    //   elem.Name$ = elem.CustomFormAnswer[0].LastModifiedBy === undefined ? '' : elem.CustomFormAnswer[0].LastModifiedBy
    // })

    let x = obj.map((elem, index) => {
      return [
        {
          margin: [-34, 0, 0, 2],
          layout: {
            hLineWidth: function (i, node) {
              return i === 0 || i === node.table.body.length ? 1.5 : 1.5;
            },
            vLineWidth: function (i, node) {
              return i === 0 || i === node.table.widths.length ? 1.5 : 1.5;
            },
            hLineColor: function (i, node) {
              return i === 0 || i === node.table.body.length
                ? "lightgrey"
                : "lightgrey";
            },
            vLineColor: function (i, node) {
              return i === 0 || i === node.table.widths.length
                ? "lightgrey"
                : "lightgrey";
            },
          },
          style: {
            borderColor: "grey",
          },
          table: {
            widths: [572],
            body: [
              [
                {
                  layout: "noBorders",
                  table: {
                    widths: [320, 190],
                    body: [
                      [
                        {
                          text: elem.Title,
                          style: {
                            fontSize: 13,
                          },
                          margin: [28, 0, 0, 0],
                        },
                        {
                          text: `Last Update: ${elem.LastModifiedDate} By: ${elem.LastModifiedBy}`,
                          style: {
                            color: "grey",
                          },
                          margin: [60, 2, -60, 0],
                        },
                      ],
                    ],
                  },
                },
              ],
              [
                elem.CustomFormAnswer.map((elem1, index1) => {
                  if (elem1.ElementTypeId == 5) {
                    if (elem1.Answer != "" && elem1.Answer != null) {
                      let d = new Date(elem1.Answer);
                      let d1 =
                        d.getMonth() +
                        1 +
                        "/" +
                        d.getDate() +
                        "/" +
                        d.getFullYear();
                      elem1.Answer = d1;
                    } else {
                      elem1.Answer = elem1.Answer;
                    }
                  } else if (elem1.ElementTypeId == 6) {
                    if (elem1.Answer != "" && elem1.Answer != null) {
                      let time = elem1.Answer.split("||");
                      let d = new Date(time[0]);
                      let d1 =
                        d.getMonth() +
                        1 +
                        "/" +
                        d.getDate() +
                        "/" +
                        d.getFullYear() +
                        "," +
                        time[1];
                      elem1.Answer = d1;
                    } else {
                      elem1.Answer = elem1.Answer;
                    }
                  } else if (elem1.ElementTypeId == 9) {
                    if (elem1.Answer != "" && elem1.Answer != null) {
                      let file = elem1.Answer.split("/");
                      if (file[0] == "data" + ":" + "image") {
                        elem1.Answer = "";
                      }
                      elem1.Answer = file[2];
                    } else {
                      elem1.Answer = elem1.Answer;
                    }
                  } else if (elem1.ElementTypeId == 7) {
                    if (elem1.Answer != "" && elem1.Answer != null) {
                      let check = elem1.Answer.split(",");
                      elem1.Answer = check.join(", ");
                    }
                  } else {
                    elem1.Answer = elem1.Answer;
                  }
                  return {
                    layout: "noBorders",
                    table: {
                      widths: [490],
                      body: [
                        [
                          {
                            text: elem1.ElementName,
                            style: {
                              bold: true,
                              fontSize: 10,
                            },
                            margin: [28, 5, 0, 0],
                          },
                        ],
                        [
                          {
                            text: elem1.Answer,
                            style: {},
                            margin: [34, 0, 0, 0],
                          },
                        ],
                      ],
                    },
                  };
                }),
              ],
            ],
          },
        },
      ];
    });

    let urlPath = environment.origin;
    if (
      PropertyDetails.ImagePath === "" ||
      PropertyDetails.ImagePath === undefined ||
      PropertyDetails.ImagePath === null
    ) {
      urlPath = `${location.origin}/assets/images/imagenaBg.png`;
      // urlPath = `https://i.picsum.photos/id/866/200/200.jpg`;
    } else {
      urlPath = environment.imagePath + "users/" + PropertyDetails.ImageName;
    }
    // console.log("urlPath====>>>", urlPath);

    let propertyImageBase64 = await this.toDataUrlBase64(urlPath);
    // console.log("propertyImageBase64-->", propertyImageBase64)

    //  console.log("parserQuest", parserQuest)
    // console.log("parserQuest1", parserQuest1)

    var dd = {
      pageSize: "A4",
      // info: {
      //   // title: `${this.obj.companyDetail.CompanyName}`,
      //   // author: `${this.obj.companyDetail.CompanyName}`,
      //   subject: "All Detail of Company and work group and Company",
      //   keywords: "Company Management",
      //   creationDate: `${new Date()}`,
      // },
      content: [
        {
          alignment: "justify",
          columns: [
            {
              image: logoBase64,
              width: 150,
              height: 50,
            },
          ],
        },
        {
          text: "\n",
        },
        {
          canvas: [
            {
              type: "line",
              x1: 0,
              y1: 0,
              x2: 500,
              y2: 0,
              lineWidth: 1,
              lineColor: "lightgrey",
            },
          ],
        },
        {
          text: "\n",
        },
        {
          layout: "noBorders",
          table: {
            widths: [120, 300, 150, 150],
            body: [
              [
                {
                  image: propertyImageBase64,
                  width: 110,
                  height: 70,
                  margin: [0, 0, 0, 6],
                },
                {
                  layout: "noBorders",
                  table: {
                    widths: [500],
                    body: [
                      [
                        {
                          text: `${PropertyDetails.PropertyName} - ${PropertyDetails.PropertyIdentNumber} `,
                          style: { bold: true, fontSize: 20 },
                        },
                      ],
                      [
                        {
                          text: `${
                            PropertyDetails.SubPropertyUnit == null
                              ? ""
                              : this.subprop +
                                ": " +
                                PropertyDetails.SubPropertyUnit
                          }`,
                          style: { bold: true, fontSize: 12 },
                        },
                        // {
                        //   text: `${PropertyDetails.SubPropertyUnit==null?'Subunit':''}`,
                        //   visibility:[]
                        // },
                      ],
                      // [
                      //   {
                      //     text: `PROPERTY ID- `,
                      //     color: "grey",
                      //     bold: true,
                      //     fontSize: 10
                      //   },
                      // ],
                      [
                        {
                          layout: "noBorders",
                          table: {
                            widths: [180, 150],
                            height: [80],
                            body: [
                              // [

                              //   {
                              //     text: `Update Frequency: ${PropertyDetails.Frequency}`,
                              //     color: "#181818",
                              //     bold: true,
                              //     fontSize: 10,
                              //     margin: [292, 2, -292, 0],
                              //     },

                              // ],
                              [
                                {
                                  text: `Generated on: ${this.currentdate}`,
                                  color: "#181818",
                                  bold: true,
                                  fontSize: 10,
                                  margin: [305, 30, -305, -4],
                                },
                              ],
                            ],
                          },
                        },
                      ],
                    ],
                  },
                },
              ],
            ],
          },
        },
        {
          layout: "noBorders",
          table: {
            body: [...x],
          },
        },
      ],

      styles: {
        header: {},
        bigger: {
          fontSize: 12,
          bold: true,
        },
        normal: {
          bold: true,
        },
      },
      defaultStyle: {
        columnGap: 10,
        fontSize: 9,
      },
      colorFont: {
        bold: true,
        color: "#0x153AB",
      },
    };

    pdfMake
      .createPdf(dd)
      .download(this.generateFilename("PropertyProfileSheet", ".pdf"));
    // pdfMake.createPdf(dd).open();
    // created with actual name of property name / compant name of pdf Maker.
  }
  public generateFilename(propertyName: string, extension: string): string {
    return `${
      propertyName === "" || propertyName === undefined || propertyName === null
        ? "defaultAssignPropertyProfile"
        : propertyName
    }-${Date.now()}.${extension}`;
  }

  toDataUrlBase64(url: string) {
    const toBase64 = fetch(url)
      .then((response) => response.blob())
      .then(
        (blob) =>
          new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve(reader.result);
            reader.onerror = reject;
            reader.readAsDataURL(blob);
          })
      );

    return toBase64;
  }
  /**
   * Remove Filter
   */
  removeFilter(event, prop) {
    switch (prop) {
      case "CustomFormGroupId":
        this.storage.removeData("AssignPropertyProfileFilter");
        this.customformgroupid = 0;
        this.formGroupControl.setValue("");

      case "PropertyID":
        this.storage.removeData("AssignPropertyProfileFilter");
        this.propertyid = 0;
        this.propertyControl.setValue("");

      //   //Blank the SubCategory list
      //   await this.getInspectionSubCategoryList(0);
      //   //Reset Property filter
      //   this.inspectionFormFilters['SubCategoryID'] = 0;
      //   //Reset form value
      //   this.inspectionFilterForm.get('SubCategoryID').patchValue('');
      //   break;
      // case 'WorkGroupId':
      //   //Blank the Propety list
      //   await this.getPropertiesByWorkGroupId(0);
      //   //Reset Property filter
      //   this.inspectionFormFilters['PropertyId'] = '';
      //   //Reset form value
      //   this.inspectionFilterForm.get('Property').patchValue('');
      //   break;
    }
    //this.assetFormFilters[prop] = "";
    //this.getAssetGroupListOnViewScreen();
    this.filterAssignpropertyList();
  }

  closePage() {
    window.location.reload();
  }

  //Upload excel sheet
  /* Upload file */
  openFileBrowser(event: any) {
    event.preventDefault();
    let element: HTMLElement = document.getElementById("file") as HTMLElement;
    element.click();
  }

  uploadedFile(event) {
    this.uploadTableShow = true;
    this.OriginalTableNotShow = true;
    // this.isShown = true;
    this.fileUploaded = event.target.files[0];
    this.readExcel();
  }
  readExcel() {
    let readFile = new FileReader();

    readFile.onload = (e) => {
      this.storeData = readFile.result;

      var data = new Uint8Array(this.storeData);

      var arr = new Array();

      for (var i = 0; i != data.length; ++i)
        arr[i] = String.fromCharCode(data[i]);

      var bstr = arr.join("");

      var workbook = XLSX.read(bstr, { type: "binary" });

      var first_sheet_name = workbook.SheetNames[1];

      this.worksheet = workbook.Sheets[first_sheet_name];

      var range = XLSX.utils.decode_range(this.worksheet["!ref"]);
      range.s.r = 2; // <-- zero-indexed, so setting to 1 will skip row 0
      this.worksheet["!ref"] = XLSX.utils.encode_range(range);

      this.readAsJson(this.currentUserID);
    };

    readFile.readAsArrayBuffer(this.fileUploaded);
  }

  // Upload Excel End

  /** Read As Json */

  readAsJson(currentUserID) {
    this.jsonData = XLSX.utils.sheet_to_json(this.worksheet, { raw: false });

    //this.jsonData = JSON.stringify(this.jsonData);

    var arrofobj = (this.profilelist = this.jsonData);
    // this.patrolZoneImportList = this.jsonData

    var result = arrofobj.map(function (el) {
      var o = Object.assign({}, el);
      o.UserID = +currentUserID;
      // o.Status = "";
      o.Message = "";
      o.RecNo = "";
      return o;
    });
    let length = Object.keys(result).length;

    this.propertyProfileImport(result);
    // this.getPropertyPatrolZoneList(this.PropertyID, 0);
  }
  newObjArr = [];
  propertyProfileImport(obj) {
    // console.log("obj====final hit to service --->>>>", obj);
    // console.log("obj is here", obj);
    let matchProfile =
      Object.keys(obj[0]).includes("Frequency") &&
      Object.keys(obj[0]).includes("Form Group Title");
    // console.log("test", matchProfile);

    if (matchProfile) {
      // this.uploadfileList = true;
      // this.onscreenList = false;
      if (obj.length == 0) {
        Swal.fire({
          text: "No Data Found ",
        });
        return;
      }

      for (var i = 0; i < obj.length; i++) {
        let newObj = {
          RecNo: obj[i].RecNo,
          GOETitle: obj[i]["GOE Title"],
          FormGroupTitle: obj[i]["Form Group Title"],
          FormGroupDescription: obj[i]["Form Group Description"],
          FrequencyTitle: obj[i]["Frequency"],
          RecordFormTitle: obj[i]["Record Form Title"],
          PropertyName: obj[i]["Property Name"],
          FormGroupStatus: obj[i]["Status"],
          UserID: +obj[i].UserID,
          Status: "",
          Message: "",
        };
        this.newObjArr.push(newObj);
      }
      let passingArray = this.newObjArr;
      // console.log(passingArray);
      let result: any;
      this.AssignpropertyprofileService.PropertyProfileImport(
        passingArray
      ).subscribe(
        (res) => {
          result = res;
          if (res) {
            // console.log("Uploaded list", result);
            this.dataSourceOne = new MatTableDataSource(
              result.data.PropertyProfileImport
            );
            this.dataSourceOne.sort = this.sort;
            this.sort.disableClear = true;
            //
            // Swal.fire({
            //   text: 'Profile Imported Successfully',
            // });
            // this.profileImportData = result.profileImport.recordsets[0];
            // this.dataSourceOne = new MatTableDataSource(this.profileImportData);
            // this.showValid("Processed successfully. Please check the table.");
          }
          // this.profileImportData = result.profileImport.recordsets[0]
          // this.dataSourceOne = new MatTableDataSource(this.profileImportData)
        },
        (error) => {
          if (error.status == 500) {
            Swal.fire({
              text: "Import Failed",
            });
          }
        }
      );
    } else {
      this.tostre.warning(
        "Uploaded Excel Sheet is Invalid. Please put the right one."
      );
    }
  }

  //Download Excel Sheet

  exportImportData(): void {
    let data = JSON.parse(JSON.stringify(this.assignprofilelist));
    let tempData = [];
    // console.log("downloaded data", data);
    data.forEach(function (item, i) {
      delete item.RecNo;
      delete item.UserID;
      delete item.Status;
      delete item.Message;
      delete item.CreatedBy;
      delete item.CreatedDate;
      delete item.CustomFormGroupId;
      delete item.NEXTUpdatedDate;
      delete item.ParentProperty;
      delete item.PropertyAnswerCount;
      delete item.PropertyID;
      delete item.PropertyIdentNumber;
      delete item.UpdatedBy;
      delete item.UpdatedDate;
      delete item.PropertyType;
      //  delete item.UpdateStatus;
      tempData.push(item);
    });
    tempData.forEach((data) => {
      data.IsActive = data.IsActive ? "Active" : "Inactive";
    });
    // console.log("what data is going for download", tempData);
    this.AssignpropertyprofileService.exportAsExcelFile(tempData);
  }

  exportData(): void {
    let data = JSON.parse(JSON.stringify(this.assignprofilelist));
    let tempData = [];
    // console.log("downloaded data", data);
    data.forEach(function (item, i) {
      delete item.RecNo;
      delete item.CreatedBy;
      delete item.CreatedDate;
      delete item.CustomFormGroupId;
      delete item.NEXTUpdatedDate;
      delete item.ParentProperty;
      delete item.PropertyAnswerCount;
      delete item.PropertyID;
      delete item.PropertyIdentNumber;
      delete item.UpdatedBy;
      delete item.UpdatedDate;
      delete item.PropertyType;
      tempData.push(item);
    });
    tempData.forEach((data) => {
      data.IsActive = data.IsActive ? "Active" : "Inactive";
    });
    // console.log("what data is going for download", tempData);
    this.AssignpropertyprofileService.exportFile(tempData);
  }
  // exportProfileList() {
  //   let data = JSON.parse(JSON.stringify(this.profilelist));
  //   console.log(this.profilelist);
  //   let tempData = [];
  //   data.forEach(function (item, i) {
  //     delete item.ProfileID;
  //     delete item.CompanyID;
  //     delete item.CompanySubDivision;
  //     delete item.CreatedDate;
  //     delete item.CreatedBy;
  //     delete item.RecordTimeStamp;
  //     delete item.IsAssociateJobTitle;
  //     delete item.ParentName;
  //     if (item.IsActive == 1) {
  //       item.IsActive = "Active";
  //     } else {
  //       item.IsActive = "Inactive";
  //     }
  //     tempData.push(item);
  //   });
  //   console.log(tempData);
  //   this.profileService.exportAsExcelFile(tempData);
  // }
}
