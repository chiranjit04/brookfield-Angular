import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DynamicrecordformsComponent } from './dynamicrecordforms.component';
import { DynamicrecordformslistComponent } from './dynamicrecordformslist/dynamicrecordformslist.component';
import { AuthGuard } from "./../../../guard/auth.guard";

const routes: Routes = [
  { 
    path: '', 
    canActivate: [ AuthGuard ],
    component: DynamicrecordformslistComponent
   },
  { 
    path: 'dynamicrecordformslist', 
    canActivate: [ AuthGuard ],
    component: DynamicrecordformslistComponent 
  },
  { 
    path: 'dynamicrecordforms', 
    canActivate: [ AuthGuard ],
    component: DynamicrecordformsComponent 
  },
];



@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DynamicrecordformsRoutingModule { }
