import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { environment } from "../../../../environments/environment";
import { Observable } from "rxjs";
@Injectable({
  providedIn: "root",
})
export class DynamicrecordformsService {
  GetCustomFormList(pbody: {
    FormTypeId: number;
    GlobalEnvironmentId: number;
  }) {
    throw new Error("Method not implemented.");
  }
  url: any;
  observable: Observable<any>;
  constructor(private http: HttpClient) {
    this.url = environment.origin + "api/";
  }
  // private url = 'http://localhost:1601/api/';

  getDynamiclist(pbody) {
    this.observable = this.http.post(`${this.url}GetCustomFormList`, pbody);
    return this.observable;
  }

  Deleteformlist(dbody) {
    this.observable = this.http.post(`${this.url}DeleteCustomForm`, dbody);
    return this.observable;
  }

  Updatecustomform(cbody) {
    this.observable = this.http.post(`${this.url}UpdateCustomForm`, cbody);
    return this.observable;
  }

  Updatecustomformelement(bbody) {
    this.observable = this.http.post(
      `${this.url}UpdateCustomFormElement`,
      bbody
    );
    return this.observable;
  }

  GetCustomFormElementList(gbody) {
    this.observable = this.http.post(
      `${this.url}GetCustomFormElementList`,
      gbody
    );
    return this.observable;
  }

  DeleteCustomFormElement(dfbody) {
    this.observable = this.http.post(
      `${this.url}DeleteCustomFormElement`,
      dfbody
    );
    return this.observable;
  }

  UpdateCustomFormSubject(sbody) {
    this.observable = this.http.post(
      `${this.url}UpdateCustomFormSubject`,
      sbody
    );
    return this.observable;
  }

  GetReportingSetList(rslbody) {
    this.observable = this.http.post(`${this.url}GetReportingSetList`, rslbody);
    return this.observable;
  }

  GetAssignedSubjectByID(sibody) {
    this.observable = this.http.post(
      `${this.url}GetAssignedSubjectByID`,
      sibody
    );
    return this.observable;
  }

  GetCustomFormElementByID(editform) {
    this.observable = this.http.post(
      `${this.url}GetCustomFormElementByID`,
      editform
    );
    return this.observable;
  }

  UpdateCustomFormStatus(statusform) {
    this.observable = this.http.post(
      `${this.url}UpdateCustomFormStatus`,
      statusform
    );
    return this.observable;
  }

  companySearchList(companysearch) {
    this.observable = this.http.post(
      `${this.url}companySearchList`,
      companysearch
    );
    return this.observable;
  }

  propertySearchList(propertsearch) {
    this.observable = this.http.post(
      `${this.url}propertySearchList`,
      propertsearch
    );
    return this.observable;
  }

  GetCustomFormElementType() {
    this.observable = this.http.get(
      `${this.url}assetManagement/GetCustomFormElementType`
    );
    return this.observable;
  }

  GetCustomFormType()
  {
    this.observable = this.http.get(
      `${this.url}GetCustomFormType`
    );
    return this.observable;
  }




  UpdateCustomFormElementOrder(cbody) {
    this.observable = this.http.post(`${this.url}UpdateCustomFormElementOrder`, cbody);
    return this.observable;
  }
}
