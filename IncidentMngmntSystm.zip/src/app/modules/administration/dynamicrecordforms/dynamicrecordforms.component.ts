import { Component, OnInit, Renderer2 } from "@angular/core";
import { CdkDragDrop, moveItemInArray } from "@angular/cdk/drag-drop";
import { MatDialog } from "@angular/material";
import {
  FormBuilder,
  FormGroup,
  Validators,
  FormArray,
  FormControl,
} from "@angular/forms";
import { DynamicrecordformsService } from "./dynamicrecordforms.service";
import { ToastrService } from "ngx-toastr";
import Swal from "sweetalert2";
import { Validation } from "../../../shared/common-validation";
import { ActivatedRoute } from "@angular/router";
// tslint:disable-next-line: max-line-length
import { ModelIncidentsubjectComponent } from 'src/app/modules/dispatch/incident-dispatch/model-incidentsubject/model-incidentsubject.component';
import { AssigntriggerstorecordComponent } from "./assigntriggerstorecord/assigntriggerstorecord.component";
import { StorageService } from '../../../services/storage.service';
import { UserPermissionService } from "../../../services/user-permission.service";

@Component({
  selector: "app-dynamicrecordforms",
  templateUrl: "./dynamicrecordforms.component.html",
  providers: [Validation],
  styleUrls: ["./dynamicrecordforms.component.scss"],
})
export class DynamicrecordformsComponent implements OnInit {
  favoriteformtypes: string;
  // formtypes = [
  //   { id: "1", formtype: "Dispatch Guide Form" },
  //   { id: "2", formtype: "Property Profile Form" },
  //   { id: "3", formtype: "Daily Activity Log Record Extra Information" },
  //   { id: "4", formtype: "Incident Report File Extra Record" },
  //   { id: "5", formtype: "inspection Form" },
  //   { id: "6", formtype: "Assets" },
  // ];
  // SystemPickValue = [
  //   { name: "Properties" },
  //   { name: "Officer" },
  //   { name: "Role" },
  //   { name: "Officer" },
  //   { name: "Location Code" },
  //   { name: "Sector" },
  //   { name: "Incident" },
  // ];

  formtypesadd = [
    { CustomFormElementTypeId: "1", Title: "Line of Text" },
    { CustomFormElementTypeId: "2", Title: "Text Box" },
    { CustomFormElementTypeId: "3", Title: "Radio Buttons" },
    { CustomFormElementTypeId: "4", Title: "Dropdown Menu" },
    { CustomFormElementTypeId: "5", Title: "Date Field Picker" },
    { CustomFormElementTypeId: "6", Title: "Date and Time Field" },
    { CustomFormElementTypeId: "7", Title: "Checkboxes" },
    { CustomFormElementTypeId: "8", Title: "Numeric Field" },
    { CustomFormElementTypeId: "9", Title: "Upload Option" },
    // { id: "10", name: "Select System Pick Value Type" }
  ];

  // formtypesaddassets = [
  //   { id: "1", name: "Line of Text" },
  //   { id: "2", name: "Text Box" },
  //   { id: "3", name: "Radio Buttons" },
  //   { id: "4", name: "Dropdown Menu" },
  //   { id: "5", name: "Date Field Picker" },
  //   { id: "6", name: "Date and Time Field" },
  //   { id: "7", name: "Checkboxes" },
  //   { id: "8", name: "Number of Field" },
  //   { id: "9", name: "Upload Option" },
  //   { id: "10", name: "Record Name" },
  //   { id: "11", name: "Last Updated" },
  //   { id: "12", name: "Status" },
  //   { id: "13", name: "Expires On" },

  // ];
  statuspickvalue = [
    { name: "Fully Functional" },
    { name: "Functional Not Optimal" },
    { name: "Not Functional" },
  ];
  getnulltypes = [{ ElementTypeId: 0 }];
  registerForm: FormGroup;
  LineoftextForm: FormGroup;
  textbox: FormGroup;
  NumberfieldForm: FormGroup;
  TimefieldForm: FormGroup;
  DatefieldForm: FormGroup;
  RadioForm: FormGroup;
  DropdownForm: FormGroup;
  CheckboxForm: FormGroup;
  UpdateCustomForm: FormGroup;
  FileUploadForm: FormGroup;
  SystemPickForm: FormGroup;
  LastUpdatedForm: FormGroup;
  StatusForm: FormGroup;
  ExpiresonForm: FormGroup;
  RecordnameForm: FormGroup;
  items: FormArray;
  items1: FormArray;
  submitted = false;
  submitted2 = false;
  submitted3 = false;
  submitted4 = false;
  submitted8 = false;
  submitted6 = false;
  submitted5 = false;
  submitted7 = false;
  submitted9 = false;
  submitted10 = false;
  submitted11 = false;
  submitted12 = false;
  submitted13 = false;
  submitted14 = false;
  submitted15 = false;
  submitted16 = false;
  linetext: any;
  textboxvalue: any;
  radioformarray: any;
  ttle: any;
  desc: any;
  formId: any;
  word = "3";
  replytype: any;
  updatetoform: any;
  formselect:boolean;
  firstcustomformid = 0;
  movies = [
    "Episode I - The Phantom Menace",
    "Episode II - Attack of the Clones",
    "Episode III - Revenge of the Sith",
    "Episode IV - A New Hope",
    "Episode V - The Empire Strikes Back",
    "Episode VI - Return of the Jedi",
    "Episode VII - The Force Awakens",
    "Episode VIII - The Last Jedi",
    "Episode IX – The Rise of Skywalker",
  ];
  items2: FormArray;
  FormPreview="Form Preview"
  dynamicrecordlist: any;
  GlobalEnvironmentID = 0;
  GlobalEnvironmentName = "";
  GOENumber = "";
  GlobalEnvironmentDetails = null;
  lint: any;
  eti: any;
  radiobt: any;
  Dropdownformarray: any;
  dmenutitle: any;
  datefieldtitle: any;
  timefieldtitle: any;
  checkfieldtitle: any;
  checkfieldarray: any;
  numberfieldtitle: any;
  responseformid = null;
  getrecordformdata: any;
  newradioformarrau: any;
  aroy: string;
  user: string;
  UserID: any;
  UserData: any;
  FirstName: any;
  LastName: any;
  FullName: any;
  day: any;
  month: any;
  year: any;
  fullDated: string;
  reportingset = false;
  radioarray: any;
  work: string;
  formmodelopen = false;
  qwer: any;
  falseWhileNoValue: true;
  customformelementid = null;
  customformid: any;
  elementtypeid: any;
  p1: string;
  p2: string;
  cufid: string;
  lntx: any;
  clicked = false;
  subjectid: any;
  p3: string;
  p4: string;
  p5: boolean;
  p6: boolean;
  p7: string;
  p9: string;
  p11: boolean = true;
  condition1 = true;
  condition2 = true;
  p8: string;
  getsubjectbyid: any;
  UpdateFormElementName: any;
  updaterowarrow: any;
  clicked1 = false;
  title: any;
  description: any;
  uploadtitle: any;
  systemtitle: any;
  maxcharacter: any;
  maxnod: any;
  defaulttext: any;
  ddtext: any;
  sdefualt: any;
  UpdateFormCustomFormElement: any;
  noofch: any;
  defulattext: any;
  updateformbutton = "ADD TO FORM";
  deafultvalueofradiobutton: any;
  deafultvalueofCheckbox: any;
  ptitle = "Record Form Title";
  nocharcter: any;
  clicked2: boolean;
  selectedformelement: any;
  TimeZoneOffset: Date;
  timeList: any[];
  clicked3: boolean;
  reportingset1: boolean;
  saveforming: boolean;
  selectedsubject: boolean;
  getCustomFormType: any;
  GetCustomFormElementType: any;
  formpreviewcondition:boolean;
  buttoncolorvariable:boolean;
  fromwork: { CustomFormElementTypeId: string; Title: string }[];
  recordnamevariable=true;
  currentCheckedValue = null;
  constructor(
    private validation: Validation,
    public dialog: MatDialog,
    private tostre: ToastrService,
    private DynamicService: DynamicrecordformsService,
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private storage: StorageService,
    public UserPermission: UserPermissionService,
    private ren: Renderer2
  ) {
    this.GlobalEnvironmentDetails = JSON.parse(
      this.storage.getData("GlobalEnvironmentDetails")
    );
    // console.log(this.GlobalEnvironmentDetails);
    if (this.GlobalEnvironmentDetails) {
      this.GlobalEnvironmentID = this.GlobalEnvironmentDetails.GlobalEnvironmentId;
      this.GlobalEnvironmentName = this.GlobalEnvironmentDetails.GlobalEnvironmentName;
      this.GOENumber = this.GlobalEnvironmentDetails.GOENo;
    }
    this.UserData = JSON.parse(this.storage.getData("UserData"));
    // console.log(this.UserData);
    this.TimeZoneOffset = this.validation.calcTime(
      this.UserData[0].TimeZoneOffset
    );
    this.FirstName = this.UserData[0].FirstName;
    this.LastName = this.UserData[0].LastName;
    this.UserID = this.UserData[0].UserID;
    this.FullName = this.FirstName + " " + this.LastName;
    const a = new Date();
    this.day = a.getDate();
    this.month = a.getMonth() + 1;
    this.year = a.getFullYear();
    this.fullDated = this.month + "/" + this.day + "/" + this.year;
    this.fromwork = this.formtypesadd;

    const now = this.TimeZoneOffset;
    var timeList = [];
    for (let i = 0; i < 20; i++) {
      now.setMinutes(now.getMinutes() - 1);
      const time =
        ("0" + now.getHours()).slice(-2) +
        "" +
        ("0" + now.getMinutes()).slice(-2);
      timeList.push(time);
    }
    this.timeList = timeList;
    this.DynamicService.GetCustomFormElementType().subscribe((res1) => {
      this.GetCustomFormElementType = res1.data.GetCustomFormElementType;
    });
  }

  editPage:any = false;

  ngOnInit() {
    this.DynamicService.GetCustomFormType().subscribe((res) => {
      this.getCustomFormType = res.data.getCustomFormType;
    });

    this.route.paramMap.subscribe((params) => {
      this.p1 = params.get("p1");
      if (this.p1 == null) {
        this.firstcustomformid = 0;
        this.editPage = false;
      } else {
        this.firstcustomformid = JSON.parse(this.p1);
        this.editPage = true;
      }
      
      this.formpreviewcondition=true;
      this.p2 = params.get("p2");
      this.p3 = params.get("p3");
      this.p4 = params.get("p4");
      this.p5 = JSON.parse(params.get("p5"));
      this.p6 = JSON.parse(params.get("p6"));
      this.p7 = params.get("p7");
      this.p9 = params.get("p9")
      console.log("worked", this.p7);
      this.p8 = params.get("p8");
      if (this.p3 == null) {
        this.title = "";
      } else {
        this.title = this.p3;
        this.ptitle = this.p3;
      }
      if (this.p4 == null) {
        this.description = "";
      } else {
        this.description = this.p4;
      }
      if(this.p2==null)
      {
      }
      else
      {
        this.selectformpreviewtype(this.p2);
      }
      if (JSON.parse(params.get("p2")) == 6) {
        this.DynamicService.GetCustomFormElementType().subscribe((res1) => {
          this.GetCustomFormElementType = res1.data.GetCustomFormElementType;
          this.fromwork = this.GetCustomFormElementType;
        });
        console.log("theframwork", this.fromwork);
      }

      if (JSON.parse(params.get("p2")) == 2) {
        this.selectedsubject = true;
      }
    });

    this.responseformid = this.p1;
    this.cufid = this.p2;
    const gbody = {
      CustomFormID: this.p1,
    };
    this.DynamicService.GetCustomFormElementList(gbody).subscribe((res2) => {
      this.getrecordformdata = res2.CustomFormElementList;
      if(this.getrecordformdata.length!=0)
      {
        this.getrecordformdata.forEach(element=>{
            if(element.ElementTypeId==10)
            {
             this.recordnamevariable=false;
            }
        })
      }
    });
    this.LineoftextForm = this.formBuilder.group({
      linetext: ["", Validators.required],
    });
    this.textbox = this.formBuilder.group({
      textboxtitle: ["", Validators.required],
      maxno: ["", [Validators.required, Validators.pattern("^[0-9]*$")]],
      defaulttextbox: ["", Validators.required],
    });
    this.NumberfieldForm = this.formBuilder.group({
      numberfield: ["", Validators.required],
      maxnd: ["", [Validators.required, Validators.pattern("^[0-9]*$")]],
    });
    this.TimefieldForm = this.formBuilder.group({
      timefield: ["", [Validators.required]],
    });
    this.DatefieldForm = this.formBuilder.group({
      datefield: ["", Validators.required],
    });
    this.RadioForm = this.formBuilder.group({
      items: this.formBuilder.array([]),
      nofradio: ["", [Validators.required, Validators.pattern("^[0-9]*$")]],
      Radiobuttontitle: ["", Validators.required],
    });

    this.DropdownForm = this.formBuilder.group({
      items1: this.formBuilder.array([]),
      dmenutitle: ["", Validators.required],
      nopickvalue: ["", [Validators.required, Validators.pattern("^[0-9]*$")]],
      // ddefaulttext: ["", Validators.required],
      ddefaulttext: [""],
    });

    this.CheckboxForm = this.formBuilder.group({
      items2: this.formBuilder.array([]),
      Checkboxtitle: ["", Validators.required],
      nocbox: ["", [Validators.required, Validators.pattern("^[0-9]*$")]],
    });

    this.UpdateCustomForm = this.formBuilder.group({
      CustomFormId: ["", Validators.required],
      Title: [""],
      Description: [""],
    });

    this.FileUploadForm = this.formBuilder.group({
      fileuploadname: ["", Validators.required],
    });

    this.SystemPickForm = this.formBuilder.group({
      systempickvalue: ["", Validators.required],
      sdefaulttext: ["", Validators.required],
    });

    this.LastUpdatedForm = this.formBuilder.group({
      lastupdatedname: ["", Validators.required],
    });

    this.StatusForm = this.formBuilder.group({
      statusname: ["", Validators.required],
    });

    this.ExpiresonForm = this.formBuilder.group({
      expireson: ["", Validators.required],
    });

    this.RecordnameForm = this.formBuilder.group({
      recordname: ["", Validators.required],
    });
  }
  // All forms controls link
  get f() {
    return this.LineoftextForm.controls;
  }
  get f2() {
    return this.textbox.controls;
  }
  get f3() {
    return this.RadioForm.controls;
  }
  get f4() {
    return this.DropdownForm.controls;
  }
  get f5() {
    return this.DatefieldForm.controls;
  }
  get f6() {
    return this.TimefieldForm.controls;
  }
  get f7() {
    return this.CheckboxForm.controls;
  }
  get f8() {
    return this.NumberfieldForm.controls;
  }
  get f9() {
    return this.UpdateCustomForm.controls;
  }
  get f10() {
    return this.FileUploadForm.controls;
  }
  get f11() {
    return this.SystemPickForm.controls;
  }
  get f12() {
    return this.LastUpdatedForm.controls;
  }
  get f13() {
    return this.StatusForm.controls;
  }
  get f14() {
    return this.ExpiresonForm.controls;
  }
  get f15() {
    return this.RecordnameForm.controls;
  }
  // All Form Reset Link
  onReset() {
    this.getFormArray.controls.splice(0);
    this.getFormArray1.controls.splice(0);
    this.getFormArray2.controls.splice(0);
    this.submitted = false;
    this.submitted2 = false;
    this.submitted3 = false;
    this.submitted4 = false;
    this.submitted5 = false;
    this.submitted6 = false;
    this.submitted7 = false;
    this.submitted8 = false;
    this.submitted11 = false;
    this.submitted12 = false;
    this.submitted13 = false;
    this.submitted14 = false;
    this.submitted15 = false;
    this.submitted16 = false;
    this.LineoftextForm.reset();
    this.textbox.reset();
    this.RadioForm.reset();
    this.DropdownForm.reset();
    this.DatefieldForm.reset();
    this.TimefieldForm.reset();
    this.CheckboxForm.reset();
    this.NumberfieldForm.reset();
    this.FileUploadForm.reset();
    this.SystemPickForm.reset();
    this.LastUpdatedForm.reset();
    this.StatusForm.reset();
    this.ExpiresonForm.reset();
    this.RecordnameForm.reset();
    this.img1 = false;
    this.img2 = false;
    this.img3 = false;
    this.img4 = false;
    this.img4 = false;
    this.img5 = false;
    this.img6 = false;
    this.img7 = false;
    this.img8 = false;
    this.img9 = false;
    this.img10 = true;
    this.img11 = false;
    this.img12 = false;
    this.img13 = false;

    // this.customformelementid = null;
    // this.updateformbutton = "ADD TO FORM";
    this.clicked2 = false;

    this.ExpiresonForm.patchValue({
      expireson:"Expires On"
    });

    this.RecordnameForm.patchValue({
      recordname:"Record Name"
    });

    this.LastUpdatedForm.patchValue({
      lastupdatedname:"Last Updated"
    });

     this.StatusForm.patchValue({
      statusname:"Status"
    });

  }

  // getTime() {

  // }
  numberOnly(event: any): boolean {
    event = (event) ? event : window.event
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
  array=[];
  drop(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.getrecordformdata, event.previousIndex, event.currentIndex);
    this.array=[];
    this.getrecordformdata.forEach((element,index) => {
    this.array.push(element.CustomFormElementId+','+(index+1));
    });
    const param=
    {
      CustomFormElementOrder:this.array.join('|')
    }
    console.log("param",param);
   this.DynamicService.UpdateCustomFormElementOrder(param).subscribe(res=>{

   });

  }
 selectformpreviewtype(id)
 {
    if(id==1)
    {
      this.FormPreview="Dispatch Guide Form";
    }
    else if(id==2)
    {
      this.FormPreview="Property Profile Form";
    }
    else if(id==3)
    {
      this.FormPreview="Daily Activity Log Record Extra Information";
    }
    else if(id==4)
    {
      this.FormPreview="Incident Report File Extra Record";
    }
    else if(id==5)
    {
      this.FormPreview="Inspection Form";
    }
    else if(id==6)
    {
      this.FormPreview="Asset Record Form";
    }
 }

buttoncolor()
{
  this.buttoncolorvariable=true;
}

  takevalue(t, el) {
    setTimeout(() => {
      this.deafultvalueofradiobutton = t;
      // let flagCheck;
      // if (this.currentCheckedValue == null || this.currentCheckedValue == 0) {
      //   flagCheck = true
      // } else {
      //   flagCheck = false
      // }
      if (this.currentCheckedValue != null && this.currentCheckedValue === el.value) {
        el.checked = false;
        this.ren.removeClass(el['_elementRef'].nativeElement, 'cdk-focused');
        this.ren.removeClass(el['_elementRef'].nativeElement, 'cdk-program-focused');
        this.currentCheckedValue = null;
        this.deafultvalueofradiobutton = null
      } else {
        this.currentCheckedValue = el.value
      }
    })
  }

  setCheckBoxDefault(value, ele) {
    if (ele.checked == true) {
      this.deafultvalueofCheckbox = "undefined";
    } else {
      this.deafultvalueofCheckbox = value;
    }
  }
  opentype(id) {
    this.replytype = id;
  }

  formpreview()
  {
  this.formpreviewcondition=false;

  }
  onscreen()
  {
    this.formpreviewcondition=true;
  }
  selectformtype(id) {
    console.log("selected form type:",id)
    if (this.p9 != 'edit') {
      this.formselect=id;
      this.clicked = false;
      if (id == 6) {
        this.fromwork = this.GetCustomFormElementType;
      } else {
        this.fromwork = this.formtypesadd;
      }
    }
  }
  // All Form Element List right side
  getlist() {
    setTimeout(() => {
      const gbody = {
        CustomFormID: this.responseformid,
      };
      this.DynamicService.GetCustomFormElementList(gbody).subscribe((res2) => {
        this.getrecordformdata = res2.CustomFormElementList;
      });
    });
  }

  // First Time CustomFormId  creation
  responseidnullupdatemethod() {
    this.formId = this.UpdateCustomForm.value.CustomFormId;
    this.ttle = this.UpdateCustomForm.value.Title;
    this.desc = this.UpdateCustomForm.value.Description;
    const cbody = {
      CustomFormId: 0,
      Title: this.ttle,
      Description: this.desc,
      UserId: this.UserID,
      GlobalEnvironmentId: this.GlobalEnvironmentID,
      CustomFormTypeId: this.formId,
    };
    this.DynamicService.Updatecustomform(cbody).subscribe((res1) => {
      this.responseformid = res1.UpdateCustomForm[0].ID;
      this.firstcustomformid = res1.UpdateCustomForm[0].ID;
      console.log(this.responseformid);
    });
  }


// copyformelement(id)
// {
//   console.log('idddddddddd',id);
//   if()
// }

  updatecustomform(n, lebel) {
    if (n == 1) {
      this.qwer = this.UpdateCustomForm.value.CustomFormId;
      if (this.qwer == 1 || this.qwer == 3 || this.qwer == 4) {
        this.openSubjectDialog(1);
      }
    }
    if (this.qwer == 2) {
      // this.openssigntriggersrecordDialog();
    }
    this.submitted9 = true;
    if (this.UpdateCustomForm.invalid || this.UpdateCustomForm.value.CustomFormId=='' || this.UpdateCustomForm.value.CustomFormId==null || this.UpdateCustomForm.value.CustomFormId==0) {
      this.tostre.warning("Please Select Form Type");
      return;
    } else if (this.firstcustomformid == 0) {
      this.saveforming = true;
      this.formId = this.UpdateCustomForm.value.CustomFormId;
      this.ttle = this.UpdateCustomForm.value.Title;
      this.desc = this.UpdateCustomForm.value.Description;
      const cbody = {
        CustomFormId: 0,
        Title: this.ttle,
        Description: this.desc,
        UserId: this.UserID,
        GlobalEnvironmentId: this.GlobalEnvironmentID,
        CustomFormTypeId: this.formId,
      };

      this.DynamicService.Updatecustomform(cbody).subscribe((res) => {
        this.selectformpreviewtype(this.formId);
        this.responseformid = res.UpdateCustomForm[0].ID;
        this.firstcustomformid = res.UpdateCustomForm[0].ID;
        this.saveforming = false;
        console.log(res.UpdateCustomForm[0].ID);
        this.ptitle = this.ttle;
        if (res.statusCode == 200) {
          this.tostre.success("The Record has been saved successfully.");
        } else {
          this.tostre.warning("Record not updated");
        }
      });
    } else {
      this.formId = this.UpdateCustomForm.value.CustomFormId;
      console.log(this.title, ' ', this.ptitle)
      // this.ttle = this.UpdateCustomForm.value.Title;
      // this.desc=this.UpdateCustomForm.value.Description;
      this.ttle = lebel ? this.UpdateCustomForm.value.Title : this.title;
      this.desc = this.description;
      const cbody = {
        CustomFormId: this.firstcustomformid,
        Title: this.ttle,
        Description: this.desc,
        UserId: this.UserID,
        GlobalEnvironmentId: this.GlobalEnvironmentID,
        CustomFormTypeId: this.formId,
      };

      this.DynamicService.Updatecustomform(cbody).subscribe((res) => {
        this.selectformpreviewtype(this.formId);
        this.responseformid = res.UpdateCustomForm[0].ID;
        this.firstcustomformid = res.UpdateCustomForm[0].ID;
        console.log(res.UpdateCustomForm[0].ID);
        this.ptitle = this.ttle;
        if (res.statusCode == 200) {
          if (n == 1) {
            this.tostre.success("The Record has been save successfully.");
          } else if (n == 2) {
            this.title = this.UpdateCustomForm.value.Title
            this.tostre.success("Record form title save successfully.");
          } else {
            this.tostre.success(
              "Record form description save successfully."
            );
          }
        } else {
          this.tostre.warning("Record not updated.");
        }
      });
    }

    // if(this.p5==true)
    // {
    // this.formId = this.UpdateCustomForm.value.CustomFormId;
    // this.ttle = this.UpdateCustomForm.value.Title;
    // this.desc = this.UpdateCustomForm.value.Description;
    // const cbody = {
    //   CustomFormId: 0,
    //   Title: this.ttle,
    //   Description: this.desc,
    //   UserId: this.UserID,
    //   GlobalEnvironmentId: this.GlobalEnvironmentID,
    //   CustomFormTypeId: this.formId
    // }

    // this.DynamicService.Updatecustomform(cbody).subscribe(res => {
    //   this.responseformid = res.UpdateCustomForm[0].ID;
    //   console.log(res.UpdateCustomForm[0].ID)
    //   if (res.statusCode == 200) {
    //     this.tostre.success(res.UpdateCustomForm[0].Message);
    //   }
    //   else {
    //     this.tostre.warning('Record not updated');
    //   }
    // });
    // }
    // else
    // {
    //   this.formId=this.UpdateCustomForm.value.CustomFormId;
    //   this.ttle = this.UpdateCustomForm.value.Title;
    //   this.desc=this.UpdateCustomForm.value.Description;
    //   const cbody={
    //     CustomFormId:this.p1,
    //     Title: this.ttle,
    //     Description:this.desc,
    //     UserId:this.UserID,
    //     GlobalEnvironmentId:this.GlobalEnvironmentID,
    //     CustomFormTypeId:this.formId
    //   }

    //   this.DynamicService.Updatecustomform(cbody).subscribe(res=>{
    //     this.responseformid=res.UpdateCustomForm[0].ID;
    //      console.log( res.UpdateCustomForm[0].ID)
    //     if(res.statusCode==200)
    //     {
    //       this.tostre.success('Record Updated');
    //     }
    //     else
    //     {
    //       this.tostre.warning('Record not updated');
    //     }
    //     });
    // }
  }

  // All ADD form ELement Method
  Submit1() {
    this.submitted = true;
    this.submitted9 = true;
    if (this.UpdateCustomForm.invalid || this.UpdateCustomForm.value.CustomFormId==0) {
      this.tostre.warning("Please Select Form Type.");
    }
    if (this.LineoftextForm.invalid || this.UpdateCustomForm.invalid || this.UpdateCustomForm.value.CustomFormId==0) {
      return false;
    } else {
      this.clicked2 = true;
      if (this.responseformid == null) {
        this.responseidnullupdatemethod();
      }
      setTimeout(() => {
        this.linetext = this.LineoftextForm.value.linetext;
        this.lint = this.LineoftextForm.value.linetext;
        this.eti = this.replytype;
        if (this.customformelementid == null) {
          const bbody = {
            CustomFormElementId: 0,
            CustomFormId: this.responseformid,
            ElementTypeId: this.eti,
            ElementName: this.lint,
            CustomElementName: "",
            IsMandatory: this.img1,
          };

          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element added successfully.");
                this.getlist();
                this.LineoftextForm.reset();
                this.submitted = false;
                this.img1 = false;
                this.clicked2 = false;
                this.updateformbutton = "ADD TO FORM";
              }
            }
          );
        } else if (this.elementtypeid == 1) {
          const bbody = {
            CustomFormElementId: this.customformelementid,
            CustomFormId: this.customformid,
            ElementTypeId: this.elementtypeid,
            ElementName: this.lint,
            CustomElementName: "",
            IsMandatory: this.img1,
          };
          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element updated successfully.");
                this.getlist();
                this.LineoftextForm.reset();
                this.submitted = false;
                this.clicked2 = false;
                this.img1 = false;
                this.updateformbutton = "ADD TO FORM";
                this.customformelementid = null;
              }
            }
          );
        } else {
          const dfbody = {
            CustomFormElementID: this.customformelementid,
          };
          this.DynamicService.DeleteCustomFormElement(
            dfbody
          ).subscribe((res3) => {
            if(this.eti==10){
            this.recordnamevariable=false;}
          });
          const bbody = {
            CustomFormElementId: 0,
            CustomFormId: this.customformid,
            ElementTypeId: 1,
            ElementName: this.lint,
            CustomElementName: "",
            IsMandatory: this.img1,
          };
          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element updated successfully.");
                this.getlist();
                this.LineoftextForm.reset();
                this.submitted = false;
                this.clicked2 = false;
                this.img1 = false;
                this.updateformbutton = "ADD TO FORM";
                this.customformelementid = null;
              }
            }
          );
        }
      }, 2000);
    }
  }
  // All Update formElementmethod
  updateformelement(cfei, cfi, eti) {
    this.getFormArray2.controls.splice(0);
    this.getFormArray1.controls.splice(0);
    this.getFormArray.controls.splice(0);
    this.updateformbutton = "UPDATE";
    this.customformelementid = cfei;
    this.customformid = cfi;
    this.elementtypeid = eti;
    if (eti == 1) {
      this.selectedformelement = "Line of Text";
      setTimeout(() => {
        const editform = {
          CustomFormElementId: this.customformelementid,
        };
        this.DynamicService.GetCustomFormElementByID(editform).subscribe(
          (res) => {
            this.UpdateFormElementName =
              res.CustomFormElement.recordset[0].ElementName;
            this.img1 = res.CustomFormElement.recordset[0].IsMandatory;
            this.LineoftextForm.patchValue({
              linetext: this.UpdateFormElementName,
            });
          }
        );
      });
      this.replytype = "1";
    } else if (eti == 2) {
      this.selectedformelement = "Text Box";
      const editform = {
        CustomFormElementId: this.customformelementid,
      };
      this.DynamicService.GetCustomFormElementByID(editform).subscribe(
        (res) => {
          this.UpdateFormElementName =
            res.CustomFormElement.recordset[0].ElementName;
          this.img2 = res.CustomFormElement.recordset[0].IsMandatory;
          this.UpdateFormCustomFormElement =
            res.CustomFormElement.recordsets[1][0].CustomElementName;
          this.noofch = res.CustomFormElement.recordset[0].numberofcharacter;
          this.img2 = res.CustomFormElement.recordset[0].IsMandatory;
          this.textbox.patchValue({ textboxtitle: this.UpdateFormElementName });
          this.textbox.patchValue({ maxno: this.noofch });
          this.textbox.patchValue({
            defaulttextbox: this.UpdateFormCustomFormElement,
          });
        }
      );
      this.replytype = "2";
    } else if (eti == 3) {
      this.selectedformelement = "Radio Buttons";
      const editform = {
        CustomFormElementId: this.customformelementid,
      };
      this.DynamicService.GetCustomFormElementByID(editform).subscribe(
        (res) => {
          this.getFormArray.controls.splice(0);
          this.clicked3 = false;
          this.UpdateFormElementName =
            res.CustomFormElement.recordset[0].ElementName;
          this.img3 = res.CustomFormElement.recordset[0].IsMandatory;
          this.RadioForm.patchValue({
            Radiobuttontitle: this.UpdateFormElementName,
          });
          this.updaterowarrow = res.CustomFormElement.recordsets[1];
          this.value1 = this.updaterowarrow.length;
          // this.RadioForm.patchValue({ nofradio: this.value1, });
          // this.RadioForm.patchValue({ nofradio: this.updaterowarrow.length });
          this.items = this.RadioForm.get("items") as FormArray;
          console.log(this.updaterowarrow);
          this.updaterowarrow.forEach((element: any, index: number) => {
            if (index != 0) {
              this.items.push(
                this.formBuilder.group({
                  name: [element.CustomElementName],
                  checked:
                    this.updaterowarrow[0].CustomElementName != undefined &&
                    parseInt(this.updaterowarrow[0].CustomElementName) ===
                      index - 1
                      ? true
                      : false,
                })
              );
            }
          });
          console.log(this.RadioForm.get("items")["controls"]);
          this.RadioForm.patchValue({ nofradio: this.items.length });
        }
      );
      this.replytype = "3";
    } else if (eti == 4) {
      this.selectedformelement = "Dropdown Menu";
      const editform = {
        CustomFormElementId: this.customformelementid,
      };
      this.DynamicService.GetCustomFormElementByID(editform).subscribe(
        (res) => {
          this.getFormArray1.controls.splice(0);
          this.UpdateFormElementName =
            res.CustomFormElement.recordset[0].ElementName;
          this.img4 = res.CustomFormElement.recordset[0].IsMandatory;
          this.DropdownForm.patchValue({
            dmenutitle: this.UpdateFormElementName,
          });
          this.updaterowarrow = res.CustomFormElement.recordsets[1];
          this.defulattext =
            res.CustomFormElement.recordsets[1][0].CustomElementName;
          this.defulattext = this.DropdownForm.patchValue({
            ddefaulttext: this.defulattext,
          });
          this.items1 = this.DropdownForm.get("items1") as FormArray;
          this.updaterowarrow.forEach((element: any, index: number) => {
            if (index != 0)
              this.items1.push(
                this.formBuilder.group({
                  name: [element.CustomElementName],
                  checked: 
                  // new code dated 11/05/21
                  this.updaterowarrow[index].IsPickValue ? true : false

                  // old code 
                  
                    // this.updaterowarrow[0].CustomElementName != undefined &&
                    // this.updaterowarrow[0].CustomElementName ===
                    //   element.CustomElementName
                    //   ? true
                    //   : false,
                })
              );
          });
          this.value2 = this.items1.length;
          this.DropdownForm.patchValue({ nopickvalue: this.value2 });
        }
      );
      this.replytype = "4";
    } else if (eti == 5) {
      this.selectedformelement = "Date Field Picker";
      const editform = {
        CustomFormElementId: this.customformelementid,
      };
      this.DynamicService.GetCustomFormElementByID(editform).subscribe(
        (res) => {
          this.UpdateFormElementName =
            res.CustomFormElement.recordset[0].ElementName;
          this.img5 = res.CustomFormElement.recordset[0].IsMandatory;
          this.DatefieldForm.patchValue({
            datefield: this.UpdateFormElementName,
          });
        }
      );
      this.replytype = "5";
    } else if (eti == 6) {
      this.selectedformelement = "Date and Time Field";
      const editform = {
        CustomFormElementId: this.customformelementid,
      };
      this.DynamicService.GetCustomFormElementByID(editform).subscribe(
        (res) => {
          this.UpdateFormElementName =
            res.CustomFormElement.recordset[0].ElementName;
          this.img6 = res.CustomFormElement.recordset[0].IsMandatory;
          this.TimefieldForm.patchValue({
            timefield: this.UpdateFormElementName,
          });
        }
      );
      this.replytype = "6";
    } else if (eti == 7) {
      this.selectedformelement = "Checkboxes";
      const editform = {
        CustomFormElementId: this.customformelementid,
      };
      this.DynamicService.GetCustomFormElementByID(editform).subscribe(
        (res) => {
          this.getFormArray2.controls.splice(0);
          this.UpdateFormElementName =
            res.CustomFormElement.recordset[0].ElementName;
          this.img7 = res.CustomFormElement.recordset[0].IsMandatory;
          this.CheckboxForm.patchValue({
            Checkboxtitle: this.UpdateFormElementName,
          });
          this.updaterowarrow = res.CustomFormElement.recordsets[1];
          this.items2 = this.CheckboxForm.get("items2") as FormArray;
          this.updaterowarrow.forEach((element: any, index: number) => {
            if (index != 0)
              this.items2.push(
                this.formBuilder.group({
                  name: [element.CustomElementName],
                  checked:
                    this.updaterowarrow[0].CustomElementName != undefined &&
                    parseInt(this.updaterowarrow[0].CustomElementName) ===
                      index - 1
                      ? true
                      : false,
                })
              );
          });
          this.CheckboxForm.patchValue({ nocbox: this.items2.length });
          console.log("" + this.CheckboxForm.get("items2")["controls"]);
        }
      );
      this.replytype = "7";
    } else if (eti == 8) {
      this.selectedformelement = "Number of Field";
      const editform = {
        CustomFormElementId: this.customformelementid,
      };
      this.DynamicService.GetCustomFormElementByID(editform).subscribe(
        (res) => {
          this.UpdateFormElementName =
            res.CustomFormElement.recordset[0].ElementName;
          this.noofch = res.CustomFormElement.recordset[0].numberofcharacter;
          this.img8 = res.CustomFormElement.recordset[0].IsMandatory;
          this.NumberfieldForm.patchValue({
            numberfield: this.UpdateFormElementName,
          });
          this.NumberfieldForm.patchValue({ maxnd: this.noofch });
        }
      );
      this.replytype = "8";
    } else if (eti == 9) {
      this.selectedformelement = "Upload Option";
      const editform = {
        CustomFormElementId: this.customformelementid,
      };
      this.DynamicService.GetCustomFormElementByID(editform).subscribe(
        (res) => {
          this.UpdateFormElementName =
            res.CustomFormElement.recordset[0].ElementName;
          this.img9 = res.CustomFormElement.recordset[0].IsMandatory;
          this.FileUploadForm.patchValue({
            fileuploadname: this.UpdateFormElementName,
          });
        }
      );
      this.replytype = "9";
    } else if (eti == 10) {
      this.selectedformelement = "Record Name";
      const editform = {
        CustomFormElementId: this.customformelementid,
      };
      this.DynamicService.GetCustomFormElementByID(editform).subscribe(
        (res) => {
          this.UpdateFormElementName =
            res.CustomFormElement.recordset[0].ElementName;
          this.img10 = res.CustomFormElement.recordset[0].IsMandatory;
          this.UpdateFormCustomFormElement =
            res.CustomFormElement.recordsets[1][0].CustomElementName;
          this.RecordnameForm.patchValue({
            recordname: this.UpdateFormElementName,
          });
        }
      );
      this.replytype = "10";
    } else if (eti == 11) {
      this.selectedformelement = "Last Updated";
      const editform = {
        CustomFormElementId: this.customformelementid,
      };
      this.DynamicService.GetCustomFormElementByID(editform).subscribe(
        (res) => {
          this.UpdateFormElementName =
            res.CustomFormElement.recordset[0].ElementName;
          this.img11 = res.CustomFormElement.recordset[0].IsMandatory;
          this.UpdateFormCustomFormElement =
            res.CustomFormElement.recordsets[1][0].CustomElementName;
          this.LastUpdatedForm.patchValue({
            lastupdatedname: this.UpdateFormElementName,
          });
        }
      );
      this.replytype = "11";
    } else if (eti == 12) {
      this.selectedformelement = "Status";
      const editform = {
        CustomFormElementId: this.customformelementid,
      };
      this.DynamicService.GetCustomFormElementByID(editform).subscribe(
        (res) => {
          this.UpdateFormElementName =
            res.CustomFormElement.recordset[0].ElementName;
          this.img12 = res.CustomFormElement.recordset[0].IsMandatory;
          this.UpdateFormCustomFormElement =
            res.CustomFormElement.recordsets[1][0].CustomElementName;
          this.StatusForm.patchValue({
            statusname: this.UpdateFormElementName,
          });
        }
      );
      this.replytype = "12";
    } else if (eti == 13) {
      this.selectedformelement = "Expires On";
      const editform = {
        CustomFormElementId: this.customformelementid,
      };
      this.DynamicService.GetCustomFormElementByID(editform).subscribe(
        (res) => {
          this.UpdateFormElementName =
            res.CustomFormElement.recordset[0].ElementName;
          this.img13 = res.CustomFormElement.recordset[0].IsMandatory;
          this.UpdateFormCustomFormElement =
            res.CustomFormElement.recordsets[1][0].CustomElementName;
          this.ExpiresonForm.patchValue({
            expireson: this.UpdateFormElementName,
          });
        }
      );
      this.replytype = "13";
    }
  }
  // Delete method and popup
  deleteformelement(dle, eltid) {
    console.log(dle);
    console.log(eltid);
    Swal.fire({
      text: "Are you sure you want to delete?",
      showCancelButton: true,
      width: "30%",
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes",
      cancelButtonText: "No",
    }).then((result) => {
      if (result.value) {
        setTimeout(() => {
          const dfbody = {
            CustomFormElementID: dle,
          };
          this.DynamicService.DeleteCustomFormElement(dfbody).subscribe(
            (res3) => {
              if (res3.statusCode == 200) {
                // this.tostre.success("Record deleted successfully.");
                if (this.elementtypeid == eltid) {
                  this.updateformbutton = "ADD TO FORM";
                  this.customformelementid = null;
                  this.onReset();
                }
                if(eltid==10)
                {
                   this.recordnamevariable=true;
                }

                const gbody = {
                  CustomFormID: this.responseformid,
                };
                console.log("msg", this.responseformid);
                this.DynamicService.GetCustomFormElementList(gbody).subscribe(
                  (res5) => {
                    console.log(res5);
                    if (res5.statusCode == 500) {
                      this.tostre.success("500");
                      this.getrecordformdata = this.getnulltypes;
                      console.log("hii", this.getrecordformdata);
                    } else {
                      this.getrecordformdata = res5.CustomFormElementList;
                    }
                  }
                );
              }
              // setTimeout(() => {
            }
          );
        }, 500);
        console.log("responeformid" + this.responseformid);
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        // this.tostre.warning("Your imaginary file is safe :)");
      }
    });
  }
  Submit2() {
    this.submitted2 = true;
    this.submitted9 = true;
    if (this.UpdateCustomForm.invalid || this.UpdateCustomForm.value.CustomFormId==0) {
      this.tostre.warning("Please Select Form Type");
    }
    if (this.textbox.invalid || this.UpdateCustomForm.invalid || this.UpdateCustomForm.value.CustomFormId==0) {
      return;
    } else {
      this.clicked2 = true;
      if (this.responseformid == null) {
        this.responseidnullupdatemethod();
      }
      console.log(this.responseformid);
      setTimeout(() => {
        this.textboxvalue = this.textbox.value.textboxtitle;
        this.maxcharacter = this.textbox.value.maxno;
        this.eti = this.replytype;
        this.defaulttext = this.textbox.value.defaulttextbox;
        if (this.customformelementid == null) {
          const bbody = {
            CustomFormElementId: 0,
            CustomFormId: this.responseformid,
            ElementTypeId: this.eti,
            ElementName: this.textboxvalue,
            CustomElementName: this.defaulttext + "|",
            IsMandatory: this.img2,
            numberofcharacter: this.maxcharacter,
          };
          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element added successfully.");
                this.getlist();
                this.textbox.reset();
                this.submitted2 = false;
                this.img2 = false;
                this.clicked2 = false;
                this.updateformbutton = "ADD TO FORM";
              }
            }
          );
        } else if (this.elementtypeid == 2) {
          const bbody = {
            CustomFormElementId: this.customformelementid,
            CustomFormId: this.customformid,
            ElementTypeId: this.elementtypeid,
            ElementName: this.textboxvalue,
            CustomElementName: this.defaulttext + "|",
            IsMandatory: this.img2,
            numberofcharacter: this.maxcharacter,
          };
          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element updated successfully.");
                this.getlist();
                this.textbox.reset();
                this.submitted2 = false;
                this.clicked2 = false;
                this.img2 = false;
                this.updateformbutton = "ADD TO FORM";
              }
            }
          );
          this.customformelementid = null;
        } else {
          const dfbody = {
            CustomFormElementID: this.customformelementid,
          };
          this.DynamicService.DeleteCustomFormElement(
            dfbody
          ).subscribe((res3) => {
            if(this.eti==10){
            this.recordnamevariable=false;}
          });
          const bbody = {
            CustomFormElementId: 0,
            CustomFormId: this.customformid,
            ElementTypeId: 2,
            ElementName: this.textboxvalue,
            CustomElementName: this.defaulttext + "|",
            IsMandatory: this.img2,
            numberofcharacter: this.maxcharacter,
          };
          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element updated successfully.");
                this.getlist();
                this.textbox.reset();
                this.submitted2 = false;
                this.clicked2 = false;
                this.img2 = false;
                this.updateformbutton = "ADD TO FORM";
              }
            }
          );
          this.customformelementid = null;
        }
      }, 2000);
    }
  }

  Submit3() {
    this.submitted9 = true;
    this.submitted3 = true;
    if (this.UpdateCustomForm.invalid || this.UpdateCustomForm.value.CustomFormId==0) {
      this.tostre.warning("Please Select Form Type");
    }
    if (this.RadioForm.invalid || this.UpdateCustomForm.invalid || this.UpdateCustomForm.value.CustomFormId==0) {
      return;
    } else {
      this.clicked2 = true;
      if (this.responseformid == null) {
        this.responseidnullupdatemethod();
      }
      setTimeout(() => {
        this.radioformarray = this.RadioForm.value.items;
        var arroy = "";
        this.radioformarray.forEach((res) => {
          arroy += res.name + "|";
        });
        this.radiobt = this.RadioForm.value.Radiobuttontitle;
        this.eti = this.replytype;
        if (this.customformelementid == null) {
          const bbody = {
            CustomFormElementId: 0,
            CustomFormId: this.responseformid,
            ElementTypeId: this.eti,
            ElementName: this.radiobt,
            CustomElementName: this.deafultvalueofradiobutton + "|" + arroy,
            IsMandatory: this.img3,
          };

          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element added successfully.");
                this.getlist();
                this.submitted3 = false;
                this.RadioForm.reset();
                this.getFormArray.controls.splice(0);
                this.img3 = false;
                this.clicked2 = false;
                this.deafultvalueofradiobutton = "undefined";
                this.updateformbutton = "ADD TO FORM";
              }
            }
          );
        } else if (this.elementtypeid == 3) {
          const bbody = {
            CustomFormElementId: this.customformelementid,
            CustomFormId: this.customformid,
            ElementTypeId: this.elementtypeid,
            ElementName: this.radiobt,
            CustomElementName: this.deafultvalueofradiobutton + "|" + arroy,
            IsMandatory: this.img3,
          };

          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element updated successfully.");
                this.getlist();
                this.submitted3 = false;
                this.RadioForm.reset();
                this.clicked1 = false;
                this.getFormArray.controls.splice(0);
                this.img3 = false;
                this.clicked2 = false;
                this.deafultvalueofradiobutton = "undefined";
                this.updateformbutton = "ADD TO FORM";
                this.customformelementid = null;
              }
            }
          );
        } else {
          const dfbody = {
            CustomFormElementID: this.customformelementid,
          };
          this.DynamicService.DeleteCustomFormElement(
            dfbody
          ).subscribe((res3) => {
             if(this.eti==10){
            this.recordnamevariable=false;}
          });
          const bbody = {
            CustomFormElementId: 0,
            CustomFormId: this.customformid,
            ElementTypeId: 3,
            ElementName: this.radiobt,
            CustomElementName: this.deafultvalueofradiobutton + "|" + arroy,
            IsMandatory: this.img3,
          };

          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element updated successfully.");
                this.getlist();
                this.submitted3 = false;
                this.RadioForm.reset();
                this.clicked1 = false;
                this.getFormArray.controls.splice(0);
                this.img3 = false;
                this.clicked2 = false;
                this.deafultvalueofradiobutton = "undefined";
                this.updateformbutton = "ADD TO FORM";
                this.customformelementid = null;
              }
            }
          );
        }
      }, 2000);
    }
  }

  dsdt
  Submit4() {
    this.submitted9 = true;
    this.submitted4 = true;
    if (this.UpdateCustomForm.invalid || this.UpdateCustomForm.value.CustomFormId==0) {
      this.tostre.warning("Please Select Form Type");
    }
    if (this.DropdownForm.invalid || this.UpdateCustomForm.invalid || this.UpdateCustomForm.value.CustomFormId==0) {
      return;
    } else {
      this.clicked2 = true;
      if (this.responseformid == null) {
        this.responseidnullupdatemethod();
      }
      console.log(this.responseformid);

      setTimeout(() => {
        this.Dropdownformarray = this.DropdownForm.value.items1;
        var arroy1 = "";
        this.ddtext = this.DropdownForm.value.ddefaulttext;
        if(this.DropdownForm.value.ddefaulttext == null){
          this.ddtext = '';
        }
        this.dsdt = this.DropdownSelectDefaulText
        console.log(this.DropdownForm.value.items1);
        // if (
        //   !this.DropdownForm.value.items1.some((e) => e.name === this.ddtext)
        // ) {
        //   this.tostre.warning(
        //     "Default pick value must match with one of pick values."
        //   );
        //   this.clicked2 = false;
        //   return 0;
        // }
        this.Dropdownformarray.forEach((res) => {
          if (res) arroy1 += res.name + "|";
        });
        this.dmenutitle = this.DropdownForm.value.dmenutitle;
        this.eti = this.replytype;
        if (this.customformelementid == null) {
          const bbody = {
            CustomFormElementId: 0,
            CustomFormId: this.responseformid,
            ElementTypeId: this.eti,
            ElementName: this.dmenutitle,
            CustomElementName: this.ddtext + "|" + arroy1,
            IsMandatory: this.img4,
          };

          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element added successfully.");
                this.getlist();
                this.submitted4 = false;
                this.DropdownForm.reset();
                this.getFormArray1.controls.splice(0);
                this.img4 = false;
                this.clicked2 = false;
                this.updateformbutton = "ADD TO FORM";
              }
            }
          );
        } else if (this.elementtypeid == 4) {
          const bbody = {
            CustomFormElementId: this.customformelementid,
            CustomFormId: this.customformid,
            ElementTypeId: this.elementtypeid,
            ElementName: this.dmenutitle,
            CustomElementName: this.ddtext + "|" + arroy1,
            IsMandatory: this.img4,
            DefaultPickValue: this.dsdt
          };

          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element updated successfully.");
                this.getlist();
                this.submitted4 = false;
                this.DropdownForm.reset();
                this.clicked1 = false;
                this.getFormArray1.controls.splice(0);
                this.img4 = false;
                this.clicked2 = false;
                this.updateformbutton = "ADD TO FORM";
                this.customformelementid = null;
              }
            }
          );
        } else {
          const dfbody = {
            CustomFormElementID: this.customformelementid,
          };
          this.DynamicService.DeleteCustomFormElement(
            dfbody
          ).subscribe((res3) => {
              if(this.eti==10){
            this.recordnamevariable=false;}
          });
          const bbody = {
            CustomFormElementId: 0,
            CustomFormId: this.customformid,
            ElementTypeId: 4,
            ElementName: this.dmenutitle,
            CustomElementName: this.ddtext + "|" + arroy1,
            IsMandatory: this.img4,
          };

          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element updated successfully.");
                this.getlist();
                this.submitted4 = false;
                this.DropdownForm.reset();
                this.clicked1 = false;
                this.getFormArray1.controls.splice(0);
                this.img4 = false;
                this.clicked2 = false;
                this.updateformbutton = "ADD TO FORM";
                this.customformelementid = null;
              }
            }
          );
        }
      }, 2000);
    }
  }

  Submit5() {
    this.submitted9 = true;
    this.submitted5 = true;
    if (this.UpdateCustomForm.invalid || this.UpdateCustomForm.value.CustomFormId==0) {
      this.tostre.warning("Please Select Form Type");
    }
    if (this.DatefieldForm.invalid || this.UpdateCustomForm.invalid || this.UpdateCustomForm.value.CustomFormId==0) {
      return;
    } else {
      this.clicked2 = true;
      if (this.responseformid == null) {
        this.responseidnullupdatemethod();
      }
      console.log(this.responseformid);

      setTimeout(() => {
        this.datefieldtitle = this.DatefieldForm.value.datefield;
        this.eti = this.replytype;
        if (this.customformelementid == null) {
          const bbody = {
            CustomFormElementId: 0,
            CustomFormId: this.responseformid,
            ElementTypeId: this.eti,
            ElementName: this.datefieldtitle,
            CustomElementName: "",
            IsMandatory: this.img5,
          };

          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element added successfully.");
                this.getlist();
                this.submitted5 = false;
                this.DatefieldForm.reset();
                this.img5 = false;
                this.clicked2 = false;
                this.updateformbutton = "ADD TO FORM";
              }
            }
          );
        } else if (this.elementtypeid == 5) {
          const bbody = {
            CustomFormElementId: this.customformelementid,
            CustomFormId: this.customformid,
            ElementTypeId: this.elementtypeid,
            ElementName: this.datefieldtitle,
            CustomElementName: "",
            IsMandatory: this.img5,
          };

          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element updated successfully.");
                this.getlist();
                this.submitted5 = false;
                this.DatefieldForm.reset();
                this.clicked1 = false;
                this.img5 = false;
                this.clicked2 = false;
                this.updateformbutton = "ADD TO FORM";
                this.customformelementid = null;
              }
            }
          );
        } else {
          const dfbody = {
            CustomFormElementID: this.customformelementid,
          };
          this.DynamicService.DeleteCustomFormElement(
            dfbody
          ).subscribe((res3) => {
            if(this.eti==10){
            this.recordnamevariable=false;}
          });
          const bbody = {
            CustomFormElementId: 0,
            CustomFormId: this.customformid,
            ElementTypeId: 5,
            ElementName: this.datefieldtitle,
            CustomElementName: "",
            IsMandatory: this.img5,
          };

          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element updated successfully.");
                this.getlist();
                this.submitted5 = false;
                this.DatefieldForm.reset();
                this.clicked1 = false;
                this.img5 = false;
                this.clicked2 = false;
                this.updateformbutton = "ADD TO FORM";
                this.customformelementid = null;
              }
            }
          );
        }
      }, 2000);
    }
  }

  Submit6() {
    this.submitted9 = true;
    this.submitted6 = true;
    if (this.UpdateCustomForm.invalid || this.UpdateCustomForm.value.CustomFormId==0) {
      this.tostre.warning("Please Select Form Type");
    }
    if (this.TimefieldForm.invalid || this.UpdateCustomForm.invalid || this.UpdateCustomForm.value.CustomFormId==0) {
      return;
    } else {
      this.clicked2 = true;
      if (this.responseformid == null) {
        this.responseidnullupdatemethod();
      }
      console.log(this.responseformid);
      setTimeout(() => {
        this.timefieldtitle = this.TimefieldForm.value.timefield;
        this.eti = this.replytype;
        if (this.customformelementid == null) {
          const bbody = {
            CustomFormElementId: 0,
            CustomFormId: this.responseformid,
            ElementTypeId: this.eti,
            ElementName: this.timefieldtitle,
            CustomElementName: "",
            IsMandatory: this.img6,
          };
          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element added successfully.");
                this.getlist();
                this.submitted6 = false;
                this.TimefieldForm.reset();
                this.img6 = false;
                this.clicked2 = false;
                this.updateformbutton = "ADD TO FORM";
              }
            }
          );
        } else if (this.elementtypeid == 6) {
          const bbody = {
            CustomFormElementId: this.customformelementid,
            CustomFormId: this.customformid,
            ElementTypeId: this.elementtypeid,
            ElementName: this.timefieldtitle,
            CustomElementName: "",
            IsMandatory: this.img6,
          };
          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element updated successfully.");
                this.getlist();
                this.submitted6 = false;
                this.TimefieldForm.reset();
                this.clicked1 = false;
                this.img6 = false;
                this.clicked2 = false;
                this.updateformbutton = "ADD TO FORM";
                this.customformelementid = null;
              }
            }
          );
        } else {
          const dfbody = {
            CustomFormElementID: this.customformelementid,
          };
          this.DynamicService.DeleteCustomFormElement(
            dfbody
          ).subscribe((res3) => {
            if(this.eti==10){
            this.recordnamevariable=false;}
          });
          const bbody = {
            CustomFormElementId: 0,
            CustomFormId: this.customformid,
            ElementTypeId: 6,
            ElementName: this.timefieldtitle,
            CustomElementName: "",
            IsMandatory: this.img1,
          };
          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element updated successfully.");
                this.getlist();
                this.submitted6 = false;
                this.TimefieldForm.reset();
                this.clicked1 = false;
                this.img6 = false;
                this.clicked2 = false;
                this.updateformbutton = "ADD TO FORM";
                this.customformelementid = null;
              }
            }
          );
        }
      }, 2000);
    }
  }

  Submit7() {
    this.submitted9 = true;
    this.submitted7 = true;
    if (this.UpdateCustomForm.invalid || this.UpdateCustomForm.value.CustomFormId==0) {
      this.tostre.warning("Please Select Form Type");
    }
    if (this.CheckboxForm.invalid || this.UpdateCustomForm.invalid || this.UpdateCustomForm.value.CustomFormId==0) {
      return;
    } else {
      this.clicked2 = true;
      if (this.responseformid == null) {
        this.responseidnullupdatemethod();
      }
      console.log(this.responseformid);
      setTimeout(() => {
        this.checkfieldtitle = this.CheckboxForm.value.Checkboxtitle;
        this.checkfieldarray = this.CheckboxForm.value.items2;
        var arroy2 = "";
        this.checkfieldarray.forEach((res) => {
          arroy2 += res.name + "|";
        });
        this.eti = this.replytype;

        if (this.customformelementid == null) {
          const bbody = {
            CustomFormElementId: 0,
            CustomFormId: this.responseformid,
            ElementTypeId: this.eti,
            ElementName: this.checkfieldtitle,
            CustomElementName: this.deafultvalueofCheckbox + "|" + arroy2,
            IsMandatory: this.img7,
          };

          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element added successfully.");
                this.getlist();
                this.submitted7 = false;
                this.CheckboxForm.reset();
                this.getFormArray2.controls.splice(0);
                this.img7 = false;
                this.clicked2 = false;
                this.deafultvalueofCheckbox = "undefined";
                this.updateformbutton = "ADD TO FORM";
              }
            }
          );
        } else if (this.elementtypeid == 7) {
          const bbody = {
            CustomFormElementId: this.customformelementid,
            CustomFormId: this.customformid,
            ElementTypeId: this.elementtypeid,
            ElementName: this.checkfieldtitle,
            CustomElementName: this.deafultvalueofCheckbox + "|" + arroy2,
            IsMandatory: this.img7,
          };
          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element updated successfully.");
                this.getlist();
                this.submitted7 = false;
                this.CheckboxForm.reset();
                this.clicked1 = false;
                this.getFormArray2.controls.splice(0);
                this.img7 = false;
                this.clicked2 = false;
                this.deafultvalueofCheckbox = "undefined";
                this.updateformbutton = "ADD TO FORM";
                this.customformelementid = null;
              }
            }
          );
        } else {
          const dfbody = {
            CustomFormElementID: this.customformelementid,
          };
          this.DynamicService.DeleteCustomFormElement(
            dfbody
          ).subscribe((res3) => {
            if(this.eti==10){
            this.recordnamevariable=false;}
          });
          const bbody = {
            CustomFormElementId: 0,
            CustomFormId: this.customformid,
            ElementTypeId: 7,
            ElementName: this.checkfieldtitle,
            CustomElementName: this.deafultvalueofCheckbox + "|" + arroy2,
            IsMandatory: this.img7,
          };
          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element updated successfully.");
                this.getlist();
                this.submitted7 = false;
                this.CheckboxForm.reset();
                this.clicked1 = false;
                this.getFormArray2.controls.splice(0);
                this.img7 = false;
                this.clicked2 = false;
                this.deafultvalueofCheckbox = "undefined";
                this.updateformbutton = "ADD TO FORM";
                this.customformelementid = null;
              }
            }
          );
        }
      }, 2000);
    }
  }

  Submit8() {
    this.submitted9 = true;
    this.submitted8 = true;
    if (this.UpdateCustomForm.invalid || this.UpdateCustomForm.value.CustomFormId==0) {
      this.tostre.warning("Please Select Form Type");
    }
    if (this.NumberfieldForm.invalid || this.UpdateCustomForm.invalid || this.UpdateCustomForm.value.CustomFormId==0) {
      return;
    } else {
      this.clicked2 = true;
      if (this.responseformid == null) {
        this.responseidnullupdatemethod();
      }
      console.log(this.responseformid);
      setTimeout(() => {
        this.numberfieldtitle = this.NumberfieldForm.value.numberfield;
        this.eti = this.replytype;
        this.maxnod = this.NumberfieldForm.value.maxnd;
        if (this.customformelementid == null) {
          const bbody = {
            CustomFormElementId: 0,
            CustomFormId: this.responseformid,
            ElementTypeId: this.eti,
            ElementName: this.numberfieldtitle,
            CustomElementName: "",
            IsMandatory: this.img8,
            numberofcharacter: this.maxnod,
          };

          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element added successfully.");
                this.getlist();
                this.submitted8 = false;
                this.NumberfieldForm.reset();
                this.img8 = false;
                this.clicked2 = false;
                this.updateformbutton = "ADD TO FORM";
              }
            }
          );
        } else if (this.elementtypeid == 8) {
          const bbody = {
            CustomFormElementId: this.customformelementid,
            CustomFormId: this.customformid,
            ElementTypeId: this.elementtypeid,
            ElementName: this.numberfieldtitle,
            CustomElementName: "",
            IsMandatory: this.img8,
            numberofcharacter: this.maxnod,
          };

          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element updated successfully.");
                this.getlist();
                this.submitted8 = false;
                this.NumberfieldForm.reset();
                this.clicked1 = false;
                this.clicked2 = false;
                this.img8 = false;
                this.updateformbutton = "ADD TO FORM";
                this.customformelementid = null;
              }
            }
          );
        } else {
          const dfbody = {
            CustomFormElementID: this.customformelementid,
          };
          this.DynamicService.DeleteCustomFormElement(
            dfbody
          ).subscribe((res3) => {
            if(this.eti==10){
            this.recordnamevariable=false;}
          });

          const bbody = {
            CustomFormElementId: 0,
            CustomFormId: this.customformid,
            ElementTypeId: 8,
            ElementName: this.numberfieldtitle,
            CustomElementName: "",
            IsMandatory: this.img8,
            numberofcharacter: this.maxnod,
          };

          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element updated successfully.");
                this.getlist();
                this.submitted8 = false;
                this.NumberfieldForm.reset();
                this.clicked1 = false;
                this.clicked2 = false;
                this.img8 = false;
                this.updateformbutton = "ADD TO FORM";
                this.customformelementid = null;
              }
            }
          );
        }
      }, 2000);
    }
  }

  Submit9() {
    this.submitted9 = true;
    this.submitted11 = true;
    if (this.UpdateCustomForm.invalid || this.UpdateCustomForm.value.CustomFormId==0) {
      this.tostre.warning("Please Select Form Type");
    }
    if (this.FileUploadForm.invalid || this.UpdateCustomForm.invalid || this.UpdateCustomForm.value.CustomFormId==0) {
      return;
    } else {
      this.clicked2 = true;
      if (this.responseformid == null) {
        this.responseidnullupdatemethod();
      }
      console.log(this.responseformid);
      setTimeout(() => {
        this.uploadtitle = this.FileUploadForm.value.fileuploadname;
        this.eti = this.replytype;
        if (this.customformelementid == null) {
          const bbody = {
            CustomFormElementId: 0,
            CustomFormId: this.responseformid,
            ElementTypeId: this.eti,
            ElementName: this.uploadtitle,
            CustomElementName: "",
            IsMandatory: this.img9,
          };

          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element added successfully.");
                this.getlist();
                this.submitted11 = false;
                this.FileUploadForm.reset();
                this.img9 = false;
                this.clicked2 = false;
                this.updateformbutton = "ADD TO FORM";
              }
            }
          );
        } else if (this.elementtypeid == 9) {
          const bbody = {
            CustomFormElementId: this.customformelementid,
            CustomFormId: this.customformid,
            ElementTypeId: this.elementtypeid,
            ElementName: this.uploadtitle,
            CustomElementName: "",
            IsMandatory: this.img9,
          };

          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element updated successfully.");
                this.getlist();
                this.submitted11 = false;
                this.FileUploadForm.reset();
                this.clicked1 = false;
                this.img9 = false;
                this.clicked2 = false;
                this.updateformbutton = "ADD TO FORM";
                this.customformelementid = null;
              }
            }
          );
        } else {
          const dfbody = {
            CustomFormElementID: this.customformelementid,
          };
          this.DynamicService.DeleteCustomFormElement(
            dfbody
          ).subscribe((res3) => {
             if(this.eti==10){
            this.recordnamevariable=false;}
          });

          const bbody = {
            CustomFormElementId: 0,
            CustomFormId: this.customformid,
            ElementTypeId: 9,
            ElementName: this.uploadtitle,
            CustomElementName: "",
            IsMandatory: this.img9,
          };

          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element updated successfully.");
                this.getlist();
                this.submitted11 = false;
                this.FileUploadForm.reset();
                this.clicked1 = false;
                this.img9 = false;
                this.clicked2 = false;
                this.updateformbutton = "ADD TO FORM";
                this.customformelementid = null;
              }
            }
          );
        }
      }, 2000);
    }
  }

  Submit10() {

    this.submitted9 = true;
    this.submitted16 = true;
    if (this.UpdateCustomForm.invalid || this.UpdateCustomForm.value.CustomFormId==0) {
      this.tostre.warning("Please Select Form Type");
    }
    if (this.RecordnameForm.invalid || this.UpdateCustomForm.invalid || this.UpdateCustomForm.value.CustomFormId==0) {
      return;
    } else {
      this.clicked2 = true;
      if (this.responseformid == null) {
        this.responseidnullupdatemethod();
      }
      console.log(this.responseformid);
      setTimeout(() => {
        this.eti = this.replytype;
        if (this.customformelementid == null) {
          if(this.recordnamevariable==true)
          {
          const bbody = {
            CustomFormElementId: 0,
            CustomFormId: this.responseformid,
            ElementTypeId: this.eti,
            ElementName: this.RecordnameForm.value.recordname,
            CustomElementName: "" + "|",
            IsMandatory: this.img10,
          };

          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element added successfully.");
                this.getlist();
                this.submitted16 = false;
                this.RecordnameForm.reset();
                this.img10 = true;
                this.clicked2 = false;
                this.recordnamevariable=false;
                this.updateformbutton = "ADD TO FORM";
                 this.RecordnameForm.patchValue({
                     recordname:"Record Name"
                 });

              }
            }
          );
          }
          else
          {
            this.clicked2 = false;
            this.tostre.warning("Record  name is already exists.");
          }
        } else if (this.elementtypeid == 10) {
          const bbody = {
            CustomFormElementId: this.customformelementid,
            CustomFormId: this.customformid,
            ElementTypeId: this.elementtypeid,
            ElementName: this.RecordnameForm.value.recordname,
            CustomElementName: "" + "|",
            IsMandatory: this.img10,
          };

          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element updated successfully.");
                this.getlist();
                this.submitted16 = false;
                this.RecordnameForm.reset();
                this.clicked1 = false;
                this.img10 = true;
                this.clicked2 = false;
                this.updateformbutton = "ADD TO FORM";
                 this.RecordnameForm.patchValue({
                     recordname:"Record Name"
                 });
              }
            }
          );
          this.customformelementid = null;
        } else
        {
          const dfbody = {
            CustomFormElementID: this.customformelementid,
          };
          this.DynamicService.DeleteCustomFormElement(
            dfbody
          ).subscribe((res3) => {
            if(this.eti==10){
            this.recordnamevariable=false;}
          });
          const bbody = {
            CustomFormElementId: 0,
            CustomFormId: this.customformid,
            ElementTypeId: 10,
            ElementName: this.RecordnameForm.value.recordname,
            CustomElementName: "" + "|",
            IsMandatory: this.img10,
          };
          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element updated successfully.");
                this.getlist();
                this.submitted16 = false;
                this.RecordnameForm.reset();
                this.clicked1 = false;
                this.img10 = true;
                this.clicked2 = false;
                this.updateformbutton = "ADD TO FORM";
                this.customformelementid = null;
              }
            }
          );
        }
      }, 2000);
    }
  }

  Submit11() {
    this.submitted9 = true;
    this.submitted13 = true;
    if (this.UpdateCustomForm.invalid || this.UpdateCustomForm.value.CustomFormId==0) {
      this.tostre.warning("Please Select Form Type");
    }
    if (this.LastUpdatedForm.invalid || this.UpdateCustomForm.invalid || this.UpdateCustomForm.value.CustomFormId==0) {
      return;
    } else {
      this.clicked2 = true;
      if (this.responseformid == null) {
        this.responseidnullupdatemethod();
      }
      console.log(this.responseformid);
      setTimeout(() => {
        this.eti = this.replytype;
        if (this.customformelementid == null) {
          const bbody = {
            CustomFormElementId: 0,
            CustomFormId: this.responseformid,
            ElementTypeId: this.eti,
            ElementName: this.LastUpdatedForm.value.lastupdatedname,
            CustomElementName: "" + "|",
            IsMandatory: this.img11,
          };

          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element added successfully.");
                this.getlist();
                this.submitted13 = false;
                this.LastUpdatedForm.reset();
                this.img11 = false;
                this.clicked2 = false;
                this.updateformbutton = "ADD TO FORM";
                this.LastUpdatedForm.patchValue({
                   lastupdatedname:"Last Updated"
                });
              }
            }
          );
        } else if (this.elementtypeid == 11) {
          const bbody = {
            CustomFormElementId: this.customformelementid,
            CustomFormId: this.customformid,
            ElementTypeId: this.elementtypeid,
            ElementName: this.LastUpdatedForm.value.lastupdatedname,
            CustomElementName: "" + "|",
            IsMandatory: this.img10,
          };

          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element updated successfully.");
                this.getlist();
                this.submitted13 = false;
                this.LastUpdatedForm.reset();
                this.clicked1 = false;
                this.img11 = false;
                this.clicked2 = false;
                this.updateformbutton = "ADD TO FORM";
                this.LastUpdatedForm.patchValue({
                   lastupdatedname:"Last Updated"
                });
              }
            }
          );
          this.customformelementid = null;
        }
        else
        {
          const dfbody = {
            CustomFormElementID: this.customformelementid,
          };
          this.DynamicService.DeleteCustomFormElement(
            dfbody
          ).subscribe((res3) => {
            if(this.eti==10){
            this.recordnamevariable=false;}
          });
          const bbody = {
            CustomFormElementId: 0,
            CustomFormId: this.customformid,
            ElementTypeId: 11,
            ElementName: this.LastUpdatedForm.value.lastupdatedname,
            CustomElementName: "" + "|",
            IsMandatory: this.img10,
          };
          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element updated successfully.");
                this.getlist();
                this.submitted13 = false;
                this.LastUpdatedForm.reset();
                this.clicked1 = false;
                this.img11 = false;
                this.clicked2 = false;
                this.customformelementid = null;
              }
            }
          );

        }
      }, 2000);
    }
  }

  Submit12() {
    this.submitted9 = true;
    this.submitted14 = true;
    if (this.UpdateCustomForm.invalid || this.UpdateCustomForm.value.CustomFormId==0) {
      this.tostre.warning("Please Select Form Type");
    }
    if (this.StatusForm.invalid || this.UpdateCustomForm.invalid || this.UpdateCustomForm.value.CustomFormId==0) {
      return;
    } else {
      this.clicked2 = true;
      if (this.responseformid == null) {
        this.responseidnullupdatemethod();
      }
      console.log(this.responseformid);
      setTimeout(() => {
        this.eti = this.replytype;
        if (this.customformelementid == null) {
          const bbody = {
            CustomFormElementId: 0,
            CustomFormId: this.responseformid,
            ElementTypeId: this.eti,
            ElementName: this.StatusForm.value.statusname,
            CustomElementName: "" + "|",
            IsMandatory: this.img12,
          };

          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element added successfully.");
                this.getlist();
                this.submitted14 = false;
                this.StatusForm.reset();
                this.img12 = false;
                this.clicked2 = false;
                this.updateformbutton = "ADD TO FORM";
                this.StatusForm.patchValue({
                   statusname:"Status"
                 });
              }
            }
          );
        } else if (this.elementtypeid == 12) {
          const bbody = {
            CustomFormElementId: this.customformelementid,
            CustomFormId: this.customformid,
            ElementTypeId: this.elementtypeid,
            ElementName: this.StatusForm.value.statusname,
            CustomElementName: "" + "|",
            IsMandatory: this.img12,
          };

          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element updated successfully.");
                this.getlist();
                this.submitted14 = false;
                this.StatusForm.reset();
                this.clicked1 = false;
                this.img12 = false;
                this.clicked2 = false;
                this.updateformbutton = "ADD TO FORM";
                this.StatusForm.patchValue({
                   statusname:"Status"
                 });
              }
            }
          );
          this.customformelementid = null;
        }
        else
        {

          const dfbody = {
            CustomFormElementID: this.customformelementid,
          };
          this.DynamicService.DeleteCustomFormElement(
            dfbody
          ).subscribe((res3) => {
            if(this.eti==10){
            this.recordnamevariable=false;}
          });
          const bbody = {
            CustomFormElementId: 0,
            CustomFormId: this.customformid,
            ElementTypeId: 12,
            ElementName: this.StatusForm.value.statusname,
            CustomElementName: "" + "|",
            IsMandatory: this.img12,
          };
          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                 this.tostre.success("Form element updated successfully.");
                this.getlist();
                this.submitted14 = false;
                this.StatusForm.reset();
                this.clicked1 = false;
                this.img12 = false;
                this.clicked2 = false;
                this.updateformbutton = "ADD TO FORM";
                this.customformelementid = null;
              }
            }
          );


        }
      }, 2000);
    }
  }

  Submit13() {
    this.submitted9 = true;
    this.submitted15 = true;
    if (this.UpdateCustomForm.invalid || this.UpdateCustomForm.value.CustomFormId==0) {
      this.tostre.warning("Please Select Form Type");
    }
    if (this.ExpiresonForm.invalid || this.UpdateCustomForm.invalid || this.UpdateCustomForm.value.CustomFormId==0) {
      return;
    } else {
      this.clicked2 = true;
      if (this.responseformid == null) {
        this.responseidnullupdatemethod();
      }
      console.log(this.responseformid);
      setTimeout(() => {
        this.eti = this.replytype;
        if (this.customformelementid == null) {
          const bbody = {
            CustomFormElementId: 0,
            CustomFormId: this.responseformid,
            ElementTypeId: this.eti,
            ElementName: this.ExpiresonForm.value.expireson,
            CustomElementName: "" + "|",
            IsMandatory: this.img13,
          };

          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element added successfully.");
                this.getlist();
                this.submitted15 = false;
                this.ExpiresonForm.reset();
                this.img13 = false;
                this.clicked2 = false;
                this.updateformbutton = "ADD TO FORM";
                this.ExpiresonForm.patchValue({
                   expireson:"Expires On"
                });
              }
            }
          );
        } else if (this.elementtypeid == 13) {
          const bbody = {
            CustomFormElementId: this.customformelementid,
            CustomFormId: this.customformid,
            ElementTypeId: this.elementtypeid,
            ElementName: this.ExpiresonForm.value.expireson,
            CustomElementName: "" + "|",
            IsMandatory: this.img13,
          };

          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("Form element updated successfully.");
                this.getlist();
                this.submitted15 = false;
                this.ExpiresonForm.reset();
                this.clicked1 = false;
                this.img13 = false;
                this.clicked2 = false;
                this.updateformbutton = "ADD TO FORM";
                 this.ExpiresonForm.patchValue({
                   expireson:"Expires On"
                });
              }
            }
          );
          this.customformelementid = null;
        }
         else
        {

          const dfbody = {
            CustomFormElementID: this.customformelementid,
          };
          this.DynamicService.DeleteCustomFormElement(
            dfbody
          ).subscribe((res3) => {
             if(this.eti==10){
            this.recordnamevariable=false;}
          });
          const bbody = {
            CustomFormElementId: 0,
            CustomFormId: this.customformid,
            ElementTypeId: 13,
            ElementName: this.StatusForm.value.statusname,
            CustomElementName: "" + "|",
            IsMandatory: this.img12,
          };
          this.DynamicService.Updatecustomformelement(bbody).subscribe(
            (res) => {
              if (res.statusCode == 200) {
                this.tostre.success("The Record has been save successfully.");
                this.getlist();
                this.submitted15 = false;
                this.ExpiresonForm.reset();
                this.clicked1 = false;
                this.img13 = false;
                this.clicked2 = false;
                this.updateformbutton = "ADD TO FORM";
                this.customformelementid = null;
              }
            }
          );


        }
      }, 2000);
    }
  }


  setvariable=1;
  openSubjectDialog(n) {
    if (n === 1) {
      // if(this.p5==true)
      // {
      //   this.reportingset1 = true;
      // }
      // else
      // {
      this.reportingset1 = true;
      // }
    }
    this.storage.setData("dynamicvariable",this.setvariable);
    const dialogRef = this.dialog.open(ModelIncidentsubjectComponent, {
      width: "70%",
      maxWidth: "100vw",
    });
    // if(this.p5==true)
    // {
    dialogRef.componentInstance.reportingset1 = this.reportingset1;
    if (this.selectedsubject == true) {
      dialogRef.componentInstance.cfi = 0;
    } else {
      dialogRef.componentInstance.cfi = this.p1;
    }

    // }
    // else
    // {
    //   dialogRef.componentInstance.reportingset = this.reportingset;
    // }

    // const subjectid = JSON.parse(this.storage.getData('ListofFinalSub'));
    // if(this.storage.getData('ListofFinalSub') === null){
    //  const subjectid = [];
    // } else {
    //  const  subjectid = JSON.parse(this.storage.getData('ListofFinalSub'));
    //  var arroyd='';
    //  subjectid.forEach(res=>{
    //    arroyd += res + '|';
    //   })

    // console.log('mywork',subjectid);
    dialogRef.afterClosed().subscribe((result) => {
      const subjectid = result;
      console.log("subjectid", subjectid);
      this.storage.removeData("dynamicvariable");
      if (subjectid != undefined) {
        var arroyd = "";
        subjectid.forEach((res) => {
          arroyd += res + "|";
        });

        console.log("mywork", subjectid);
        const sbody = {
          CustomFormId: this.responseformid,
          SubjectIds: arroyd,
          IsActive: 1,
        };
        this.DynamicService.UpdateCustomFormSubject(
          sbody
        ).subscribe((res) => {});
      }

      // this.storage.removeData('ListofFinalSub');
      // const sibody={
      //   CustomFormId:this.responseformid,
      // }
      // this.DynamicService.GetAssignedSubjectByID(sibody).subscribe(res=>{
      // this.getsubjectbyid=res.getAssignedSubjectByID;
      // this.storage.setData('getsubjectbyid',JSON.stringify(this.getsubjectbyid));
      //   console.log('getsubjectbyid',res);
      //  })

      // this.incidentDispatchForm.get('incidentSubject').patchValue(result.ISCISubjectName);
    });
  }

  createItem(): FormGroup {
    return this.formBuilder.group({
      name: ["", Validators.required],
    });
  }
  createItem1(): FormGroup {
    return this.formBuilder.group({
      name: ["", Validators.required],
    });
  }
  createItem2(): FormGroup {
    return this.formBuilder.group({
      name: ["", Validators.required],
    });
  }

  img1 = false;
  img2 = false;
  img3 = false;
  img4 = false;
  img5 = false;
  img6 = false;
  img7 = false;
  img8 = false;
  img9 = false;
  img10 = true;
  img11 = false;
  img12 = false;
  img13 = false;
  mandatryc() {
    this.img1 = !this.img1;
  }
  mandatryc1() {
    this.img2 = !this.img2;
  }
  mandatryc2() {
    this.img3 = !this.img3;
  }
  mandatryc3() {
    this.img4 = !this.img4;
  }
  mandatryc4() {
    this.img5 = !this.img5;
  }
  mandatryc5() {
    this.img6 = !this.img6;
    console.log("this.img6",this.img6);
  }
  mandatryc6() {
    this.img7 = !this.img7;
  }
  mandatryc7() {
    this.img8 = !this.img8;
  }
  mandatryc8() {
    this.img9 = !this.img9;
  }
  mandatryc9() {
    this.img10 = true;
  }
  mandatryc10() {
    this.img11 = !this.img11;
  }
  mandatryc11() {
    this.img12 = !this.img12;
  }
  mandatryc12() {
    this.img13 = !this.img13;
  }
  value1: any;
  get getFormArray() {
    return this.RadioForm.get("items") as FormArray;
  }
  formwork() {
    this.getFormArray.controls.splice(0);
    console.log("hello");
    const assistingDispatchBlue: HTMLInputElement = document.getElementById(
      "getvalue"
    ) as HTMLInputElement;
    this.value1 = assistingDispatchBlue.value;
    console.log(this.value1);
    for (var i = 1; i <= this.value1; i++) {
      this.items = this.RadioForm.get("items") as FormArray;
      this.items.push(this.createItem());
    }
  }
  value2: any;
  get getFormArray1() {
    return this.DropdownForm.get("items1") as FormArray;
  }
  formwork1() {
    this.getFormArray1.controls.splice(0);
    const assistingDispatchBlued: HTMLInputElement = document.getElementById(
      "getvalue1"
    ) as HTMLInputElement;
    this.value2 = assistingDispatchBlued.value;
    console.log(this.value2);
    for (var i = 1; i <= this.value2; i++) {
      this.items1 = this.DropdownForm.get("items1") as FormArray;
      this.items1.push(this.createItem1());
    }
  }
  value3: any;
  get getFormArray2() {
    return this.CheckboxForm.get("items2") as FormArray;
  }
  formwork2() {
    this.getFormArray2.controls.splice(0);
    const assistingDispatchBluedd: HTMLInputElement = document.getElementById(
      "getvalue2"
    ) as HTMLInputElement;
    this.value3 = assistingDispatchBluedd.value;
    console.log(this.value3);
    for (var i = 1; i <= this.value3; i++) {
      this.items2 = this.CheckboxForm.get("items2") as FormArray;
      this.items2.push(this.createItem2());
    }
    console.log(this.getFormArray.value);
  }

  openssigntriggersrecordDialog() {
    const dialogRef = this.dialog.open(AssigntriggerstorecordComponent, {
      width: "70%",
      maxWidth: "100vw",
    });
  }

  disableForms(CustomFormTypeId, cufid) {
    if (this.p9 == 'edit' && CustomFormTypeId != cufid) {
      return true
    }
    return false
  }

  checkPermission(formType:any){
    // console.log("formType:",formType)
    if(this.editPage){
      if(formType == 1){
        if(this.UserPermission.checkPermission('modify_dispatch_guide_form')){
          return true;
        }else{
          return false;
        }
      }
      if(formType == 2){
        if(this.UserPermission.checkPermission('modify_property_profile_form')){
          return true;
        }else{
          return false;
        }
      }
      if(formType == 3){
        if(this.UserPermission.checkPermission('modify_daily_log_record_extra_information_form')){
          return true;
        }else{
          return false;
        }
      }
      if(formType == 4){
        if(this.UserPermission.checkPermission('modify_incident_report_file_extra_record_form')){
          return true;
        }else{
          return false;
        }
      }
      if(formType == 5){
        if(this.UserPermission.checkPermission('modify_inspection_form')){
          return true;
        }else{
          return false;
        }
      }
      if(formType == 6){
        if(this.UserPermission.checkPermission('modify_asset_form')){
          return true;
        }else{
          return false;
        }
      }
      if(formType == 7){
        if(this.UserPermission.checkPermission('modify_user_messages_form')){
          return true;
        }else{
          return false;
        }
      }
    }else{
      if(formType == 1){
        if(this.UserPermission.checkPermission('add_dispatch_guide _form')){
          return true;
        }else{
          return false;
        }
      }
      if(formType == 2){
        if(this.UserPermission.checkPermission('add_property_profile_form')){
          return true;
        }else{
          return false;
        }
      }
      if(formType == 3){
        if(this.UserPermission.checkPermission('add_daily_log_record_extra _information_form')){
          return true;
        }else{
          return false;
        }
      }
      if(formType == 4){
        if(this.UserPermission.checkPermission('add_incident_report_file_extra_record_form')){
          return true;
        }else{
          return false;
        }
      }
      if(formType == 5){
        if(this.UserPermission.checkPermission('add_inspection_form')){
          return true;
        }else{
          return false;
        }
      }
      if(formType == 6){
        if(this.UserPermission.checkPermission('add_asset_form')){
          return true;
        }else{
          return false;
        }
      }
      if(formType == 7){
        if(this.UserPermission.checkPermission('add_user_messages_form')){
          return true;
        }else{
          return false;
        }
      }
    }
  }

  checkSavePermission(){
    if(this.editPage){
      if(
        this.UserPermission.checkPermission('modify_dispatch_guide_form') || 
        this.UserPermission.checkPermission('modify_property_profile_form') || 
        this.UserPermission.checkPermission('modify_daily_log_record_extra_information_form') || 
        this.UserPermission.checkPermission('modify_incident_report_file_extra_record_form') || 
        this.UserPermission.checkPermission('modify_inspection_form') || 
        this.UserPermission.checkPermission('modify_asset_form') || 
        this.UserPermission.checkPermission('modify_user_messages_form')
      ){
        return true;
      }else{
        return false;
      }
    }else{
      if(
        this.UserPermission.checkPermission('add_dispatch_guide _form') || 
        this.UserPermission.checkPermission('add_property_profile_form') || 
        this.UserPermission.checkPermission('add_daily_log_record_extra _information_form') || 
        this.UserPermission.checkPermission('add_incident_report_file_extra_record_form') || 
        this.UserPermission.checkPermission('add_inspection_form') || 
        this.UserPermission.checkPermission('add_asset_form') || 
        this.UserPermission.checkPermission('add_user_messages_form')
      ){
        return true;
      }else{
        return false;
      }
    }
  }

  noSelectFormType(event:any){    
    return false;
  }

  addDropDownFields() {
    let k = this.DropdownForm.get('nopickvalue').value
    let y = +k
    this.DropdownForm.patchValue({
      nopickvalue: y + 1
    });

      this.items1 = this.DropdownForm.get("items1") as FormArray;
      this.items1.push(this.createItem1());
  }

  removeDropDownField(i) {
    let k = this.DropdownForm.get('nopickvalue').value
    let y = +k
    this.DropdownForm.patchValue({
      nopickvalue: y - 1
    });

    this.items1 = this.DropdownForm.get("items1") as FormArray;
    this.items1.removeAt(i)
  }

  addDropDownFieldsRadio() {
    let k = this.RadioForm.get('nofradio').value
    let y = +k
    this.RadioForm.patchValue({
      nofradio: y + 1
    });

      this.items = this.RadioForm.get("items") as FormArray;
      this.items.push(this.createItem());
  }

  removeDropDownFieldRadio(i) {
    let k = this.RadioForm.get('nofradio').value
    let y = +k
    this.RadioForm.patchValue({
      nofradio: y - 1
    });

    this.items = this.RadioForm.get("items") as FormArray;
    this.items.removeAt(i)
  }

  addDropDownFieldsRadioCheckBox() {
    let k = this.CheckboxForm.get('nocbox').value
    let y = +k
    this.CheckboxForm.patchValue({
      nocbox: y + 1
    });

      this.items2 = this.CheckboxForm.get("items2") as FormArray;
      this.items2.push(this.createItem2());
  }

  removeDropDownFieldCheckBox(i) {
    let k = this.CheckboxForm.get('nocbox').value
    let y = +k
    this.CheckboxForm.patchValue({
      nocbox: y - 1
    });

    this.items2 = this.CheckboxForm.get("items2") as FormArray;
    this.items2.removeAt(i)
  }

  checkDropdownCheckValue = null
  DropdownSelectDefaulText
  placeholderName(txt, el, ind) {
    setTimeout(() => {
      // let m = this.items1.value[ind]
      // this.getrecordformdata.forEach(element => {
      //   if (element.ElementTypeId == 4) {
      //     element.CustomElementName[0] = m.name
      //   }
      // });
      // this.DropdownForm.value.ddefaulttext = this.items1.value[ind].name
      this.DropdownSelectDefaulText = this.items1.value[ind].name
      if (this.checkDropdownCheckValue != null && this.checkDropdownCheckValue === ind) {
        el.checked = false;
        this.ren.removeClass(el['_elementRef'].nativeElement, 'cdk-focused');
        this.ren.removeClass(el['_elementRef'].nativeElement, 'cdk-program-focused');
        // this.DropdownForm.value.ddefaulttext = ""
      this.DropdownSelectDefaulText = ""
      this.checkDropdownCheckValue = null;
      } else {
        this.checkDropdownCheckValue = ind
      }
    })
  }

}
