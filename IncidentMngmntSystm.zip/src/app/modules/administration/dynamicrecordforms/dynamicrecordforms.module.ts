import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DragDropModule } from '@angular/cdk/drag-drop';

import { ReactiveFormsModule } from '@angular/forms';
import { DynamicrecordformsRoutingModule } from './dynamicrecordforms-routing.module';
import { DynamicrecordformsComponent } from './dynamicrecordforms.component';
import { DynamicrecordformslistComponent } from './dynamicrecordformslist/dynamicrecordformslist.component';
import { AssigntriggerstorecordComponent } from './assigntriggerstorecord/assigntriggerstorecord.component';
import { SharedMaterialModule } from './../../../shared/shared-material.module';
@NgModule({
  declarations: [
    DynamicrecordformsComponent,
    DynamicrecordformslistComponent,
    AssigntriggerstorecordComponent
  ],
  imports: [
    CommonModule,
    DragDropModule,
    FormsModule,
    DynamicrecordformsRoutingModule,
    ReactiveFormsModule,
    SharedMaterialModule
  ],
  entryComponents: [
    AssigntriggerstorecordComponent
  ],
  providers: []
})
export class DynamicrecordformsModule { }
