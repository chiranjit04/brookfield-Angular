import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DynamicrecordformsComponent } from './dynamicrecordforms.component';

describe('DynamicrecordformsComponent', () => {
  let component: DynamicrecordformsComponent;
  let fixture: ComponentFixture<DynamicrecordformsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DynamicrecordformsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DynamicrecordformsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
