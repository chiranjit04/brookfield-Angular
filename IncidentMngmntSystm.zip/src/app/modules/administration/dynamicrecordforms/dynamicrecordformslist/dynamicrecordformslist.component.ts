import { Component, OnInit, ViewChild } from "@angular/core";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource, MatDialog, MatDialogRef } from "@angular/material";
import { Router } from "@angular/router";
import Swal from "sweetalert2";
import { ToastrService } from "ngx-toastr";
import { DynamicrecordformsService } from "../dynamicrecordforms.service";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
// tslint:disable-next-line: max-line-length
// import { ModelIncidentsubjectComponent } from 'src/app/modules/dispatch/incident-dispatch/model-incidentsubject/model-incidentsubject.component';
import { ModelIncidentsubjectComponent } from "../../../dispatch/incident-dispatch/model-incidentsubject/model-incidentsubject.component";
import { AssigntriggerstorecordComponent } from "../assigntriggerstorecord/assigntriggerstorecord.component";
import { UserPermissionService } from "../../../../services/user-permission.service";
import { StorageService } from "src/app/services/storage.service";
import { ServiceService } from "./../../service/service.service";

@Component({
  selector: "app-dynamicrecordformslist",
  templateUrl: "./dynamicrecordformslist.component.html",
  styleUrls: ["./dynamicrecordformslist.component.scss"],
})
export class DynamicrecordformslistComponent implements OnInit {
  options: string[] = ["One", "Two", "Three"];
  registerForm: FormGroup;
  dataSourcethree: MatTableDataSource<any>;
  displayedColumns: string[] = [
    "CustomFormId",
    "FormType",
    "Title",
    "Description",
    "Createdby",
    "CreatedDate",
    "action",
  ];

  GlobalEnvironmentID = 0;
  GlobalEnvironmentName = "";
  GOENumber = "";
  GlobalEnvironmentDetails = null;
  reportingset1 = false;
  dynamicrecordlist: any;
  dynamicarray: any;
  Hvrclck: any;
  formvalue = "";
  value2 = 0;
  subjectwork: any;
  getreportinglist: any;
  getsubjectbyid: any;
  FinalSublist: any;
  GetISCISubject: any;
  name: string;
  valuesList: any;
  getCustomFormType: any;

  userData = null;
  authToken = null;

  constructor(
    private formBuilder: FormBuilder,
    private storage: StorageService,
    private tostre: ToastrService,
    private DynamicService: DynamicrecordformsService,
    public dialog: MatDialog,
    private DynamicrecordformsService: DynamicrecordformsService,
    public router: Router,
    private UserPermission: UserPermissionService,
    private adminService: ServiceService
  ) {
    //... Read User Data ...
    this.authToken = localStorage.getItem("token");
    this.userData = JSON.parse(localStorage.getItem("UserData"));
    if (this.authToken == null) {
      this.router.navigate(["/login"]);
    }

    /* check module permission of the user */
    if (
      this.UserPermission.checkPermission(
        "access_dynamic_record_forms",
        "",
        "",
        ""
      ) == false
    ) {
      this.router.navigate(["/products/list"]);
      this.tostre.warning(
        "You don't have permission to access this module.",
        "",
        {
          positionClass: "toast-top-right",
        }
      );
    }

    this.GlobalEnvironmentDetails = JSON.parse(
      localStorage.getItem("GlobalEnvironmentDetails")
    );
    if (this.GlobalEnvironmentDetails) {
      this.GlobalEnvironmentID = this.GlobalEnvironmentDetails.GlobalEnvironmentId;
      this.GlobalEnvironmentName = this.GlobalEnvironmentDetails.GlobalEnvironmentName;
      this.GOENumber = this.GlobalEnvironmentDetails.GOENo;
    }

    this.DynamicService.GetCustomFormType().subscribe((res) => {
      this.getCustomFormType = res.data.getCustomFormType;
    });

    const rslbody = {
      GlobalEnvironmentID: this.GlobalEnvironmentID,
    };
    this.DynamicService.GetReportingSetList(rslbody).subscribe((res) => {
      this.getreportinglist = res.GetReportingSetList;
      // console.log(this.getreportinglist)
    });

    this.dataSourcethree = new MatTableDataSource();

    const pbody = {
      FormTypeId: 0,
      GlobalEnvironmentId: this.GlobalEnvironmentID,
    };

    this.DynamicService.getDynamiclist(pbody).subscribe((res) => {
      this.dynamicarray = res.CustomFormElement;

      this.dataSourcethree.data = this.dynamicarray;
      // console.log("worked")
      // console.log(this.dynamicarray);
      this.dataSourcethree.sort = this.tableOneSort;
      this.tableOneSort.disableClear = true;
      this.norecordshow();
    });
  }
  @ViewChild("TableOneSort", { static: true }) tableOneSort: MatSort;

  checkGoe() {
    if (this.GlobalEnvironmentID) {
      return true;
    } else {
      // Swal.fire({
      //   text: "Please first select a Global Operations Environment."
      // }).then((result) => {
      //   this.router.navigate(['products/administration/goe/mygoe']);
      // })
      this.tostre.error(
        "Please first select a Global Operations Environment.",
        "",
        {
          positionClass: "toast-top-right",
        }
      );
      return false;
    }
  }

  ngOnInit() {
    if (this.checkGoe()) {
    }

    this.registerForm = this.formBuilder.group({
      searchbox: [""],
    });
  }

  unactive(event: any): boolean {
    event.stopPropagation();
    return false;
  }

  updategetlist(event, dcfi, dcfti, ttle, dtdi, dby, cby) {
    event.stopPropagation();
    // localStorage.setItem('dynamiccustomformid', dcfi);
    // localStorage.setItem('dynamiccustomformtypeid',dcfti);
    // this.router.navigate(['products/administration/goe/dynamicrecord/dynamicrecordforms'])
    this.router.navigate([
      "products/administration/goe/dynamicrecord/dynamicrecordforms",
      {
        p1: dcfi,
        p2: dcfti,
        p3: ttle,
        p4: dtdi,
        p5: true,
        p6: true,
        p7: dby,
        p8: cby,
        p9: 'edit'
      },
    ]);
  }

  statuschange(event, statusid) {
    event.stopPropagation();
    // Swal.fire({
    //   text: "Are you sure you want to change status?",
    //   showCancelButton: true,
    //   width: "30%",
    //   confirmButtonColor: "#3085d6",
    //   cancelButtonColor: "#d33",
    //   confirmButtonText: "Yes",
    //   cancelButtonText: "No",
    // }).then((result) => {
    //   if (result.value) {
    //     const statusform = {
    //       CustomFormId: statusid,
    //     };

    //     this.DynamicService.UpdateCustomFormStatus(statusform).subscribe(
    //       (res) => {
    //         if (res.statusCode == 200) {
    //           const pbody = {
    //             FormTypeId: this.value2,
    //             GlobalEnvironmentId: this.GlobalEnvironmentID,
    //           };
    //           this.tostre.success("Status changed successfully.");
    //           this.DynamicService.getDynamiclist(pbody).subscribe((res) => {
    //             this.dynamicarray = res.CustomFormElement;
    //             this.dataSourcethree.data = this.dynamicarray;
    //             this.dataSourcethree.sort = this.tableOneSort;
    //             this.norecordshow();
    //           });
    //         }
    //       }
    //     );
    //   }
    // });
    const statusform = {
      CustomFormId: statusid,
    };

    this.DynamicService.UpdateCustomFormStatus(statusform).subscribe(
      (res) => {
        if (res.statusCode == 200) {
          const pbody = {
            FormTypeId: this.value2,
            GlobalEnvironmentId: this.GlobalEnvironmentID,
          };
          this.tostre.success(this.adminService.statusMsg);
          this.DynamicService.getDynamiclist(pbody).subscribe((res) => {
            this.dynamicarray = res.CustomFormElement;
            this.dataSourcethree.data = this.dynamicarray;
            this.dataSourcethree.sort = this.tableOneSort;
            this.tableOneSort.disableClear = true;
            this.norecordshow();
          });
        }
      }
    );
  }

  Deletelist(event, d) {
    event.stopPropagation();
    Swal.fire({
      // text: "Are you sure you want to delete?",
      text: this.adminService.deleteMsg,
      showCancelButton: true,
      width: "30%",
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes",
      cancelButtonText: "No",
    }).then((result) => {
      if (result.value) {
        const dbody = {
          CustomFormID: d,
        };

        this.DynamicService.Deleteformlist(dbody).subscribe((res) => {
          if (res.statusCode == 200) {
            const pbody = {
              FormTypeId: this.value2,
              GlobalEnvironmentId: this.GlobalEnvironmentID,
            };
            // this.tostre.success("Record deleted successfully.");
            this.DynamicService.getDynamiclist(pbody).subscribe((res) => {
              this.dynamicarray = res.CustomFormElement;
              this.dataSourcethree.data = this.dynamicarray;
              this.dataSourcethree.sort = this.tableOneSort;
              this.tableOneSort.disableClear = true;
              this.norecordshow();
            });
          }
        });
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        // this.tostre.warning("Your imaginary file is safe :)");
      }
    });
  }

  filterform(value1) {
    this.value2 = value1;
    const pbody = {
      FormTypeId: value1,
      GlobalEnvironmentId: this.GlobalEnvironmentID,
    };

    this.DynamicService.getDynamiclist(pbody).subscribe((res) => {
      this.dynamicarray = res.CustomFormElement;
      this.dataSourcethree.data = this.dynamicarray;
      this.dataSourcethree.sort = this.tableOneSort;
      this.tableOneSort.disableClear = true;
      this.norecordshow();
    });
  }
  norecordvariable = false;
  norecordshow() {
    setTimeout(() => {
      if (this.dataSourcethree.data.length === 0) {
        this.norecordvariable = true;
      } else {
        this.norecordvariable = false;
      }
    }, 1000);
  }

  addrecordform() {
    this.router.navigate([
      "products/administration/goe/dynamicrecord/dynamicrecordforms",
      { p2: this.value2 },
    ]);
  }

  hoverclick(i) {
    if (this.Hvrclck == i) {
      this.Hvrclck = "";
    } else {
      this.Hvrclck = i;
    }
  }
  /**
   * Open Popup for Subjects
   */
  // localStorage.setItem('getsubjectbyid',JSON.stringify(this.getsubjectbyid));
  //  console.log('getsubjectbyid',res);
  //  localStorage.setItem('SetListofFinalSub',JSON.stringify(this.SetListofFinalSub));
  setvariable = 1;
  openSubjectDialog(event, n, cfi) {
    event.stopPropagation();
    if (n === 1) {
      this.reportingset1 = true;
    }
    this.storage.setData("dynamicvariable", this.setvariable);
    //     const sibody = {
    //       CustomFormId: cfi,
    //     }
    //     this.DynamicService.GetAssignedSubjectByID(sibody).subscribe(res => {
    //       if (res.statusCode == 200) {
    //         this.getsubjectbyid = res.getAssignedSubjectByID;
    //         this.valuesList.forEach(element => {
    //           this.getsubjectbyid.forEach(element1 => {
    //             if (element.ISCISubjectID === element1.ISCISubjectID) {
    //               element['flag'] = 'true';
    //             }
    //           });
    //         });
    //       };
    //     });

    //   this.FinalSublist=this.valuesList;
    // console.log('Full Final sublist',this.FinalSublist);
    setTimeout(() => {
      const dialogRef = this.dialog.open(ModelIncidentsubjectComponent, {
        width: "70%",
        maxWidth: "100vw",
        // data: { name: this.FinalSublist }
      });
      dialogRef.componentInstance.reportingset1 = this.reportingset1;
      dialogRef.componentInstance.cfi = cfi;

      dialogRef.afterClosed().subscribe((result) => {
        this.registerForm.patchValue({
          searchbox: "",
        });
        const subjectid = result;
        if (subjectid != undefined) {
          var arroyd = "";
          subjectid.forEach((res) => {
            arroyd += res + "|";
          });
          this.storage.removeData("dynamicvariable");
          const sbody = {
            CustomFormId: cfi,
            SubjectIds: arroyd,
            IsActive: 1,
          };
          this.DynamicService.UpdateCustomFormSubject(sbody).subscribe(
            (res) => {
              const pbody = {
                FormTypeId: 0,
                GlobalEnvironmentId: this.GlobalEnvironmentID,
              };
              this.DynamicService.getDynamiclist(pbody).subscribe((res) => {
                this.dynamicarray = res.CustomFormElement;
                this.dataSourcethree.data = this.dynamicarray;
                this.dataSourcethree.sort = this.tableOneSort;
                this.tableOneSort.disableClear = true;
              });
            }
          );
        }
      });
    }, 400);
  }
  /**
   * Open Popup for Assign triggers to record
   */
  openssigntriggersrecordDialog() {
    const dialogRef = this.dialog.open(AssigntriggerstorecordComponent, {
      width: "70%",
      maxWidth: "100vw",
    });
  }

  checkPermission(formType:any){
    // console.log("formType:",formType)
    if(formType == 1){
      if(this.UserPermission.checkPermission('modify_dispatch_guide_form')){
        return true;
      }else{
        return false;
      }
    }
    if(formType == 2){
      if(this.UserPermission.checkPermission('modify_property_profile_form')){
        return true;
      }else{
        return false;
      }
    }
    if(formType == 3){
      if(this.UserPermission.checkPermission('modify_daily_log_record_extra_information_form')){
        return true;
      }else{
        return false;
      }
    }
    if(formType == 4){
      if(this.UserPermission.checkPermission('modify_incident_report_file_extra_record_form')){
        return true;
      }else{
        return false;
      }
    }
    if(formType == 5){
      if(this.UserPermission.checkPermission('modify_inspection_form')){
        return true;
      }else{
        return false;
      }
    }
    if(formType == 6){
      if(this.UserPermission.checkPermission('modify_asset_form')){
        return true;
      }else{
        return false;
      }
    }
    if(formType == 7){
      if(this.UserPermission.checkPermission('modify_user_messages_form')){
        return true;
      }else{
        return false;
      }
    }
  }

}

export interface PeriodicElement {}
