import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DynamicrecordformslistComponent } from './dynamicrecordformslist.component';

describe('DynamicrecordformslistComponent', () => {
  let component: DynamicrecordformslistComponent;
  let fixture: ComponentFixture<DynamicrecordformslistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DynamicrecordformslistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DynamicrecordformslistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
