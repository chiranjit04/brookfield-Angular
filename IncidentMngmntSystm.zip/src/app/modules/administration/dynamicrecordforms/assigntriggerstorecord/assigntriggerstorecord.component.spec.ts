import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssigntriggerstorecordComponent } from './assigntriggerstorecord.component';

describe('AssigntriggerstorecordComponent', () => {
  let component: AssigntriggerstorecordComponent;
  let fixture: ComponentFixture<AssigntriggerstorecordComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssigntriggerstorecordComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssigntriggerstorecordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
