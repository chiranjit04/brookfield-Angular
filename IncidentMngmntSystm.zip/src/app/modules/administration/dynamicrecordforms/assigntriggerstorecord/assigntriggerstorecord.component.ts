import { Component, OnInit } from '@angular/core';
import { DynamicrecordformsService } from '../dynamicrecordforms.service';
import { StorageService } from '../../../../services/storage.service';

@Component({
  selector: 'app-assigntriggerstorecord',
  templateUrl: './assigntriggerstorecord.component.html',
  styleUrls: ['./assigntriggerstorecord.component.scss']
})
export class AssigntriggerstorecordComponent implements OnInit {
  onCloseReturnValue:any;
  companylist: any;
  propertlist: any;
  ListofFinalSub=[];
  _IncidentInsideSub: any;
  constructor( private DynamicService: DynamicrecordformsService) {
     
    const companysearch = {
      CompanyID: 0,
      CompanyTypeID:0,
      StateId: 0,
      Status:null,
      IsActive:null,
      IsArchive:0,
      Zip:null,
      Address:null,
      ShortFilter:null
    }
    this.DynamicService.companySearchList(companysearch).subscribe(res => {
      this.companylist=res.companySearchList;
    })


    const propertsearch = {
      PropertyID: 0,
      PropertyName: null,
      GOEId: 0,
      ComapnyId:0,
      CountryId:0,
      StateId:0,
      City:null,
      Status:0,
      IsActive:null,
      IsArchive:0,
      IsAssignedGOE:null,
      Zip:null,
      Address:null,
      ShortFilter:null
    }
    this.DynamicService.propertySearchList(propertsearch).subscribe(res => {
      this.propertlist=res.propertySearchList;
    })

   }

  ngOnInit() {
  }


  takebyid(take,event)
  {
    var flag=0;
    if(this.ListofFinalSub.length!=0)
    {
    
    this.ListofFinalSub.forEach(element => {
       if(element==take)
       {
        this._IncidentInsideSub = event;
        this._IncidentInsideSub.classList.remove("selected");
        event.className += "deselected";
         this.ListofFinalSub = this.ListofFinalSub.filter(function(e) { return e !== element })
        flag=1;

       }
      });
      
  }
  if(flag==0)
  {
  this.ListofFinalSub.push(take);
  this._IncidentInsideSub = event;
  event.className += " selected";
 
  }

  console.log('ListofFinalSub',this.ListofFinalSub);
  // this.storage.setData('ListofFinalSub',JSON.stringify(this.ListofFinalSub));

  }


}
