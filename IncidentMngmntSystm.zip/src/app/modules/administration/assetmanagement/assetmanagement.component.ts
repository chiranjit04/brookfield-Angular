import { Component, OnInit, ViewChild } from "@angular/core";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import * as XLSX from "xlsx";
import {
  FormBuilder,
  FormGroup,
  FormArray,
  FormControl,
  Validators,
} from "@angular/forms";
import Swal from "sweetalert2";
import { ToastrService } from "ngx-toastr";
import { Router } from "@angular/router";
import { AssetmanagementService } from "./assetmanagement.service";
import { startWith, map } from "rxjs/operators";
import { data } from "jquery";
import {
  MatDialog,
  MAT_DIALOG_DATA,
  MatDialogRef,
} from "@angular/material/dialog";
import { UplaodiconComponent } from "./uplaodicon/uplaodicon.component";
import { environment } from "../../../../environments/environment";
import { Observable } from "rxjs";
import { UserPermissionService } from "../../../services/user-permission.service";
import { StorageService } from "../../../services/storage.service";
import { ServiceService } from "./../service/service.service";

@Component({
  selector: "app-assetmanagement",
  templateUrl: "./assetmanagement.component.html",
  styleUrls: ["./assetmanagement.component.scss"],
})
export class AssetmanagementComponent implements OnInit {
  displayedColumns: string[] = [
    "PropertyName",
    "PropertyIdentNumber",
    "AssetGroup",
    "Title",
    "AddedBy",
    "Status",
    // 'ExpiresON',
    "LastUpdate",
  ];

  displayedColumnsOne: string[] = [
    "GOETitle",
    "AssetGroupTitle",
    "AssetGroupDescription",
    "RecordFormAssetType",
    "PropertyName",
    "AssetGroupStatus",
    "Status",
    "Message",
  ];

  dataSource = new MatTableDataSource();
  dataSourceOne = new MatTableDataSource();

  @ViewChild(MatSort, null) sort: MatSort;

  //applyFilter: any;
  GlobalEnvironmentID = 0;
  GlobalEnvironmentName = "";
  GOENumber = "";
  GlobalEnvironmentDetails = null;

  //customformgrouplist: any;
  //customformlist: any;
  //propertylist: any;
  userData = null;
  currentUserID: any;

  addcate2 = false;
  RecordFormGroupEditable = false;
  isShown = false;
  selectedItem: any = false;
  selectedItemType: any = false;

  //selectedCustomFormGroupId = false;

  statusShowSub = false;

  selectedAssetCustomFormGroupID = false;
  selectedAssetCustomFormID = false;
  //assignprofilelist: any;
  selectedPropertyID: false;

  iconPath: any;
  authToken = null;

  uploadTableShow: any = false;
  OriginalTableNotShow: any = false;
  uploadedListForDnld: any = [];

  /** Upload Excel start  */

  title = "read-excel-in-angular8";
  storeData: any;
  jsonData: any;
  fileUploaded: File;
  worksheet: any;
  htmlData: any;

  profilelist: any;

  constructor(
    private tostre: ToastrService,
    private AssetmanagementService: AssetmanagementService,
    public router: Router,
    private fb: FormBuilder,
    public dialog: MatDialog,
    public UserPermission: UserPermissionService,
    private storage: StorageService,
    private adminService: ServiceService
  ) {
    //... Read User Data ...
    this.authToken = this.storage.getData("token");
    this.userData = JSON.parse(this.storage.getData("UserData"));
    if (this.authToken == null) {
      this.router.navigate(["/login"]);
    }

    /* check module permission of the user */
    if (
      this.UserPermission.checkPermission(
        "access_asset_management",
        "",
        "",
        ""
      ) == false
    ) {
      this.router.navigate(["/products/list"]);
      this.tostre.warning(
        "You don't have permission to access this module.",
        "",
        {
          positionClass: "toast-top-right",
        }
      );
    }

    this.GlobalEnvironmentDetails = JSON.parse(
      this.storage.getData("GlobalEnvironmentDetails")
    );
    if (this.GlobalEnvironmentDetails) {
      //this.groupData = this.organise(this.exportreport);
      this.GlobalEnvironmentID = this.GlobalEnvironmentDetails.GlobalEnvironmentId;
      this.GlobalEnvironmentName = this.GlobalEnvironmentDetails.GlobalEnvironmentName;
      this.GOENumber = this.GlobalEnvironmentDetails.GOENo;
    }
    this.userData = JSON.parse(this.storage.getData("UserData"));
    this.currentUserID = this.userData[0].UserID;

    this.assetFormFilters.GlobalEnvironmentID = this.GlobalEnvironmentID;

    this.iconPath = `${environment.imagePath}`;
  }

  /** Filter Onscreen View   */

  AssetFilters: any;
  assetRecordList: any = [];

  // goe: any = [];
  // goeList: any = [];

  workgroup: any = [];
  workgroupList: Observable<any>;

  properties: any = [];
  propertyList: any = [];
  propertyFilterList: Observable<any>;

  assetTypes: any = [];
  assetTypeList: Observable<any>;

  assetGroup: any = [];
  assetGroupList: any = [];

  assetGroupFilterList: Observable<any>;
  assetCustomFormList: any;

  IsActiveType: any = 1;

  assetFormFilters = {
    GlobalEnvironmentID: this.GlobalEnvironmentID,
    AssetGroupID: 0,
    CustomFormID: 0,
    WorkGroupID: 0,
    PropertyID: 0,
    IsActive: +this.IsActiveType,
  };

  assetFilterForm: FormGroup;

  ngOnInit() {
    if (this.checkGoe()) {
      this.getAssetGroupByGlobalEnvironmentID(0, this.GlobalEnvironmentID);
      this.getAssetFormListByGlobalEnvironmentID(0, this.GlobalEnvironmentID);
      this.GetAssetGroupPropertyByGlobalEnvironmentID(
        0,
        this.GlobalEnvironmentID
      );
      this.dataSource.sort = this.sort;
      this.dataSourceOne.sort = this.sort;
      this.getAssetGroupListOnViewScreen();

      // this.storage.removeData("AssignPropertyProfileFilter")
      // this.CustomFormGroupScreenView(this.GlobalEnvironmentID, 0, 0);
      //this.dataSource.sort = this.sort;

      this.AssetFilters = {
        GlobalEnvironmentID: "",
        AssetGroupID: "",
        CustomFormID: "",
        WorkGroupID: "",
        PropertyID: "",
        IsActive: "",
      };

      this.assetFilterForm = this.fb.group({
        GlobalEnvironmentID: "",
        AssetGroupID: "",
        CustomFormID: "",
        WorkGroupID: "",
        PropertyID: "",
        IsActive: "",
      });

      /* Get GOE List */
      // this.getGoeList();

      // Add Goe Filter
      // this.goeList = this.assetFilterForm.controls.GlobalEnvironmentID.valueChanges.pipe(
      //   startWith(""),
      //   map((value) => {
      //     let list = value.length >= 1 ? this.filterGoe(value) : [];
      //     if (list.length == 1 && list[0].GlobalEnvironmentName == value) {
      //       list = [];
      //     }
      //     return list;
      //   })
      // );
      this.getWorkgroupList();

      this.getPropertyList();

      this.getAssetTypeList();
    }
  }

  /**
   * Get Filter Goe List Service Call
   */

  // getGoeList() {
  //   this.AssetmanagementService.GetGoeByUser(this.currentUserID).subscribe(
  //     (response: any) => {
  //       this.goe = response.geoByUser;
  //     }
  //   );
  // }

  // private filterGoe(name: string): any {
  //   const filterValue = name.toLowerCase();
  //   return this.goe.filter((option) => {
  //     return option.GlobalEnvironmentName.toLowerCase().includes(filterValue);
  //   });
  // }

  /**
   * Get Filter Workgroup List Service Call
   */
  getWorkgroupList() {
    const obj = {
      UserID: this.currentUserID,
      GlobalEnvironmentID: this.GlobalEnvironmentID,
    };
    this.AssetmanagementService.GetAssetWorkgroupByGlobalEnvironmentID(
      obj
    ).subscribe((res) => {
      this.workgroup = res.data.GetAssetWorkgroupByGlobalEnvironmentID;
      this.workgroupList = this.assetFilterForm.controls.WorkGroupID.valueChanges.pipe(
        startWith(""),
        map((val: any) => (val.length >= 0 ? this.filterWorkGroup(val) : []))
      );
    });
  }

  private filterWorkGroup(name: string): any {
    const filterValue = name.toLowerCase();
    return this.workgroup.filter((option) => {
      return option.WorkGroupName.toLowerCase().includes(filterValue);
    });
  }

  checkWorkgroup(test) {
    this.workgroupList = this.assetFilterForm.controls.WorkGroupID.valueChanges.pipe(
      startWith(""),
      map((val: any) => (val.length >= 0 ? this.filterWorkGroup(val) : []))
    );
    //test.blur();
  }

  /**
   * Get Filter Property List Service Call
   */
  getPropertyList() {
    const obj = {
      UserID: this.currentUserID,
      GlobalEnvironmentID: this.GlobalEnvironmentID,
    };
    this.AssetmanagementService.GetAssetPropertyByGlobalEnvironmentID(
      obj
    ).subscribe((res) => {
      this.properties = res.data.GetAssetPropertyByGlobalEnvironmentID;
      this.propertyFilterList = this.assetFilterForm.controls.PropertyID.valueChanges.pipe(
        startWith(""),
        map((val: any) => (val.length >= 0 ? this.filterProperty(val) : []))
      );
    });
  }

  private filterProperty(name: string): any {
    const filterValue = name.toLowerCase();
    return this.properties.filter((option) => {
      return option.PropertyName.toLowerCase().includes(filterValue);
    });
  }

  checkProperty(test) {
    this.propertyFilterList = this.assetFilterForm.controls.PropertyID.valueChanges.pipe(
      startWith(""),
      map((val: any) => (val.length >= 0 ? this.filterProperty(val) : []))
    );
    test.blur();
  }

  /**
   * Get Filter Asset Type List Service Call
   */

  getAssetTypeList() {
    const obj = { GlobalEnvironmentID: this.GlobalEnvironmentID };
    this.AssetmanagementService.GetAssetTypeByGlobalEnvironmentID(
      obj
    ).subscribe((res) => {
      this.assetTypes = res.data.GetAssetTypeByGlobalEnvironmentID;

      this.assetTypeList = this.assetFilterForm.controls.CustomFormID.valueChanges.pipe(
        startWith(""),
        map((val: any) => (val.length >= 0 ? this.filterAssetType(val) : []))
      );
    });
  }

  private filterAssetType(name: string): any {
    const filterValue = name.toLowerCase();
    return this.assetTypes.filter((option) => {
      return option.AssetType.toLowerCase().includes(filterValue);
    });
  }

  checkAssetType() {
    this.assetTypeList = this.assetFilterForm.controls.CustomFormID.valueChanges.pipe(
      startWith(""),
      map((val: any) => (val.length >= 0 ? this.filterAssetType(val) : []))
    );
  }

  /**
   *
   * Add Assets Record Group Form
   *
   */

  AddAssetCustomGroupForm = new FormGroup({
    Title: new FormControl("", [Validators.required]),
    Description: new FormControl(""),
  });

  addAssetCustomGForm = false;
  get addACGF() {
    return this.AddAssetCustomGroupForm.controls;
  }

  /**
   *
   * Edit Asset Record Group Form
   *
   */

  EditAssetCustomGroupForm = new FormGroup({
    Title: new FormControl("", [Validators.required]),
    Description: new FormControl(""),
    IsActive: new FormControl(""),
    //frequencyValue: new FormControl("")
  });

  editAssetCustomGF = false;

  get editAssetCGF() {
    return this.EditAssetCustomGroupForm.controls;
  }

  /**
   * Add filter
   */
  async addFilter(event, prop, value) {
    if (event.isUserInput) {
      switch (
        prop
        // case 'CategoryID':
        //Fetch the SubCategory data
        // await this.getInspectionSubCategoryList(value);
        // //Reset SubCategory filter
        // this.inspectionFormFilters['SubCategoryID'] = 0;
        // //Reset form value
        // this.inspectionFilterForm.get('SubCategoryID').patchValue('');
        // break;
        // case 'WorkGroupId':
        //   //Fetch the Property
        //   await this.getPropertiesByWorkGroupId(value);
        //   //Reset Property filter
        //   this.inspectionFormFilters['PropertyId'] = '';
        //   //Reset form value
        //   this.inspectionFilterForm.get('Property').patchValue('');

        //   this.inspectionFilterForm.get('WorkGroup').patchValue(this.inspectionFilterForm.get('WorkGroup').value);
      ) {
      }
      this.assetFormFilters[prop] = value;
      this.getAssetGroupListOnViewScreen();
    }
  }

  /**
   * Remove Filter
   */
  async removeFilter(event, prop) {
    switch (prop) {
      case "GlobalEnvironmentID":
        this.assetFormFilters.GlobalEnvironmentID = this.GlobalEnvironmentID;

      case "WorkGroupID":
        this.assetFormFilters.WorkGroupID = 0;

      case "PropertyID":
        this.assetFormFilters.PropertyID = 0;

      case "CustomFormID":
        this.assetFormFilters.CustomFormID = 0;
        this.assetFilterForm.controls.CustomFormID.setValue("");

      case "AssetGroupID":
        this.assetFormFilters.AssetGroupID = 0;

        this.assetFilterForm.controls.AssetGroupID.setValue("");

      //   //Blank the SubCategory list
      //   await this.getInspectionSubCategoryList(0);
      //   //Reset Property filter
      //   this.inspectionFormFilters['SubCategoryID'] = 0;
      //   //Reset form value
      //   this.inspectionFilterForm.get('SubCategoryID').patchValue('');
      //   break;
      // case 'WorkGroupId':
      //   //Blank the Propety list
      //   await this.getPropertiesByWorkGroupId(0);
      //   //Reset Property filter
      //   this.inspectionFormFilters['PropertyId'] = '';
      //   //Reset form value
      //   this.inspectionFilterForm.get('Property').patchValue('');
      //   break;
    }
    //this.assetFormFilters[prop] = "";
    this.getAssetGroupListOnViewScreen();
  }

  /**
   * Toggle to Hide/ Show Onscreen View
   */

  toggleShow() {
    this.isShown = !this.isShown;
    this.assetFormFilters.IsActive = 1;
    this.getAssetGroupListOnViewScreen();
  }

  /**Change Active/ Inactive Status */

  changeStatus(IsActive) {
    if (IsActive.value == "0" || IsActive.value == "1") {
      this.IsActiveType = +IsActive.value;
      this.assetFormFilters.IsActive = +IsActive.value;
      this.getAssetGroupListOnViewScreen();
    //  this.tostre.success(this.adminService.statusMsg);
    }
  }

  /**
   * Check Goe
   */

  checkGoe() {
    if (this.GlobalEnvironmentID) {
      return true;
    } else {
      // Swal.fire({
      //   text: "Please first select a Global Operations Environment.",
      // }).then((result) => {
      //   this.router.navigate(["products/administration/goe/mygoe"]);
      //   //}
      // });
      this.tostre.error(
        "Please first select a Global Operations Environment.",
        "",
        {
          positionClass: "toast-top-right",
        }
      );
      return false;
    }
  }

  /**
   * Add Asset Group
   */

  addAssetRecordGroup() {
    let postData = this.AddAssetCustomGroupForm.value;
    this.addAssetCustomGForm = true;

    if (this.AddAssetCustomGroupForm.invalid) {
      return;
    }

    if (postData.Title.trim() == "") {
      this.showValid("Title is required");
      // Swal.fire({
      //   text: " Title is required"
      // })
      return false;
    }
    const obj = {
      AssetGroupID: 0,
      Title: postData.Title.trim(),
      Description: postData.Description,
      GlobalEnvironmentID: +this.GlobalEnvironmentID,
      IsActive: 1,
      UserID: +this.currentUserID,
    };

    if (
      !this.assetGroupList.find((elem) => obj.Title.trim() == elem.Title.trim())
    ) {
      this.updateAssetGroup(obj);
    } else {
      this.showValid(` ${obj.Title} Title already exists`);
      // Swal.fire({
      //   title: ` ${obj.Title} Title already exists`
      // });
    }
  }

  /**
   *
   * Update Asset Group
   * @param data
   *
   */

  updateAssetGroup(data) {
    this.AssetmanagementService.UpdateAssetGroup(data).subscribe((res) => {
      this.addcate2 = false;
      this.RecordFormGroupEditable = false;
      this.getAssetGroupByGlobalEnvironmentID(0, this.GlobalEnvironmentID);
    });
  }

  closeEditAssetGroupForm() {
    this.addcate2 = !this.addcate2;
    this.RecordFormGroupEditable = false;
    this.AddAssetCustomGroupForm.reset();
    this.addAssetCustomGForm = false;
    let shadesEl = document.querySelectorAll(".show");
    for (let i = 0; i < shadesEl.length; i++) {
      shadesEl[i].classList.remove("show");
    }
  }

  /**
   * Reset Asset Custom Record Group Form
   *
   */

  resetAssetCustomRecordGroup() {
    this.addcate2 = !this.addcate2;
    this.AddAssetCustomGroupForm.reset();
    this.addAssetCustomGForm = false;
  }

  /**
   * Get Asset Group List
   */

  getAssetGroupByGlobalEnvironmentID(AssetGroupID, GlobalEnvironmentID) {
    const obj = { GlobalEnvironmentID: +GlobalEnvironmentID };

    this.AssetmanagementService.GetAssetGroup(obj).subscribe((res) => {
      this.assetGroupList = res.data.GetAssetGroup;
      this.assetGroupFilterList = this.assetFilterForm.controls.AssetGroupID.valueChanges.pipe(
        startWith(""),
        map((val: any) => (val.length >= 0 ? this.filterAssetGroup(val) : []))
      );
    });
  }

  private filterAssetGroup(name: string): any {
    const filterValue = name.toLowerCase();
    return this.assetGroupList.filter((option) => {
      return option.Title.toLowerCase().includes(filterValue);
    });
  }

  checkAssetGroup(test) {
    this.assetGroupFilterList = this.assetFilterForm.controls.AssetGroupID.valueChanges.pipe(
      startWith(""),
      map((val: any) => (val.length >= 0 ? this.filterAssetGroup(val) : []))
    );
    //test.blur();
  }

  /**
   * Get Asset Custom Record Form List
   */

  getAssetFormListByGlobalEnvironmentID(AssetGroupID, GlobalEnvironmentID) {
    const obj = {
      AssetGroupId: AssetGroupID,
      GlobalEnvironmentID: +GlobalEnvironmentID,
    };

    this.AssetmanagementService.GetAssetFormListByGlobalEnvironmentID(
      obj
    ).subscribe((res) => {
      this.assetCustomFormList = res.data.GetAssetFormListByGlobalEnvironmentID;
    });
  }

  /**
   * Get Asset Property List
   */

  GetAssetGroupPropertyByGlobalEnvironmentID(
    AssetGroupID,
    GlobalEnvironmentID
  ) {
    const obj = {
      AssetGroupID: AssetGroupID,
      GlobalEnvironmentID: +GlobalEnvironmentID,
    };

    this.AssetmanagementService.GetAssetGroupPropertyByGlobalEnvironmentID(
      obj
    ).subscribe((res) => {
      this.propertyList = res.data.GetAssetGroupPropertyByGlobalEnvironmentID;
    });
  }

  /** Get Asset Group List OnScreenView */

  getAssetGroupListOnViewScreen() {
    this.AssetmanagementService.GetAssetGroupListOnViewScreen(
      this.assetFormFilters
    ).subscribe((result) => {
      this.assetRecordList = result.data.GetAssetGroupListOnViewScreen;
      this.dataSource = new MatTableDataSource(this.assetRecordList);
      this.dataSource.sort = this.sort;
      this.sort.disableClear = true;
    });
  }

  editAssetGroupForm(data) {
    this.selectedAssetCustomFormGroupID = data.AssetGroupID;
    this.addcate2 = false;
    this.EditAssetCustomGroupForm.patchValue({
      Title: data.Title,
    });
    this.EditAssetCustomGroupForm.patchValue({
      Description: data.Description,
      IsActive: data.IsActive,
    });

    this.statusShowSub = data.IsActive;
  }

  /**
   * Delete Asset Group
   * @param AssetGroupID
   */

  deleteAssetGroup(AssetGroupID) {
    const obj = {
      AssetGroupID: +AssetGroupID,
    };
    Swal.fire({
      // text: "Are you sure you want to remove this ?",
      text: this.adminService.deleteMsg,
      showCancelButton: true,
      confirmButtonText: "Yes",
      cancelButtonText: "No",
    }).then((result) => {
      if (result.value) {
        this.AssetmanagementService.DeleteAssetGroup(obj).subscribe((res) => {
          this.getAssetGroupByGlobalEnvironmentID(0, this.GlobalEnvironmentID);
        });
      }
    });
  }

  /**
   * Select Asset Group
   * @param AssetGroupId
   *
   */
  assetGroupSelected(AssetGroupId) {
    this.addcate2 = false;

    if (this.selectedAssetCustomFormGroupID == AssetGroupId) {
      this.selectedAssetCustomFormGroupID = false;
      this.selectedPropertyID = false;
      this.selectedAssetCustomFormID = false;
    } else {
      this.selectedAssetCustomFormGroupID = AssetGroupId;
      this.getAssetFormListByGlobalEnvironmentID(
        AssetGroupId,
        this.GlobalEnvironmentID
      );
      this.GetAssetGroupPropertyByGlobalEnvironmentID(
        AssetGroupId,
        this.GlobalEnvironmentID
      );
    }
  }

  /**
   *
   * Reset Edit Form when Close
   */

  resetEditAssetRecordGroup() {
    this.EditAssetCustomGroupForm.reset();
  }

  changeAssetRecordStatus(id: any) {
    let element: HTMLElement = document.getElementById(
      "status-assetgroup-" + id
    ) as HTMLElement;
    element.click();
    this.statusShowSub = !this.statusShowSub;
  }

  changeAssetRecordGroupstatus(AssetGroupID) {
    const obj = {
      AssetGroupID: +AssetGroupID,
    };
    this.AssetmanagementService.ChangeAssetGroupStatus(obj).subscribe((res) => {
      let data = this.assetGroupList.find(
        (o) => o.AssetGroupID == obj.AssetGroupID
      );

      let index = this.assetGroupList.indexOf(data);
      this.assetGroupList.fill(
        (data.IsActive = !data.IsActive),
        index,
        index++
      );
     this.tostre.success(this.adminService.statusMsg); 
    });
  }

  /**
   * Update Asset Group
   * @param data
   * @param value
   */
  updateAssetRecordGroup(data, value) {
    this.editAssetCustomGF = true;
    if (this.EditAssetCustomGroupForm.invalid) {
      if (value.Title.trim() == "") {
        this.showValid("Title is required");
        // Swal.fire({
        //   text: "Title is required"
        // })
        return false;
      }
      return false;
    }

    // if (value.Description.trim() == "") {
    //   Swal.fire({
    //     text: " Zone Description is required"
    //   })
    //   return false
    // }

    const obj = {
      AssetGroupID: data.AssetGroupID,
      Title: value.Title.trim(),
      Description: value.Description,
      GlobalEnvironmentID: +this.GlobalEnvironmentID,
      IsActive: value.IsActive ? 1 : 0,
      UserID: +this.currentUserID,
    };

    // if (!this.customformgrouplist.find(

    //   elem => obj.Title.trim() == elem.Title.trim())) {

    //   this.UpdateCustomFormGroup(obj)

    // }
    // else {

    //   Swal.fire({
    //     title: ` ${obj.Title} Title already exists`
    //   });
    // }

    this.updateAssetGroup(obj);
  }

  /**
   *
   * Select Asset Record Form
   * @param data
   *
   */

  assetRecordFormSelected(data) {
    if (this.selectedAssetCustomFormGroupID) {
      this.UpdateAssetFormToAssetGroup(data);
    } else {
      this.showValid("Please Select Asset Record Form Group First");
      // Swal.fire({
      //   text: "Please Select Asset Record Form Group First",
      // });
    }
  }

  /**
   * Assign Asset type Form to Asset Group
   */

  UpdateAssetFormToAssetGroup(data) {
    const obj = {
      AssetGroupID: this.selectedAssetCustomFormGroupID,
      CustomFormID: data.CustomFormID,
      IsAssined: data.IsAssigned ? 0 : 1,
      DisplayOrder: 0,
    };

    this.AssetmanagementService.UpdateAssetFormToAssetGroup(obj).subscribe(
      (res) => {
        /**
         * Refresh List for Asset Record Form List
         */

        this.getAssetFormListByGlobalEnvironmentID(
          obj.AssetGroupID,
          this.GlobalEnvironmentID
        );
      }
    );
  }

  // Assign Asset Property to AssetGroup

  assetPropertySelected(data) {
    let postData = {
      AssetGroupID: this.selectedAssetCustomFormGroupID,
      PropertyID: data.PropertyID,
      IsAssined: data.IsAssigned ? 0 : 1,
    };

    if (this.selectedAssetCustomFormGroupID) {
      if (data.IsAssignedToAssetGroup == 1) {
        this.AssetmanagementService.UpdateAssetGroupProperty(
          postData
        ).subscribe((resp) => {
          this.GetAssetGroupPropertyByGlobalEnvironmentID(
            this.selectedAssetCustomFormGroupID,
            this.GlobalEnvironmentID
          );
        });
      } else if (data.IsAssigned == 1) {
        this.AssetmanagementService.UpdateAssetGroupProperty(
          postData
        ).subscribe((res) => {
          this.GetAssetGroupPropertyByGlobalEnvironmentID(
            this.selectedAssetCustomFormGroupID,
            this.GlobalEnvironmentID
          );
        });
      } else {
        Swal.fire({
          //title: 'Are you sure you want to delete ?',
          text:
            "This property is assigned to other group. Do you want to assign this?",
          showCancelButton: true,
          confirmButtonText: "Yes",
          cancelButtonText: "No",
        }).then((result) => {
          if (result.value) {
            let result: any;
            this.AssetmanagementService.UpdateAssetGroupProperty(
              postData
            ).subscribe((resp) => {
              result = resp;
              this.GetAssetGroupPropertyByGlobalEnvironmentID(
                this.selectedAssetCustomFormGroupID,
                this.GlobalEnvironmentID
              );
            });
          }
        });
      }
    } else {
      this.showValid("Please Select Asset Record Form Group First");
      // Swal.fire({
      //   text: "Please Select Asset Record Form Group First",
      // });
    }
  }

  /*  upload icon dialog */

  openDialog(item: any, action: any) {
    const dialogRef = this.dialog.open(UplaodiconComponent, {
      width: "40%",
      maxWidth: "100vw",
      data: { item: item, action: action },
      disableClose: true,
      autoFocus: false,
    });

    dialogRef.afterClosed().subscribe((result) => {
      //console.log(`Dialog result: ${result}`);
      this.getAssetFormListByGlobalEnvironmentID(
        this.selectedAssetCustomFormGroupID,
        this.GlobalEnvironmentID
      );
    });
  }

  // toastr warning/success message
  showInvalid(msg) {
    this.tostre.warning(msg, "", {
      positionClass: "toast-top-right",
    });
  }

  showValid(validMsg) {
    this.tostre.success(validMsg, "", {
      positionClass: "toast-top-right",
    });
  }

  closePage() {
    window.location.reload();
  }

  //Upload excel sheet
  openFileBrowser(event: any) {
    event.preventDefault();
    let element: HTMLElement = document.getElementById("file") as HTMLElement;
    element.click();
  }

  uploadedFile(event) {
    this.uploadTableShow = true;
    this.OriginalTableNotShow = true;
    // this.isShown = true;
    this.fileUploaded = event.target.files[0];
    this.readExcel();
  }
  readExcel() {
    let readFile = new FileReader();

    readFile.onload = (e) => {
      this.storeData = readFile.result;

      var data = new Uint8Array(this.storeData);

      var arr = new Array();

      for (var i = 0; i != data.length; ++i)
        arr[i] = String.fromCharCode(data[i]);

      var bstr = arr.join("");

      var workbook = XLSX.read(bstr, { type: "binary" });

      var first_sheet_name = workbook.SheetNames[1];

      this.worksheet = workbook.Sheets[first_sheet_name];

      var range = XLSX.utils.decode_range(this.worksheet["!ref"]);
      range.s.r = 2; // <-- zero-indexed, so setting to 1 will skip row 0
      this.worksheet["!ref"] = XLSX.utils.encode_range(range);

      this.readAsJson(this.currentUserID);
    };

    readFile.readAsArrayBuffer(this.fileUploaded);
  }

  // Upload Excel End

  /** Read As Json */

  readAsJson(currentUserID) {
    this.jsonData = XLSX.utils.sheet_to_json(this.worksheet, { raw: false });
    //this.jsonData = JSON.stringify(this.jsonData);

    var arrofobj = (this.profilelist = this.jsonData);
    // this.patrolZoneImportList = this.jsonData

    var result = arrofobj.map(function (el) {
      var o = Object.assign({}, el);
      o.UserID = +currentUserID;
      // o.Status = "";
      o.Message = "";
      o.RecNo = "";
      return o;
    });
    let length = Object.keys(result).length;

    this.assetManagementImport(result);
    // this.getPropertyPatrolZoneList(this.PropertyID, 0);
  }
  newObjArr = [];
  assetManagementImport(obj) {
    //console.log("obj====final hit to service --->>>>", obj);
    //console.log("obj is here", obj);
    let matchProfile =
      Object.keys(obj[0]).includes("Asset Group Title") &&
      Object.keys(obj[0]).includes("Record Form Asset Type");
    //console.log("test", matchProfile);

    if (matchProfile) {
      // this.uploadfileList = true;
      // this.onscreenList = false;
      if (obj.length == 0) {
        Swal.fire({
          text: "No Data Found ",
        });
        return;
      }

      for (var i = 0; i < obj.length; i++) {
        let newObj = {
          RecNo: obj[i].RecNo,
          GOETitle: obj[i]["GOE Title"],
          AssetGroupTitle: obj[i]["Asset Group Title"],
          AssetGroupDescription: obj[i]["Asset Group Description"],
          RecordFormAssetType: obj[i]["Record Form Asset Type"],
          PropertyName: obj[i]["Property Name"],
          AssetGroupStatus: obj[i]["Status"],
          UserID: +obj[i].UserID,
          Status: "",
          Message: "",
        };
        //console.log(obj[i]);
        //console.log("what a game", newObj);
        this.newObjArr.push(newObj);
      }
      let passingArray = this.newObjArr;
      //console.log("passing array", passingArray);
      let result: any;
      this.AssetmanagementService.AssetImport(passingArray).subscribe(
        (res) => {
          result = res;
          if (res) {
            //console.log("Uploaded list", result.data.AssetImport);
            this.dataSourceOne = new MatTableDataSource(
              result.data.AssetImport
            );
            this.dataSourceOne.sort = this.sort;
            this.sort.disableClear = true;
            this.uploadedListForDnld = result.data.AssetImport;
            //console.log("data source one", result.data.AssetImport);
            //  this.profileImportData = result.profileImport.recordsets[0];
            this.showValid("Processed successfully. Please check the table.");
          }
          // this.profileImportData = result.profileImport.recordsets[0]
          // this.dataSourceOne = new MatTableDataSource(this.profileImportData)
        },
        (error) => {
          if (error.status == 500) {
            Swal.fire({
              text: "Import Failed",
            });
          }
        }
      );
    } else {
      this.showInvalid(
        "Uploaded Excel Sheet is Invalid. Please put the right one."
      );
    }
  }

  //Download Excel Sheet

  exportImportData(): void {
    let data = JSON.parse(JSON.stringify(this.assetRecordList));
    let tempData = [];
    //console.log("downloaded data", data);
    data.forEach(function (item, i) {
      delete item.RecNo;
      delete item.AddedBy;
      delete item.AssetGroupID;
      delete item.CustomFormId;
      delete item.LastUpdate;
      delete item.PropertyID;
      delete item.PropertyIdentNumber;
      tempData.push(item);
    });
    tempData.forEach((data) => {
      data.Status = data.Status ? "Active" : "Inactive";
    });
    //console.log("what data is going for download", tempData);
    this.AssetmanagementService.exportAsExcelFile(tempData);
  }

  //Download uploaded Excel Sheet

  exportUploadData(): void {
    let data = JSON.parse(JSON.stringify(this.uploadedListForDnld));
    let tempData = [];
    //console.log("downloaded dataF", data);
    data.forEach(function (item, i) {
      delete item.RecNo;
      delete item.UserID;
      tempData.push(item);
    });
    // tempData.forEach(data => {
    //   data.Status = data.Status ? "Active" : "Inactive"
    // })
    //console.log("what data is going for download", tempData);
    this.AssetmanagementService.exportAsUploadExcelFile(tempData);
  }

  onItemSelect(row) {
    if (this.selectedItem == row.PropertyIdentNumber && this.selectedItemType == row.CustomFormId) {
      this.selectedItem = !this.selectedItem;
      this.selectedItemType = !this.selectedItemType;
    } else {
      this.selectedItem = row.PropertyIdentNumber;
      this.selectedItemType = row.CustomFormId;
    }
  }
}
