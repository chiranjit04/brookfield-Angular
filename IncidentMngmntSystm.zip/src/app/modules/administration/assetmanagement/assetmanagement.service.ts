import { Injectable } from "@angular/core";
import { Observable, of } from "rxjs";
import { HttpClient } from "@angular/common/http";
import { environment } from "../../../../environments/environment";
// import * as logoFile from "../propertymanagement/patrolzonemanagement/brookfieldlogo1";
import  * as logoFile from "src/assets/images/logo/brookfieldlogo";
import { Workbook } from "exceljs";
import * as fs from "file-saver";
import * as XLSX from "xlsx";

@Injectable({
  providedIn: "root",
})
export class AssetmanagementService {
  observable: Observable<any>;
  url: any;

  constructor(private http: HttpClient) {
    this.url = environment.origin + "api/";
  }

  // GetAssetFormGroup(obj) {
  //   try {
  //     return this.http.post<any>(`${this.url}GetCustomFormGroup`, obj);
  //   } catch (error) {
  //     throw error;
  //   }
  // }

  // GetCustomFormListByGoeId(obj) {
  //   try {
  //     return this.http.post<any>(`${this.url}GetCustomFormListByGoeId`, obj);
  //   } catch (error) {
  //     throw error;
  //   }
  // }

  GetGoeByUser(UserId: any) {
    let data = { UserId: +UserId };
    return this.http.post<any>(`${this.url}getGoeByUser`, data);
  }

  UpdateAssetGroup(param: any) {
    return this.http.post<any>(
      `${this.url}assetManagement/UpdateAssetGroup`,
      param
    );
  }
  GetAssetGroup(param: any) {
    return this.http.post<any>(
      `${this.url}assetManagement/GetAssetGroup`,
      param
    );
  }
  GetAssetFormListByGlobalEnvironmentID(param: any) {
    return this.http.post<any>(
      `${this.url}assetManagement/GetAssetFormListByGlobalEnvironmentID`,
      param
    );
  }

  GetAssetGroupPropertyByGlobalEnvironmentID(param: any) {
    return this.http.post<any>(
      `${this.url}assetManagement/GetAssetGroupPropertyByGlobalEnvironmentID`,
      param
    );
  }
  GetAssetPropertyByGlobalEnvironmentID(param: any) {
    return this.http.post<any>(
      `${this.url}assetManagement/GetAssetPropertyByGlobalEnvironmentID`,
      param
    );
  }

  GetAssetWorkgroupByGlobalEnvironmentID(param: any) {
    return this.http.post<any>(
      `${this.url}assetManagement/GetAssetWorkgroupByGlobalEnvironmentID`,
      param
    );
  }
  GetAssetTypeByGlobalEnvironmentID(param: any) {
    return this.http.post<any>(
      `${this.url}assetManagement/GetAssetTypeByGlobalEnvironmentID`,
      param
    );
  }
  ChangeAssetGroupStatus(param: any) {
    return this.http.post<any>(
      `${this.url}assetManagement/ChangeAssetGroupStatus`,
      param
    );
  }
  DeleteAssetGroup(param: any) {
    return this.http.post<any>(
      `${this.url}assetManagement/DeleteAssetGroup`,
      param
    );
  }

  UpdateAssetFormToAssetGroup(param: any) {
    return this.http.post<any>(
      `${this.url}assetManagement/UpdateAssetFormToAssetGroup`,
      param
    );
  }

  UpdateAssetGroupProperty(param: any) {
    return this.http.post<any>(
      `${this.url}assetManagement/UpdateAssetGroupProperty`,
      param
    );
  }

  GetAssetGroupListOnViewScreen(param: any) {
    return this.http.post<any>(
      `${this.url}assetManagement/GetAssetGroupListOnViewScreen`,
      param
    );
  }

  uploadIcon(data: any) {
    return this.http.post<any>(
      `${this.url}assetManagement/UpdateAssetIcon`,
      data
    );
  }

  //Asset Import
  AssetImport(data: any) {
    return this.http.post<any>(`${this.url}assetManagement/AssetImport`, data);
  }

  GetAssetIconList(data: any) {
    return this.http.post(`${this.url}GetAssetsIconList`, data);
  }
  DeleteAssetIcon(data: any) {
    return this.http.post(`${this.url}DeleteAssetsIcon`, data);
  }
  ChangeAssetsIsDefault(data: any) {
    return this.http.post(`${this.url}ChangeAssetsIsDefault`, data);
  }

  swap(input: any, index_A: any, index_B: any) {
    let temp = input[index_A];

    input[index_A] = input[index_B];
    input[index_B] = temp;
  }

  //Asset Download
  //Download Excel
  async exportAsExcelFile(json: any[]) {
    const title = "Asset Management Exported Data";

    const header = [
      "GOE Title",
      "Asset Group Title",
      "Asset Group Description",
      "Record Form Asset Type",
      "Property Name",
      "Status",
    ];

    // Create workbook and worksheet
    const workbook = new Workbook();
    const worksheetOne = workbook.addWorksheet("Instructions");
    const worksheet = workbook.addWorksheet("Asset Management Profile Data");
    const worksheetTwo = workbook.addWorksheet("System Pick Values");

    let objectList = [];

    objectList = json.map((ob) => Object.values(ob));
    console.log("Object list", objectList);
    // objectList.forEach((data) => {
    //   const row = worksheet.addRow(data);
    //   row.alignment = { horizontal: "center", wrapText: true };
    //   const qty = row.getCell(4);
    // });

    // Add the Header Image
    worksheet.mergeCells("A1:B1");
    const imageRow = worksheet.getRow(1);
    imageRow.height = 80;

    // Add Image
    const logo = workbook.addImage({
      base64: logoFile.logoBase64,
      extension: "png",
    });

    worksheet.addImage(logo, {
      tl: { col: 0.5, row: 0.5 },
      ext: { width: 350, height: 85 },
    });
    const titleRow = worksheet.addRow([title]);
    titleRow.font = { name: "Calibri", family: 4, size: 16, bold: true };
    worksheet.mergeCells("A2:C2");
    // Add Header Row
    const headerRow = worksheet.addRow(header);

    // Set a specific row height
    headerRow.height = 42.5;

    headerRow.font = { name: "Calibri", family: 4, size: 11, bold: true };
    headerRow.alignment = {
      vertical: "middle",
      horizontal: "center",
    };

    // Cell Style : Fill and Border
    headerRow.eachCell((cell, number) => {
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "C9DEC9" },
        bgColor: { argb: "FF0000FF" },
      };
      cell.border = {
        top: { style: "thin" },
        left: { style: "thin" },
        bottom: { style: "thin" },
        right: { style: "thin" },
      };
    });

    worksheet.getCell("C3").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "FFFFFF" },
      bgColor: { argb: "FFFFFF" },
    };
    worksheet.getCell("D3").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "FFFFFF" },
      bgColor: { argb: "FFFFFF" },
    };
    worksheet.getCell("E3").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "FFFFFF" },
      bgColor: { argb: "FFFFFF" },
    };
    // worksheet.addRows(data);

    // Add Data and Conditional Formatting
    objectList.forEach((d) => {
      this.swap(d, 0, 3);
      this.swap(d, 3, 4);
      this.swap(d, 3, 1);
      this.swap(d, 2, 5);
      this.swap(d, 5, 6);
      const row = worksheet.addRow(d);
      row.alignment = { horizontal: "center", wrapText: true };
      const qty = row.getCell(4);
    });

    worksheet.getColumn(1).width = 30;
    worksheet.getColumn(2).width = 30;
    worksheet.getColumn(3).width = 30;
    worksheet.getColumn(4).width = 30;
    worksheet.getColumn(5).width = 30;
    worksheet.getColumn(6).width = 30;
    worksheet.getColumn(7).width = 30;

    worksheet.addRow([]);

    worksheetOne.getColumn(3).width = 13;
    worksheetOne.getColumn(4).width = 13;

    // Add the Header Image
    worksheetOne.mergeCells("D1:H6");
    // Add Image
    const logoOne = workbook.addImage({
      base64: logoFile.logoBase64,
      extension: "png",
    });

    worksheetOne.addImage(logoOne, "D1:H6");
    worksheetOne.addRow([]);
    worksheetOne.getCell("C7").value =
      "Brookfield Property Retail Property Upload Spreadsheet";
    worksheetOne.getCell("C7").font = {
      name: "Calibri",
      family: 4,
      size: 16,
      underline: true,
      bold: true,
    };

    worksheetOne.addRow([]);
    worksheetOne.addRow([]);

    worksheetOne.getCell("B10").value =
      "Please list the Brookfield Property Retail Properties, these Properties are customized to represent that company’s organizational structure and related positions of oversight.";
    worksheetOne.getCell("B10").alignment = {
      vertical: "top",
      horizontal: "left",
      wrapText: true,
    };

    worksheetOne.mergeCells("B10", "K13");

    worksheetOne.getCell("B10").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "C9DEC9" },
      bgColor: { argb: "FF0000FF" },
    };

    worksheetOne.getCell("B15").value =
      "Set of Instructions for the Spreadsheet:";
    worksheetOne.getCell("B15").font = {
      name: "Calibri",
      family: 4,
      size: 12,
      bold: true,
    };
    worksheetOne.addRow([]);
    worksheetOne.getCell("B17").value = "GENERAL INFO:";
    worksheetOne.getCell("B23").alignment = { horizontal: "center" };
    worksheetOne.getCell("B17").font = {
      name: "Calibri",
      family: 4,
      size: 12,
      bold: true,
    };
    worksheetOne.getCell("B18").value = "-";
    worksheetOne.getCell("B18").alignment = { horizontal: "right" };
    worksheetOne.getCell("C18").value =
      "Please fill in the required fields to upload data into maxIMuS.";
    worksheetOne.addRow([]);
    worksheetOne.getCell("B20").value = "-";
    worksheetOne.getCell("B20").alignment = { horizontal: "right" };
    worksheetOne.getCell("C20").value =
      "Dropdown values will appear in each cell if there is a selection to be made,";
    worksheetOne.getCell("C21").value = " otherwise enter appropriate data.";
    worksheetOne.addRow([]);
    worksheetOne.getCell("B23").value = "-";
    worksheetOne.getCell("B23").alignment = { horizontal: "right" };
    worksheetOne.getCell("C23").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "C9DEC9" },
      bgColor: { argb: "FF0000FF" },
    };
    worksheetOne.getCell("C23").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheetOne.getCell("D23").value =
      "Headers in Light Green are Mandatory or Required fields.";
    worksheetOne.getCell("B24").value = "-";
    worksheetOne.getCell("B24").alignment = { horizontal: "right" };
    worksheetOne.getCell("C24").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "" },
      bgColor: { argb: "" },
    };
    worksheetOne.getCell("C24").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheetOne.getCell("D24").value =
      "Headers in White are not Required entry fields.";
    worksheetOne.addRow([]);
    worksheetOne.getCell("B26").value = "-";
    worksheetOne.getCell("B26").alignment = { horizontal: "right" };
    worksheetOne.getCell("C26").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "" },
      bgColor: { argb: "" },
    };
    worksheetOne.getCell("C26").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheetOne.getCell("D26").value =
      "Header cells that include a red triangle at top right provide";
    worksheetOne.getCell("D27").value =
      "information about the field when you mouse over the cell.";

    worksheetOne.addRow([]);

    //Worksheet for System Pick Values
    worksheetTwo.getCell("C2").value = "Active";
    worksheetTwo.getCell("C3").value = "InActive";

    // Generate Excel File with given name
    workbook.xlsx.writeBuffer().then((data: any) => {
      const blob = new Blob([data], {
        type:
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });
      fs.saveAs(blob, "AssetManagement.xlsx");
    });
  }

  //Download Uploaded Excel
  async exportAsUploadExcelFile(json: any[]) {
    const title = "Asset Management Exported Data";

    const header = [
      "GOE Title",
      "Asset Group Title",
      "Asset Group Description",
      "Record Form Asset Type",
      "Property Name",
      "Asset Group Status",
      "Status",
      "Message",
    ];

    // Create workbook and worksheet
    const workbook = new Workbook();
    const worksheetOne = workbook.addWorksheet("Instructions");
    const worksheet = workbook.addWorksheet("Asset Management Profile Data");
    const worksheetTwo = workbook.addWorksheet("System Pick Values");

    let objectList = [];

    objectList = json.map((ob) => Object.values(ob));
    console.log("Object list", objectList[0]);
    // objectList.forEach((data) => {
    //   const row = worksheet.addRow(data);
    //   row.alignment = { horizontal: "center", wrapText: true };
    //   const qty = row.getCell(4);
    // });

    // Add the Header Image
    worksheet.mergeCells("A1:B1");
    const imageRow = worksheet.getRow(1);
    imageRow.height = 80;

    // Add Image
    const logo = workbook.addImage({
      base64: logoFile.logoBase64,
      extension: "png",
    });

    worksheet.addImage(logo, {
      tl: { col: 0.5, row: 0.5 },
      ext: { width: 350, height: 85 },
    });
    const titleRow = worksheet.addRow([title]);
    titleRow.font = { name: "Calibri", family: 4, size: 16, bold: true };
    worksheet.mergeCells("A2:C2");
    // Add Header Row
    const headerRow = worksheet.addRow(header);

    // Set a specific row height
    headerRow.height = 42.5;

    headerRow.font = { name: "Calibri", family: 4, size: 11, bold: true };
    headerRow.alignment = {
      vertical: "middle",
      horizontal: "center",
    };

    // Cell Style : Fill and Border
    headerRow.eachCell((cell, number) => {
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "C9DEC9" },
        bgColor: { argb: "FF0000FF" },
      };
      cell.border = {
        top: { style: "thin" },
        left: { style: "thin" },
        bottom: { style: "thin" },
        right: { style: "thin" },
      };
    });

    worksheet.getCell("C3").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "FFFFFF" },
      bgColor: { argb: "FFFFFF" },
    };
    worksheet.getCell("D3").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "FFFFFF" },
      bgColor: { argb: "FFFFFF" },
    };
    worksheet.getCell("E3").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "FFFFFF" },
      bgColor: { argb: "FFFFFF" },
    };
    // worksheet.addRows(data);

    // Add Data and Conditional Formatting
    objectList.forEach((d) => {
      // this.swap(d, 1, 3);
      // this.swap(d, 4, 5);
      // this.swap(d, 0, 4);
      // this.swap(d, 2, 3);
      // this.swap(d, 4, 6);
      const row = worksheet.addRow(d);
      row.alignment = { horizontal: "center", wrapText: true };
      const qty = row.getCell(4);
    });

    worksheet.getColumn(1).width = 30;
    worksheet.getColumn(2).width = 30;
    worksheet.getColumn(3).width = 30;
    worksheet.getColumn(4).width = 30;
    worksheet.getColumn(5).width = 30;
    worksheet.getColumn(6).width = 30;
    worksheet.getColumn(7).width = 30;
    worksheet.getColumn(8).width = 30;

    worksheet.addRow([]);

    worksheetOne.getColumn(3).width = 13;
    worksheetOne.getColumn(4).width = 13;

    // Add the Header Image
    worksheetOne.mergeCells("D1:H6");
    // Add Image
    const logoOne = workbook.addImage({
      base64: logoFile.logoBase64,
      extension: "png",
    });

    worksheetOne.addImage(logoOne, "D1:H6");
    worksheetOne.addRow([]);
    worksheetOne.getCell("C7").value =
      "Brookfield Property Retail Property Upload Spreadsheet";
    worksheetOne.getCell("C7").font = {
      name: "Calibri",
      family: 4,
      size: 16,
      underline: true,
      bold: true,
    };

    worksheetOne.addRow([]);
    worksheetOne.addRow([]);

    worksheetOne.getCell("B10").value =
      "Please list the Brookfield Property Retail Properties, these Properties are customized to represent that company’s organizational structure and related positions of oversight.";
    worksheetOne.getCell("B10").alignment = {
      vertical: "top",
      horizontal: "left",
      wrapText: true,
    };

    worksheetOne.mergeCells("B10", "K13");

    worksheetOne.getCell("B10").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "C9DEC9" },
      bgColor: { argb: "FF0000FF" },
    };

    worksheetOne.getCell("B15").value =
      "Set of Instructions for the Spreadsheet:";
    worksheetOne.getCell("B15").font = {
      name: "Calibri",
      family: 4,
      size: 12,
      bold: true,
    };
    worksheetOne.addRow([]);
    worksheetOne.getCell("B17").value = "GENERAL INFO:";
    worksheetOne.getCell("B23").alignment = { horizontal: "center" };
    worksheetOne.getCell("B17").font = {
      name: "Calibri",
      family: 4,
      size: 12,
      bold: true,
    };
    worksheetOne.getCell("B18").value = "-";
    worksheetOne.getCell("B18").alignment = { horizontal: "right" };
    worksheetOne.getCell("C18").value =
      "Please fill in the required fields to upload data into maxIMuS.";
    worksheetOne.addRow([]);
    worksheetOne.getCell("B20").value = "-";
    worksheetOne.getCell("B20").alignment = { horizontal: "right" };
    worksheetOne.getCell("C20").value =
      "Dropdown values will appear in each cell if there is a selection to be made,";
    worksheetOne.getCell("C21").value = " otherwise enter appropriate data.";
    worksheetOne.addRow([]);
    worksheetOne.getCell("B23").value = "-";
    worksheetOne.getCell("B23").alignment = { horizontal: "right" };
    worksheetOne.getCell("C23").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "C9DEC9" },
      bgColor: { argb: "FF0000FF" },
    };
    worksheetOne.getCell("C23").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheetOne.getCell("D23").value =
      "Headers in Light Green are Mandatory or Required fields.";
    worksheetOne.getCell("B24").value = "-";
    worksheetOne.getCell("B24").alignment = { horizontal: "right" };
    worksheetOne.getCell("C24").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "" },
      bgColor: { argb: "" },
    };
    worksheetOne.getCell("C24").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheetOne.getCell("D24").value =
      "Headers in White are not Required entry fields.";
    worksheetOne.addRow([]);
    worksheetOne.getCell("B26").value = "-";
    worksheetOne.getCell("B26").alignment = { horizontal: "right" };
    worksheetOne.getCell("C26").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "" },
      bgColor: { argb: "" },
    };
    worksheetOne.getCell("C26").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheetOne.getCell("D26").value =
      "Header cells that include a red triangle at top right provide";
    worksheetOne.getCell("D27").value =
      "information about the field when you mouse over the cell.";

    worksheetOne.addRow([]);

    //Worksheet for System Pick Values
    worksheetTwo.getCell("C2").value = "Active";
    worksheetTwo.getCell("C3").value = "InActive";

    // Generate Excel File with given name
    workbook.xlsx.writeBuffer().then((data: any) => {
      const blob = new Blob([data], {
        type:
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });
      fs.saveAs(blob, "AssetManagement.xlsx");
    });
  }
}
