import { Component, OnInit, Inject, Optional } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { AssetmanagementService } from "../assetmanagement.service";
import {
  FormBuilder,
  FormGroup,
  FormControl,
  Validators,
} from "@angular/forms";
import Swal from "sweetalert2";
import { environment } from "../../../../../environments/environment";

@Component({
  selector: "app-uplaodicon",
  templateUrl: "./uplaodicon.component.html",
  styleUrls: ["./uplaodicon.component.scss"],
})
export class UplaodiconComponent implements OnInit {
  item: any;
  action: any;
  private file2: File = null;
  iconPath: any;
  uploadedImageList = [];
  constructor(
    private AssetService: AssetmanagementService,
    public dialogRef: MatDialogRef<UplaodiconComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.iconPath = `${environment.imagePath}`;
  }
  optionsList = [
    { name: "Fully Functional", id: 1 },
    { name: "Functional Not Optimal", id: 2 },
    { name: "Not Functional", id: 3 },
  ];
  uploadForm = new FormGroup({
    CustomFormId: new FormControl(""),
    IconName: new FormControl(""),
    iconimage: new FormControl("", [Validators.required]),
    oldicon: new FormControl(""),
    CustomFormStatusId: new FormControl(""),
    CustomFormStatusIdOnly: new FormControl("", [Validators.required]),
    Isdefault: new FormControl(""),
  });
  submitted = false;
  get uploadFormF() {
    return this.uploadForm.controls;
  }

  ngOnInit() {
    this.item = this.data.item;
    this.action = this.data.action;

    /**
     * for setting value of status
     */
    let itemsOpt: any = this.optionsList.find(
      (accu) => accu.id == this.item.CustomFormStatusID
    );

    if (itemsOpt) {
      this.uploadForm.patchValue({
        CustomFormStatusId: itemsOpt.id,
        CustomFormStatusIdOnly: itemsOpt.name,
        Isdefault: this.item.Isdefault,
      });
    }
    /**
     * end
     */

    console.log("hello ----> ", this.item);

    this.uploadForm.patchValue({ CustomFormId: this.item.CustomFormID });
    this.uploadForm.patchValue({ oldicon: this.item.IconName });
    /**
     * gettting iconList
     */

    this.getIconList(this.item.CustomFormID);
  }

  openFile(event) {
    var input = event.target;
    if (
      input.files[0].type == "image/jpeg" ||
      input.files[0].type == "image/jpg" ||
      input.files[0].type == "image/png"
    ) {
      this.file2 = event && event.target.files.item(0);

      var reader = new FileReader();
      reader.onload = function () {
        var dataURL = reader.result;
      };
      reader.readAsDataURL(input.files[0]);
    } else {
      Swal.fire({
        text: "Plese select jpg or png image only",
      });
      event.target.value = "";
    }
  }

  uploadIcon() {
    console.log(this.uploadForm.invalid);

    this.submitted = true;
    if (this.uploadForm.invalid) {
      return;
    }
    this.uploadForm.value.Isdefault = 0; //this.uploadForm.value.Isdefault ? 1 : 0;

    console.log(this.uploadForm.value);
    let formData = this.uploadForm.value;
    delete formData.CustomFormStatusIdOnly;
    let payload = new FormData();
    if (this.file2 != null) {
      payload.append("IconName", this.file2, this.file2.name);
    }
    Object.keys(formData).forEach((key: string) => {
      payload.append(key, formData[key]);
    });

    // console.log(formData); // return false;
    this.AssetService.uploadIcon(payload).subscribe((resp) => {
      // console.log(resp);
      this.closeDialog();
    });
  }

  closeDialog() {
    this.dialogRef.close(1);
  }

  setIds(option) {
    this.uploadForm.patchValue({
      CustomFormStatusId: option.id,
    });
  }

  getIconList(customFormId: string | number) {
    this.AssetService.GetAssetIconList({
      CustomFormId: customFormId,
    }).subscribe((elem: any) => {
      console.log("uploaded image lis", elem);
      this.uploadedImageList = elem.data.GetAssetsIconList;
    });
  }

  setAsDefault(obj) {
    // if (obj.Isdefault) {
    //   return;
    // }

    this.AssetService.ChangeAssetsIsDefault({
      CustomFormIconid: +obj.CustomFormIconID,
      CustomFormId: obj.CustomFormID,
      Isdefault: 1,
    }).subscribe((elem) => {
      /**
       * call at the end of change status
       *
       */
      let itemsOpt: any = this.optionsList.find(
        (accu) => accu.id == obj.CustomFormStatusID
      );

      if (itemsOpt) {
        this.uploadForm.patchValue({
          CustomFormStatusId: itemsOpt.id,
          CustomFormStatusIdOnly: itemsOpt.name,
          Isdefault: obj.Isdefault,
        });
      }

      this.getIconList(obj.CustomFormID);
    });
  }

  deleteIconFromList(obj) {
    this.AssetService.DeleteAssetIcon({
      CustomFormIconid: obj.CustomFormIconID,
      CustomFormId: obj.CustomFormID,
      toBeDeletedFileName: obj.ImageName,
    }).subscribe((elem) => {
      /**
       * call every status Changed
       */

      this.getIconList(obj.CustomFormID);
    });
  }
}
