import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UplaodiconComponent } from './uplaodicon.component';

describe('UplaodiconComponent', () => {
  let component: UplaodiconComponent;
  let fixture: ComponentFixture<UplaodiconComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UplaodiconComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UplaodiconComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
