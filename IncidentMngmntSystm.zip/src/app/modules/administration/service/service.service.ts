import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  deleteMsg:string = "Are you sure you want to delete this record?";
  statusMsg:string = "The Record has been saved successfully.";
  constructor() { }
}
