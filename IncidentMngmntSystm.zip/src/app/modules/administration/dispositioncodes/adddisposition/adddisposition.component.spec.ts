import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdddispositionComponent } from './adddisposition.component';

describe('AdddispositionComponent', () => {
  let component: AdddispositionComponent;
  let fixture: ComponentFixture<AdddispositionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdddispositionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdddispositionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
