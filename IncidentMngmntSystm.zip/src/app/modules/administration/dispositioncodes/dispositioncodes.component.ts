import { AfterViewInit, Component, OnInit, ViewChild } from "@angular/core";
import { MatSort } from "@angular/material/sort";
import { FormControl } from "@angular/forms";
import { Router } from "@angular/router";
import { MatTableDataSource } from "@angular/material/table";
import { DispositionService } from "./disposition.service";
import { StorageService } from "../../../services/storage.service";
import * as XLSX from "xlsx";
import Swal from "sweetalert2";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-dispositioncodes",
  templateUrl: "./dispositioncodes.component.html",
  styleUrls: ["./dispositioncodes.component.scss"],
})
export class DispositioncodesComponent implements OnInit, AfterViewInit {
  displayedColumns: string[] = [
    "DispositionCode",
    "DispositionDescription",
    "AssignedDate",
    "AssignedBy",
    "IsActive",
  ];
  displayedColumnsOne: string[] = [
    "GOETitle",
    "DispositionCode",
    "DespositonDescription",
    "DispositionStatus",
    "Status",
    "Message",
  ];
  dataSource = new MatTableDataSource();
  dataSourceOne = new MatTableDataSource();

  //Local Variables
  dispositionList: string[] = [];
  uploadedList: any = [];
  searchControl: any = new FormControl();
  searchText: any;
  uploadfileList: any = false;
  GlobalEnvironmentID = 0;
  GlobalEnvironmentDetails = null;
  GlobalEnvironmentName = "";
  GOENumber = "";
  selectedItem: any = false;

  /** Upload Excel start  */

  title = "read-excel-in-angular8";
  storeData: any;
  jsonData: any;
  fileUploaded: File;
  worksheet: any;
  htmlData: any;
  currentUserID: any;
  userData = null;

  @ViewChild(MatSort, { static: false }) sort: MatSort;

  constructor(
    private service: DispositionService,
    private storage: StorageService,
    private tostre: ToastrService,
    public router: Router
  ) {
    this.userData = JSON.parse(this.storage.getData("UserData"));
    this.currentUserID = this.userData[0].UserID;
    this.GlobalEnvironmentDetails = JSON.parse(
      this.storage.getData("GlobalEnvironmentDetails")
    );
    if (this.GlobalEnvironmentDetails) {
      //this.groupData = this.organise(this.exportreport);
      this.GlobalEnvironmentID = this.GlobalEnvironmentDetails.GlobalEnvironmentId;
      this.GlobalEnvironmentName = this.GlobalEnvironmentDetails.GlobalEnvironmentName;
      this.GOENumber = this.GlobalEnvironmentDetails.GOENo;
    }
  }

  ngOnInit() {
    console.log("striker");
    if (this.checkGoe()) {
      this.getDispositionCode();
    }
    this.service.currentMessage.subscribe((data) => {
      this.selectedItem = data;
    });
  }

  ngAfterViewInit() {
    //this.dataSource.sort = this.sort;
  }

  getDispositionCode() {
    this.service
      .GetDispositionCode(this.GlobalEnvironmentID)
      .subscribe((data) => {
        this.dispositionList = data.data.getDispositionCode;
        this.dataSource = new MatTableDataSource(data.data.getDispositionCode);
        this.dataSource.sort = this.sort;
        this.sort.disableClear = true;
        console.log("Disposition list", this.dispositionList, this.dataSource);
      });
  }

  clearSearchField() {
    this.searchControl.patchValue("");
    this.getDispositionCode();
  }

  closePage() {
    // window.location.reload();
    this.uploadfileList = false;
  }

  //Upload excel sheet
  openFileBrowser(event: any) {
    event.preventDefault();
    let element: HTMLElement = document.getElementById("file") as HTMLElement;
    element.click();
  }

  uploadedFile(event) {
    this.fileUploaded = event.target.files[0];
    this.readExcel();
  }

  readExcel() {
    let readFile = new FileReader();

    readFile.onload = (e) => {
      this.storeData = readFile.result;

      var data = new Uint8Array(this.storeData);

      var arr = new Array();

      for (var i = 0; i != data.length; ++i)
        arr[i] = String.fromCharCode(data[i]);

      var bstr = arr.join("");

      var workbook = XLSX.read(bstr, { type: "binary" });

      var first_sheet_name = workbook.SheetNames[1];

      this.worksheet = workbook.Sheets[first_sheet_name];

      var range = XLSX.utils.decode_range(this.worksheet["!ref"]);
      range.s.r = 2; // <-- zero-indexed, so setting to 1 will skip row 0
      this.worksheet["!ref"] = XLSX.utils.encode_range(range);

      this.readAsJson(+this.currentUserID);
    };

    readFile.readAsArrayBuffer(this.fileUploaded);
  }

  // Upload Excel End

  /** Read As Json */

  readAsJson(currentUserID) {
    this.jsonData = XLSX.utils.sheet_to_json(this.worksheet, { raw: false });
    //this.jsonData = JSON.stringify(this.jsonData);

    var arrofobj = this.jsonData;
    // this.patrolZoneImportList = this.jsonData

    var result = arrofobj.map(function (el) {
      var o = Object.assign({}, el);
      o.UserID = +currentUserID;
      // o.Status = "";
      o.Message = "";
      o.RecNo = "";
      return o;
    });
    let length = Object.keys(result).length;

    this.shiftImport(result);
    // this.getPropertyPatrolZoneList(this.PropertyID, 0);
  }
  newObjArr = [];
  shiftImport(obj) {
    console.log("obj====final hit to service --->>>>", obj);
    console.log("obj is here", obj);
    let matchProfile =
      Object.keys(obj[0]).includes("Disposition Code") &&
      Object.keys(obj[0]).includes("GOE Title");
    console.log("test", matchProfile);

    if (matchProfile) {
      this.uploadfileList = true;
      // this.onscreenList = false;
      if (obj.length == 0) {
        Swal.fire({
          text: "No Data Found ",
        });
        return;
      }

      for (var i = 0; i < obj.length; i++) {
        let newObj = {
          RecNo: obj[i].RecNo,
          GOETitle: obj[i]["GOE Title"],
          DispositionCode: obj[i]["Disposition Code"],
          DespositonDescription: obj[i]["Dispositon Description"],
          DispositionStatus: obj[i]["Status"],
          UserID: +obj[i].UserID,
          // Status: obj[i]["Status"],
          Message: "",
        };
        console.log(obj[i]);
        console.log("what a game", newObj);
        this.newObjArr.push(newObj);
      }
      let passingArray = this.newObjArr;
      console.log("passing array", passingArray);
      let result: any;
      this.service.dispositionCodeImport(passingArray).subscribe(
        (res) => {
          result = res;
          if (res) {
            console.log("Uploaded list", result.data.DispositionCodeImport);
            this.dataSourceOne = new MatTableDataSource(
              result.data.DispositionCodeImport
            );
            this.dataSourceOne.sort = this.sort;
            this.sort.disableClear = true;
            this.uploadedList = result.data.DispositionCodeImport;

            this.tostre.success(
              "Processed successfully. Please check the table."
            );
          }
        },
        (error) => {
          if (error.status == 500) {
            Swal.fire({
              text: "Import Failed",
            });
          }
        }
      );
    } else {
      this.tostre.warning(
        "Uploaded Excel Sheet is Invalid. Please put the right one."
      );
    }
  }

  //Download Excel Sheet

  exportImportData(): void {
    let data = JSON.parse(JSON.stringify(this.dispositionList));
    let tempData = [];
    console.log("downloaded data", data);
    data.forEach(function (item, i) {
      delete item.RecNo;
      delete item.AssignedBy;
      delete item.AssignedDate;
      delete item.ComDisposition;
      delete item.CreatedBy;
      delete item.DispositionID;
      delete item.GlobalEnvironmentID;
      delete item.IsLock;
      tempData.push(item);
    });
    tempData.forEach((data) => {
      data.IsActive = data.IsActive ? "Active" : "Inactive";
    });
    console.log("what data is going for download", tempData);
    this.service.exportAsExcelFile(tempData);
  }

  exportData(): void {
    let data = JSON.parse(JSON.stringify(this.uploadedList));
    let tempData = [];
    console.log("downloaded dataF", data);
    data.forEach(function (item, i) {
      delete item.RecNo;
      delete item.UserID;
      delete item.Message;
      tempData.push(item);
    });
    // tempData.forEach(data => {
    //   data.IsActive = data.IsActive ? "Active" : "Inactive"
    // })
    // console.log("what data is going for download", tempData);
    this.service.exportExcelFile(tempData);
  }

  onDispositionItemClick(data: any) {
    if (this.selectedItem == data.DispositionID) {
      this.selectedItem = !this.selectedItem;
      this.service.changeMessage(this.selectedItem);
    } else {
      this.selectedItem = data.DispositionID;
      this.service.changeMessage(this.selectedItem);
    }
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    console.log("Filtersss", this.dataSource);
  }

  /**
   * Check Goe
   */

  checkGoe() {
    if (this.GlobalEnvironmentID) {
      return true;
    } else {
      this.showInvalid("Please first select a Global Operations Environment.");
      this.router.navigate(["products/administration/goe/mygoe"]);
      return false;
    }
  }

  // toastr warning/success message
  showInvalid(msg) {
    this.tostre.error(msg, "", {
      positionClass: "toast-top-right",
    });
  }

  showValid(validMsg) {
    this.tostre.success(validMsg, "", {
      positionClass: "toast-top-right",
    });
  }
}
