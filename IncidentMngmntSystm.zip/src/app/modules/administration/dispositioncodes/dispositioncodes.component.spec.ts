import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DispositioncodesComponent } from './dispositioncodes.component';

describe('DispositioncodesComponent', () => {
  let component: DispositioncodesComponent;
  let fixture: ComponentFixture<DispositioncodesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DispositioncodesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DispositioncodesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
