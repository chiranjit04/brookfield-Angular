import {
  Component,
  OnInit,
  Input,
  ViewChild,
  AfterViewInit,
} from "@angular/core";
import {
  FormGroup,
  FormControl,
  Validators,
  FormBuilder,
} from "@angular/forms";
import { GlobalService } from "../../administration/reportingsets/reportingsets.service";
import { Router } from "@angular/router";
import { myEnvironmentService } from "./myenvironment.service";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { GoeDetailService } from "./goe-detail/goe-detail.service";
import Swal from "sweetalert2";
import { UserPermissionService } from "../../../services/user-permission.service";
import { ToastrService } from "ngx-toastr";
import * as XLSX from "xlsx";
import { StorageService } from "../../../services/storage.service";
import { ServiceService } from "./../service/service.service";
import { IpaddressComponent } from "./goe-detail/ipaddress/ipaddress.component";
import { MatDialog } from "@angular/material";
import { environment } from "src/environments/environment";

@Component({
  selector: "app-myenvironment",
  templateUrl: "./myenvironment.component.html",
  styleUrls: ["./myenvironment.component.scss"],
})
export class MyenvironmentComponent implements OnInit {
  dataSourceOne: MatTableDataSource<any>;

  displayedColumnsOne: string[] = [
    "GOENo",
    "EnvironmentName",
    "EnvironmentDescription",
    "CreatedDateTime",
    "CreatedBy",
    "UpdatedDate",
    "IsRestrictedUse",
    "GeoRoleName",
    "Status",
  ];

  @ViewChild("TableOneSort", { static: false }) tableOneSort: MatSort;

  dataSourceTwo: MatTableDataSource<any>;
  displayedColumnsTwo: string[] = [
    "PropertyName",
    "PropertyNumber",
    "CompanyName",
    "Companydivision",
    "GOETitle",
    "GoeIDNo",
    "GoeAssignedDateTime",
    "IsActive",
  ];

  dataSourceThree: MatTableDataSource<any>;
  displayedColumnsThree: string[] = [
    "TitleOfGlobalOperations",
    "Description",
    "Restricted",
    "Assigned",
    "GOEStatus",
    "Status",
    "Message",
  ];

  @ViewChild("TableTwoSort", { static: false }) tableTwoSort: MatSort;

  GlobalEnvironmentID = 0;
  GlobalEnvironmentName = "";
  GOENumber = "";
  GlobalEnvironmentDetails = null;
  userData = null;
  authToken = null;
  UserID: any = false;
  restrictedUserLength: any;
  responseData: any = [];

  showgoe = true;
  showThree: any = false;
  myGOEForm: FormGroup;

  //For GOE Table
  goeTableResult: any[];
  // For Goe Table
  isShowdetail = true;

  GoeList: any = [];
  GoeListbyProperty = [];
  detail: any;
  duplicateList: any;

  userGoeProfile = "";
  selectedPropertyId: any = false;

  highlighteds: any;
  highlightedRows: any;

  formValues = [];
  updateInFields = {};
  activeIcon = "../../../../assets/images/icons/global-ops-green.png";
  inActiveIcon = "../../../../assets/images/icons/global-ops-grey.png";
  selectedRow: false;
  selectedGroupId = false;
  setbyevn = true;

  GOEImportList: any = [];
  currentUserID = false;

  form = new FormGroup({
    EnvironmentName: new FormControl("", Validators.required),
    EnvironmentDescription: new FormControl("", Validators.required),
    GlobalEnvironmentID: new FormControl(),
    Status: new FormControl(),
  });

  UserPermissionData: any = [];
  /*Add IP*/
  allowWhiteListButton = environment.AllowWhiteListButton;
  allowUsersID = environment.AllowUsersID;
  allowAddIPButton: boolean = false;
  userId: string;
  /**/
  constructor(
    private GlobalService: GlobalService,
    private myEnvironmentService: myEnvironmentService,
    public router: Router,
    private GoeDetailService: GoeDetailService,
    private formBuilder: FormBuilder,
    public UserPermission: UserPermissionService,
    private toaster: ToastrService,
    private storage: StorageService,
    private adminService: ServiceService,
    public dialog: MatDialog
  ) {
    //... Read User Data ...
    this.authToken = this.storage.getData("token");
    if (this.authToken == null) {
      this.router.navigate(["/login"]);
    }
    this.userData = JSON.parse(this.storage.getData("UserData"));
    this.UserID = this.userData[0].UserID;

    let permissionData = JSON.parse(this.storage.getData("ModulePermission"));
    let checkAdmin = this.hasPermission(
      permissionData,
      "access_administration"
    );
    if (!checkAdmin) {
      this.router.navigate(["/products/list"]);
      this.toaster.warning(
        "You don't have permission to access this module.",
        "",
        {
          positionClass: "toast-top-right",
        }
      );
    }

    this.UserPermissionData = JSON.parse(
      this.storage.getData("UserPermissionData")
    );

    this.GlobalEnvironmentDetails = JSON.parse(
      this.storage.getData("GlobalEnvironmentDetails")
    );
    if (this.GlobalEnvironmentDetails) {
      this.GlobalEnvironmentID = this.GlobalEnvironmentDetails.GlobalEnvironmentId;
      this.GlobalEnvironmentName = this.GlobalEnvironmentDetails.GlobalEnvironmentName;
      this.GOENumber = this.GlobalEnvironmentDetails.GOENo;
    }

    //... Read User Data ...
    this.authToken = this.storage.getData("token");
    this.userData = JSON.parse(this.storage.getData("UserData"));
    this.currentUserID = this.userData[0].UserID;

    this.dataSourceOne = new MatTableDataSource();
    this.dataSourceTwo = new MatTableDataSource();
    this.dataSourceThree = new MatTableDataSource();

    this.myGOEForm = this.formBuilder.group({
      _ByGOESearch: new FormControl(""),
      _ByPropertySearch: new FormControl(""),
    });
  }

  ngOnInit() {
    this.userId = this.storage.getUserID();
    if (this.allowWhiteListButton) {
      if (this.allowUsersID.length > 0) {
        this.allowUsersID.forEach((element) => {
          if (this.userId == element) {
            this.allowAddIPButton = true;
          }
        });
      }
    }
    this.getGoeList();
    this.GetGoeListbyProperty();
  }

  hasPermission(permissions: any, moduleName: string) {
    if (!permissions) {
      return false;
    } else {
      let access_administration = permissions.find(
        (x) => x.ResourceKey == moduleName
      );
      let administration_index = permissions.indexOf(access_administration);
      if (administration_index == -1) {
        return false;
      }
    }
    return true;
  }

  tabClick(tab) {
    if (tab.index == 1) {
      this.showgoe = false;
    } else {
      this.showgoe = true;
    }
  }

  getGoeList() {
    const param = {
      UserId: this.userData[0].UserID,
    };
    this.myEnvironmentService.getGoeList(param).subscribe((response) => {
      this.GoeList = response.goeList;

      // this.GoeList = [this.GoeList[0]];
      this.dataSourceOne.data = this.GoeList;
      this.dataSourceOne.sort = this.tableOneSort;
      this.tableOneSort.disableClear = true;
      this.goeDefaultSelected(this.GoeList);
      if (this.GoeList.length == 1) {
        this.setbyevn = false;
        this.isShowdetail = !this.isShowdetail;
        const GlobalEnvironmentDetails = {
          GlobalEnvironmentName: this.GoeList[0].EnvironmentName,
          GlobalEnvironmentId: this.GoeList[0].GlobalEnvironmentID,
          GOENo: this.GoeList[0].GOENo,
        };
        this.storage.removeData("GlobalEnvironmentDetails");
        this.storage.setData(
          "GlobalEnvironmentDetails",
          JSON.stringify(GlobalEnvironmentDetails)
        );
      } else {
        this.setbyevn = true;

        this.GlobalEnvironmentDetails = JSON.parse(
          this.storage.getData("GlobalEnvironmentDetails")
        );
        if (this.GlobalEnvironmentDetails) {
          this.GlobalEnvironmentID = this.GlobalEnvironmentDetails.GlobalEnvironmentId;
          this.GlobalEnvironmentName = this.GlobalEnvironmentDetails.GlobalEnvironmentName;
          this.GOENumber = this.GlobalEnvironmentDetails.GOENo;
        } else {
          let goe_id = this.userData[0].GlobalEnvironmentID;
          let obj = this.GoeList.find((x) => x.GlobalEnvironmentID == goe_id);
          let index = this.GoeList.indexOf(obj);
          if (index != -1) {
            const GlobalEnvironmentDetails = {
              GlobalEnvironmentName: obj.EnvironmentName,
              GlobalEnvironmentId: obj.GlobalEnvironmentID,
              GOENo: obj.GOENo,
            };
            this.storage.setData(
              "GlobalEnvironmentDetails",
              JSON.stringify(GlobalEnvironmentDetails)
            );
            this.GlobalEnvironmentID = obj.GlobalEnvironmentID;
          }
        }
      }
    });
  }

  GetGoeListbyProperty() {
    const param = {
      UserId: this.userData[0].UserID,
      PropertyId: 0, //this.userData[0].PropertyID
    };
    this.myEnvironmentService.goeListbyProperty(param).subscribe((response) => {
      // this.GoeListbyProperty = [response.goeListbyProperty[0]];
      this.GoeListbyProperty = response.goeListbyProperty;
      this.dataSourceTwo.data = this.GoeListbyProperty;
      this.dataSourceTwo.sort = this.tableTwoSort;
      this.tableOneSort.disableClear = true;
    });
  }

  createnewGoe() {
    this.isShowdetail = !this.isShowdetail;
    this.router.navigate(["products/administration/goe/mygoe/create"]);
  }

  highlited(
    i: any,
    GlobalEnvironmentID: any,
    GOENo: any,
    EnvironmentName: any
  ) {
    // this.highlightedRows = i;
    if (this.highlightedRows == GlobalEnvironmentID) {
      this.highlightedRows = this.GlobalEnvironmentID = null;
      this.storage.removeData("GlobalEnvironmentDetails");
    } else {
      this.highlightedRows = GlobalEnvironmentID;
      this.GlobalEnvironmentID = GlobalEnvironmentID;
      const GlobalEnvironmentDetails = {
        GlobalEnvironmentName: EnvironmentName,
        GlobalEnvironmentId: GlobalEnvironmentID,
        CreatedUserID: i.CreatedUserID,
        GOENo: GOENo,
      };
      this.storage.setData(
        "GlobalEnvironmentDetails",
        JSON.stringify(GlobalEnvironmentDetails)
      );
    }
  }

  changeStatus(event: any, data: any) {
    event.preventDefault();
    event.stopPropagation();

    if (data.IsAssigned && data.IsActive) {
      // Swal.fire({ text: "An assigned GOE can not be deactivate!" });
      this.toaster.warning("An assigned GOE can not be deactivate.");
      return false;
    }
    let GoeID = data.GlobalEnvironmentID;
    this.myEnvironmentService
      .changeGlobalEnvironmentStatus(GoeID)
      .subscribe((d) => {
        let obj = this.GoeList.find((o) => o.GlobalEnvironmentID == GoeID);
        let index = this.GoeList.indexOf(obj);
        this.GoeList.fill((obj.IsActive = !obj.IsActive), index, index++);
        this.toaster.success(this.adminService.statusMsg);
      });
  }

  changeAssigned(event: any, data: any) {
    event.preventDefault();
    event.stopPropagation();
  }

  removeGoe(event: any, data: any) {
    event.preventDefault();
    event.stopPropagation();

    if (data.IsAssigned) {
      // Swal.fire({ text: "An assigned GOE can not be deleted!" });
      this.toaster.warning("An assigned GOE can not be deleted.");
      return false;
    }

    Swal.fire({
      // text: "Are you sure you want to remove this?",
      text: this.adminService.deleteMsg,
      showCancelButton: true,
      confirmButtonText: "Yes",
      cancelButtonText: "No",
    }).then((result) => {
      if (result.value) {
        let GoeID = data.GlobalEnvironmentID;
        this.myEnvironmentService
          .deleteGlobalEnvironment(GoeID)
          .subscribe((d) => {
            this.getGoeList();
          });
      }
    });
  }
  selectedPropertyIds: any = false;
  propertySelected(row: any, i) {
    if (i == this.selectedPropertyIds) {
      this.selectedPropertyIds = null;
    } else {
      this.selectedPropertyIds = i;
    }
    // if (row.PropertyID == this.selectedPropertyId) {
    //   this.selectedPropertyId = !this.selectedPropertyId;
    // } else {
    //   this.selectedPropertyId = row.PropertyID;
    // }
    const GlobalEnvironmentDetails = {
      GlobalEnvironmentName: row.GOETitle,
      GlobalEnvironmentId: row.GlobalEnvironmentID,
      GOENo: row.GOENo,
    };
    this.storage.setData(
      "GlobalEnvironmentDetails",
      JSON.stringify(GlobalEnvironmentDetails)
    );
    this.GlobalEnvironmentID = row.GlobalEnvironmentID;
  }

  UserGoeProfiledetail(event: any, data: any) {
    let GlobalEnvironmentID = data.GlobalEnvironmentID;
    event.preventDefault();
    event.stopPropagation();
    this.GoeDetailService.currentPopups = null;
    this.router.navigate([
      "products/administration/goe/mygoe/detail/" + btoa(GlobalEnvironmentID),
    ]);
  }

  globalSubmit() {
    const formValue = this.form.value;
    const otherParams = {
      EnvironmentName: formValue.EnvironmentName,
      EnvironmentDescription: formValue.EnvironmentDescription,
      GlobalEnvironmentID: formValue.GlobalEnvironmentID || "",
      Status: formValue.Status || true,
      UserId: "1",
    };

    this.GlobalService.postOperations(otherParams).subscribe((data) => {
      this.getGlobalEnvironments();
      this.form.reset();
    });
  }

  onClick(event: HTMLTableRowElement, value) {
    this.selectedGroupId = value.GlobalEnvironmentID;

    if (value.Status) {
      this.form.patchValue({
        EnvironmentName: value.EnvironmentName,
        EnvironmentDescription: value.EnvironmentDescription,
        GlobalEnvironmentID: value.GlobalEnvironmentID,
        Status: value.Status,
      });
    } else {
      this.form.reset();
    }

    const GlobalEnvironmentDetails = {
      GlobalEnvironmentName: "GlobalEnvironmentName",
      GlobalEnvironmentId: "1",
    };
    this.storage.removeData("GlobalEnvironmentDetails");
    this.storage.setData(
      "GlobalEnvironmentDetails",
      JSON.stringify(GlobalEnvironmentDetails)
    );
  }

  getGlobalEnvironments() {
    this.GlobalService.getOperations().subscribe((d) => {
      this.formValues = d.GetGlobalEnvironmentList;
    });
  }

  showProprtyDetail(data: any) {
    this.router.navigate([
      "products/administration/goe/mygoe/detail/" +
        btoa(data.GlobalEnvironmentID),
    ]);
  }

  applyFilter(event: Event) {
    let filterValue = (event.target as HTMLInputElement).value;
    this.dataSourceOne.filter = filterValue.trim().toLowerCase();
  }
  applyFilterProperty(event: Event) {
    let filterValue = (event.target as HTMLInputElement).value;
    this.dataSourceTwo.filter = filterValue.trim().toLowerCase();
  }

  onSelectActive(event, PropertyID: any) {
    event.stopPropagation();
    this.myEnvironmentService.onSelectActive(PropertyID).subscribe((d) => {
      this.GetGoeListbyProperty();
    });
  }

  ClearListByGOE() {
    this.myGOEForm.patchValue({ _ByGOESearch: "" });
    this.dataSourceOne.filter = "";
  }
  ClearListByProperty() {
    this.myGOEForm.patchValue({ _ByPropertySearch: "" });
    this.dataSourceTwo.filter = "";
  }

  //Download here
  downloadLocation() {
    let data = [];

    this.GoeList.forEach(function (item, i) {
      let x = {
        EnvironmentName: item.TitleOfGlobalOperations || item.EnvironmentName,
        EnvironmentDescription: item.Description || item.EnvironmentDescription,
        IsActive: item.GOEStatus || (item.IsActive ? "Active" : "Inactive"),
        IsAssigned:
          item.Assigned || (item.IsAssigned ? "Assigned" : "Unassigned"),
        IsRestrictedUse: item.Restricted || item.IsRestrictedUse,
      };

      // delete item["CreatedUserID"];
      // delete item["GlobalEnvironmentID"];
      // delete item["CreatedBy"];
      // delete item["CreatedDateTime"];
      // delete item["GOENo"];
      // delete item["GeoRoleName"];
      // delete item["UpdatedDateTime"];
      // delete item["UpdatedBy"];
      data.push(x);
    });

    // data.forEach((data) => {
    //   data.IsActive = data.IsActive ? "Active" : "Inactive";
    //   data.IsAssigned = data.IsAssigned ? "Assigned" : "Unassigned";
    // });
    this.myEnvironmentService.exportAsExcelFile(data);
  }

  //upload here

  title = "read-excel-in-angular8";
  storeData: any;
  jsonData: any;
  fileUploaded: File;
  worksheet: any;
  htmlData: any;

  uploadedFile(event) {
    this.fileUploaded = event.target.files[0];

    if (!this.validateFile(this.fileUploaded.name)) {
      //  window.location.reload();
      this.toaster.warning("Selected file format is not supported.");
      return false;
    }
    this.readExcel();
  }

  validateFile(name: any) {
    var ext = name.substring(name.lastIndexOf(".") + 1);

    if (ext.toLowerCase() == "xlsx") {
      return true;
    } else {
      return false;
    }
  }

  readExcel() {
    let readFile = new FileReader();

    readFile.onload = (e) => {
      this.storeData = readFile.result;

      var data = new Uint8Array(this.storeData);

      var arr = new Array();

      for (var i = 0; i != data.length; ++i)
        arr[i] = String.fromCharCode(data[i]);

      var bstr = arr.join("");

      var workbook = XLSX.read(bstr, { type: "binary" });

      var first_sheet_name = workbook.SheetNames[1];

      this.worksheet = workbook.Sheets[first_sheet_name];

      var range = XLSX.utils.decode_range(this.worksheet["!ref"]);
      range.s.r = 2; // <-- zero-indexed, so setting to 1 will skip row 0
      this.worksheet["!ref"] = XLSX.utils.encode_range(range);

      this.readAsJson(this.currentUserID);
    };

    readFile.readAsArrayBuffer(this.fileUploaded);
  }

  // Upload Excel End

  /** Read As Json */

  readAsJson(currentUserID) {
    this.jsonData = XLSX.utils.sheet_to_json(this.worksheet, { raw: false });

    //this.jsonData = JSON.stringify(this.jsonData);

    var arrofobj = (this.GOEImportList = this.jsonData);

    var result = arrofobj.map(function (el) {
      var o = Object.assign({}, el);
      o.UserID = currentUserID;
      o.Message = "";
      o.RecNo = "";
      return o;
    });
    let length = Object.keys(result).length;
    // this.dataSourceTwo = result;
    this.GOEImport(result);
  }

  /**
   * Import Location List
   *
   */

  newObjArr = [];

  GOEImport(obj) {
    let matchLocation =
      Object.keys(obj[0]).includes("GOE TITLE") &&
      Object.keys(obj[0]).includes("DESCRIPTION PURPOSE");
    if (matchLocation) {
      this.showThree = true;
      for (var i = 0; i < obj.length; i++) {
        let newObj = {
          // RecNo: obj[i]["RecNo"],
          TitleOfGlobalOperations: obj[i]["GOE TITLE"],
          Description: obj[i]["DESCRIPTION PURPOSE"],
          // GOEID: obj[i]["SubCategory Name"],
          Assigned:
            obj[i]["IS ASSIGNED"] == "Assigned" ? "Assigned" : "Unassigned",
          Restricted: obj[i]["USE RESTRICTED"],
          GOEStatus: obj[i]["STATUS"] == "Active" ? "Active" : "Inactive",
          UserID: +obj[i]["UserID"],
          Status: "",
          Message: "",
        };
        this.newObjArr.push(newObj);
      }

      let passingArray = this.newObjArr;

      this.myEnvironmentService.GOEImporter(passingArray).subscribe((res) => {
        this.dataSourceThree = res.GlobalOperationsImport;
        this.GoeList = this.dataSourceThree;

        // this.UploadedLocationList = res.LocationImport.recordset;
        this.toaster.success("Processed Successfully. Please check the table.");
        // this.GetLocationList();
      });
      // this.getGoeList();
    } else {
      this.toaster.warning(
        "Uploaded Excel Sheet is Invalid. Please put the right one."
      );
    }
  }

  openFileBrowser(event) {
    event.preventDefault();
    let element: HTMLElement = document.getElementById("file") as HTMLElement;
    element.click();
  }

  cancelUploadView() {
    window.location.reload();
  }

  private goeDefaultSelected(goeList) {
    // debugger;
    if (Array.isArray(goeList)) {
      if (goeList.length === 1) {
        this.highlited(
          goeList[0],
          goeList[0].GlobalEnvironmentID,
          goeList[0].GOENo,
          goeList[0].EnvironmentName
        );
      }
    }
  }
  openIpaddress() {
    const dialogRef = this.dialog.open(IpaddressComponent, {
      disableClose: true,
      width: "40%",
      maxWidth: "100vw",
    });
  }
}
