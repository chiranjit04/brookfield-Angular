import { Component, OnInit, ViewChild, Input, OnDestroy } from "@angular/core";
import { MatTableDataSource } from "@angular/material/table";
//import { GoeDetail } from './goe-detail.service';
import { GoeDetailService } from "./goe-detail.service";
import { myEnvironmentService } from "../myenvironment.service";
import { MatDialog } from "@angular/material/dialog";
import { MatSort } from "@angular/material/sort";
import { GoeadminComponent } from "./goeadmin/goeadmin.component";
import { GoeleadersComponent } from "./goeleaders/goeleaders.component";
import { RestricteduseComponent } from "./restricteduse/restricteduse.component";
import { StorageService } from "../../../../services/storage.service";
import { ToastrService } from "ngx-toastr";
import {
  FormControl,
  FormGroupDirective,
  NgForm,
  Validators,
  FormGroup,
  FormBuilder,
} from "@angular/forms";
import Swal from "sweetalert2";
import { Router, ActivatedRoute } from "@angular/router";
import { UserPermissionService } from "src/app/services/user-permission.service";

export interface GoeLeaderTable {
  goeleadername: string;

  glpositiontitle: string;
  glsubdivision: string;
  glphone: number;
  glemail: string;
  glaction: string;
}
export interface GoeAdminTable {
  goeadminname: string;
  gApositiontitle: string;
  gAsubdivision: string;
  gAphone: number;
  gAemail: string;
  gAaction: string;
}

@Component({
  selector: "app-goe-detail",
  templateUrl: "./goe-detail.component.html",
  styleUrls: ["./goe-detail.component.scss"],
})
export class GoeDetailComponent implements OnInit, OnDestroy {
  displayedColumns: string[] = [
    "companyname",
    "companysubdivisionname ",
    "companytype",
    "action",
  ];
  Goe: any;

  addgop = false;
  labelgoe = false;
  descriptiongoe = false;

  timeList = [];
  userGoeProfile = null;
  dataSource: any;
  dataRevised: any;

  @Input() parentData: any;

  GlobalEnvironmentID = 0;
  GlobalEnvironmentName = "";
  GOENumber = "";
  GlobalEnvironmentDetails = null;
  isGoeAdminFlag;
  userData = null;
  authToken = null;
  EnvironmentName_: string = "";
  EnvironmentDescription_: string = "";
  GoeID: any = false;
  leaderLength: any;
  adminLength: any;
  restrictedUserLength: any;
  gId: any;
  GOEProprties = {
    status: "1",
    assigned: "1",
    restricted: "0",
  };
  CreatedUserIDForPermission;
  restrictedUseList: any[];
  propertybycompany: any[];

  // @ViewChild('callAPIDialog') callAPIDialog: TemplateRef<any>;

  constructor(
    private goeDetailService: GoeDetailService,
    private myEnvironmentService: myEnvironmentService,
    public dialog: MatDialog,
    public router: Router,
    private route: ActivatedRoute,
    private storage: StorageService,
    private tostre: ToastrService,
    public UserPermission: UserPermissionService
  ) {
    this.GlobalEnvironmentDetails = JSON.parse(
      this.storage.getData("GlobalEnvironmentDetails")
    );
    if (this.GlobalEnvironmentDetails) {
      this.GlobalEnvironmentID = this.GlobalEnvironmentDetails.GlobalEnvironmentId;
      this.GlobalEnvironmentName = this.GlobalEnvironmentDetails.GlobalEnvironmentName;
      this.GOENumber = this.GlobalEnvironmentDetails.GOENo;
    }
    //... Read User Data ...
    this.authToken = this.storage.getData("token");
    this.userData = JSON.parse(this.storage.getData("UserData"));
  }
  //@ViewChild(MatSort, {static: true}) sort: MatSort;

  GoeForm = new FormGroup({
    GlobalEnvironmentID: new FormControl(""),
    EnvironmentName: new FormControl("", [Validators.required]),
    EnvironmentDescription: new FormControl("", [Validators.required]),
  });
  submitted = false;
  get GoeF() {
    return this.GoeForm.controls;
  }

  restrictedUsedList: any;

  dataSource3: MatTableDataSource<any>;
  companyList: any = [];
  restrictedListLength: any;
  displayedColumns3 = [
    "companysubdivisionname",
    "companyname",
    "companytype",
    "status",
  ];

  receiveMessage($event) {
    this.GOEProprties.restricted = $event;
  }

  checkGoe() {
    if (this.GlobalEnvironmentID) {
      return true;
    } else {
      Swal.fire({
        text: "Please select your GOE first",
      }).then((result) => {
        //if (result.value) {
        this.router.navigate(["products/administration/goe/mygoe"]);
        //}
      });
      return false;
    }
  }

  ngOnInit() {
    //if (this.checkGoe()) {
    let goeID = this.route.snapshot.paramMap.get("id");
    if (!goeID) {
      this.addgop = !this.addgop;
    } else {
      goeID = atob(goeID);
      this.GoeID = goeID;
    }
    this.getGoeProfile(this.GoeID);

    this.GetRestrictCompanybyGOE();

    //}
    this.goeDetailService.currentMessage.subscribe((r: any) => {
      if (typeof r == "string") {
        console.log("hello");
        return;
      }
      this.leaderLength = r.length;
      console.log("Checking the length here", r.length);
    });
    this.goeDetailService.currentMessageAdmin.subscribe((r: any) => {
      if (typeof r == "string") {
        return;
      }
      this.adminLength = r.length;
    });
    this.goeDetailService.currentRestricted.subscribe((r: any) => {
      if (typeof r == "string") {
        return;
      }
      this.restrictedUserLength = r;
      // if (this.restrictedUserLength) {
      //   this.GOEProprties.restricted = "1";
      // } else {
      //   this.GOEProprties.restricted = "0";
      // }
    });
    // if(){

    // }
    this.dataRevised = this.goeDetailService.currentPopups.subscribe((data) => {
      console.log("what are we thinking", data);
      if (data == "leader") {
        this.opengoeleaders(0, goeID);
      } else if (data == "admin") {
        this.opengoeadmin(0, goeID);
      } else if (data == "use") {
        this.openrestricteduse();
      }
    });
  }

  getGoeProfile(goeID: any) {
    const param = {
      //GoeId: this.GlobalEnvironmentID,
      GoeId: goeID ? goeID : 0,
      UserId: this.userData[0].UserID,
      //PropertyId: this.userData[0].PropertyID
    };
    let result: any;
    this.goeDetailService.GoeProfile(param).subscribe((response) => {
      result = response.GoeProfile[0];
      this.userGoeProfile = result;
      this.CreatedUserIDForPermission = result.CreatedUserID;
      this.isGoeAdminFlag = result.ISGOEAdmin;
      console.log("Incoming data", this.userGoeProfile);
      this.GOEProprties.status = result.IsActive ? "1" : "0";
      this.GOEProprties.assigned = result.IsAssigned ? "1" : "0";
      this.GOEProprties.restricted = result.IsRestrictedUse ? "1" : "0";
    });
  }

  opencreatedgoe() {}

  opengoeadmin(GOEUserId: any, GoeID: any) {
    const dialogRef = this.dialog.open(GoeadminComponent, {
      width: "80%",
      maxWidth: "100vw",
      height: "90vh",
    });
    dialogRef.componentInstance.GOEUserId = GOEUserId;
    dialogRef.componentInstance.gId = GoeID;
    console.log("what up", GoeID);
  }

  opengoeleaders(GOEUserId: any, GoeID: any) {
    console.log("tetsingbdfsvdfvf", GoeID);
    const dialogRef = this.dialog.open(GoeleadersComponent, {
      width: "80%",
      maxWidth: "100vw",
      height: "90vh",
    });
    dialogRef.componentInstance.GOEUserId = GOEUserId;
    dialogRef.componentInstance.gId = GoeID;
  }

  // Restricted Use area code start
  openrestricteduse() {
    const dialogRef = this.dialog.open(RestricteduseComponent, {
      width: "40%",
      maxWidth: "100vw",
      height: "90vh",
    });
    this.GOEProprties.restricted = "1";

    dialogRef.afterClosed().subscribe((x) => {
      // console.log("data is here" , x)
      if (x.length) {
        for (let i = 0; i < x.length; i++) {
          let a = x[i];
          a.IsActive = 1;
          this.companyList.push(x[i]);
        }
        this.updateGOECompanyRestrict(x);
      }
      this.dataSource3 = new MatTableDataSource(this.companyList);
      console.log("data is here", this.companyList);
      if (this.companyList.length == 0) {
        this.GOEProprties.restricted = "0";
      }
    });
  }
  updateGOECompanyRestrict(tempList) {
    let GlobalEnvironmentID = this.GoeID;
    let GoeDetailService = this.goeDetailService;

    for (let i = 0; i < tempList.length; i++) {
      let data = {
        GOECompanyRestrictID: 0,
        GlobalEnvironmentID: +GlobalEnvironmentID,
        CompanyIds: +tempList[i].CompanyID,
      };
      GoeDetailService.updateGOECompanyRestrict(data).subscribe((resp) => {
        // console.log(resp)
        this.updateGlobalEnvironment();
      });
    }
  }
  updateGlobalEnvironment() {
    let GoeData = this.userGoeProfile;
    let finalData = {
      GlobalEnvironmentID: GoeData.GlobalEnvironmentID,
      EnvironmentName: GoeData.EnvironmentName,
      EnvironmentDescription: GoeData.EnvironmentDescription,
      IsActive: GoeData.IsActive ? 1 : 0,
      IsAssigned: GoeData.IsAssigned ? 1 : 0,
      IsRestrictedUse: 1,
      UserId: this.userData[0].UserID,
    };
    this.myEnvironmentService
      .updateGlobalEnvironment(finalData)
      .subscribe((resp) => {
        let result = resp;
        console.log(result);
      });
  }
  GetRestrictCompanybyGOE() {
    this.GoeID;
    let data = {
      GlobalEnvironmentID: +this.GoeID,
    };
    let result: any;
    this.goeDetailService.GetRestrictCompanybyGOE(data).subscribe((resp) => {
      result = resp.getRestrictCompanybyGOE;
      var filtered = this.companyList.filter(function (el) {
        return el != "";
      });
      this.companyList = filtered;
      let companyList = [];
      result.forEach(function (item, i) {
        companyList.push(item);
      });
      this.restrictedListLength = result.length;
      this.goeDetailService.changeRestrictedUsers(this.restrictedListLength);

      this.companyList = companyList;
      this.dataSource3 = new MatTableDataSource(this.companyList);
    });
  }
  // Restricted Use area code ends

  formOpen = false;
  createNewGOE() {
    this.formOpen = !this.formOpen;
    this.addgop = !this.addgop;
  }

  UpdateGoeRecord() {
    this.submitted = true;
    // if (this.GoeForm.invalid) {
    //   console.log("not entering");
    //   return;
    // } else {
    console.log("entering");
    let postData = this.GoeForm.value;
    let EnvironmentName =
      postData.EnvironmentName.trim() || this.userGoeProfile.EnvironmentName;
    let EnvironmentDescription =
      postData.EnvironmentDescription.trim() ||
      this.userGoeProfile.EnvironmentDescription;
    if (EnvironmentName == "") {
      Swal.fire({ text: "Title Name is required" });
      return false;
    }
    if (EnvironmentDescription == "") {
      Swal.fire({ text: "Description is required" });
      return false;
    }
    //console.log(this.GOEProprties)
    let finalData = {
      GlobalEnvironmentID:
        this.GoeID || this.userGoeProfile.GlobalEnvironmentID,
      EnvironmentName: EnvironmentName || this.userGoeProfile.EnvironmentName,
      EnvironmentDescription:
        EnvironmentDescription || this.userGoeProfile.EnvironmentDescription,
      IsActive: this.GOEProprties.status == "1" ? 1 : 0,
      IsAssigned: this.GOEProprties.assigned == "1" ? 1 : 0,
      IsRestrictedUse: this.GOEProprties.restricted == "1" ? 1 : 0,
      UserId: this.userData[0].UserID,
    };
    console.log(finalData);
    let result: any;
    this.myEnvironmentService
      .updateGlobalEnvironment(finalData)
      .subscribe((resp) => {
        result = resp;
        console.log(result);
        console.log(result.UpdateGlobalEnvironment);
        console.log(result.UpdateGlobalEnvironment.recordset);
        console.log(result.UpdateGlobalEnvironment.recordset[0].ID);
        if (
          result.UpdateGlobalEnvironment.recordset[0].Meaasage.trim() ==
          "Environment Name Already exist."
        ) {
          Swal.fire({ text: "Environment Name Already exist." });
        } else {
          this.addgop = !this.addgop;
          this.GoeForm.reset();
          this.submitted = false;
          let GoeID = result.UpdateGlobalEnvironment.recordset[0].ID;
          // this.router.navigate(['products/administration/goe/mygoe/detail', {goeID: btoa(GoeID)}]);
          this.router.navigate([
            "products/administration/goe/mygoe/detail/" + btoa(GoeID),
          ]);
          this.getGoeProfile(GoeID);
          this.GoeID = GoeID;
        }
      });
    // }
  }

  CancelGoe() {
    this.GoeForm.reset();
    this.addgop = !this.addgop;
  }

  searchVal() {}

  applyFilter(object: any) {}

  /**
   * Edit Goe Name
   * @param userGoeProfile
   */
  editGoeName(userGoeProfile) {
    console.log(userGoeProfile);
    this.labelgoe = !this.labelgoe;
    this.EnvironmentName_ = userGoeProfile.EnvironmentName;
  }
  /**
   * Update Goe Name
   * @param userGoeProfile
   */
  updateGoeName(userGoeProfile) {
    // this.labelgoe = !this.labelgoe;
    const obj = {
      GlobalEnvironmentID: userGoeProfile.GlobalEnvironmentID,
      EnvironmentName: this.EnvironmentName_,
      EnvironmentDescription: userGoeProfile.EnvironmentDescription,
      IsActive: userGoeProfile.IsActive ? userGoeProfile.IsActive : false,
      IsAssigned: userGoeProfile.IsAssigned ? userGoeProfile.IsAssigned : false,
      IsRestrictedUse: userGoeProfile.IsRestrictedUse
        ? userGoeProfile.IsRestrictedUse
        : false,
      UserId: this.userData[0].UserID,
    };

    //////
    this.myEnvironmentService.updateGlobalEnvironment(obj).subscribe((resp) => {
      let result = resp;
      if (
        result.UpdateGlobalEnvironment.recordset[0].Message ==
        "Environment Name Already exist. "
      ) {
        Swal.fire({ text: "Environment Name Already exist." });
      } else {
        this.labelgoe = !this.labelgoe;
        // this.addgop = !this.addgop
        // this.GoeForm.reset();
        // this.submitted = false;
        // let GoeID = result.UpdateGlobalEnvironment.recordset[0].ID
        // this.router.navigate(['products/administration/goe/mygoe/detail', {goeID: btoa(GoeID)}]);
        // this.router.navigate(['products/administration/goe/mygoe/detail/' + btoa(GoeID)]);
        // this.getGoeProfile(GoeID);
        // this.GoeID = GoeID
      }
    });
    ///////
    if (obj.EnvironmentName == "") {
      Swal.fire({ text: "Environment Name is required" });
      return false;
    }
    // console.log('update Goe Data ===>>', obj)
    this.myEnvironmentService.updateGlobalEnvironment(obj).subscribe((res) => {
      this.getGoeProfile(obj.GlobalEnvironmentID);
      // console.log('update Goe Data', res)
    });
  }

  /**
   * Edit Goe Description
   * @param userGoeProfile
   */
  editGoeDesc(userGoeProfile) {
    this.descriptiongoe = !this.descriptiongoe;
    this.EnvironmentDescription_ = userGoeProfile.EnvironmentDescription;
    // console.log('userGoeProfile for desc==>>', userGoeProfile)
  }

  /**
   * Update Goe Description
   * @param userGoeProfile
   */
  updateGoeDesc(userGoeProfile) {
    this.descriptiongoe = !this.descriptiongoe;
    const obj = {
      GlobalEnvironmentID: userGoeProfile.GlobalEnvironmentID,
      EnvironmentName: userGoeProfile.EnvironmentName,
      EnvironmentDescription: this.EnvironmentDescription_,
      IsActive: userGoeProfile.IsActive ? userGoeProfile.IsActive : false,
      IsAssigned: userGoeProfile.IsAssigned ? userGoeProfile.IsAssigned : false,
      IsRestrictedUse: userGoeProfile.IsRestrictedUse
        ? userGoeProfile.IsRestrictedUse
        : false,
      UserId: this.userData[0].UserID,
    };

    if (obj.EnvironmentDescription == "") {
      // Swal.fire({ text: "Environment Description is required" });
      this.tostre.error("Environment Description is required", "", {
        positionClass: "toast-top-right",
      });
      return false;
    }
    this.myEnvironmentService.updateGlobalEnvironment(obj).subscribe((res) => {
      this.getGoeProfile(obj.GlobalEnvironmentID);
    });
  }

  showGoeWarning() {
    // Swal.fire({ text: "You need to create a Goe first" });
    this.tostre.error("You need to create a Goe first", "", {
      positionClass: "toast-top-right",
    });
  }

  /**
   * Get Property by Company Subdivision
   * @param GlobalEnvironmentID
   * @param CompanyId
   * @param CompanySubdivisionId
   * @param CompanyTypeId
   */

  GetPropertybyCompanySubdivion(
    GlobalEnvironmentID,
    CompanyId,
    CompanySubdivisionId,
    CompanyTypeId
  ) {
    const obj = {
      GlobalEnvironmentID: +GlobalEnvironmentID,
      CompanyId: +CompanyId,
      CompanySubdivisionId: CompanySubdivisionId,
      CompanyTypeId: CompanyTypeId,
    };

    console.log("obj in", obj);
    let result;
    this.goeDetailService
      .GetPropertybyCompanySubdivion(obj)
      .subscribe((res) => {
        result = res;
        this.propertybycompany = result.getPropertybyCompanySubdivion;
        if (this.propertybycompany.length) {
          let obj1 = this.propertybycompany.find((o) => o.IsAssigned == 1);
          if (obj1) {
            this.GOEProprties.restricted = "1";
          } else {
            this.GOEProprties.restricted = "0";
          }
        } else {
          this.GOEProprties.restricted = "0";
        }
      });
  }

  ngOnDestroy() {
    console.log("this might gets us to work further");
    // this.goeDetailService.currentPopups.subscribe((data) => {
    //   console.log("need", data);
    // });
  }
}
