import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
// import { environment } from "../../../../environments/environment";
import { environment } from "../../../../../environments/environment";
import { Observable } from "rxjs";
import { BehaviorSubject } from "rxjs";

@Injectable({
  providedIn: "root",
})
export class GoeDetailService {
  observable: Observable<any>;
  url: any;

  //data sharing
  private messageSource = new BehaviorSubject("default message");
  currentMessage = this.messageSource.asObservable();

  //data sharing Admin
  private messageSourceAdmin = new BehaviorSubject("default");
  currentMessageAdmin = this.messageSourceAdmin.asObservable();

  //warning message for changing user

  private messageWarning = new BehaviorSubject("default message");
  currentWarning = this.messageWarning.asObservable();

  private messageSendingFunction = new BehaviorSubject("default message");
  currentSendingFunction = this.messageSendingFunction.asObservable();

  private messageList = new BehaviorSubject("default message");
  currentList = this.messageList.asObservable();

  private messageClear = new BehaviorSubject("default message");
  currentClear = this.messageClear.asObservable();

  //data sharing for array length
  // private messageSource = new BehaviorSubject('default message');
  // currentMessage = this.messageSource.asObservable();
  /**
   * For Company
   */
  private messageCompany = new BehaviorSubject("");
  currentCompany = this.messageCompany.asObservable();

  //For passing ID to leader list
  private messageLeaderId = new BehaviorSubject("");
  currentLeaderId = this.messageLeaderId.asObservable();

  //For passing ID to Admin list
  private messageAdminId = new BehaviorSubject("");
  currentAdminId = this.messageAdminId.asObservable();

  //For removing the unselected user from leader list
  private messageRemove = new BehaviorSubject("");
  currentRemoveLeader = this.messageRemove.asObservable();

  //For getting the list length for restricted
  private messageRestricted = new BehaviorSubject("");
  currentRestricted = this.messageRestricted.asObservable();

  //sending data from detail to popup
  private messagedata = new BehaviorSubject("");
  currentdata = this.messagedata.asObservable();

  //For removing the unselected user from leader list
  // private messageRemove1 = new BehaviorSubject("");
  // currentRemoveLeader1 = this.messageRemove1.asObservable();

  //opening popups
  private messagePopups = new BehaviorSubject("default message");
  currentPopups = this.messagePopups.asObservable();

  changeMessagePopup(message: string) {
    this.messagePopups.next(message);
  }

  changeMessageWarning(message: any) {
    this.messageWarning.next(message);
  }

  changeMessageFunction(message: any) {
    this.messageSendingFunction.next(message);
  }

  changeList(message: any) {
    this.messageList.next(message);
  }

  changeClear(message: any) {
    this.messageClear.next(message);
  }

  constructor(private http: HttpClient) {
    this.url = environment.origin + "api/";
    // this.url = "http://localhost:1601/" + "api/";
  }

  changeMessage(message: string) {
    this.messageSource.next(message);
  }

  GoeProfile(param: any) {
    try {
      return this.http.post<any>(`${this.url}GetGoeProfile`, param);
    } catch (error) {
      throw error;
    }
  }

  /* UpdateGlobalEnvironment(postData: any){
              try {
                  return this.http.post<any>(`${this.url}UpdateGlobalEnvironment`, postData);
              } catch (error) {
                  throw error;
              }
          } */

  GoeLeaderList(GlobalEnvironmentID: any) {
    try {
      return this.http.post<any>(`${this.url}GOELeaderList`, {
        GlobalEnvironmentID,
      });
    } catch (error) {
      throw error;
    }
  }

  GOEAdminList(GlobalEnvironmentID: any) {
    try {
      return this.http.post<any>(`${this.url}GOEAdminList`, {
        GlobalEnvironmentID,
      });
    } catch (error) {
      throw error;
    }
  }

  GetCompanyDetails() {
    try {
      return this.http.get<any>(`${this.url}GetCompanyList`);
    } catch (error) {
      throw error;
    }
  }

  GetGlobalEnvironmentSubDivisionbyCompanyId(obj) {
    try {
      return this.http.post<any>(
        `${this.url}GetGlobalEnvironmentSubDivisionbyCompanyId`,
        obj
      );
    } catch (error) {
      throw error;
    }
  }
  GetCompanySubdivision() {
    try {
      return this.http.get<any>(`${this.url}GetCompanySubdivision`);
    } catch (error) {
      throw error;
    }
  }

  GetComapnySubdivisonByComapnyId(param): Observable<any> {
    try {
      return this.http.post<any>(`${this.url}GetComapnySubdivisonbyUseridOM`, param);
    } catch (error) {
      throw error;
    }
  }

  setCompanyList(param: any) {
    this.messageCompany.next(param);
  }

  getGoeUserList(UserId: any) {
    try {
      console.log("Here it is hello", UserId);
      return this.http.post<any>(`${this.url}GetGoeSourceUserList`, { UserId });
    } catch (error) {
      throw error;
    }
  }

  updateGoeUser(GlobalEnvironmentID, UserIds, GOEUserTypeId, IsAssigned) {
    try {
      console.log("is it hitting?");
      return this.http.post<any>(`${this.url}UpdateGOEUser`, {
        GlobalEnvironmentID,
        UserIds,
        GOEUserTypeId,
        IsAssigned,
      });
    } catch (error) {
      throw error;
    }
  }

  /**
   * ASSIGN PROPERTIES TO GOE
   * @param obj
   *
   */

  GetCompanybyUserid(obj) {
    try {
      return this.http.post<any>(`${this.url}GetCompanybyUserid`, obj);
    } catch (error) {
      throw error;
    }
  }

  GetCompanySubdivisonbyUserid(obj) {
    try {
      return this.http.post<any>(
        `${this.url}GetComapnySubdivisonbyUserid`,
        obj
      );
    } catch (error) {
      throw error;
    }
  }

  GetCompanyTypeByUserId(obj) {
    try {
      return this.http.post<any>(`${this.url}GetComapnyTypeByUserId`, obj);
    } catch (error) {
      throw error;
    }
  }
  GetPropertybyCompanySubdivion(obj) {
    try {
      return this.http.post<any>(`${this.url}GetPropertybyCompanySubdivion`, obj);
    } catch (error) {
      throw error;
    }
  }

  AssignGoeToProperty(obj) {
    try {
      return this.http.post<any>(`${this.url}AssignGoeToProperty`, obj);
    } catch (error) {
      throw error;
    }
  }

  updateGOECompanyRestrict(postData: any) {
    try {
      return this.http.post<any>(
        `${this.url}updateGOECompanyRestrict`,
        postData
      );
    } catch (error) {
      throw error;
    }
  }

  GetRestrictCompanybyGOE(postData: any) {
    try {
      return this.http.post<any>(
        `${this.url}GetRestrictCompanybyGOE`,
        postData
      );
    } catch (error) {
      throw error;
    }
  }

  onClickActiveService(GOEUserId, IsActive) {
    try {
      let data = {
        GOEUserId: GOEUserId,
        IsActive: IsActive,
      };
      return this.http.post<any>(`${this.url}ActiveInActiveGoeUser`, data);
    } catch (error) {
      throw error;
    }
  }

  changeMessageAdmin(messageData: string) {
    this.messageSourceAdmin.next(messageData);
  }

  changeMessageLeaderId(messageId: any) {
    console.log("Hopes are best", messageId);
    this.messageLeaderId.next(messageId);
  }

  changeMessageAdminId(messageId: any) {
    console.log("Hopes are best", messageId);
    this.messageAdminId.next(messageId);
  }

  changeMessageRemove(message: string) {
    this.messageRemove.next(message);
  }

  changeRestrictedUsers(message: string) {
    this.messageRestricted.next(message);
  }

  sendingData(message: string) {
    this.messagedata.next(message);
  }
  // changeMessageRemove1(message: string) {
  //   this.messageRemove.next(message);
  // }

    /*add or edit ip apis*/
    updateMachineInfo(param){
      return this.http.post(
         this.url + "jobTitle/UpdateMachineInfo",
         param
       );
     }
     getMachineInformation(param){
       return this.http.post(
          this.url + "jobTitle/GetMachineInformation",
          param
        );
     }
     getMachineInfoList(param){
       return this.http.post(
          this.url + "jobTitle/GetMachineInfoList",
          param
        );
     } 
    // /api/getPropertyByUser
    //  getPropertyList(userId) {
    //    return this.http.get(`${this.url}getProperty/${userId}`);
    //  }
    getPropertyList(param){
      return this.http.post(
         this.url + "getPropertyByUser",
         param
       );
    } 
   
     /*====================*/
}
