import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GeoleaderlistComponent } from './geoleaderlist.component';

describe('GeoleaderlistComponent', () => {
  let component: GeoleaderlistComponent;
  let fixture: ComponentFixture<GeoleaderlistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GeoleaderlistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GeoleaderlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
