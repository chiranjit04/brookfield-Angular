import {
  Component,
  OnInit,
  ViewChild,
  Output,
  EventEmitter,
  Input,
} from "@angular/core";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { GoeDetailService } from "../goe-detail.service";
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { Router, ActivatedRoute } from "@angular/router";
import { GoeleadersComponent } from "../goeleaders/goeleaders.component";
import { ServiceService } from "./../../../service/service.service";
import { ToastrService } from "ngx-toastr";
import { UserPermissionService } from "src/app/services/user-permission.service";
import { StorageService } from "src/app/services/storage.service";
// for GOE leader table
export interface GoeLeaderTable {
  GOEUserId: any;
  GlobalEnvironmentId: any;
  Name: string;
  PositionTitle: string;
  CompanyName: string;
  Subdivision: any;
  PhoneNumber: any;
  Email: any;
}

const ELEMENT_DATA: GoeLeaderTable[] = [];

@Component({
  selector: "app-geoleaderlist",
  templateUrl: "./geoleaderlist.component.html",
  styleUrls: ["./geoleaderlist.component.scss"],
})
export class GeoleaderlistComponent implements OnInit {
  onchangeVal: any;
  dataSource: MatTableDataSource<any>;
  NoData: boolean;
  @Input() createdUserId;
  @Input() isGoeAdminFlag;
  constructor(
    private goeDetailService: GoeDetailService,
    private route: ActivatedRoute,
    public dialog: MatDialog,
    private adminService: ServiceService,
    private toastr: ToastrService,
    public UserPermission: UserPermissionService,
    public storageService: StorageService
  ) {
    this.userData = JSON.parse(this.storageService.getData("UserData"));
  }
  goeLeaderListArray: any = [];
  displayedColumns: string[] = [
    "Name",
    "PositionTitle",
    "CompanyName",
    "Subdivsion",
    "PhoneNumber",
    "Email",
    "Action",
  ];

  //exporting to the parent - Geo Details

  // message: any;
  // dataSource = new MatTableDataSource(ELEMENT_DATA);
  // dataFromChild: any;

  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @Input() childValue: any;

  GoeID: any = 0;
  GOEUserTypeId = 2;
  GlobalEnvironmentId: any;
  currentUserID: any;
  leaderListLength: any;
  isAssigned: any = "";
  IsActiveToggle: any;
  GlobalEnvironmentID: any;
  selectedLeader: any = false;
  userData: any;

  // onEditOpen(
  //   GlobalEnvironmentId: any = 1,
  //   UserId: any,
  //   GOEUserTypeId: any = 2
  // ) {
  //   this.currentUserID = +UserId;
  //   console.log("adele", this.currentUserID);
  //   const dialogRef = this.dialog.open(GoeleadersComponent, {
  //     width: "70%",
  //     maxWidth: "100vw"
  //   });
  //   dialogRef.componentInstance.GOEUserId = +UserId;
  //   this.goeDetailService.getGoeUserList(+UserId).subscribe(data => {
  //     console.log("what are we getting", data.getGoeSourceUserList);
  //   });
  //   // this.goeDetailService
  //   //   .updateGoeUser(GlobalEnvironmentId, GOEUserId, GOEUserTypeId)
  //   //   .subscribe(data => {
  //   //     console.log("Data is updated and can be replaced");
  //   //   });
  //   console.log("Getting all the params", {
  //     GlobalEnvironmentId,
  //     UserId,
  //     GOEUserTypeId
  //   });
  //   // this.goeDetailService.updateGoeUser();
  //   // console.log("let us hope", GOEUserId);
  // }

  ngOnInit() {
    let goeID = this.route.snapshot.paramMap.get("id");
    if (goeID) {
      goeID = atob(goeID);
      this.GoeID = goeID;
    }
    // console.log(this.GoeID)
    // let GlobalEnvironmentID = this.GoeID;
    this.GlobalEnvironmentID = this.GoeID;
    // let GlobalEnvironmentID = 2;
    this.goeDetailService
      .GoeLeaderList(this.GlobalEnvironmentID)
      .subscribe((goeLeaderList) => {
        this.goeLeaderListArray = goeLeaderList.goeLeaderList;
        this.leaderListLength = this.goeLeaderListArray.length;
        // console.log("Hey it is here", this.leaderListLength);
        this.dataSource = new MatTableDataSource(this.goeLeaderListArray);

        this.goeDetailService.changeMessage(this.goeLeaderListArray);
        this.dataSource.sort = this.sort;
        this.sort.disableClear = true;
        console.log(this.dataSource);
      });
    this.goeDetailService.currentMessage.subscribe((r: any) => {
      if (typeof r == "string") {
        console.log("hello");
        return;
      }
      console.log("checked", r);
      this.goeLeaderListArray = r;
      this.dataSource = new MatTableDataSource(this.goeLeaderListArray);
    });
    this.goeDetailService.changeMessageLeaderId(this.currentUserID);
  }

  childVal() {
    this.onchangeVal = this.childValue;

    setTimeout(() => {}, 2000);
  }

  onEditOpen(
    GlobalEnvironmentId: any = this.GoeID,
    UserId: any,
    GOEUserTypeId: any = 2
  ) {
    this.currentUserID = UserId;
    this.isAssigned = this.currentUserID;
    const dialogRef = this.dialog.open(GoeleadersComponent, {
      width: "70%",
      maxWidth: "100vw",
    });
    dialogRef.componentInstance.GOEUserId = +UserId;
    dialogRef.componentInstance.gId = +this.GoeID;
    this.goeDetailService.getGoeUserList(+UserId).subscribe((data) => {
      console.log("what are we getting", data.getGoeSourceUserList);
    });
    this.goeDetailService.changeMessageLeaderId(this.currentUserID);

    this.goeDetailService.changeMessageRemove(this.isAssigned);
  }

  applyFilter(ref,event: any) {
    console.log(ref.value)
    const filterValue = (event.target || {}).value;

    this.dataSource.filter = (filterValue || ("" as any)).trim().toLowerCase();
  }
  newMessage() {
    this.goeDetailService.changeMessage("Hello from Sibling");
  }

  onClickActive(GOEUserId, IsActive) {
    //console.log(GOEUserId);
    if (IsActive === true) {
      this.IsActiveToggle = 0;
    } else {
      this.IsActiveToggle = 1;
    }

    //console.log("Toggle", this.IsActiveToggle);
    this.goeDetailService
      .onClickActiveService(GOEUserId, +this.IsActiveToggle)
      .subscribe((data) => {
        this.goeDetailService.GoeLeaderList(this.GoeID).subscribe((d) => {
          console.log("Toggle", d);
          this.toastr.success(this.adminService.statusMsg);
          this.dataSource = new MatTableDataSource(d.goeLeaderList);
        });
        //console.log("here is the result", data);
      });
  }

  onLeaderClick(data: any) {
    if (this.selectedLeader == data.GOEUserId) {
      this.selectedLeader = !this.selectedLeader;
    } else {
      this.selectedLeader = data.GOEUserId;
    }
  }
}
