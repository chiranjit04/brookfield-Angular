import { Component, OnInit } from '@angular/core';
import * as _ from "lodash";
import { StorageService } from "./../../../../../services/storage.service";
import { ToastrService } from "ngx-toastr";
//import { JobtitlesService } from './../jobtitles.service';
import { GoeDetailService } from './../goe-detail.service';
import {
  FormBuilder,
  FormGroup,
  FormControl,
  Validators,
} from "@angular/forms";
import { MatDialogRef, MatTableDataSource, MAT_DIALOG_DATA } from '@angular/material';

export interface PeriodicElement {
  name: string;
  ipaddress: string;
  action: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {name: 'property 1', ipaddress: '192.168.1.111', action: ''},
  {name: 'property 2', ipaddress: '192.168.1.112', action: ''},
  {name: 'property 3', ipaddress: '192.168.1.113', action: ''},
  {name: 'property 4', ipaddress: '192.168.1.114', action: ''},
  {name: 'property 5', ipaddress: '192.168.1.115', action: ''},
  {name: 'property 6', ipaddress: '192.168.1.116', action: ''},
  {name: 'property 7', ipaddress: '192.168.1.117', action: ''},
  {name: 'property 8', ipaddress: '192.168.1.118', action: ''},
  {name: 'property 9', ipaddress: '192.168.1.119', action: ''},
  {name: 'property 1', ipaddress: '192.168.1.111', action: ''},
  {name: 'property 2', ipaddress: '192.168.1.112', action: ''},
  {name: 'property 3', ipaddress: '192.168.1.113', action: ''},
  {name: 'property 4', ipaddress: '192.168.1.114', action: ''},
  {name: 'property 5', ipaddress: '192.168.1.115', action: ''},
  {name: 'property 6', ipaddress: '192.168.1.116', action: ''},
  {name: 'property 7', ipaddress: '192.168.1.117', action: ''},
  {name: 'property 8', ipaddress: '192.168.1.118', action: ''},
  {name: 'property 9', ipaddress: '192.168.1.119', action: ''},
];


@Component({
  selector: 'app-ipaddress',
  templateUrl: './ipaddress.component.html',
  styleUrls: ['./ipaddress.component.scss']
})
export class IpaddressComponent implements OnInit {
  displayedColumns: string[] = ['PropertyName', 'IPAddress', 'action'];
  dataSource = ELEMENT_DATA;
  machineInfoList: MatTableDataSource<any>;
  propertystreets: any = [];
  propertyfilteredStreets: any = [];
  properties: any = [];
  userId: string;
  constructor(private toaster: ToastrService,
    private storage: StorageService,
    private goeDetailService:GoeDetailService,
    public dialogRef: MatDialogRef<IpaddressComponent>,) {

  }
  show: any;
  show1: any;
  AddIPForm = new FormGroup({
    PropertyControl: new FormControl("",Validators.required),
    IpAddress: new FormControl("",Validators.required),
  });
  ngOnInit() {
    this.machineInfoList = new MatTableDataSource();
    // this.machineInfoList.filterPredicate = this.createFilter();
    this.userId = this.storage.getUserID();
    this.getPropertyList();
    this.ipAddressList();
  }

  tutorialquestions = [
    { id: 1, name: "property 1" },
    { id: 2, name: "property 2" },
    { id: 2, name: "property 3" },
    { id: 2, name: "property 4" },
    { id: 2, name: "property 5" },
  ];

  clickit() {
    this.show = !this.show;
  }

  viewlist() {
    this.show = !this.show;
    this.AddIPForm.get("PropertyControl").patchValue("");
    this.AddIPForm.get("IpAddress").patchValue("");
   // this.ipAddressList();
  }
  getPropertyList() {
    this.propertystreets = [];
    let param = {
      UserId: 0
    }
    this.goeDetailService.getPropertyList(param).subscribe(
      (response: any) => {
        this.properties = response.getPropertyByUser;
        for (let i = 0; i < this.properties.length; i++) {
          const arr = this.properties[i].PropertyName;
          this.propertystreets.push({
            PropertyID: this.properties[i].PropertyID,
            PropertyName: this.properties[i].ParopertyName
          });
        }
        // this.propertyfilteredStreets = this.managelocation.controls.PropertyControl.valueChanges.pipe(
        //   startWith(""),
        //   map(value => this._filterProperty(value))
        // );
      }
    );
  }
  setPropertyRef() {
    //console.log(("set property ref");
    this.propertyfilteredStreets = _.cloneDeep(this.propertystreets);
  }
  onPropertyChange(searchValue: string) {
    console.log("on property change ",searchValue);
    if (searchValue && searchValue.length) {
      this.propertyfilteredStreets = _.filter(
        this.propertystreets,
        (result: any) =>
          _.includes(_.toLower(result.PropertyName), _.toLower(searchValue))
      );
    } else {
      this.setPropertyRef();
    }
  }
  selectedPropertyID:any;
  selectProperty(property, lastInputRef?: HTMLInputElement) {
    console.log("selected property name",property);
    // setTimeout(() => {
    //   this.containScroll.nativeElement.scrollIntoView();
    // }, 300);
    if (lastInputRef != undefined) {
      lastInputRef.blur();
    }
    //console.log(("property", this.selectedGoe);
    if (property != undefined) {
      this.selectedPropertyID = property.PropertyID;
    }
  }
  getPropertyName(option: any) {
    if (option) {
      return option.PropertyName;
    }
  }

  machineInfoID:any = 0
  save(){
    console.log("api forms",this.AddIPForm)
    let property = this.AddIPForm.get('PropertyControl').value;
    let ip = this.AddIPForm.get('IpAddress').value;
    // if((property ==  '') || (property ==  undefined)){
    //   console.log("property and ip",property,ip);
    //   this.toaster.error("Please Select Property First.");
    //   return;
    // }
    if((ip ==  '') || (ip ==  undefined)){
      this.toaster.error("Please Enter IP Address.");
      return;
    }
    console.log("property and ip",property,ip);
    let param = {
      "MachineInfo":this.machineInfoID, // first time-0//
      "IPAddress":ip,
      "PropertyID":this.selectedPropertyID,
    }
   this.goeDetailService.updateMachineInfo(param).
   subscribe((res:any)=>{
        let data = res.UpdateMachineInfo;
        if(data.length >0){
          this.toaster.success("IP Address Inserted Successfully.");
          this.AddIPForm.get("PropertyControl").patchValue('');
          this.AddIPForm.get("IpAddress").patchValue('');
         // this.dialogRef.close();
        }
   },
   err =>{
       this.toaster.error(err);
   })
  }
//machineInfoList:any = [];
ipAddressList(){
  let param = {
    "PropertyID":0,
  }
  this.goeDetailService.getMachineInfoList(param).
  subscribe((res:any)=>{
     let data = res.GetMachineInfoList;
     if(data.length>0){
     //this.machineInfoList = data;
     this.machineInfoList.data = data;
     
    //  this.machineInfoList.filterPredicate =
    //   (data: any, filter: string) => !filter || data.level == filter;
      }
  },
  err =>{

  })
}



propertyName:any;
edit(element:any){
  this.selectedPropertyID = element.PropertyID;
  this.machineInfoID = element.MachineInfoID;
  console.log("element edit--<",element);
  //this.propertyName = element.PropertyName;
  this.AddIPForm.get("PropertyControl").patchValue(element.PropertyName);
  this.AddIPForm.get("IpAddress").patchValue(element.IPAddress);
  console.log("form value-->",this.AddIPForm);
  this.show = !this.show;
}

applyFilter(event) {
  // this.machineInfoList.filter = filterValue.trim().toLowerCase();
  // console.log("filter value",filterValue);
  // this.machineInfoList.filter = JSON.stringify(filterValue);
    let filterValue = (event.target as HTMLInputElement).value;
    this.machineInfoList.filter = filterValue.trim().toLowerCase();
    console.log("filtervalue",filterValue,this.machineInfoList);
}
// getMachineInformation(element){
//   let param = {
//     "MachineInfoID":element.MachineInfoID
//   }
//   this.jobtitlesService.getMachineInformation(param).
//   subscribe((res:any)=>{
//         let data = res.GetMachineInformation;
//         if(data.length>0){

//         }
//   },
//   err =>{

//   })
// }
}
