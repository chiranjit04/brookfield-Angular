import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RestricteduseComponent } from './restricteduse.component';

describe('RestricteduseComponent', () => {
  let component: RestricteduseComponent;
  let fixture: ComponentFixture<RestricteduseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RestricteduseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RestricteduseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
