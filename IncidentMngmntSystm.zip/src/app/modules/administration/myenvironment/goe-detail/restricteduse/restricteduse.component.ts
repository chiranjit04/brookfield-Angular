import { Component, OnInit, Output, EventEmitter } from "@angular/core";
import { from } from "rxjs";
import { GoeDetailService } from "../goe-detail.service";
import { MatTableDataSource } from "@angular/material/table";
import { myEnvironmentService } from "../../myenvironment.service";
import Swal from "sweetalert2";
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

export interface PeriodicElement {
  CompanyORSubdivision: string;

  // companysubdivisionname: string;
  // companytype: string;
  // action: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  // {companyname: 'LoremIpsum', companysubdivisionname : 'LoremIpsum', companytype: 'LoremIpsum', action: ''},
  // {companyname: 'LoremIpsum', companysubdivisionname : 'LoremIpsum', companytype: 'LoremIpsum', action: ''},
];
@Component({
  selector: "app-restricteduse",
  templateUrl: "./restricteduse.component.html",
  styleUrls: ["./restricteduse.component.scss"]
})
export class RestricteduseComponent implements OnInit {
  // selectedCompanyId = false

  selectedCompany: any = [];
  selectedCompanyList: any = [];
  selectedCompanySubdivision: any = [];
  userGoeProfile = null;
  userData = null;
  EnvironmentName_: string = "";
  labelgoe = false;
  dataSource: MatTableDataSource<any>;

  companysubdivision: any;
  // displayedColumns = ['companyname', 'companysubdivisionname', 'companytype', 'status'];
  displayedColumns = ["CompanyORSubdivision"];
  // displayedColumns = ['companyname', 'companysubdivisionname', 'companytype'];
  // dataSource = this.companysubdivision;

  restricted = "0"
  @Output() messageEvent = new EventEmitter<string>();

  constructor(
    private GoeDetailService: GoeDetailService,
    private myEnvironmentService: myEnvironmentService,
    public dialogRef: MatDialogRef<RestricteduseComponent>
  ) {}

  ngOnInit() {
    this.getCompanySubdivision();
    console.log("The list might come here", this.companysubdivision);
  }

  /**
   * Get Company Subdivision
   *
   */
  getCompanySubdivision() {
    let result: any;
    this.GoeDetailService.GetCompanySubdivision().subscribe(res => {
      result = res;
      this.companysubdivision = result.getCompanySubdivision;
      this.dataSource = new MatTableDataSource(this.companysubdivision);
      // console.log('companysubdivision==========>>>', this.companysubdivision)
    });
  }
  selectCompanySubdivision(row) {
    // console.log(row)
    if (this.selectedCompany.includes(row.CompanyID)) {
      let index = this.selectedCompany.indexOf(row.CompanyID);
      this.selectedCompany.splice(index);
      this.selectedCompanyList.splice(index);
    } else {
      // this.highlightedRows = i;
      const GoeCompanyList = {
        CompanyID: row.CompanyID,
        CompanyORSubdivision: row.CompanyORSubdivision
      };
      this.selectedCompanyList.push(GoeCompanyList);
      this.selectedCompany.push(row.CompanyID);
    }
    //this.GoeDetailService.setCompanyList(this.selectedCompanyList)
  }
  /**
   * Update
   * @param userGoeProfile
   */
  SetCompanyLists(userGoeProfile) {
    // this.GoeDetailService.setCompanyList(this.selectedCompanyList);
    //console.log(this.selectedCompanyList) 
    this.dialogRef.close(this.selectedCompanyList)   
  }

  closePopup(){
    if(this.selectedCompanyList.length == 0){
      this.restricted = "0"
      this.messageEvent.emit(this.restricted)
    }
  }

}
