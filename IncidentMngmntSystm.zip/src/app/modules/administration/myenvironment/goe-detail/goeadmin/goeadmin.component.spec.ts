import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GoeadminComponent } from './goeadmin.component';

describe('GoeadminComponent', () => {
  let component: GoeadminComponent;
  let fixture: ComponentFixture<GoeadminComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GoeadminComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GoeadminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
