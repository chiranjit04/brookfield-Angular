import { Component, OnInit, ViewChild } from "@angular/core";
import { SelectionModel } from "@angular/cdk/collections";
import { MatTableDataSource } from "@angular/material/table";
import { GoeDetailService } from "../goe-detail.service";
import Swal from "sweetalert2";
import { ToastrService } from "ngx-toastr";
import { MatSort } from "@angular/material/sort";

export interface UserTable {
  UserId: any;
  GlobalEnvironmentId: any;
  Name: string;
  PositionTitle: string;
  Subdivision: any;
}

@Component({
  selector: "app-goeadmin",
  templateUrl: "./goeadmin.component.html",
  styleUrls: ["./goeadmin.component.scss"],
})
export class GoeadminComponent implements OnInit {
  displayedColumns: string[] = [
    "Name",
    "PositionTitle",
    "CompanyName",
    "Subdivision",
  ];
  @ViewChild(MatSort, { static: false }) sort: MatSort;

  selection = new SelectionModel<UserTable>(true, []);
  goeUserListy: any = [];
  dataSource: MatTableDataSource<any>;
  highlightedRows: any = [];
  selectedAdmin = [];
  selectedLeaderList: any = [];
  id: any;
  selectedLeader = [];
  selectedUsers: any = [];
  GlobalEnvironmentID = 1;
  GOEUserTypeId = 1;
  GOEUserId: any;
  currentUserId: any;
  IsAssigned: any = 1;
  gId: any;
  // highlited(row) {
  //   this.id = row.UserId;
  //   // console.log(GOEUserId);
  //   if (this.selectedLeader.includes(row.UserId)) {
  //     let index = this.selectedLeader.indexOf(row.UserId);
  //     console.log("INDEXXX", index);
  //     this.selectedLeader.splice(index, 1);
  //     this.selectedUsers.splice(index, 1);
  //   } else {
  //     this.selectedLeader.push(row.UserId);
  //     console.log(row.UserId);
  //   }
  // }

  highlited(row) {
    this.gettingPreLeaderList();
    console.log("selected1", this.selectedLeaderList, row.UserId);
    this.selectedLeaderList = this.selectedLeaderList.map((data) => {
      return data.UserID;
    });
    console.log("new.,", this.selectedLeaderList);
    if (this.selectedLeaderList.includes(row.UserId)) {
      Swal.fire({
        text:
          "This User is already assigned as Leader. Do you want to change it to Admin?",
        showCancelButton: true,
        confirmButtonText: "Yes",
        cancelButtonText: "No",
      }).then((result) => {
        if (result.value) {
          console.log("hi");
          this.selectedAdmin.push(row.UserId);
          this.data
            .updateGoeUser(+this.gId, row.UserId, 2, 0)
            .subscribe((x) => {
              this.data.GoeLeaderList(+this.gId).subscribe((y) => {
                console.log("List refreshed", y);
                this.data.changeMessage(y.goeLeaderList);
              });
            });
          this.gettingPreLeaderList();
          // this.selectedUsers.splice(index, 1);
        } else {
          console.log("hi cancel");
          this.gettingPreLeaderList();
          return false;
        }
      });
    } else {
      if (this.selectedAdmin.includes(row.UserId)) {
        let index = this.selectedAdmin.indexOf(row.UserId);
        this.selectedAdmin.splice(index, 1);
        this.selectedUsers.splice(index, 1);
        this.data
          .updateGoeUser(+this.gId, this.currentUserId, 1, 0)
          .subscribe((x) => {
            this.data.GOEAdminList(+this.gId).subscribe((y) => {
              console.log("List refreshed", y);
              this.data.changeMessageAdmin(y.goeAdminList);
            });
          });
      } else if (this.currentUserId == row.UserId) {
        this.currentUserId = false;
        this.selectedAdmin.push(row.UserId);
      } else {
        this.selectedAdmin.push(row.UserId);
      }
      this.gettingPreLeaderList();
    }

    console.log("DEXTER", this.selectedAdmin);
  }

  clearingUser(id) {
    let index = this.selectedAdmin.indexOf(id);
    this.selectedAdmin.splice(index, 1);
    this.selectedUsers.splice(index, 1);
    // this.onAcceptSelections(this.GlobalEnvironmentID, this.selectedAdmin, );
    this.ngOnInit();
  }

  onAcceptSelections(
    GlobalEnvironmentID,
    selectedAdmin: any,
    GOEUserTypeId,
    IsAssigned
  ) {
    console.log("merry christmas", this.gId);
    if (this.selectedAdmin.length > 0) {
      this.data
        .updateGoeUser(
          (GlobalEnvironmentID = +this.gId),
          this.selectedAdmin,
          GOEUserTypeId,
          IsAssigned
        )
        .subscribe((x) => {
          this.data.GOEAdminList(GlobalEnvironmentID).subscribe((y) => {
            console.log("List refreshed", y);
            this.data.changeMessageAdmin(y.goeAdminList);
          });
        });
    } else {
      console.log("wow bruce", +this.gId, this.currentUserId, GOEUserTypeId);
      this.data
        .updateGoeUser(
          (GlobalEnvironmentID = +this.gId),
          this.currentUserId,
          GOEUserTypeId,
          0
        )
        .subscribe((x) => {
          this.data.GOEAdminList(GlobalEnvironmentID).subscribe((y) => {
            console.log("List refreshed", y);
            this.data.changeMessageAdmin(y.goeAdminList);
          });
        });
    }
  }

  // onAcceptSelections(GlobalEnvironmentID, UserIds, GOEUserTypeId) {
  //   this.data
  //     .updateGoeUser(GlobalEnvironmentID, this.id, GOEUserTypeId)
  //     .subscribe(x => {
  //       console.log("Update in order", x.UpdateGOEUser);
  //       this.data.GOEAdminList(GlobalEnvironmentID).subscribe(y => {
  //         console.log(">>>>>>>>>>>>>", y);
  //         console.log("List refreshed");
  //         this.data.changeMessageAdmin(y);
  //       });
  //     });
  // }

  /** Whether the number of selected elements matches the total number of rows. */
  // isAllSelected() {
  //   const numSelected = this.selection.selected.length;
  //   const numRows = this.dataSource.data.length;
  //   return numSelected === numRows;
  // }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  // masterToggle() {
  //   this.isAllSelected()
  //     ? this.selection.clear()
  //     : this.dataSource.data.forEach(row => this.selection.select(row));
  // }

  /** The label for the checkbox on the passed row */
  // checkboxLabel(row?: UserTable): string {
  //   if (!row) {
  //     return `${this.isAllSelected() ? "select" : "deselect"} all`;
  //   }
  //   return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.position + 1}`;
  // }
  constructor(private data: GoeDetailService, private tostre: ToastrService) {}

  ngOnInit() {
    this.data.getGoeUserList(this.GOEUserId).subscribe((userList) => {
      this.goeUserListy = userList.getGoeSourceUserList;
      this.data.changeList(this.goeUserListy);
      this.dataSource = new MatTableDataSource(this.goeUserListy);
      this.dataSource.sort = this.sort;
      this.sort.disableClear = true;
    });
    this.data.currentAdminId.subscribe((message) => {
      this.currentUserId = message;
    });
    this.selectedAdmin.push(this.GOEUserId.toString());
    console.log("Dexter2", this.GOEUserId);
    console.log("DEXTERRR", this.selectedAdmin);
    //  this.gettingLeaderList();
    this.gettingPreLeaderList();
  }

  // gettingLeaderList() {
  //   //this.data.changeMessageFunction("true");
  //   this.data.getGoeUserList(this.GOEUserId).subscribe((userList) => {
  //     console.log("Nice");
  //     this.selectedLeaderList = userList.getGoeSourceUserList;
  //   });
  // }

  // toastr warning/success message
  showInvalid(msg) {
    this.tostre.warning(msg, "", {
      positionClass: "toast-top-right",
    });
  }

  showValid(validMsg) {
    this.tostre.success(validMsg, "", {
      positionClass: "toast-top-right",
    });
  }

  gettingPreLeaderList() {
    this.data.GoeLeaderList(+this.gId).subscribe((userList) => {
      this.selectedLeaderList = userList.goeLeaderList;
      console.log("thsi", this.selectedLeaderList);
    });
  }
}
