import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RestricteduselistComponent } from './restricteduselist.component';

describe('RestricteduselistComponent', () => {
  let component: RestricteduselistComponent;
  let fixture: ComponentFixture<RestricteduselistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RestricteduselistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RestricteduselistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
