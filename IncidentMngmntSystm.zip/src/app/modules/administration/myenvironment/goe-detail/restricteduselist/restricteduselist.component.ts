import { Component, OnInit, Output, EventEmitter, Input } from "@angular/core";

import { GoeDetailService } from "../goe-detail.service";
import { MatTableDataSource } from "@angular/material/table";
import { Router, ActivatedRoute } from "@angular/router";
import { myEnvironmentService } from "../../myenvironment.service";
import { StorageService } from '../../../../../services/storage.service';
import { UserPermissionService } from "src/app/services/user-permission.service";
@Component({
  selector: "app-restricteduselist",
  templateUrl: "./restricteduselist.component.html",
  styleUrls: ["./restricteduselist.component.scss"]
})
export class RestricteduselistComponent implements OnInit {
  displayedColumns = [
    "companyname",
    "companysubdivisionname",
    "companytype",
    "status"
  ];
  // displayedColumns = ['companyname', 'companysubdivisionname', 'companytype'];
  // dataSource = ELEMENT_DATA;

  userGoeProfile = null
  userData = null;
  authToken = null;

  restricted = "0"
  @Output() messageEvent = new EventEmitter<string>();
  @Input() childMessage: any;

  constructor(
    private GoeDetailService: GoeDetailService,
    private route: ActivatedRoute,
    private myEnvironmentService: myEnvironmentService,
    private storage: StorageService,
    public UserPermission: UserPermissionService
  ) {
    //... Read User Data ...
    this.authToken = this.storage.getData("token");
    this.userData = JSON.parse(this.storage.getData("UserData"));
  }

  dataSource: MatTableDataSource<any>;
  companyList: any = [];
  GoeID: any = false;
  restrictedListLength: any;


  ngOnInit() {
    let goeID = this.route.snapshot.paramMap.get("id");
    if (goeID) {
      goeID = atob(goeID);
      this.GoeID = goeID;
      this.getCompanyList();
      this.GetRestrictCompanybyGOE();
      this.getGoeProfile(this.GoeID);
    }    
  }

  /* getCompanyList() {    
    this.GoeDetailService.currentCompany.subscribe(resp => {
      let result: any;
      result = resp;      
      console.log("Ram -- ", result)
      /* if (result != "") {       
        for (let i = 0; i < result.length; i++) {          
          this.companyList.push(result[i]);
        }
        this.dataSource = new MatTableDataSource(this.companyList);        
        this.updateGOECompanyRestrict(result);
      }else{
        if(this.companyList.length == 0){
          this.restricted = "0"
          this.messageEvent.emit(this.restricted)
        }
      } * /
    });
  } */

  getCompanyList() {    
         
      console.log("Ram 11 -- ", this.childMessage)
      /* if (result != "") {       
        for (let i = 0; i < result.length; i++) {          
          this.companyList.push(result[i]);
        }
        this.dataSource = new MatTableDataSource(this.companyList);        
        this.updateGOECompanyRestrict(result);
      }else{
        if(this.companyList.length == 0){
          this.restricted = "0"
          this.messageEvent.emit(this.restricted)
        }
      } */
    
  }

  updateGOECompanyRestrict(tempList) {
    let GlobalEnvironmentID = this.GoeID;
    let GoeDetailService = this.GoeDetailService;
    // console.log(tempList)
    let CompanyIDS = "";
    for (let i = 0; i < tempList.length; i++) {
      let data = {
        GOECompanyRestrictID: 0,
        GlobalEnvironmentID: +GlobalEnvironmentID,
        CompanyIds: +tempList[i].CompanyID
      };
      // console.log(data);
      GoeDetailService.updateGOECompanyRestrict(data).subscribe(resp => {
        // console.log(resp)
        this.updateGlobalEnvironment()
      });
    }    
  }


  GetRestrictCompanybyGOE() {
    this.GoeID;
    let data = {
      GlobalEnvironmentID: +this.GoeID
    };
    let result: any;
    this.GoeDetailService.GetRestrictCompanybyGOE(data).subscribe(resp => {
      result = resp.getRestrictCompanybyGOE;
      var filtered = this.companyList.filter(function(el) {
        return el != "";
      });
      this.companyList = filtered;
      let companyList = [];
      result.forEach(function(item, i) {
        companyList.push(item);
      });
      this.restrictedListLength = result.length;
      this.GoeDetailService.changeRestrictedUsers(this.restrictedListLength);
      // console.log("testing the right way", result.length);
      //console.log(companyList)
      this.companyList = companyList;
      this.dataSource = new MatTableDataSource(this.companyList);
    });
  }

  getGoeProfile(goeID: any) {
    const param = {      
      GoeId: goeID ? goeID : 0,
      UserId: this.userData[0].UserID      
    };
    let result: any;
    this.GoeDetailService.GoeProfile(param).subscribe(response => {
      result = response.GoeProfile[0];
      this.userGoeProfile = result;          
    });
  }

  updateGlobalEnvironment(){
    let GoeData = this.userGoeProfile
    let finalData = {
      GlobalEnvironmentID: GoeData.GlobalEnvironmentID,
      EnvironmentName: GoeData.EnvironmentName,
      EnvironmentDescription: GoeData.EnvironmentDescription,
      IsActive: (GoeData.IsActive) ? 1 : 0,
      IsAssigned: (GoeData.IsAssigned) ? 1 : 0,
      IsRestrictedUse: 1,
      UserId: this.userData[0].UserID
    };
    this.myEnvironmentService.updateGlobalEnvironment(finalData).subscribe(resp => {
      let result = resp; 
      console.log(result)     
    });
  }

}

/* export interface PeriodicElement {
  companyname: string;
  companysubdivisionname: string;
  companytype: string;
  action: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {
    companyname: "LoremIpsum",
    companysubdivisionname: "LoremIpsum",
    companytype: "LoremIpsum",
    action: ""
  },
  {
    companyname: "LoremIpsum",
    companysubdivisionname: "LoremIpsum",
    companytype: "LoremIpsum",
    action: ""
  }
]; */
