import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GoeDetailComponent } from './goe-detail.component';

describe('GoeDetailComponent', () => {
  let component: GoeDetailComponent;
  let fixture: ComponentFixture<GoeDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GoeDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GoeDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
