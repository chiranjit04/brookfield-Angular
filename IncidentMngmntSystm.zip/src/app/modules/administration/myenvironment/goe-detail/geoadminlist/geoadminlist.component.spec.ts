import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GeoadminlistComponent } from './geoadminlist.component';

describe('GeoadminlistComponent', () => {
  let component: GeoadminlistComponent;
  let fixture: ComponentFixture<GeoadminlistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GeoadminlistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GeoadminlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
