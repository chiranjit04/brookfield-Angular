import { Component, OnInit, ViewChild, Input } from "@angular/core";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { GoeDetailService } from "../goe-detail.service";
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { GoeadminComponent } from "../goeadmin/goeadmin.component";

import { Router, ActivatedRoute } from "@angular/router";
import { UserPermissionService } from "src/app/services/user-permission.service";
import { StorageService } from "src/app/services/storage.service";

export interface GoeAdminTable {
  GOEUserId: any;
  GlobalEnvironmentId: any;
  Name: string;
  PositionTitle: string;
  CompanyName: string;
  Subdivision: any;
  PhoneNumber: any;
  Email: any;
}

const ELEMENT_DATA: GoeAdminTable[] = [];

@Component({
  selector: "app-geoadminlist",
  templateUrl: "./geoadminlist.component.html",
  styleUrls: ["./geoadminlist.component.scss"],
})
export class GeoadminlistComponent implements OnInit {
  dataSource: MatTableDataSource<any>;
  userData: any;
  @Input() createdUserId;
  @Input() isGoeAdminFlag;
  constructor(
    private goeDetailService: GoeDetailService,
    private route: ActivatedRoute,
    public UserPermission: UserPermissionService,
    public dialog: MatDialog,
    public storage: StorageService
  ) {
    this.userData = JSON.parse(this.storage.getData("UserData"));
  }
  goeAdminListArray: any = [];
  displayedColumns: string[] = [
    "Name",
    "PositionTitle",
    "CompanyName",
    "Subdivsion",
    "PhoneNumber",
    "Email",
    "Action",
  ];

  @ViewChild(MatSort, { static: true }) sort: MatSort;
  GoeID: any = 0;
  currentUserID: any;
  GlobalEnvironmentId: any;
  GOEUserTypeId: any;
  IsActiveToggle: any;
  GlobalEnvironmentID: any;
  selectedAdmin: any = false;

  ngOnInit() {
    let goeID = this.route.snapshot.paramMap.get("id");
    if (goeID) {
      goeID = atob(goeID);
      this.GoeID = goeID;
    }

    this.GlobalEnvironmentID = this.GoeID;
    // let GlobalEnvironmentID = 2;
    this.goeDetailService
      .GOEAdminList(this.GlobalEnvironmentID)
      .subscribe((goeAdminList) => {
        this.goeAdminListArray = goeAdminList.goeAdminList;
        this.dataSource = new MatTableDataSource(this.goeAdminListArray);

        console.log("admin screen data", this.goeAdminListArray);

        this.goeDetailService.changeMessageAdmin(this.goeAdminListArray);
        this.dataSource.sort = this.sort;
        this.sort.disableClear = true;
      });
    this.goeDetailService.currentMessageAdmin.subscribe((r: any) => {
      if (typeof r == "string") {
        return;
      }
      console.log("checked", r);
      this.goeAdminListArray = r;
      this.dataSource = new MatTableDataSource(this.goeAdminListArray);
      console.log("WPWPWPW", this.goeAdminListArray);
    });
  }

  onEditOpen(
    GlobalEnvironmentId: any = this.GoeID,
    UserId: any,
    GOEUserTypeId: any = 1
  ) {
    this.currentUserID = UserId;
    const dialogRef = this.dialog.open(GoeadminComponent, {
      width: "70%",
      maxWidth: "100vw",
    });
    dialogRef.componentInstance.GOEUserId = +UserId;
    dialogRef.componentInstance.gId = +this.GoeID;
    this.goeDetailService.getGoeUserList(+UserId).subscribe((data) => {
      console.log("what are we getting in admin", data.getGoeSourceUserList);
    });

    this.goeDetailService.changeMessageAdminId(this.currentUserID);
    console.log("Let me check", this.currentUserID);
  }

  applyFilter(event: any) {
    const filterValue = (event.target || {}).value;
    this.dataSource.filter = (filterValue || "").trim().toLowerCase();
  }

  newMessage() {
    this.goeDetailService.changeMessageAdmin("Hello from Sibling");
  }

  onClickActive(GOEUserId, IsActive) {
    //console.log(GOEUserId);
    if (IsActive === true) {
      this.IsActiveToggle = 0;
    } else {
      this.IsActiveToggle = 1;
    }

    //console.log("Toggle", this.IsActiveToggle);
    this.goeDetailService
      .onClickActiveService(GOEUserId, +this.IsActiveToggle)
      .subscribe((data) => {
        this.goeDetailService.GOEAdminList(this.GoeID).subscribe((d) => {
          console.log("Toggle", d);
          this.dataSource = new MatTableDataSource(d.goeAdminList);
        });
        //console.log("here is the result", data);
      });
  }

  onAdminClick(data: any) {
    // console.log("Z5", data);
    if (this.selectedAdmin == data.GOEUserId) {
      this.selectedAdmin = !this.selectedAdmin;
    } else {
      this.selectedAdmin = data.GOEUserId;
    }
  }
}
