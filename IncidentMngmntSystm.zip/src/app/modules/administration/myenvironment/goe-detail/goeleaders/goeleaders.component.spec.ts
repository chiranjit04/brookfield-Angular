import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GoeleadersComponent } from './goeleaders.component';

describe('GoeleadersComponent', () => {
  let component: GoeleadersComponent;
  let fixture: ComponentFixture<GoeleadersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GoeleadersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GoeleadersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
