import { Component, OnInit, ViewChild } from "@angular/core";
import { SelectionModel } from "@angular/cdk/collections";
import { MatTableDataSource } from "@angular/material/table";
import { GoeDetailService } from "../goe-detail.service";
import { MatDialog } from "@angular/material";
import { MatSort } from "@angular/material/sort";
import swal from "sweetalert2";
export interface UserTable {
  UserId: any;
  GlobalEnvironmentId: any;
  Name: string;
  PositionTitle: string;
  CompanyName: string;
  Subdivision: any;
  PhoneNumber: any;
  Email: any;
}

@Component({
  selector: "app-goeleaders",
  templateUrl: "./goeleaders.component.html",
  styleUrls: ["./goeleaders.component.scss"],
})
export class GoeleadersComponent implements OnInit {
  selectedRowIndex: number = -1;
  selectedUsers: any = [];
  message: any = [];
  goeUserListy: any = [];
  selectedAdminList: any = [];
  dataSource: MatTableDataSource<any>;
  displayedColumns: string[] = [
    "Name",
    "PositionTitle",
    "CompanyName",
    "Subdivsion",
  ];
  // dataSource = new MatTableDataSource<UserTable>(ELEMENT_DATA);
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  GlobalEnvironmentID: any;
  GOEUserTypeId = 2; // for leaders
  selection = new SelectionModel<UserTable>(true, []);
  highlightedRows: any = [];
  ids: any = [];
  selectedLeader = [];
  GOEUserId: any;
  UserId: any = 1;
  currentUserId: any;
  removedItemLeader: any = "";
  IsAssigned: any = 1;
  // globalUserId: any;
  gId: any;

  highlited(row) {
    this.gettingPreAdmistList();
    console.log("selected1", this.selectedAdminList);
    this.selectedAdminList = this.selectedAdminList.map((data) => {
      return data.UserID;
    });
    console.log("selected", this.selectedAdminList);
    if (this.selectedAdminList.includes(row.UserId)) {
      swal
        .fire({
          text:
            "This User is already assigned as Admin. Do you want to change it to Leader?",
          showCancelButton: true,
          confirmButtonText: "Yes",
          cancelButtonText: "No",
        })
        .then((result) => {
          if (result.value) {
            console.log("hi");
            this.selectedLeader.push(row.UserId);
            this.data
              .updateGoeUser(+this.gId, row.UserId, 1, 0)
              .subscribe((x) => {
                this.data.GOEAdminList(+this.gId).subscribe((y) => {
                  console.log("List refreshed", y);
                  this.data.changeMessageAdmin(y.goeAdminList);
                });
              });

            // this.selectedUsers.splice(index, 1);
          } else {
            console.log("hi cancel");
            this.gettingPreAdmistList();
            return false;
          }
        });
    } else {
      if (this.selectedLeader.includes(row.UserId)) {
        let index = this.selectedLeader.indexOf(row.UserId);
        this.selectedLeader.splice(index, 1);
        this.selectedUsers.splice(index, 1);
        this.data
          .updateGoeUser(+this.gId, this.currentUserId, 2, 0)
          .subscribe((x) => {
            this.data.GoeLeaderList(+this.gId).subscribe((y) => {
              console.log("List refreshed", y);
              if (this.selectedLeader) this.data.changeMessage(y.goeLeaderList);
            });
          });
      } else if (this.currentUserId == row.UserId) {
        this.currentUserId = false;
        this.selectedLeader.push(row.UserId);
      } else {
        this.selectedLeader.push(row.UserId);
      }
    }

    console.log("DEXTERRR check", this.selectedLeader);
  }

  onAcceptSelections(
    GlobalEnvironmentID,
    selectedLeader: any,
    GOEUserTypeId,
    IsAssigned = 1
  ) {
    console.log("let us see what is coming", this.gId, this.selectedLeader);
    if (this.selectedLeader.length > 0) {
      this.data
        .updateGoeUser(
          (GlobalEnvironmentID = +this.gId),
          this.selectedLeader,
          GOEUserTypeId,
          this.IsAssigned
        )
        .subscribe((x) => {
          // console.log("let me", this.gId);
          this.data.GoeLeaderList(GlobalEnvironmentID).subscribe((y) => {
            console.log("List refreshed", y);
            if (this.selectedLeader) this.data.changeMessage(y.goeLeaderList);
          });
        });
    } else {
      console.log("hurray", this.gId);
      this.data
        .updateGoeUser(
          (GlobalEnvironmentID = +this.gId),
          this.currentUserId,
          GOEUserTypeId,
          0
        )
        .subscribe((x) => {
          console.log("mice", +this.gId, this.currentUserId, GOEUserTypeId);
          this.data.GoeLeaderList(GlobalEnvironmentID).subscribe((y) => {
            console.log("List refreshed", y);
            if (this.selectedLeader) this.data.changeMessage(y.goeLeaderList);
          });
        });
    }

    // this.data.currentRemoveLeader.subscribe(d => {
    //   console.log("let us see what is coming here", d);
    //   this.removedItemLeader = d;
    // });
    // this.data.changeMessageRemove1(this.removedItemLeader);
  }

  constructor(private data: GoeDetailService, public dialog: MatDialog) {}

  ngOnInit() {
    this.data.getGoeUserList(this.GOEUserId).subscribe((userList) => {
      console.log("Nice");
      this.goeUserListy = userList.getGoeSourceUserList;

      this.data.changeMessageWarning(this.goeUserListy);
      this.dataSource = new MatTableDataSource(this.goeUserListy);
      this.dataSource.sort = this.sort;
      this.sort.disableClear = true;
    });

    this.data.currentLeaderId.subscribe((message) => {
      this.currentUserId = message;
    });
    this.selectedLeader.push(this.GOEUserId.toString());
    console.log("Dexter2", this.GOEUserId);
    console.log("DEXTERRR", this.selectedLeader);
    this.gettingAdminList();
    this.gettingPreAdmistList();
    // this.sendinFunction();
  }

  gettingAdminList() {
    //this.data.changeMessageFunction("true");
    this.data.currentList.subscribe((data) => {
      console.log("Nice 3", data);
      this.selectedAdminList = data;
    });
  }

  gettingPreAdmistList() {
    this.data.GOEAdminList(+this.gId).subscribe((userList) => {
      this.selectedAdminList = userList.goeAdminList;
      console.log("thsi", this.selectedAdminList);
    });
  }
}
