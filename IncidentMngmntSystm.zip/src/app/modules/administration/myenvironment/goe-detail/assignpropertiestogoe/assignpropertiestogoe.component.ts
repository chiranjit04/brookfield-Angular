import { Component, Input, OnInit } from "@angular/core";
import { GoeDetailService } from "../goe-detail.service";
import { Router, ActivatedRoute } from "@angular/router";
import { StorageService } from "../../../../../services/storage.service";
import { UserPermissionService } from "src/app/services/user-permission.service";

@Component({
  selector: "app-assignpropertiestogoe",
  templateUrl: "./assignpropertiestogoe.component.html",
  styleUrls: ["./assignpropertiestogoe.component.scss"],
})
export class AssignpropertiestogoeComponent implements OnInit {
  companylist: any;
  companylistbyuserid: any;
  companysubdivison: any;
  companytype: any;
  propertybycompany: any;

  GoeID: any = false;

  selectedCompanyId = false;
  selectedSubdivisionId = false;
  selectedCompanyTypeId = false;
  selectedPropertyId = false;
  GlobalEnvironmentSubDivision: any;
  userData = null;
  authToken = null;
  UserID: number;

  GlobalEnvironmentID = 0;
  GlobalEnvironmentName = "";
  GOENumber = "";
  GlobalEnvironmentDetails = null;
  @Input() createdUserId;
  @Input() isGoeAdminFlag;
  defaultFilter = {
    CompanyId: 0,
    CompanySubdivisionId: 0,
    CompanyTypeId: 0,
    GlobalEnvironmentID: 0,
  };

  constructor(
    private GoeDetailService: GoeDetailService,
    private route: ActivatedRoute,
    private storage: StorageService,
    public UserPermission: UserPermissionService
  ) {
    this.GlobalEnvironmentDetails = JSON.parse(
      this.storage.getData("GlobalEnvironmentDetails")
    );
    if (this.GlobalEnvironmentDetails) {
      this.GlobalEnvironmentID = this.GlobalEnvironmentDetails.GlobalEnvironmentId;
      this.GlobalEnvironmentName = this.GlobalEnvironmentDetails.GlobalEnvironmentName;
      this.GOENumber = this.GlobalEnvironmentDetails.GOENo;
      this.defaultFilter.GlobalEnvironmentID = this.GlobalEnvironmentID;
    }

    this.authToken = this.storage.getData("token");
    this.userData = JSON.parse(this.storage.getData("UserData"));
  }

  ngOnInit() {
    let goeID = this.route.snapshot.paramMap.get("id");
    if (goeID) {
      goeID = atob(goeID);
      this.GoeID = goeID;
      this.getCompanyListByUserId();
      // this.GetCompanySubdivisonbyUserid();
      this.GetCompanyTypeByUserId();
      // this.GetPropertybyCompanySubdivion(this.GoeID, 0, 0, 0);
      this.GetPropertybyCompanySubdivion();
    }
  }

  /**
   *
   * Select Company
   *
   */

  companySelected(CompanyID) {
    if (this.selectedCompanyId == CompanyID) {
      this.selectedCompanyId = false;
      // this.GetPropertybyCompanySubdivion(this.GoeID, 0, 0, 0);
      // this.defaultFilter.CompanyId = 0;
      // this.GetPropertybyCompanySubdivion();
    } else {
      this.selectedCompanyId = CompanyID;
      // this.propertybycompany = this.GetPropertybyCompanySubdivion(this.GoeID, CompanyID, 0, 0);
      this.GetCompanySubdivisonbyUserid(CompanyID);
    }
    this.selectedSubdivisionId = false;
    this.selectedCompanyTypeId = false;
    this.defaultFilter.CompanyId = +this.selectedCompanyId;
    this.defaultFilter.CompanySubdivisionId = 0;
    this.defaultFilter.CompanyTypeId = 0;
    this.GetPropertybyCompanySubdivion();
  }

  /**
   *
   * Select SubDivision
   *
   */

  companysubdivisionSelected(CompanyID) {
    if (this.selectedSubdivisionId == CompanyID) {
      this.selectedSubdivisionId = false;
      // this.GetPropertybyCompanySubdivion(this.GoeID, 0, 0, 0);
      // this.defaultFilter.CompanySubdivisionId = 0;
      // this.GetPropertybyCompanySubdivion();
    } else {
      this.selectedSubdivisionId = CompanyID;
      // this.propertybycompany = this.GetPropertybyCompanySubdivion(this.GoeID, 0, CompanyID, 0);
      // this.propertybycompany = this.GetPropertybyCompanySubdivion();
    }
    this.selectedCompanyTypeId = false;
    this.defaultFilter.CompanySubdivisionId = +this.selectedSubdivisionId;
    this.defaultFilter.CompanyTypeId = 0;
    this.propertybycompany = this.GetPropertybyCompanySubdivion();
    console.log(this.propertybycompany);
  }

  /**
   *
   * Select Company Type
   *
   */

  companytypeSelected(CompanyTypeID) {
    if (this.selectedCompanyTypeId == CompanyTypeID) {
      this.selectedCompanyTypeId = false;
      // this.GetPropertybyCompanySubdivion(this.GoeID, 0, 0, 0);
      // this.defaultFilter.CompanyTypeId = 0;
      // this.GetPropertybyCompanySubdivion();
    } else {
      this.selectedCompanyTypeId = CompanyTypeID;
      // this.propertybycompany = this.GetPropertybyCompanySubdivion(this.GoeID, 0, 0, CompanyTypeID);
      // this.propertybycompany = this.GetPropertybyCompanySubdivion();
    }
    this.defaultFilter.CompanyTypeId = +this.selectedCompanyTypeId;
    this.propertybycompany = this.GetPropertybyCompanySubdivion();
    console.log(this.propertybycompany);
  }

  /**
   *
   * Select Property
   *
   */

  propertySelected(PropertyID, IsAssigned) {
    //this.propertybycompany
    let obj = this.propertybycompany.find((o) => o.PropertyID == PropertyID);
    let index = this.propertybycompany.indexOf(obj);
    this.propertybycompany.fill(
      (obj.IsAssigned = !obj.IsAssigned),
      index,
      index++
    );

    const data = {
      PropertyID: +PropertyID,
      GlobalEnvironmentID: this.GoeID,
      IsAssigned: obj.IsAssigned == 1 ? 1 : 0,
    };

    this.AssignGoeToProperty(data);
  }
  /**
   *
   * Get Company List by UserId
   * @param UserId
   *
   */

  // UserId: any

  getCompanyListByUserId() {
    const obj = {
      UserId: +this.userData[0].UserID,
    };
    let result;
    this.GoeDetailService.GetCompanybyUserid(obj).subscribe((res) => {
      result = res;
      this.companylistbyuserid = result.getCompanybyUserid;
    });
  }

  /**
   * Get CompanySubdivision List by UserId
   * @param UserId
   *
   */
  GetCompanySubdivisonbyUserid(compID) {
    const obj = {
      ComapnyId: +compID,
    };
    let result;
    this.GoeDetailService.GetComapnySubdivisonByComapnyId(obj).subscribe(
      (res) => {
        result = res;
        // console.log(result);
        this.companysubdivison = result.getComapnySubdivisonbyUserid;
      }
    );
  }

  /**
   * Get Company Type by UserId
   * @param UserId
   *
   */

  GetCompanyTypeByUserId() {
    const obj = {
      UserId: +this.userData[0].UserID,
    };

    let result;
    this.GoeDetailService.GetCompanyTypeByUserId(obj).subscribe((res) => {
      result = res;
      this.companytype = result.getComapnyTypeByUserId;
    });
  }

  /**
   * Get Property by Company Subdivision
   * @param CompanyId
   * @param CompanySubdivisionId
   * @param CompanyTypeId
   */

  /* GetPropertybyCompanySubdivion(GlobalEnvironmentID, CompanyId, CompanySubdivisionId, CompanyTypeId) {
    const obj = {
      GlobalEnvironmentID: +GlobalEnvironmentID,
      CompanyId: +CompanyId,
      CompanySubdivisionId: CompanySubdivisionId,
      CompanyTypeId: CompanyTypeId,
    };

    let result;
    this.GoeDetailService.GetPropertybyCompanySubdivion(obj).subscribe((res) => {
        result = res;
        this.propertybycompany = result.getPropertybyCompanySubdivion;        
      }
    );   
  } */
  GetPropertybyCompanySubdivion() {
    this.GoeDetailService.GetPropertybyCompanySubdivion(
      this.defaultFilter
    ).subscribe((result: any) => {
      this.propertybycompany = result.getPropertybyCompanySubdivion;
      console.log(this.propertybycompany);
      // console.log(this.propertybycompany);
    });
  }

  /**
   * Assign Property to Goe
   * @param PropertyID
   * @param GlobalEnvironmentID
   */

  AssignGoeToProperty(obj) {
    this.GoeDetailService.AssignGoeToProperty(obj).subscribe((res) => {
      // console.log("Assign/Unassign property to Goe===>>>>result", res);
    });
  }

  /**
   * GetGlobalEnvironmentSubDivisionbyCompanyId
   * @param CompanyID
   * @param
   *
   * */

  getGlobalEnvironmentSubDivisionbyCompanyId(CompanyID, GlobalEnvironmentID) {
    const obj = {
      CompanyId: CompanyID,
      GlobalEnvironmentID: GlobalEnvironmentID,
    };

    let result: any;
    this.GoeDetailService.GetGlobalEnvironmentSubDivisionbyCompanyId(
      obj
    ).subscribe((res) => {
      result = res;
      this.GlobalEnvironmentSubDivision =
        result.GetGlobalEnvironmentSubDivisionbyCompanyId;
      // console.log(this.GlobalEnvironmentSubDivision);
      this.selectedCompanyId = CompanyID;
    });
  }
}
