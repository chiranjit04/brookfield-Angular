import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignpropertiestogoeComponent } from './assignpropertiestogoe.component';

describe('AssignpropertiestogoeComponent', () => {
  let component: AssignpropertiestogoeComponent;
  let fixture: ComponentFixture<AssignpropertiestogoeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssignpropertiestogoeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignpropertiestogoeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
