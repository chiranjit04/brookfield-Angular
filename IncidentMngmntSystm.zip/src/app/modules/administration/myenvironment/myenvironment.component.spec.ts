import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyenvironmentComponent } from './myenvironment.component';

describe('MyenvironmentComponent', () => {
  let component: MyenvironmentComponent;
  let fixture: ComponentFixture<MyenvironmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyenvironmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyenvironmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
