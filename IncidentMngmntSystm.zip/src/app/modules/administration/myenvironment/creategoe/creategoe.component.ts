import { Component, OnInit } from "@angular/core";
import { GoeDetailService } from "../goe-detail/goe-detail.service";
import { myEnvironmentService } from "../myenvironment.service";
import { MatDialog } from "@angular/material/dialog";
import { GoeadminComponent } from "../goe-detail/goeadmin/goeadmin.component";
import { GoeleadersComponent } from "../goe-detail/goeleaders/goeleaders.component";
import { RestricteduseComponent } from "../goe-detail/restricteduse/restricteduse.component";
import { StorageService } from "../../../../services/storage.service";

import {
  FormControl,
  FormGroupDirective,
  NgForm,
  Validators,
  FormGroup,
  FormBuilder,
} from "@angular/forms";
import Swal from "sweetalert2";
import { Router, ActivatedRoute } from "@angular/router";
import { UserPermissionService } from "../../../../services/user-permission.service";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-creategoe",
  templateUrl: "./creategoe.component.html",
  styleUrls: ["./creategoe.component.scss"],
})
export class CreategoeComponent implements OnInit {
  displayedColumns: string[] = [
    "companyname",
    "companysubdivisionname ",
    "companytype",
    "action",
  ];
  Goe: any;

  addgop = false;
  labelgoe = false;
  descriptiongoe = false;

  timeList = [];
  userGoeProfile = null;
  dataSource: any;

  GlobalEnvironmentID = 0;
  GlobalEnvironmentName = "";
  GOENumber = "";
  GlobalEnvironmentDetails = null;

  userData = null;
  authToken = null;
  EnvironmentName_: string = "";
  EnvironmentDescription_: string = "";
  GoeID: any = false;

  GOEProprties = {
    status: "1",
    assigned: "0",
    restricted: "0",
  };
  restrictedUseList: any[];

  // @ViewChild('callAPIDialog') callAPIDialog: TemplateRef<any>;

  constructor(
    private goeDetailService: GoeDetailService,
    private myEnvironmentService: myEnvironmentService,
    public dialog: MatDialog,
    public router: Router,
    private route: ActivatedRoute,
    private UserPermission: UserPermissionService,
    private toaster: ToastrService,
    private storage: StorageService
  ) {
    //... Read User Data ...
    this.authToken = this.storage.getData("token");
    this.userData = JSON.parse(this.storage.getData("UserData"));
    if (this.authToken == null) {
      this.router.navigate(["/login"]);
    }

    if (!this.UserPermission.checkPermission("create_new_goe")) {
      this.router.navigate(["/products/administration/goe/mygoe"]);
      this.toaster.warning("You don't have permission.", "", {
        positionClass: "toast-top-right",
      });
    }

    this.GlobalEnvironmentDetails = JSON.parse(
      this.storage.getData("GlobalEnvironmentDetails")
    );
    if (this.GlobalEnvironmentDetails) {
      this.GlobalEnvironmentID = this.GlobalEnvironmentDetails.GlobalEnvironmentId;
      this.GlobalEnvironmentName = this.GlobalEnvironmentDetails.GlobalEnvironmentName;
      this.GOENumber = this.GlobalEnvironmentDetails.GOENo;
    }
    //... Read User Data ...
    this.authToken = this.storage.getData("token");
    this.userData = JSON.parse(this.storage.getData("UserData"));
  }
  //@ViewChild(MatSort, {static: true}) sort: MatSort;

  GoeForm = new FormGroup({
    GlobalEnvironmentID: new FormControl(""),
    EnvironmentName: new FormControl("", [Validators.required]),
    EnvironmentDescription: new FormControl("", [Validators.required]),
  });
  submitted = false;
  get GoeF() {
    return this.GoeForm.controls;
  }

  checkGoe() {
    if (this.GlobalEnvironmentID) {
      return true;
    } else {
      Swal.fire({
        text: "Please select your GOE first",
      }).then((result) => {
        //if (result.value) {
        this.router.navigate(["products/administration/goe/mygoe"]);
        //}
      });
      return false;
    }
  }

  ngOnInit() {
    //if(this.checkGoe()){
    let goeID = this.route.snapshot.paramMap.get("goeID");
    if (!goeID) {
      this.addgop = !this.addgop;
    } else {
      goeID = atob(goeID);
      this.GoeID = goeID;
    }
    this.getGoeProfile(this.GoeID);
    //}
  }

  getGoeProfile(goeID: any) {
    const param = {
      //GoeId: this.GlobalEnvironmentID,
      GoeId: goeID ? goeID : 0,
      UserId: this.userData[0].UserID,
      //PropertyId: this.userData[0].PropertyID
    };
    this.goeDetailService.GoeProfile(param).subscribe((response) => {
      this.userGoeProfile = response.GoeProfile[0];
      console.log("profile", this.userGoeProfile);
    });
  }

  formOpen = false;
  createNewGOE() {
    this.formOpen = !this.formOpen;
    this.addgop = !this.addgop;
  }

  UpdateGoeRecord() {
    this.submitted = true;
    if (this.GoeForm.get("EnvironmentName").value == "") {
      return;
    } else {
      let postData = this.GoeForm.value;
      let EnvironmentName = postData.EnvironmentName.trim();
      let EnvironmentDescription = postData.EnvironmentDescription.trim();
      if (EnvironmentName == "") {
        Swal.fire({ text: "Title Name is required" });
        return false;
      }
      // if (EnvironmentDescription == "") {
      //   Swal.fire({ text: "Description is required" });
      //   return false;
      // }
      //console.log(this.GOEProprties)
      let finalData = {
        GlobalEnvironmentID: "0",
        EnvironmentName: EnvironmentName,
        EnvironmentDescription: EnvironmentDescription,
        IsActive: this.GOEProprties.status == "1" ? 1 : 0,
        IsAssigned: this.GOEProprties.assigned == "1" ? 1 : 0,
        IsRestrictedUse: this.GOEProprties.restricted == "1" ? 1 : 0,
        UserId: this.userData[0].UserID,
      };
      // console.log(finalData)
      let result: any;
      this.myEnvironmentService
        .updateGlobalEnvironment(finalData)
        .subscribe((resp) => {
          result = resp;
          if (
            result.UpdateGlobalEnvironment.recordset[0].Message ==
            "Environment Name Already exist. "
          ) {
            Swal.fire({ text: "Environment Name Already exist." });
          } else {
            // this.addgop = !this.addgop
            this.GoeForm.reset();
            this.submitted = false;
            let GoeID = result.UpdateGlobalEnvironment.recordset[0].ID;
            // this.router.navigate(['products/administration/goe/mygoe/detail', {goeID: btoa(GoeID)}]);
            this.router.navigate([
              "products/administration/goe/mygoe/detail/" + btoa(GoeID),
            ]);
            // this.getGoeProfile(GoeID);
            // this.GoeID = GoeID
          }
        });
    }
  }

  CancelGoe() {
    this.GoeForm.reset();
    //this.addgop = !this.addgop
  }

  searchVal() {}

  applyFilter(object: any) {}

  /**
   * Edit Goe Name
   * @param userGoeProfile
   */
  editGoeName(userGoeProfile) {
    console.log(userGoeProfile);
    this.labelgoe = !this.labelgoe;
    this.EnvironmentName_ = userGoeProfile.EnvironmentName;
  }
  /**
   * Update Goe Name
   * @param userGoeProfile
   */
  updateGoeName(userGoeProfile) {
    this.labelgoe = !this.labelgoe;
    const obj = {
      GlobalEnvironmentID: userGoeProfile.GlobalEnvironmentID,
      EnvironmentName: this.EnvironmentName_,
      EnvironmentDescription: userGoeProfile.EnvironmentDescription,
      IsActive: userGoeProfile.IsActive ? userGoeProfile.IsActive : false,
      IsAssigned: userGoeProfile.IsAssigned ? userGoeProfile.IsAssigned : false,
      IsRestrictedUse: userGoeProfile.IsRestrictedUse
        ? userGoeProfile.IsRestrictedUse
        : false,
      UserId: this.userData[0].UserID,
    };

    if (obj.EnvironmentName == "") {
      Swal.fire({ text: "Environment Name is required" });
      return false;
    }
    // console.log('update Goe Data ===>>', obj)
    this.myEnvironmentService.updateGlobalEnvironment(obj).subscribe((res) => {
      this.getGoeProfile(obj.GlobalEnvironmentID);
      // console.log('update Goe Data', res)
    });
  }

  /**
   * Edit Goe Description
   * @param userGoeProfile
   */
  editGoeDesc(userGoeProfile) {
    this.descriptiongoe = !this.descriptiongoe;
    this.EnvironmentDescription_ = userGoeProfile.EnvironmentDescription;
    // console.log('userGoeProfile for desc==>>', userGoeProfile)
  }

  /**
   * Update Goe Description
   * @param userGoeProfile
   */
  updateGoeDesc(userGoeProfile) {
    this.descriptiongoe = !this.descriptiongoe;
    const obj = {
      GlobalEnvironmentID: userGoeProfile.GlobalEnvironmentID,
      EnvironmentName: userGoeProfile.EnvironmentName,
      EnvironmentDescription: this.EnvironmentDescription_,
      IsActive: userGoeProfile.IsActive ? userGoeProfile.IsActive : false,
      IsAssigned: userGoeProfile.IsAssigned ? userGoeProfile.IsAssigned : false,
      IsRestrictedUse: userGoeProfile.IsRestrictedUse
        ? userGoeProfile.IsRestrictedUse
        : false,
      UserId: this.userData[0].UserID,
    };

    if (obj.EnvironmentDescription == "") {
      Swal.fire({ text: "Environment Description is required" });
      return false;
    }
    this.myEnvironmentService.updateGlobalEnvironment(obj).subscribe((res) => {
      this.getGoeProfile(obj.GlobalEnvironmentID);
    });
  }

  //Popups open on save
  opengoeadmin(GOEUserId: any, GoeID: any) {
    const dialogRef = this.dialog.open(GoeadminComponent, {
      width: "70%",
      maxWidth: "100vw",
    });
    dialogRef.componentInstance.GOEUserId = GOEUserId;
    dialogRef.componentInstance.gId = GoeID;
    console.log("what up", GoeID);
  }

  opengoeleaders(GOEUserId: any, GoeID: any) {
    console.log("tetsingbdfsvdfvf", GoeID);
    const dialogRef = this.dialog.open(GoeleadersComponent, {
      width: "70%",
      maxWidth: "100vw",
    });
    dialogRef.componentInstance.GOEUserId = GOEUserId;
    dialogRef.componentInstance.gId = GoeID;
  }

  showGoeWarning(name: any) {
    console.log("what  is the name", name);
    if (this.GoeForm.get("EnvironmentName").value != "") {
      console.log("we can save it up");
      this.goeDetailService.changeMessagePopup(name);
      this.UpdateGoeRecord();
    } else {
      // Swal.fire({ text: "You need to create a GOE first." });
      this.toaster.error("You need to create a GOE first.", "", {
        positionClass: "toast-top-right",
      });
    }
  }
}
