import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreategoeComponent } from './creategoe.component';

describe('CreategoeComponent', () => {
  let component: CreategoeComponent;
  let fixture: ComponentFixture<CreategoeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreategoeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreategoeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
