import { Component, OnInit } from "@angular/core";
import { ActivatedRoute, Router, UrlSegment } from "@angular/router";
import { UserPermissionService } from "../../../services/user-permission.service";
import { StorageService } from "../../../services/storage.service";
import { ManagetutorialComponent } from "../../global/managetutorial/managetutorial.component";
import { MatDialog } from "@angular/material/dialog";
import { environment } from "src/environments/environment";

@Component({
  selector: "app-administrationnav",
  templateUrl: "./administrationnav.component.html",
  styleUrls: ["./administrationnav.component.scss"],
})
export class AdministrationnavComponent implements OnInit {
  router: any;
  submenuitems: any;
  subitems: any;
  orgsubitems: any;
  propertySubitems: any;
  showItem = "goe";
  /* gotoFinishing() {
    // this.imgsrc = './assets/img/dshbrdicn-5.png';
    const link = ['/finishing'];
    this.router.navigate(link);
  } */

  UserPermissionData: any = [];
  IsTraningButtonShow: boolean;

  userData = null;  
  ProfileID: any = false;

  constructor(
    private UserPermission: UserPermissionService,
    private storage: StorageService,
    private route: Router,
    public dialog: MatDialog
  ) {
    this.userData = JSON.parse(this.storage.getData("UserData"));
    this.ProfileID = this.userData[0].ProfileID;

    this.IsTraningButtonShow = environment.IsTraningButtonShow;
    /* this.UserPermissionData = JSON.parse(this.storage.getData("UserPermissionData"));
    if(!this.UserPermissionData || this.UserPermissionData.length == 0){
      this.GetUserProfilePermission();
    } */
  }

  ngOnInit() {
    let pos = location.pathname.split("/");
    this.showItem = pos[3];
    this.submenuitems = [
      {
        routerLink: ["/products/list"],
        text: "HOME",
      },
    ];

    // let permissionData = JSON.parse(this.storage.getData("ModulePermission"));
    // let access_goe = permissionData.find(
    //   (x) => x.ResourceKey == "access_administration"
    // );
    // let goe_index = permissionData.indexOf(access_goe);
    // if (goe_index != -1) {
    //   const goe = {
    //     routerLink: ["goe"],
    //     text: "GOE MANAGEMENT",
    //   };
    //   this.submenuitems.push(goe);
    // }

    this.generateMenus();
  }

  async generateMenus() {
    this.UserPermissionData = JSON.parse(
      this.storage.getData("UserPermissionData")
    );
    //if(!this.UserPermissionData || this.UserPermissionData.length == 0){
    let result = await this.UserPermission.GetUserProfilePermission({
      ModuleIDs: "1",
    }).toPromise();
    this.UserPermissionData = result.ProfilePermissionList;
    this.storage.setData(
      "UserPermissionData",
      JSON.stringify(this.UserPermissionData)
    );
    //}

    /* main menu items */

    let goeMan = this.UserPermission.checkPermission("access_goe_management");

    if (goeMan) {
      const goe = {
        routerLink: ["goe"],
        text: "GOE MANAGEMENT",
      };
      this.submenuitems.push(goe);
    }
    let orgMan = this.UserPermission.checkPermission(
      "access_organization_management"
    );

    if (orgMan) {
      const organizationmanagement = {
        routerLink: ["organizationmanagement"],
        text: "ORGANIZATION MANAGEMENT",
      };
      this.submenuitems.push(organizationmanagement);
    }
    let propMan = this.UserPermission.checkPermission(
      "access_property_management"
    );

    if (propMan) {
      const propertymanagement = {
        routerLink: ["propertymanagement"],
        text: "PROPERTY MANAGEMENT",
      };
      this.submenuitems.push(propertymanagement);
    }

    /* GOE MANAGMENT SITEMS */
    this.subitems = [];
    if (this.UserPermission.checkPermission("access_goe_management")) {
      const mygoe = {
        routerLink: ["goe/mygoe"],
        text: "MY GOES",
      };
      this.subitems.push(mygoe);
    }
    if (this.UserPermission.checkPermission("access_incident_subject")) {
      const incidentSubject = {
        routerLink: ["goe/incident-subject"],
        text: "INCIDENT SUBJECT ",
      };
      this.subitems.push(incidentSubject);
    }
    if (this.UserPermission.checkPermission("access_reporting_set")) {
      const reportingSets = {
        routerLink: ["goe/reporting-sets"],
        text: "REPORTING SET ",
      };
      this.subitems.push(reportingSets);
    }
    if (this.UserPermission.checkPermission("access_property_use_area")) {
      const propertyUseArea = {
        routerLink: ["goe/property-use-area"],
        text: "PROPERTY USE AREA",
      };
      this.subitems.push(propertyUseArea);
    }
    //if(this.UserPermission.checkPermission("access_dispositioncodes")){
    if(this.ProfileID == 1){
      const dispositioncodes = {
        routerLink: ["goe/dispositioncodes"],
        text: "DISPOSITION CODES",
      };
      this.subitems.push(dispositioncodes);
    }
    //}
    if (this.UserPermission.checkPermission("access_dynamic_record_forms")) {
      const dynamicRecord = {
        routerLink: ["goe/dynamicrecord"],
        text: "DYNAMIC RECORD FORMS",
      };
      this.subitems.push(dynamicRecord);
    }
    if (
      this.UserPermission.checkPermission(
        "access_assign_property_profile_forms"
      )
    ) {
      const assignpropertyprofile = {
        routerLink: ["goe/assignpropertyprofile"],
        text: "ASSIGN PROPERTY PROFILE FORMS",
      };
      this.subitems.push(assignpropertyprofile);
    }
    if (this.UserPermission.checkPermission("access_banning_program")) {
      const banningmanagement = {
        routerLink: ["goe/banningmanagement"],
        text: "BANNING PROGRAM",
      };
      this.subitems.push(banningmanagement);
    }
    if (this.UserPermission.checkPermission("access_asset_management")) {
      const assetmanagement = {
        routerLink: ["goe/assetmanagement"],
        text: "ASSET MANAGEMENT",
      };
      this.subitems.push(assetmanagement);
    }

    /* Organization Management Menus */
    this.orgsubitems = [];
    if (this.UserPermission.checkPermission("access_companies_management")) {
      const companies = {
        routerLink: ["organizationmanagement/companies"],
        text: "COMPANIES",
      };
      this.orgsubitems.push(companies);
    }
    if (this.UserPermission.checkPermission("access_workgroups")) {
      const workgroups = {
        routerLink: ["organizationmanagement/workgroups"],
        text: "WORKGROUPS",
      };
      this.orgsubitems.push(workgroups);
    }
    if (this.UserPermission.checkPermission("access_profiles")) {
      const profile = {
        routerLink: ["organizationmanagement/profile"],
        text: "PROFILES",
      };
      this.orgsubitems.push(profile);
    }
    if (this.UserPermission.checkPermission("access_permissions")) {
      const permission = {
        routerLink: ["organizationmanagement/permission"],
        text: "PERMISSIONS",
      };
      this.orgsubitems.push(permission);
    }
    if (this.UserPermission.checkPermission("access_user_management")) {
      const users = {
        routerLink: ["organizationmanagement/users"],
        text: "USERS",
      };
      this.orgsubitems.push(users);
    }
    if (this.UserPermission.checkPermission("access_job_titles_management")) {
      const jobtitles = {
        routerLink: ["organizationmanagement/jobtitles"],
        text: "JOB TITLES ",
      };
      this.orgsubitems.push(jobtitles);
    }

    /* Property Management Menus */
    this.propertySubitems = [];
    if (this.UserPermission.checkPermission("access_my_properties")) {
      const propertydetail = {
        routerLink: ["propertymanagement/propertydetail"],
        text: "MY PROPERTIES",
      };
      this.propertySubitems.push(propertydetail);
    }
    if (this.UserPermission.checkPermission("access_location_codes")) {
      const locationmgt = {
        routerLink: ["propertymanagement/locationmgt"],
        text: "LOCATION MANAGEMENT",
      };
      this.propertySubitems.push(locationmgt);
    }
    if (this.UserPermission.checkPermission("access_patrol_zone_management")) {
      const patrolzonemgt = {
        routerLink: ["propertymanagement/patrolzonemgt"],
        text: "PATROL ZONE MANAGEMENT",
      };
      this.propertySubitems.push(patrolzonemgt);
    }
    if (this.UserPermission.checkPermission("access_property_profile")) {
      const propertyprofile = {
        routerLink: ["propertymanagement/propertyprofile"],
        text: "PROPERTY PROFILE",
      };
      this.propertySubitems.push(propertyprofile);
    }
    if (this.UserPermission.checkPermission("aaccess_Banning_Duration")) {
      const banningduration = {
        routerLink: ["propertymanagement/banningduration"],
        text: "BANNING DURATION",
      };
      this.propertySubitems.push(banningduration);
    }
    if (this.UserPermission.checkPermission("access_activities_library")) {
      const activities = {
        routerLink: ["propertymanagement/activities"],
        text: "ACTIVITIES LIBRARY",
      };
      this.propertySubitems.push(activities);
    }
    if (
      this.UserPermission.checkPermission("access_property_management>assets")
    ) {
      const assets = {
        routerLink: ["propertymanagement/assets"],
        text: "ASSET RECORDS",
      };
      this.propertySubitems.push(assets);
    }
    if (this.UserPermission.checkPermission("access_shifts")) {
      const shift = {
        routerLink: ["propertymanagement/shift"],
        text: "SHIFTS",
      };
      this.propertySubitems.push(shift);
    }

    /**
     * checking route as permission granted
     * for checking routes level permission
     */
    if (goeMan) {
      this.route.navigate(["products/administration/goe"]);
      this.showItem = "goe";
    } else if (orgMan) {
      this.route.navigate(["products/administration/organizationmanagement"]);
      this.showItem = "organizationmanagement";
    } else if (propMan) {
      this.route.navigate(["products/administration/propertymanagement"]);
      this.showItem = "propertymanagement";
    }
  }

  async GetUserProfilePermission() {
    let data = {
      ModuleIDs: "1",
    };
    let result = await this.UserPermission.GetUserProfilePermission(
      data
    ).toPromise();
    this.UserPermissionData = result.ProfilePermissionList;
    this.storage.setData(
      "UserPermissionData",
      JSON.stringify(this.UserPermissionData)
    );
  }

  /* callOrg() {
    if (location.pathname.split('/')[3] == 'organizationmanagement') {
      return true;
    } else {
      return false;
    }
  }

  callGoe() {
    if (location.pathname.split('/')[3] == 'goe') {
      return true;
    } else {
      return false;
    }
  }

  callProperty() {
    if (location.pathname.split('/')[3] == 'propertymanagement') {
      return true;
    } else {
      return false;
    }
  } */

  mainmenu(item, current) {
    this.storage.removeData("justCreated");
    // console.log(item[0])
    this.showItem = item[0];
    if (this.showItem == "organizationmanagement" && this.showItem != current) {
      this.storage.removeData("CompanyDetails");
    } else if (
      this.showItem == "propertymanagement" &&
      this.showItem != current
    ) {
      this.storage.removeData("PropertyDetail");
    }
  }

  openmanagetutorialpop() {
    const dialogRef = this.dialog.open(ManagetutorialComponent, {
      width: "40%",
      autoFocus: false,
    });
  }
}
