import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdministrationnavComponent } from './administrationnav.component';

describe('AdministrationnavComponent', () => {
  let component: AdministrationnavComponent;
  let fixture: ComponentFixture<AdministrationnavComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdministrationnavComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdministrationnavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
