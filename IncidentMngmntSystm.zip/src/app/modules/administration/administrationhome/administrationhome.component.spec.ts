import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdministrationhomeComponent } from './administrationhome.component';

describe('AdministrationhomeComponent', () => {
  let component: AdministrationhomeComponent;
  let fixture: ComponentFixture<AdministrationhomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdministrationhomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdministrationhomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
