import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-administrationhome",
  templateUrl: "./administrationhome.component.html",
  styleUrls: ["./administrationhome.component.scss"],
})
export class AdministrationhomeComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
