import { Component, OnInit, ViewChild } from "@angular/core";
import {
  FormGroup,
  FormControl,
  Validators,
  FormBuilder,
} from "@angular/forms";
import { SectorService } from "./sector.service";
import Swal from "sweetalert2";
import { Router } from "@angular/router";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import * as XLSX from "xlsx";
import { ToastrService } from "ngx-toastr";
import { UserPermissionService } from "../../../services/user-permission.service";
import { StorageService } from "../../../services/storage.service";
import { ServiceService } from "./../service/service.service";

@Component({
  selector: "app-sectors",
  templateUrl: "./sectors.component.html",
  styleUrls: ["./sectors.component.scss"],
})
export class SectorsComponent implements OnInit {
  addgop = false;
  propertiesassigned = false;
  propertytype = false;

  sectorGroups = [];
  sectors = [];
  properties = [];
  OnScreenList: any = [];

  showMainTable = true;
  toggle = "Edit";

  selectedSectorGroupId = false;
  selectedSectorId = false;
  selectedPropertyID = false;
  groupEditable = false;
  sectorEditable = false;
  selectedSector: any = false;

  hideTableMain = true;
  showUploadTable = false;
  locationDisplay = false;
  authToken = null;
  userData = null;
  currentUserID = false;
  UseCaseImportList: any = [];
  UploadedUseList: any = [];

  GlobalEnvironmentID = 0;
  GlobalEnvironmentName = "";
  GOENumber = "";
  GlobalEnvironmentDetails = null;
  dataSourceOne: MatTableDataSource<any>;
  dataSourceTwo: MatTableDataSource<any>;
  @ViewChild("TableOneSort", { static: false }) tableOneSort: MatSort;

  displayedColumnsOne: string[] = [
    "UsesAreaGroupName",
    "UsesAreaGroupDesc",
    "UsesAreaName",
    "UsesAreaDesc",
    "CreatedDate",
    "IsActive",
  ];

  displayedColumnsTwo: string[] = [
    "UsesAreaGroupName",
    "UsesAreaGroupDesc",
    "UsesAreaName",
    "UsesAreaDesc",
    "UsesAreaStatus",
    "Status",
    "Message",
  ];
  selectedGroup: string;

  constructor(
    private sectorService: SectorService,
    public router: Router,
    private tostre: ToastrService,
    public UserPermission: UserPermissionService,
    private storage: StorageService,
    private adminService: ServiceService
  ) {
    //... Read User Data ...
    this.authToken = this.storage.getData("token");
    this.userData = JSON.parse(this.storage.getData("UserData"));
    if (this.authToken == null) {
      this.router.navigate(["/login"]);
    }

    /* check module permission of the user */
    if (
      this.UserPermission.checkPermission(
        "access_property_use_area",
        "",
        "",
        ""
      ) == false
    ) {
      this.router.navigate(["/products/list"]);
      this.tostre.warning(
        "You don't have permission to access this module.",
        "",
        {
          positionClass: "toast-top-right",
        }
      );
    }

    this.GlobalEnvironmentDetails = JSON.parse(
      this.storage.getData("GlobalEnvironmentDetails")
    );
    if (this.GlobalEnvironmentDetails) {
      this.GlobalEnvironmentID = this.GlobalEnvironmentDetails.GlobalEnvironmentId;
      this.GlobalEnvironmentName = this.GlobalEnvironmentDetails.GlobalEnvironmentName;
      this.GOENumber = this.GlobalEnvironmentDetails.GOENo;
    }

    this.currentUserID = this.userData[0].UserID;
    this.dataSourceOne = new MatTableDataSource();
    this.dataSourceTwo = new MatTableDataSource();
  }

  sectorGroupForm = new FormGroup({
    SectorGroupID: new FormControl(""),
    SectorGroupName: new FormControl("", [Validators.required]),
    SectorGroupDesc: new FormControl("", [Validators.required]),
    OrganizationID: new FormControl(this.GlobalEnvironmentID),
  });
  addFormSubmitted = false;
  get sectorGroupF() {
    return this.sectorGroupForm.controls;
  }

  editSectorGroupForm = new FormGroup({
    SectorGroupID: new FormControl(""),
    SectorGroupName: new FormControl("", [Validators.required]),
    SectorGroupDesc: new FormControl("", [Validators.required]),
    OrganizationID: new FormControl(this.GlobalEnvironmentID),
    IsActive: new FormControl(),
  });
  submitted = false;
  get editSectorGroupF() {
    return this.editSectorGroupForm.controls;
  }

  sectorForm = new FormGroup({
    GlobalEnvironmentID: new FormControl(this.GlobalEnvironmentID),
    SectorID: new FormControl(""),
    SectorGroupID: new FormControl(""),
    SectorName: new FormControl("", [Validators.required]),
    SectorDesc: new FormControl("", [Validators.required]),
  });
  sectorSubmitted = false;
  get sectorFormF() {
    return this.sectorForm.controls;
  }

  editSectorForm = new FormGroup({
    GlobalEnvironmentID: new FormControl(this.GlobalEnvironmentID),
    SectorID: new FormControl(""),
    SectorGroupID: new FormControl(""),
    SectorName: new FormControl("", [Validators.required]),
    SectorDesc: new FormControl("", [Validators.required]),
    IsActive: new FormControl(""),
  });
  editSectorSubmitted = false;
  get editSectorFormF() {
    return this.editSectorForm.controls;
  }

  checkGoe() {
    if (this.GlobalEnvironmentID) {
      return true;
    } else {
      // Swal.fire({
      //   text: "Please first select a Global Operations Environment.",
      //   timer: 3000,
      // }).then((result) => {
      //   // this.router.navigate(["products/administration/goe/mygoe"]);
      // });
      this.tostre.error(
        "Please first select a Global Operations Environment.",
        "",
        {
          positionClass: "toast-top-right",
        }
      );
      this.router.navigate(["products/administration/goe/mygoe"]);
      return false;
    }
  }

  ngOnInit() {
    // console.log(this.sectorForm.value)
    if (this.checkGoe()) {
      this.getOnScreenList();
      this.getSectorGroup(this.GlobalEnvironmentID);
      this.getSectors(0, this.GlobalEnvironmentID);
      this.getProperties(this.GlobalEnvironmentID, this.selectedSectorGroupId);
    }
  }

  /*  Sector Group Area */
  openSectorGroupForm() {
    this.sectorGroupForm.reset();
    this.addgop = !this.addgop;
    this.groupEditable = false;
    this.sectorEditable = false;
    this.propertytype = false;
    let shadesEl = document.querySelectorAll(".show");
    for (let i = 0; i < shadesEl.length; i++) {
      shadesEl[i].classList.remove("show");
    }
    this.selectedSectorGroupId = false;
  }

  getSectorGroup(GlobalEnvironmentID: any): void {
    let results: any;
    this.sectorService
      .getSectorGroup(GlobalEnvironmentID)
      .subscribe((sectorGroup) => {
        results = sectorGroup;
        this.sectorGroups = results.GetSectorGroup;
      });
  }

  getOnScreenList() {
    this.sectorService
      .getOnScreenList(this.GlobalEnvironmentID)
      .subscribe((data) => {
        this.OnScreenList = data.data.getUsesAreaOnScreenList;
        this.dataSourceOne.data = data.data.getUsesAreaOnScreenList;
        this.dataSourceOne.sort = this.tableOneSort;
        this.tableOneSort.disableClear = true;
      });
  }

  selectGroupRow(groupId: any) {
    this.resetSectorForm();
    this.groupEditable = false;
    this.sectorEditable = false;
    let shadesEl = document.querySelectorAll(".show");
    for (let i = 0; i < shadesEl.length; i++) {
      shadesEl[i].classList.remove("show");
    }

    if (groupId == this.selectedSectorGroupId) {
      this.selectedSectorGroupId = false;
      this.selectedGroup = '';
      this.selectedSectorId = false;
      this.getSectors(0, this.GlobalEnvironmentID);
    } else {
      this.selectedGroup = groupId;
      this.selectedSectorGroupId = groupId;
      this.getSectors(this.selectedGroup, this.GlobalEnvironmentID);
      this.getProperties(this.GlobalEnvironmentID, this.selectedSectorGroupId);
    }
    this.sectorForm.patchValue({ SectorGroupID: groupId });
  }

  submitSectorGroupForm() {
    this.addFormSubmitted = true;

    if (this.sectorGroupForm.get("SectorGroupName").value == null || "") {
      return;
    } else {
      let postData = this.sectorGroupForm.value;
      if (postData.SectorGroupName.trim() == "") {
        let msg = "Property Use Area Group Name is required";
        this.showValid(msg);
        return false;
      }

      postData.OrganizationID = this.GlobalEnvironmentID;
      postData.IsActive = 1;
      let result: any;
      this.sectorService.updateSectorGroup(postData).subscribe((sector) => {
        result = sector;
        if (result.UpdateSectorGroup[0].ReturnKey == "SectorGroupName") {
          let msg = result.UpdateSectorGroup[0].ReturnMessage;
          this.showValid(msg);
          return false;
        } else {
          let obj = {
            SectorGroupID: result.UpdateSectorGroup[0].ReturnMessage,
            SectorGroupName: postData.SectorGroupName,
            SectorGroupDesc: postData.SectorGroupDesc,
            IsActive: true,
            IsAllowDelete: 1,
          };
          this.sectorGroups.push(obj);
        }
        this.addgop = !this.addgop;
        this.sectorGroupForm.reset();
        this.addFormSubmitted = false;
      });
    }
  }

  resetSectorGroupForm() {
    this.addFormSubmitted = false;
    this.sectorGroupForm.reset();
    this.addgop = false;
  }

  changeSectorGroupStatus(id: any) {
    this.groupEditable = false;
    this.sectorService.changeSectorGroupStatus(id).subscribe((resp) => {
      let obj = this.sectorGroups.find((o) => o.SectorGroupID == id);
      let index = this.sectorGroups.indexOf(obj);
      this.sectorGroups.fill((obj.IsActive = !obj.IsActive), index, index++);
      this.tostre.success(this.adminService.statusMsg);
    });
  }

  statusgroup = false;
  editSectorGroup(sectorGroup: any) {
    this.selectedSectorGroupId = sectorGroup.SectorGroupID;
    this.resetSectorForm();
    this.sectorEditable = false;
    let shadesEl = document.querySelectorAll(".show");
    for (let i = 0; i < shadesEl.length; i++) {
      shadesEl[i].classList.remove("show");
    }

    this.groupEditable = sectorGroup.SectorGroupID;
    this.editSectorGroupForm.patchValue({
      SectorGroupID: sectorGroup.SectorGroupID,
    });
    this.editSectorGroupForm.patchValue({
      SectorGroupName: sectorGroup.SectorGroupName,
    });
    this.editSectorGroupForm.patchValue({
      SectorGroupDesc: sectorGroup.SectorGroupDesc,
    });
    this.editSectorGroupForm.patchValue({
      OrganizationID: this.GlobalEnvironmentID,
    });
    this.editSectorGroupForm.patchValue({ IsActive: sectorGroup.IsActive });
    this.resetSectorGroupForm();
    this.statusgroup = sectorGroup.IsActive;
  }
  changeGroupshowStatus(id: any) {
    let element: HTMLElement = document.getElementById(
      "status-group-" + id
    ) as HTMLElement;
    element.click();
    this.statusgroup = !this.statusgroup;
    this.tostre.success(this.adminService.statusMsg);
  }

  updateSectorGroup(id: any) {
    this.submitted = true;
    if (this.editSectorGroupForm.get("SectorGroupName").value == null || "") {
      return;
    } else {
      let updData = this.editSectorGroupForm.value;
      if (updData.SectorGroupName.trim() == "") {
        let msg = "Property Use Area Group Name is required";
        this.showValid(msg);
        return false;
      }
      let result: any;
      this.sectorService.updateSectorGroup(updData).subscribe((sectorGroup) => {
        result = sectorGroup;
        if (result.UpdateSectorGroup[0].ReturnKey == "SectorGroupName") {
          let msg = result.UpdateSectorGroup[0].ReturnMessage;
          this.showValid(msg);
          return false;
        } else {
          let obj = this.sectorGroups.find(
            (o) => o.SectorGroupID == updData.SectorGroupID
          );
          let index = this.sectorGroups.indexOf(obj);
          this.sectorGroups.fill(
            (obj.SectorGroupName = updData.SectorGroupName),
            index,
            index++
          );
          this.sectorGroups.fill(
            (obj.SectorGroupDesc = updData.SectorGroupDesc),
            index,
            index++
          );
          this.sectorGroups.fill(
            (obj.IsActive = updData.IsActive),
            index,
            index++
          );

          this.submitted = false;
          this.groupEditable = false;
          let element: HTMLElement = document.getElementById(
            "closetab-" + id
          ) as HTMLElement;
          element.click();
        }
      });
    }
  }

  resetEditSectorGroupForm(SectorGroupID: any) {
    this.editSectorGroupForm.reset();
    this.groupEditable = false;
  }

  removeSectorGroup(groupId: any) {
    Swal.fire({
      //title: 'Are you sure you want to delete ?',
      // text: "Are you sure you want to remove this?",
      text: this.adminService.deleteMsg,
      showCancelButton: true,
      confirmButtonText: "Yes",
      cancelButtonText: "No",
    }).then((result) => {
      if (result.value) {
        this.sectorService.removeSectorGroup(groupId).subscribe((resp) => {
          if (groupId == this.selectedSectorGroupId) {
            this.selectedSectorGroupId = false;
          }
          let obj1 = this.sectorGroups.find((x) => x.SectorGroupID == groupId);
          let index = this.sectorGroups.indexOf(obj1);
          this.sectorGroups.splice(index, 1);
        });
      }
    });
  }

  //....... Sector Area ........
  checkGroupSelected() {
    this.groupEditable = false;
    this.sectorEditable = false;
    this.addgop = false;
    this.sectorForm.reset();
    let shadesEl = document.querySelectorAll(".show");
    for (let i = 0; i < shadesEl.length; i++) {
      shadesEl[i].classList.remove("show");
    }

    // if (this.selectedSectorGroupId) {
      this.propertytype = !this.propertytype;
      let shadesEl1 = document.querySelectorAll(".show");
      for (let i = 0; i < shadesEl1.length; i++) {
        shadesEl1[i].classList.remove("show");
      }
    // } else {
    //   let msg = "Please first select a sector group.";
    //   this.showInvalid(msg);
    // }
  }

  getSectors(groupId: any, GlobalEnvironmentID: any) {
    let results: any;
    this.sectorService
      .getSectors(groupId, this.GlobalEnvironmentID)
      .subscribe((sectors) => {
        results = sectors;
        this.sectors = results.GetSectorGroupById;
      });
  }

  selectSectorRow(sectorId: any) {
    if (sectorId == this.selectedSectorId) {
      this.selectedSectorId = false;
    } else {
      this.selectedSectorId = sectorId;
    }
  }

  updateSectorGroupSector(data) {
    const body = {
      SectorGroupID: +this.selectedGroup,
      SectorID: +data.SectorID,
      IsAssigned: data.IsAssignedtoGroup==1 ? 0 : 1
    };
    // console.log(data, this.selectedGroup)
    this.sectorService.updateSectorGroupSector(body).subscribe((res: any) => {
      // console.log(res);
      this.getSectors(+this.selectedGroup, this.GlobalEnvironmentID);
    })
  }

  submitSectorForm() {
    this.sectorSubmitted = true;
    if (this.sectorForm.get("SectorName").value == null || "") {
      return;
    }
    // console.log(this.sectorForm.value)
    let postData = this.sectorForm.value;

    postData.GlobalEnvironmentID = this.GlobalEnvironmentID;
    postData.SectorGroupID = this.selectedGroup ? this.selectedGroup : '';
    if (postData.SectorName.trim() == "") {
      // let msg = "Property Use Area Name is required";
      // this.showValid(msg);
      return false;
    }
    postData.IsActive = 1;
    let result: any;
    this.sectorService.updateSector(postData).subscribe((sector) => {
      this.sectorForm.patchValue({
        SectorName: '',
        SectorDesc: ''
      });
      this.propertytype = !this.propertytype;
      result = sector;
      if (result.UpdateSector[0].ReturnKey == "SectorName") {
        let msg = result.UpdateSector[0].ReturnMessage;
        this.showValid(msg);
        return false;
      } else {
        let obj = {
          SectorID: result.UpdateSector[0].ReturnMessage,
          SectorName: postData.SectorName,
          SectorDesc: postData.SectorDesc,
          SectorGroupID: this.selectedSectorGroupId,
          IsAllowDelete: 1,
          IsActive: true,
        };
        this.sectors.push(obj);

        let obj1 = this.sectorGroups.find(
          (x) => x.SectorGroupID === this.selectedSectorGroupId
        );
        let index = this.sectorGroups.indexOf(obj1);
        this.sectorGroups.fill((obj1.IsAllowDelete = false), index, index++);
        
      }
      this.propertytype = !this.propertytype;
      this.sectorForm.reset();
      this.sectorSubmitted = false;
      this.sectorForm.patchValue({ SectorGroupID: postData.SectorGroupID });
    });
  }

  resetSectorForm() {
    this.sectorSubmitted = false;
    this.sectorForm.reset();
    this.sectorForm.patchValue({ SectorGroupID: this.selectedSectorGroupId });
    this.propertytype = false;
  }

  changeSectorStatus(sectorId: Number) {
    this.sectorEditable = false;
    this.sectorService.changeSectorStatus(sectorId).subscribe((sector) => {
      let obj = this.sectors.find((o) => o.SectorID == sectorId);
      let index = this.sectors.indexOf(obj);
      this.sectors.fill((obj.IsActive = !obj.IsActive), index, index++);
      this.tostre.success(this.adminService.statusMsg);
    });
  }

  editSector(sector: any) {
    this.selectedSectorGroupId = sector.SectorGroupID;
    this.groupEditable = false;
    this.addgop = false;
    let shadesEl = document.querySelectorAll(".show");
    for (let i = 0; i < shadesEl.length; i++) {
      shadesEl[i].classList.remove("show");
    }

    this.editSectorForm.patchValue({ SectorName: sector.SectorName });
    this.editSectorForm.patchValue({ SectorDesc: sector.SectorDesc });
    this.editSectorForm.patchValue({ IsActive: sector.IsActive });
    this.editSectorForm.patchValue({ SectorGroupID: sector.SectorGroupID });
    this.sectorEditable = sector.SectorID;
    this.resetSectorForm();
  }

  updateSector(sectorId: number) {
    this.editSectorSubmitted = true;
    if (this.editSectorForm.get("SectorName").value == null || "") {
      return;
    }
    let updData = this.editSectorForm.value;
    if (updData.SectorName.trim() == "") {
      // let msg = "Property Use Area Name is required";
      // this.showValid(msg);
      return false;
    }

    updData.GlobalEnvironmentID = this.GlobalEnvironmentID;
    updData.SectorID = sectorId;
    updData.IsActive = updData.IsActive ? 1 : 0;
    let result: any;
    this.sectorService.updateSector(updData).subscribe((sector) => {
      result = sector;
      if (result.UpdateSector[0].ReturnKey == "SectorName") {
        let msg = result.UpdateSector[0].ReturnMessage;
        this.showValid(msg);
        return false;
      } else {
        let obj = this.sectors.find((o) => o.SectorID == updData.SectorID);
        let index = this.sectors.indexOf(obj);
        this.sectors.fill(
          (obj.SectorName = updData.SectorName),
          index,
          index++
        );
        this.sectors.fill(
          (obj.SectorDesc = updData.SectorDesc),
          index,
          index++
        );
        this.sectors.fill(
          (obj.SectorGroupID = updData.SectorGroupID),
          index,
          index++
        );
        this.sectors.fill((obj.IsActive = updData.IsActive), index, index++);
      }
      this.sectorEditable = false;
      let element: HTMLElement = document.getElementById(
        "close-tabc-" + sectorId
      ) as HTMLElement;
      element.click();
      this.editSectorSubmitted = false;
    });
  }

  resetEditSectorForm() {
    this.sectorForm.reset();
    this.sectorForm.patchValue({ SectorGroupID: this.selectedSectorGroupId });
    this.sectorEditable = false;
    this.submitted = false;
  }

  removeSector(sector: Number) {
    this.groupEditable = false;
    let shadesEl = document.querySelectorAll(".show");
    for (let i = 0; i < shadesEl.length; i++) {
      shadesEl[i].classList.remove("show");
    }

    Swal.fire({
      // text: "Are you sure you want to remove this?",
      text: this.adminService.deleteMsg,
      showCancelButton: true,
      confirmButtonText: "OK",
      cancelButtonText: "NO",
    }).then((result) => {
      if (result.value) {
        this.sectorService
          .removeSector(sector["SectorID"])
          .subscribe((resp) => {
            //... find index and remove sector in sectors list
            let obj1 = this.sectors.find(
              (x) => x.SectorID == sector["SectorID"]
            );
            let index = this.sectors.indexOf(obj1);
            this.sectors.splice(index, 1);
            //... check if sectorGroup has more sector in sectors list
            let obj2 = this.sectors.find(
              (x) => x.SectorGroupID == sector["SectorGroupID"]
            );
            let index1 = this.sectors.indexOf(obj2);
            //... if not more sector in sectors list then make delete button visible in sector group list
            if (index1 == -1) {
              let obj3 = this.sectorGroups.find(
                (x) => x.SectorGroupID == sector["SectorGroupID"]
              );
              let index2 = this.sectors.indexOf(obj3);
              this.sectorGroups.fill(
                (obj3.IsAllowDelete = true),
                index2,
                index2++
              );
            }
          });
      }
    });
  }

  //... Properties Area ...
  getProperties(GlobalEnvironmentID: any, groupId: any) {
    let result: any;
    this.sectorService
      .getProperties(GlobalEnvironmentID, groupId)
      .subscribe((propery) => {
        result = propery;
        this.properties = result.GetPropertyListBySectorGroup;
      });
  }

  selectPropertyRow(PropertyID: any, index: any) {
    index = index + 1;
    if (index == this.selectedPropertyID) {
      this.selectedPropertyID = false;
    } else {
      this.selectedPropertyID = index;
    }
  }

  assignProperty(Property: any) {
    let postData = {
      IsAssigned: 0,
      vssPropertyID: Property.PropertyID,
      vssSectorGroupID: this.selectedSectorGroupId,
      UserId: 1,
    };
    if (Property.IsAssigned == 1) {
      postData.IsAssigned = 0;
    } else {
      postData.IsAssigned = 1;
    }

    if (this.selectedSectorGroupId) {
      if (Property.IsAssignedToOtherSectorGroup == 0) {
        this.sectorService.assignProperty(postData).subscribe((resp) => {
          let obj1 = this.properties.find(
            (x) => x.PropertyID === Property.PropertyID
          );
          let index = this.properties.indexOf(obj1);
          this.properties.fill(
            (obj1.IsAssigned = postData.IsAssigned),
            index,
            index++
          );
          this.properties.fill(
            (obj1.IsAssignedToOtherSectorGroup = 0),
            index,
            index++
          );
        });
      } else {
        Swal.fire({
          text:
            "This property is assigned to other group. do you want to assign this?",
          showCancelButton: true,
          confirmButtonText: "OK",
          cancelButtonText: "Cancel",
        }).then((result) => {
          if (result.value) {
            let result: any;
            this.sectorService.assignProperty(postData).subscribe((resp) => {
              result = resp;
              let obj1 = this.properties.find(
                (x) => x.PropertyID === Property.PropertyID
              );
              let index = this.properties.indexOf(obj1);
              this.properties.fill(
                (obj1.IsAssigned = postData.IsAssigned),
                index,
                index++
              );
              this.properties.fill(
                (obj1.IsAssignedToOtherSectorGroup = 0),
                index,
                index++
              );
            });
          }
        });
      }
    } else {
      let msg = "Please first select a Group.";
      this.showInvalid(msg);
    }
  }

  downloadUseArea() {
    let data = [];

    this.OnScreenList.forEach(function (item, i) {
      delete item["UsesAreaGroupID"];
      delete item["UsesAreaID"];
      delete item["CreatedDate"];

      if (item.IsActive) {
        item.IsActive = "Active";
      } else {
        item.IsActive = "InActive";
      }
      data.push(item);
    });

    this.sectorService.exportAsExcelFile(data);
  }

  downloadUploadedUseArea() {
    let newData = [];

    this.UploadedUseList.forEach(function (item, i) {
      delete item["RecNo"];
      delete item["UserID"];
      delete item["GlobalEnvironmentID"];
      delete item["Status"];

      newData.push(item);
    });

    this.sectorService.exportUploadExcelFile(newData);
  }

  onSectorSelect(data: any) {
    if (this.selectedSector == data.UsesAreaID) {
      this.selectedSector = !this.selectedSector;
    } else {
      this.selectedSector = data.UsesAreaID;
    }
  }

  //upload here

  title = "read-excel-in-angular8";
  storeData: any;
  jsonData: any;
  fileUploaded: File;
  worksheet: any;
  htmlData: any;

  uploadedFile(event) {
    this.fileUploaded = event.target.files[0];
    if (!this.validateFile(this.fileUploaded.name)) {
      let msg = "Selected file format is not supported.";
      this.showValid(msg);

      setTimeout((data) => {
        window.location.reload();
      }, 2000);
      return false;
    }
    this.readExcel();
  }

  validateFile(name: any) {
    var ext = name.substring(name.lastIndexOf(".") + 1);
    if (ext.toLowerCase() == "xlsx") {
      return true;
    } else {
      return false;
    }
  }

  readExcel() {
    let readFile = new FileReader();

    readFile.onload = (e) => {
      this.storeData = readFile.result;

      var data = new Uint8Array(this.storeData);

      var arr = new Array();

      for (var i = 0; i != data.length; ++i)
        arr[i] = String.fromCharCode(data[i]);

      var bstr = arr.join("");

      var workbook = XLSX.read(bstr, { type: "binary" });

      var first_sheet_name = workbook.SheetNames[1];

      this.worksheet = workbook.Sheets[first_sheet_name];

      var range = XLSX.utils.decode_range(this.worksheet["!ref"]);
      range.s.r = 2; // <-- zero-indexed, so setting to 1 will skip row 0
      this.worksheet["!ref"] = XLSX.utils.encode_range(range);

      this.readAsJson(this.currentUserID, this.GlobalEnvironmentID);
    };

    readFile.readAsArrayBuffer(this.fileUploaded);
  }

  // Upload Excel End

  /** Read As Json */

  readAsJson(currentUserID, GlobalEnvironmentID) {
    this.jsonData = XLSX.utils.sheet_to_json(this.worksheet, { raw: false });

    //this.jsonData = JSON.stringify(this.jsonData);

    var arrofobj = (this.UseCaseImportList = this.jsonData);

    var result = arrofobj.map(function (el) {
      var o = Object.assign({}, el);
      o.UserID = currentUserID;
      o.GlobalEnvironmentID = GlobalEnvironmentID;
      o.Message = "";
      o.RecNo = "";
      return o;
    });
    let length = Object.keys(result).length;

    // this.dataSourceTwo = result;
    this.UseCasesImport(result);
  }

  /**
   * Import Use Area List
   *
   */

  newObjArr = [];

  UseCasesImport(obj) {
    let matchSector =
      Object.keys(obj[0]).includes("Use Area Name") &&
      Object.keys(obj[0]).includes("Use Area Description");

    if (matchSector) {
      for (var i = 0; i < obj.length; i++) {
        let newObj = {
          RecNo: obj[i]["RecNo"],
          UsesAreaGroupName: obj[i]["Use Area Group Name"],
          UsesAreaGroupDesc: obj[i]["Use Area Group Description"],
          UsesAreaName: obj[i]["Use Area Name"],
          UsesAreaDesc: obj[i]["Use Area Description"],
          UsesAreaStatus: obj[i]["Status"],
          UserID: +obj[i]["UserID"],
          GlobalEnvironmentID: +obj[i]["GlobalEnvironmentID"],
        };
        this.newObjArr.push(newObj);
      }

      let passingArray = this.newObjArr;
      this.sectorService.UseCasesImport(passingArray).subscribe((res) => {
        this.dataSourceTwo = res.data.usesAreaImport;
        this.UploadedUseList = res.data.usesAreaImport;
        this.showValid("Processed successfully. Please check the table.");
      });
    } else {
      //this.locationDisplay = true;
      this.showInvalid(
        "Uploaded Excel Sheet is Invalid. Please put the right one."
      );
    }
  }

  /* Upload File */
  openFileBrowser(event: any) {
    this.hideTableMain = false;
    this.showUploadTable = true;
    this.locationDisplay = false;
    event.preventDefault();
    let element: HTMLElement = document.getElementById("file") as HTMLElement;
    element.click();
  }

  toggleScreen(value) {
    if (value) {
      this.getOnScreenList();
    } else {
      /* this.selectedSectorGroupId = false;
      this.selectedSectorId = false;

      if(this.sectorGroups.length == 0){
        this.getSectorGroup(this.GlobalEnvironmentID);
      }
      if(this.sectors.length == 0){
        this.getSectors(0, this.GlobalEnvironmentID);
      }
      if(this.properties.length == 0){
        this.getProperties(this.GlobalEnvironmentID, this.selectedSectorGroupId);
      } */
    }
    this.locationDisplay = !this.locationDisplay;
  }

  cancelUploadView() {
    window.location.reload();
  }

  // toastr warning/success message
  showInvalid(msg) {
    this.tostre.warning(msg, "", {
      positionClass: "toast-top-right",
    });
  }

  showValid(validMsg) {
    this.tostre.success(validMsg, "", {
      positionClass: "toast-top-right",
    });
  }
}
