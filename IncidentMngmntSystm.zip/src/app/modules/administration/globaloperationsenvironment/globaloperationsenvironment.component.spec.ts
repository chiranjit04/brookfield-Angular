import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GlobaloperationsenvironmentComponent } from './globaloperationsenvironment.component';

describe('GlobaloperationsenvironmentComponent', () => {
  let component: GlobaloperationsenvironmentComponent;
  let fixture: ComponentFixture<GlobaloperationsenvironmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GlobaloperationsenvironmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GlobaloperationsenvironmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
