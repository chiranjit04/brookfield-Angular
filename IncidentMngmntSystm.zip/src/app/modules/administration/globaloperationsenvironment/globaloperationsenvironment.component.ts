import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-globaloperationsenvironment',
  templateUrl: './globaloperationsenvironment.component.html',
  styleUrls: ['./globaloperationsenvironment.component.scss']
})
export class GlobaloperationsenvironmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
