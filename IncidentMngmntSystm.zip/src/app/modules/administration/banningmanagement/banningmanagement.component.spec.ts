import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BanningmanagementComponent } from './banningmanagement.component';

describe('BanningmanagementComponent', () => {
  let component: BanningmanagementComponent;
  let fixture: ComponentFixture<BanningmanagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BanningmanagementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BanningmanagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
