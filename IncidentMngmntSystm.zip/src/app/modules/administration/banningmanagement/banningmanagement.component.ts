import { Component, OnInit } from "@angular/core";
import { BanningmanagementService } from "./banningmanagement.service";
import {
  FormGroup,
  FormControl,
  Validators,
  FormBuilder,
  FormArray,
} from "@angular/forms";
import Swal from "sweetalert2";
import { Router } from "@angular/router";
import { delay } from "rxjs/internal/operators/delay";
import { ToastrService } from "ngx-toastr";
import { UserPermissionService } from "../../../services/user-permission.service";
import { StorageService } from "../../../services/storage.service";
import { ServiceService } from "./../service/service.service";

@Component({
  selector: "app-banningmanagement",
  templateUrl: "./banningmanagement.component.html",
  styleUrls: ["./banningmanagement.component.scss"],
})
export class BanningmanagementComponent implements OnInit {
  private _banningControl: any;
  private _banningCControl: any;
  private _banningPControl: any;
  private _addBanningControl: any;
  IsLock: any;
  GlobalEnvironmentID = 0;
  GlobalEnvironmentName = "";
  GOENumber = "";
  GlobalEnvironmentDetails = null;
  getBanningProtocol: any[];
  BanningProtocolID: any;

  protocolName: any;
  editProName = false;

  addBD = false;

  userData = null;
  currentUserID: any;

  Islock: boolean = false;
  banningDuration: any;
  banningCharacteristic: any;
  banningProcedural: any;
  BanningDurationID = 0;
  BanningCharacteristicID = 0;
  BanningProceduralID = 0;

  addBanningGForm = false;
  authToken = null;

  IsAddProtocolBtn: boolean = false;

  constructor(
    private BanningService: BanningmanagementService,
    public router: Router,
    private formBuilder: FormBuilder,
    public tostre: ToastrService,
    public UserPermission: UserPermissionService,
    private storage: StorageService,
    private adminService: ServiceService
  ) {
    //... Read User Data ...
    this.authToken = this.storage.getData("token");
    this.userData = JSON.parse(this.storage.getData("UserData"));
    if (this.authToken == null) {
      this.router.navigate(["/login"]);
    }

    /* check module permission of the user */
    if (
      this.UserPermission.checkPermission(
        "access_banning_program",
        "",
        "",
        ""
      ) == false
    ) {
      this.router.navigate(["/products/list"]);
      this.tostre.warning(
        "You don't have permission to access this module.",
        "",
        {
          positionClass: "toast-top-right",
        }
      );
    }

    this.GlobalEnvironmentDetails = JSON.parse(
      this.storage.getData("GlobalEnvironmentDetails")
    );
    if (this.GlobalEnvironmentDetails) {
      //this.groupData = this.organise(this.exportreport);
      this.GlobalEnvironmentID = this.GlobalEnvironmentDetails.GlobalEnvironmentId;
      this.GlobalEnvironmentName = this.GlobalEnvironmentDetails.GlobalEnvironmentName;
      this.GOENumber = this.GlobalEnvironmentDetails.GOENo;
    }
    // this.userData = JSON.parse(this.storage.getData("UserData"));
    this.currentUserID = this.userData[0].UserID;
  }

  dataDMWY: any = [
    { name: "Day" },
    { name: "Week" },
    { name: "Month" },
    { name: "Year" },
  ];

  dataTime: any = [
    { name: "1" },
    { name: "2" },
    { name: "3" },
    { name: "4" },
    { name: "5" },
    { name: "6" },
  ];

  ngOnInit() {
    if (this.checkGoe()) {
      this.getBanningProtocolBListByGlobalEnvironmentID();
      this.getBanningDuration();
      this.getBanningCharacteristic();
      this.getBanningProcedural();
    }
  }

  AddBanningProtocol = new FormGroup({
    addBanningRows: this.formBuilder.array([]),
    protocolName: new FormControl(),
  });

  addBanningRows(protocal: any): FormGroup {
    return this.formBuilder.group({
      BanningProtocalID: [protocal.BanningProtocolID],
      ProtocolName: new FormControl({
        value: protocal.ProtocolName,
        disabled: true,
      }),
      IsLock: new FormControl(protocal.IsLock),
      Notes: new FormControl(protocal.ProtocolNotes),
      IsDeleted: new FormControl(protocal.IsDeleted),
      BanningDuration: this.formBuilder.array(
        [this.createBanningRows("", "", "", "")],
        [Validators.required]
      ),
      BanningCharacteristic: this.formBuilder.array([
        this.createBanningCRows("", ""),
      ]),
      BanningProcedural: this.formBuilder.array([
        this.createBanningPRows("", ""),
      ]),
    });
  }

  get addBDGF() {
    return this.AddBanningProtocol.controls;
  }

  createBanningRows(
    value,
    BanningProtocolDurationID,
    IsDurationUsed,
    DurationTime
  ): FormGroup {
    return this.formBuilder.group({
      bannerRecordId: [BanningProtocolDurationID],
      bannerRecord: [value],
      DurationTime: [DurationTime],
      IsDurationUsed: [IsDurationUsed],
    });
  }

  createBanningCRows(value, BanningProtocolCharacteristicID): FormGroup {
    return this.formBuilder.group({
      bannerCRecordId: [BanningProtocolCharacteristicID],
      bannerCRecord: [value],
    });
  }

  createBanningPRows(value, BanningProtocolProceduralID): FormGroup {
    return this.formBuilder.group({
      bannerPRecordId: [BanningProtocolProceduralID],
      bannerPRecord: [value],
    });
  }

  /**
   *
   * Check Empty Duration
   * @param mainIndex
   * @param flag
   * @param flagOfError
   */

  checkEmptyDuration(mainIndex, flag, flagOfError) {
    if (flag === true) return false;

    let array: any = this.AddBanningProtocol.get("addBanningRows");

    this._banningControl = array.controls[mainIndex].get("BanningDuration");

    let len = this._banningControl["controls"].length - 1;

    let banningObj = this._banningControl["controls"][len]["controls"][
      "bannerRecord"
    ];

    if (banningObj.value === "") {
      if (flagOfError === false) {
        let x: any = document.querySelector("#banning" + mainIndex + "" + len);
        x.style.border = "1px solid red";
      }
      return true;
    } else if (flagOfError === "change") {
      let x: any = document.querySelector("#banning" + mainIndex + "" + len);

      x.style.border = "0px solid red";
    } else if (flagOfError === null) {
      return false;
    }
    return false;
  }

  checkEmptyDurationTime(mainIndex, flag, flagOfError) {
    if (flag === true) return false;

    let array: any = this.AddBanningProtocol.get("addBanningRows");

    this._banningControl = array.controls[mainIndex].get("BanningDuration");

    let len = this._banningControl["controls"].length - 1;

    let banningObj = this._banningControl["controls"][len]["controls"][
      "DurationTime"
    ];

    if (banningObj.value === "") {
      if (flagOfError === false) {
        let x: any = document.querySelector(
          "#banning" + mainIndex + "" + len + "-time"
        );
        x.style.border = "1px solid red";
      }
      return true;
    } else if (flagOfError === "change") {
      let x: any = document.querySelector(
        "#banning" + mainIndex + "" + len + "-time"
      );

      x.style.border = "0px solid red";
    } else if (flagOfError === null) {
      return false;
    }
    return false;
  }

  /**
   * Check for Empty Characterstic
   * @param mainIndex
   * @param flag
   * @param flagOfError
   */

  checkEmptyCharacteristic(mainIndex, flag, flagOfError) {
    if (flag === true) return false;

    let array: any = this.AddBanningProtocol.get("addBanningRows");

    this._banningCControl = array.controls[mainIndex].get(
      "BanningCharacteristic"
    );

    let len = this._banningCControl["controls"].length - 1;

    let banningObj = this._banningCControl["controls"][len]["controls"][
      "bannerCRecord"
    ];

    if (banningObj.value === "") {
      if (flagOfError === false) {
        let x: any = document.querySelector("#banningC" + mainIndex + "" + len);
        x.style.border = "1px solid red";
      }
      return true;
    } else if (flagOfError === "change") {
      let x: any = document.querySelector("#banningC" + mainIndex + "" + len);

      x.style.border = "0px solid red";
    } else if (flagOfError === null) {
      return false;
    }
    return false;
  }

  /**
   * Check Empty Procedural
   * @param mainIndex
   * @param flag
   * @param flagOfError
   */

  checkEmptyProcedural(mainIndex, flag, flagOfError) {
    if (flag === true) return false;

    let array: any = this.AddBanningProtocol.get("addBanningRows");

    this._banningPControl = array.controls[mainIndex].get("BanningProcedural");

    let len = this._banningPControl["controls"].length - 1;

    let banningObj = this._banningPControl["controls"][len]["controls"][
      "bannerPRecord"
    ];

    if (banningObj.value === "") {
      if (flagOfError === false) {
        let x: any = document.querySelector("#banningP" + mainIndex + "" + len);
        x.style.border = "1px solid red";
      }
      return true;
    } else if (flagOfError === "change") {
      let x: any = document.querySelector("#banningP" + mainIndex + "" + len);

      x.style.border = "0px solid red";
    } else if (flagOfError === null) {
      return false;
    }
    return false;
  }

  checkAlreadyExistDuration(mainIndex, value, flags) {
    if (flags === true) return false;
    let array: any = this.AddBanningProtocol.get("addBanningRows");

    this._banningControl = array.controls[mainIndex].get("BanningDuration");

    let len = this._banningControl["controls"].length - 1;
    let bArray = this._banningControl["controls"];

    let banningObj = this._banningControl["controls"][len]["controls"][
      "bannerRecord"
    ].value;
    let flag = false;
    bArray.forEach((element, index) => {
      if (len === index) return;

      if (element["controls"]["bannerRecord"].value === banningObj) {
        flag = true;
      }
    });

    return flag;
  }
  checkAlreadyExistCharacteristic(mainIndex, value, flags) {
    if (flags === true) return false;
    let array: any = this.AddBanningProtocol.get("addBanningRows");

    this._banningCControl = array.controls[mainIndex].get(
      "BanningCharacteristic"
    );

    let len = this._banningCControl["controls"].length - 1;
    let bArray = this._banningCControl["controls"];

    let banningObj = this._banningCControl["controls"][len]["controls"][
      "bannerCRecord"
    ].value;
    let flag = false;
    bArray.forEach((element, index) => {
      if (len === index) return;

      if (element["controls"]["bannerCRecord"].value === banningObj) {
        flag = true;
      }
    });

    return flag;
  }

  checkAlreadyExistProcedural(mainIndex, value, flags) {
    if (flags === true) return false;
    let array: any = this.AddBanningProtocol.get("addBanningRows");

    this._banningPControl = array.controls[mainIndex].get("BanningProcedural");

    let len = this._banningPControl["controls"].length - 1;
    let bArray = this._banningPControl["controls"];

    let banningObj = this._banningPControl["controls"][len]["controls"][
      "bannerPRecord"
    ].value;
    let flag = false;
    bArray.forEach((element, index) => {
      if (len === index) return;

      if (element["controls"]["bannerPRecord"].value === banningObj) {
        flag = true;
      }
    });

    return flag;
  }

  addPermittedduration(
    index,
    value,
    mainIndex,
    flag,
    BanningDurationID,
    IsDurationUsed,
    DurationTime
  ) {
    if (this.checkEmptyDurationTime(mainIndex, flag, null) === true) {
      this.tostre.error("Please Select Banning Duration Time", "", {
        positionClass: "toast-top-right",
      });
      this.checkEmptyDurationTime(mainIndex, false, false);
      return;
    }
    if (this.checkEmptyDuration(mainIndex, flag, null) === true) {
      this.tostre.error("Please Select Banning Duration", "", {
        positionClass: "toast-top-right",
      });
      this.checkEmptyDuration(mainIndex, false, false);
      return;
    }

    if (this.checkAlreadyExistDuration(mainIndex, value, flag) === true) {
      this.tostre.error("Already Exists", "", {
        positionClass: "toast-top-right",
      });
      return;
    }

    let array: any = this.AddBanningProtocol.get("addBanningRows");

    this._banningControl = array.controls[mainIndex].get("BanningDuration");

    if (flag === true) {
      this._banningControl["controls"][index]["controls"][
        "bannerRecord"
      ].setValue(value);
      this._banningControl["controls"][index]["controls"][
        "bannerRecordId"
      ].setValue(BanningDurationID);
      this._banningControl["controls"][index]["controls"][
        "IsDurationUsed"
      ].setValue(IsDurationUsed);

      this._banningControl["controls"][index]["controls"][
        "DurationTime"
      ].setValue(DurationTime);

      this._banningControl.push(this.createBanningRows("", "", "", ""));
      // }
    } else {
      this._banningControl.push(this.createBanningRows("", "", "", ""));
    }
  }

  addPermittedCharacteristic(
    index,
    value,
    mainIndex,
    flag,
    BanningCharacteristicID
  ) {
    if (this.checkEmptyCharacteristic(mainIndex, flag, null) === true) {
      this.tostre.error("Please Enter Banning Characteristic", "", {
        positionClass: "toast-top-right",
      });
      this.checkEmptyCharacteristic(mainIndex, false, false);
      return;
    }

    if (this.checkAlreadyExistCharacteristic(mainIndex, value, flag) === true) {
      this.tostre.error("Already Exists", "", {
        positionClass: "toast-top-right",
      });
      return;
    }

    let array: any = this.AddBanningProtocol.get("addBanningRows");
    this._banningCControl = array.controls[mainIndex].get(
      "BanningCharacteristic"
    );

    if (flag === true) {
      this._banningCControl["controls"][index]["controls"][
        "bannerCRecord"
      ].setValue(value);
      this._banningCControl["controls"][index]["controls"][
        "bannerCRecordId"
      ].setValue(BanningCharacteristicID);
      this._banningCControl.push(this.createBanningCRows("", ""));
    } else {
      this._banningCControl.push(this.createBanningCRows("", ""));
    }
  }

  addPermittedProcedural(index, value, mainIndex, flag, BanningProceduralID) {
    if (this.checkEmptyProcedural(mainIndex, flag, null) === true) {
      // Swal.fire("Please Enter Banning Procedural");
      this.tostre.error("Please Enter Banning Procedural", "", {
        positionClass: "toast-top-right",
      });
      this.checkEmptyProcedural(mainIndex, false, false);
      return;
    }

    if (this.checkAlreadyExistProcedural(mainIndex, value, flag) === true) {
      // Swal.fire("Already Exists");
      this.tostre.error("Already Exists", "", {
        positionClass: "toast-top-right",
      });
      return;
    }
    // this.addBanningProtocolProcedural(index, value)
    let array: any = this.AddBanningProtocol.get("addBanningRows");

    this._banningPControl = array.controls[mainIndex].get("BanningProcedural");

    if (flag === true) {
      // if (this._banningPControl["controls"][0]["controls"]["bannerPRecord"].value === "") {

      //   this._banningPControl["controls"][0]["controls"]["bannerPRecord"].setValue(value)
      //   this._banningPControl["controls"][0]["controls"]["bannerPRecordId"].setValue(BanningProceduralID)
      //   this._banningPControl.push(this.createBanningPRows("", ""));
      //

      // } else {
      this._banningPControl["controls"][index]["controls"][
        "bannerPRecord"
      ].setValue(value);
      this._banningPControl["controls"][index]["controls"][
        "bannerPRecordId"
      ].setValue(BanningProceduralID);
      this._banningPControl.push(this.createBanningPRows("", ""));

      // }
    } else {
      this._banningPControl.push(this.createBanningPRows("", ""));
    }
  }

  checkGoe() {
    if (this.GlobalEnvironmentID) {
      return true;
    } else {
      // Swal.fire({
      //   text: "Please first select a Global Operations Environment.",
      // }).then((result) => {
      //   // this.router.navigate(["products/administration/goe/mygoe"]);
      // });
      this.tostre.error(
        "Please first select a Global Operations Environment.",
        "",
        {
          positionClass: "toast-top-right",
        }
      );
      this.router.navigate(["products/administration/goe/mygoe"]);
      return false;
    }
  }

  /**
   * Get Banning Duration
   */

  getBanningDuration() {
    this.BanningService.getBanningDuration().subscribe((res: any) => {
      this.banningDuration = res.data.GetBanningDuration;
    });
  }

  /**
   * Get Banning Characteristic
   */

  getBanningCharacteristic() {
    this.BanningService.getBanningCharacteristic().subscribe((res: any) => {
      this.banningCharacteristic = res.data.GetBanningCharacteristic;
    });
  }
  /**
   * Get Banning Characteristic
   */

  getBanningProcedural() {
    this.BanningService.getBanningProcedural().subscribe((res) => {
      this.banningProcedural = res.data.GetBanningProcedural;
    });
  }

  /**
   * Check Box for Site Lock
   *
   */

  selectLockSite(event, index) {
    let BanningProtocalID = this.getBanningProtocol[index].BanningProtocolID;
    // if (event.checked ? false : true) {

    this.Islock = event.checked;

    if (this.Islock == true) {
      this.Islock = true;
    }

    const obj = {
      GlobalEnvironmentID: +this.GlobalEnvironmentID,
      BanningProtocolID: +BanningProtocalID,
      IsLock: this.Islock ? 1 : 0,
    };

    this.BanningService.UpdateBanningProtocolByIsLock(
      obj
    ).subscribe((res) => {});
    // }

    // if (event.checked == true) {

    //   this.Islock = true
    // }
    // else {
    //   this.Islock = false
    // }
  }

  noInput() {
    return false;
  }

  BanningID: any;
  /**
   *
   *  Banning Duration
   *
   */

  selectBanningDurationID(protocolID, BanningDurationID) {
    this.BanningID = protocolID;
    this.BanningDurationID = BanningDurationID;
  }

  /**
   * Add Banning Duration
   */
  addBanningDuration(index, j, DurationTitle, DurationTime) {
    if (DurationTitle === "" || DurationTime === "") {
      return;
    }

    let getId = this.getBanningProtocol[index].BanningProtocolID;

    const obj = {
      BanningProtocolID: +getId,
      BanningDurationID: +0,
      DurationTitle: DurationTitle,
      Duration: DurationTime,
    };

    this.updateBanningProtocolDuration(obj);
  }

  /**
   *
   *
   * Update Banning Protocol Duration
   *
   */

  updateBanningProtocolDuration(obj) {
    // this.BanningService.updateBanningProtocolDuration(obj).subscribe(res => {
    this.BanningService.UpdateBanningDuration(obj).subscribe((res) => {
      // if (res.message == "Banning protocol duration has updated.") {
      //   Swal.fire("Record Already Exist")
      // }
    });
  }

  /**
   *
   *  Select Banning Characteristic
   *
   */

  selectBanningCharacteristicID(ProtocolId, BanningCharacteristicID) {
    this.BanningID = ProtocolId;
    this.BanningCharacteristicID = BanningCharacteristicID;
  }

  /**
   *  Add Banning Protocol Characteristic
   */

  addBanningProtocolCharacteristic(index, Charactersticstitle) {
    if (Charactersticstitle === "") {
      return;
    }
    let getId = this.getBanningProtocol[index].BanningProtocolID;
    // const obj = {
    //   "BanningProtocolID": +getId,
    //   "BanningCharacteristicID": +this.BanningCharacteristicID
    // }
    const obj = {
      BanningCharacteristicID: 0,
      BanningProtocolID: +getId,
      BanningCharacteristicTitle: Charactersticstitle,
    };
    console.log(obj);
    this.updateBanningProtocolCharacteristic(obj);
  }

  updateBanningProtocolCharacteristic(obj) {
    this.BanningService.UpdateBanningCharacteristic(obj).subscribe((res) => {});
  }

  /**
   *
   *  Banning Procedual
   *
   */

  selectBanningProceduralID(ProtocolId, BanningProceduralID) {
    this.BanningID = ProtocolId;
    this.BanningProceduralID = BanningProceduralID;
  }

  /**
   * Add Banning ProtocolProcedural
   */

  addBanningProtocolProcedural(index, ProceduralName) {
    if (ProceduralName === "") return;
    let getId = this.getBanningProtocol[index].BanningProtocolID;
    // const obj = {
    //   "BanningProtocolID": +getId,
    //   "BanningProceduralID": +this.BanningProceduralID
    // }
    const obj = {
      BanningProtocolID: +getId,
      BanningProceduralID: +0,
      BanningProceduralTitle: ProceduralName,
    };

    console.log(obj);
    this.updateBanningProtocolProcedural(obj);
  }

  updateBanningProtocolProcedural(obj) {
    this.BanningService.UpdateBanningProcedural(obj).subscribe((res) => {});
  }

  BID: any;

  updateBanningProtocol(obj) {
    this.BanningService.updateBanningProtocol(obj).subscribe((res: any) => {
      this.tostre.success("The Record has been saved successfully.");
      //Swal.fire("Protocol Created Successfully")
      this.getBanningProtocolBListByGlobalEnvironmentID();

      this.IsAddProtocolBtn = false;

      // this.BID = res.data.UpdateBanningProtocol[0].ReturnKey

      //this.scroll(this.BID)
    });
  }

  banId: number = 0;
  newBanId: number = 0;
  protocolNewName: any;

  /**
   * Add Banning Protocol
   */
  //checkLen
  // getLast(i) {
  //   if (i === this.checkLen) {
  //     let scrollid = 'banningrow' + this.checkLen
  //     let r = document.getElementById(scrollid)
  //     r.scrollIntoView({ behavior: "smooth" })

  //   }

  //}
  addBannProtocol(data) {
    this.IsAddProtocolBtn = true;

    let len = data["controls"].length;
    //this.checkLen = len
    //let scrollid = 'banningrow' + (data["controls"].length - 1)

    //console.log(scrollid)
    // this.newBanId = ++this.banId

    let last = len != 0 ? this.getBanningProtocol[0] : undefined;

    let lastProtocolName = last ? last.ProtocolName : "Banning Protocol 0";

    // let proId=lastProtocolName.slice(-2)

    let pId = lastProtocolName.slice(-2);

    if (this.getBanningProtocol.length > 0) {
      this.newBanId = ++pId;
    } else {
      this.newBanId = ++len;
    }

    this.protocolNewName = "Banning Protocol " + this.newBanId;

    let protocol = {
      BanningProtocalID: 0,
      ProtocolName: this.protocolNewName,
    };

    const obj = {
      BanningProtocolID: 0,
      GlobalEnvironmentID: +this.GlobalEnvironmentID,
      ProtocolName: this.protocolNewName,
      ProtocolNotes: "",
      IsLock: "",
      CreatedBy: this.currentUserID,
    };

    console.log(obj);

    this._addBanningControl = this.AddBanningProtocol.get("addBanningRows");
    //console.log(this._addBanningControl["controls"])
    this._addBanningControl["controls"].unshift(this.addBanningRows(protocol));

    //console.log(obj)
    this.updateBanningProtocol(obj);

    // this.scroll(scrollid)
  }

  scroll(id: any) {
    console.log(`scrolling to ${id}`);

    let el: any = document.getElementById(id);
    console.log(el);
    el.scrollIntoView({ behavior: "smooth" });
  }

  /**
   * Get Banning ProtocolBList By GlobalEnvironmentID
   *
   */

  getBanningProtocolBListByGlobalEnvironmentID() {
    const obj = {
      GlobalEnvironmentID: +this.GlobalEnvironmentID,
    };
    this.BanningService.getBanningProtocolBListByGlobalEnvironmentID(
      obj
    ).subscribe((res) => {
      this.getBanningProtocol =
        res.data.getBanningProtocolBListByGlobalEnvironmentID;
      this.AddBanningProtocol = new FormGroup({
        addBanningRows: this.formBuilder.array([]),
        protocolName: new FormControl(),
      });

      console.log(this.getBanningProtocol.reverse());

      if (this.getBanningProtocol.length > 0) {
        this.getBanningProtocol.forEach((element: any, index) => {
          this._addBanningControl = this.AddBanningProtocol.get(
            "addBanningRows"
          );
          this._addBanningControl.push(this.addBanningRows(element));

          element.DurationList.forEach((elem, i) => {
            this.addPermittedduration(
              i,
              elem.DurationName,
              index,
              true,
              elem.BanningDurationID,
              elem.IsDurationUsed,
              elem.DurationTime
            );
          });

          element.charactersticsList.forEach((elem, i) => {
            this.addPermittedCharacteristic(
              i,
              elem.BanningCharacteristicTitle,
              index,
              true,
              elem.BanningCharacteristicID
            );
          });

          element.proceduralList.forEach((elem, i) => {
            this.addPermittedProcedural(
              i,
              elem.BanningProceduralTitle,
              index,
              true,
              elem.BanningProceduralID
            );
          });
        });
      }
    });
  }

  /**
   * Edit Protocol Name
   * @param index
   */

  editProtocolName(index) {
    this.editProName = true;

    this.AddBanningProtocol.get("addBanningRows")
      ["controls"][index].get("ProtocolName")
      .enable();
  }

  // saveProtocolName(index) {
  //   this.AddBanningProtocol.get("addBanningRows")["controls"][index].get("ProtocolName").disable()
  //   let y = this.AddBanningProtocol.get("addBanningRows")["controls"][index].get("ProtocolName").value

  // }

  /**
   * Update Notes
   * @param value
   * @param index
   */

  updateNotes(value, index) {
    let BanningProtocolID = this.getBanningProtocol[index].BanningProtocolID;

    const obj = {
      GlobalEnvironmentID: +this.GlobalEnvironmentID,
      BanningProtocolID: +BanningProtocolID,
      ProtocolNotes: value,
    };

    this.BanningService.UpdateBanningProtocolByProtocolNotes(
      obj
    ).subscribe((res) => {});
  }

  updateProtocolName(ProtocolName, index) {
    let BanningProtocolID = this.getBanningProtocol[index].BanningProtocolID;

    if (ProtocolName.trim() == "") {
      Swal.fire("Please Enter Protocol Name");
      return;
    }

    const obj = {
      GlobalEnvironmentID: +this.GlobalEnvironmentID,
      BanningProtocolID: +BanningProtocolID,
      ProtocolName: ProtocolName,
    };
    console.log(obj);

    this.BanningService.UpdateBanningProtocolByProtocolName(obj).subscribe(
      (res) => {
        this.editProName = false;
      }
    );
  }

  /**
   * Show Duration Delete Icon
   * @param currentIndex
   * @param BanningDControl
   */
  checkDuration(currentIndex, BanningDControl) {
    if (
      currentIndex >= 0 &&
      currentIndex < BanningDControl["controls"].length - 1
    ) {
      return true;
    }

    return false;
  }

  disableText(currentIndex, BanningDControl) {
    if (
      currentIndex >= 0 &&
      currentIndex < BanningDControl["controls"].length - 1
    ) {
      return true;
    }

    return false;
  }

  /**
   * Show Characterstic Delete Icon
   * @param currentIndex
   * @param BanningCControl
   */
  checkCharacterstics(currentIndex, BanningCControl) {
    if (
      currentIndex >= 0 &&
      currentIndex < BanningCControl["controls"].length - 1
    ) {
      return true;
    }

    return false;
  }

  /**
   * Show Procedural Delete Icon
   * @param currentIndex
   * @param BanningPControl
   */

  checkProcedural(currentIndex, BanningPControl) {
    if (
      currentIndex >= 0 &&
      currentIndex < BanningPControl["controls"].length - 1
    ) {
      return true;
    }

    return false;
  }

  /**
   * Delete Duration
   * @param index
   * @param BanningProtocolDurationID
   */

  deleteDuration(index, BanningDurationID, j) {
    let BanningProtocolID = this.getBanningProtocol[index].BanningProtocolID;

    const obj = {
      BanningProtocolID: +BanningProtocolID,
      BanningProtocolDurationID: +BanningDurationID,
    };

    let array: any = this.AddBanningProtocol.get("addBanningRows");

    this._banningControl = array.controls[index].get("BanningDuration")[
      "controls"
    ];

    this._banningControl.splice(j, 1);

    console.log(this._banningControl);

    this.BanningService.DeleteBanningProtocolDuration(obj).subscribe((res) => {
      //   document.getElementById("banningDuration" + BanningProtocolDurationID).remove()
    });
  }

  /**
   * Delete Charactersctic
   * @param index
   * @param BanningProtocolCharactersticID
   */

  deleteCharactersctic(index, BanningProtocolCharactersticID, k) {
    let BanningProtocolID = this.getBanningProtocol[index].BanningProtocolID;

    const obj = {
      BanningProtocolID: +BanningProtocolID,
      BanningProtocolCharactersticID: +BanningProtocolCharactersticID,
    };

    let array: any = this.AddBanningProtocol.get("addBanningRows");

    this._banningCControl = array.controls[index].get("BanningCharacteristic")[
      "controls"
    ];

    this._banningCControl.splice(k, 1);

    this.BanningService.DeleteBanningProtocolCharacteristic(obj).subscribe(
      (res) => {
        // document.getElementById("banningCharacterstics" + BanningProtocolCharactersticID).remove()
      }
    );
  }

  /**
   * Delete Procedural
   * @param index
   * @param BanningProtocolProceduralID
   */

  deleteProcedural(index, BanningProtocolProceduralID, l) {
    let BanningProtocolID = this.getBanningProtocol[index].BanningProtocolID;

    const obj = {
      BanningProtocolID: +BanningProtocolID,
      BanningProtocolProceduralID: +BanningProtocolProceduralID,
    };

    let array: any = this.AddBanningProtocol.get("addBanningRows");

    this._banningPControl = array.controls[index].get("BanningProcedural")[
      "controls"
    ];
    this._banningPControl.splice(l, 1);

    this.BanningService.DeleteBanningProtocolProcedural(obj).subscribe(
      (res) => {
        // document.getElementById("banningProcedural" + BanningProtocolProceduralID).remove()
      }
    );
  }

  /**
   * Delete Banning Protocol
   */
  deleteBanningProtocol(index, BanningProtocalID) {
    const obj = {
      BanningProtocolID: BanningProtocalID,
    };

    Swal.fire({
      // text: "Are you sure you want to delete banning protocol?",
      text: this.adminService.deleteMsg,
      showCancelButton: true,
      width: "30%",
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes",
      cancelButtonText: "No",
    }).then((result) => {
      if (result.value) {
        this.BanningService.DeleteBanningProtocol(obj).subscribe((res) => {
          console.log(res);
          this.AddBanningProtocol.get("addBanningRows")["controls"].splice(
            index,
            1
          );
        });
      }
    });
  }
}
