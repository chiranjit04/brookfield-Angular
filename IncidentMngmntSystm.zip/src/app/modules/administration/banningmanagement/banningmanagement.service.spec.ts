import { TestBed } from '@angular/core/testing';

import { BanningmanagementService } from './banningmanagement.service';

describe('BanningmanagementService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BanningmanagementService = TestBed.get(BanningmanagementService);
    expect(service).toBeTruthy();
  });
});
