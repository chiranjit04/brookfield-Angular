import { Injectable } from "@angular/core";
import { Observable, of } from "rxjs";
import { HttpClient } from "@angular/common/http";
import { environment } from "../../../../environments/environment";

@Injectable({
  providedIn: "root",
})
export class BanningmanagementService {
  observable: Observable<any>;
  url: any;
  constructor(private http: HttpClient) {
    this.url = environment.origin + "api/";
  }

  getBanningDuration() {
    try {
      return this.http.get<any>(`${this.url}Banning/GetBanningDuration`);
    } catch (error) {
      throw error;
    }
  }

  getBanningCharacteristic() {
    try {
      return this.http.get<any>(`${this.url}Banning/GetBanningCharacteristic`);
    } catch (error) {
      throw error;
    }
  }

  getBanningProcedural() {
    try {
      return this.http.get<any>(`${this.url}Banning/GetBanningProcedural`);
    } catch (error) {
      throw error;
    }
  }
  updateBanningProtocol(param: any) {
    try {
      return this.http.post<any>(
        `${this.url}Banning/UpdateBanningProtocol`,
        param
      );
    } catch (error) {
      throw error;
    }
  }
  updateBanningProtocolDuration(param: any) {
    try {
      return this.http.post<any>(
        `${this.url}Banning/UpdateBanningProtocolDuration`,
        param
      );
    } catch (error) {
      throw error;
    }
  }
  updateBanningProtocolCharacteristic(param: any) {
    try {
      return this.http.post<any>(
        `${this.url}Banning/UpdateBanningProtocolCharacteristic`,
        param
      );
    } catch (error) {
      throw error;
    }
  }
  updateBanningProtocolProcedural(param: any) {
    try {
      return this.http.post<any>(
        `${this.url}Banning/UpdateBanningProtocolProcedural`,
        param
      );
    } catch (error) {
      throw error;
    }
  }
  getBanningProtocolBListByGlobalEnvironmentID(param: any) {
    try {
      return this.http.post<any>(
        `${this.url}Banning/GetBanningProtocolBListByGlobalEnvironmentID`,
        param
      );
    } catch (error) {
      throw error;
    }
  }

  /* Bannig record in property module */
  GetBanningProtocolList(params: any) {
    return this.http.post<any>(
      `${this.url}Banning/GetBanningProtocolList`,
      params
    );
  }

  UpdateBanningPropertyProtocol(params: any) {
    return this.http.post<any>(
      `${this.url}Banning/UpdateBanningPropertyProtocol`,
      params
    );
  }

  GetBanningPropertyProtocolByID(params: any) {
    return this.http.post<any>(
      `${this.url}Banning/GetBanningPropertyProtocolByID`,
      params
    );
  }

  UpdateBanningProtocolByProtocolNotes(params: any) {
    return this.http.post<any>(
      `${this.url}Banning/UpdateBanningProtocolByProtocolNotes`,
      params
    );
  }

  UpdateBanningProtocolByIsLock(params: any) {
    return this.http.post<any>(
      `${this.url}Banning/UpdateBanningProtocolByIsLock`,
      params
    );
  }

  DeleteBanningProtocolDuration(params: any) {
    return this.http.post<any>(
      `${this.url}Banning/DeleteBanningProtocolDuration`,
      params
    );
  }

  DeleteBanningProtocolCharacteristic(params: any) {
    return this.http.post<any>(
      `${this.url}Banning/DeleteBanningProtocolCharacteristic`,
      params
    );
  }

  DeleteBanningProtocolProcedural(params: any) {
    return this.http.post<any>(
      `${this.url}Banning/DeleteBanningProtocolProcedural`,
      params
    );
  }

  UpdateBanningProtocolByProtocolName(params: any) {
    return this.http.post<any>(
      `${this.url}Banning/UpdateBanningProtocolByProtocolName`,
      params
    );
  }

  DeleteBanningProtocol(params: any) {
    return this.http.post<any>(
      `${this.url}Banning/DeleteBanningProtocol`,
      params
    );
  }

  UpdateBanningDuration(params: any) {
    return this.http.post<any>(
      `${this.url}Banning/UpdateBanningDuration`,
      params
    );
  }

  UpdateBanningCharacteristic(params: any) {
    return this.http.post<any>(
      `${this.url}Banning/UpdateBanningCharacteristic`,
      params
    );
  }

  UpdateBanningProcedural(params: any) {
    return this.http.post<any>(
      `${this.url}Banning/UpdateBanningProcedural`,
      params
    );
  }
  GetCustomFormDetailsByPropertyId(param) {
    return this.http.post<any>(
      this.url + "GetCustomFormDetailsByPropertyId",
      param
    );
  }
}
