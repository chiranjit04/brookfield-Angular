import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportingsetsComponent } from './reportingsets.component';

describe('ReportingsetsComponent', () => {
  let component: ReportingsetsComponent;
  let fixture: ComponentFixture<ReportingsetsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportingsetsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportingsetsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
