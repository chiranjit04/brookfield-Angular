import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { environment } from "../../../../environments/environment";
import { Observable } from "rxjs";
import { BehaviorSubject } from "rxjs";
import { Workbook } from "exceljs";
import * as fs from "file-saver";
import * as XLSX from "xlsx";
// import * as logoFile from "./Brookfieldlogo.js";
import  * as logoFile from "src/assets/images/logo/brookfieldlogo";

@Injectable({
  providedIn: "root",
})
export class GlobalService {
  url: any;
  displayedTitle: any = "";
  observable: Observable<any>;

  private messageSource = new BehaviorSubject("default message");
  currentMessage = this.messageSource.asObservable();

  constructor(private http: HttpClient) {
    this.url = environment.origin + "api/";
  }
  // private url = 'http://localhost:1601/api/';

  // posting to Database
  postOperations(formValue: any) {
    return this.http.post<any>(`${this.url}UpdateGlobalEnvironment`, formValue);
  }

  // Getting overall data from the database to render in the tables

  getOperations() {
    this.observable = this.http.get(`${this.url}GetGlobalEnvironmentList`);
    return this.observable;
  }

  // Updating the existing fields

  updateOperations(updatedData: any) {
    return this.http.put(`${this.url}UpdateGlobalEnvironment`, updatedData);
  }

  getReportingSetOnScreenList(GlobalEnvironmentID: any) {
    return this.http.post<any>(`${this.url}GetReportingSetOnScreenList`, {
      GlobalEnvironmentID: GlobalEnvironmentID,
    });
  }

  ReportingImport(obj) {
    try {
      console.log("Reporting service hitting");
      return this.http.post<any>(`${this.url}ReportingSetImport`, obj);
    } catch (error) {
      throw error;
    }
  }

  getReportingSetList(globalEnvId: any) {
    return this.http.post<any>(`${this.url}GetReportingSetList`, {
      GlobalEnvironmentID: globalEnvId,
    });
  }

  getISCITypeList(GlobalEnvironmentID: any) {
    return this.http.post<any>(`${this.url}GetISCITypeList`, {
      GlobalEnvironmentID: GlobalEnvironmentID,
    });
  }

  getISCISubject(id: any) {
    return this.http.post<any>(`${this.url}GetISCISubject`, id);
  }

  getISCICategory(id: any) {
    return this.http.post<any>(`${this.url}GetISCICategory`, id);
  }

  updateISCI(data: any) {
    return this.http.post<any>(`${this.url}UpdateISCI`, data);
  }

  updateReportingSet(data: any) {
    return this.http.post<any>(`${this.url}UpdateReportingSet`, data);
  }

  getISCISubjectList(ParentID) {
    return this.http.post<any>(`${this.url}GetISCISubjectList`, {
      ParentId: ParentID,
    });
  }

  getISCICategoryList(ParentId) {
    return this.http.post<any>(`${this.url}GetISCICategoryList`, { ParentId });
  }

  getReportingSetSubjectBreadCrumb(ReportingSetID) {
    return this.http.post<any>(`${this.url}GetReportingSetSubjectBreadCrumb`, {
      ReportingSetID,
    });
  }

  getISCIReportingSetSubjectListByLevel(
    GlobalEnvironmentID,
    ReportingSetID,
    ParentID,
    Level
  ) {
    return this.http.post<any>(
      `${this.url}GetISCIReportingSetSubjectListByLevel`,
      {
        GlobalEnvironmentID,
        ReportingSetID,
        ParentID,
        Level,
      }
    );
  }

  removeAssignedSubjects(ISCIReportingGroupId, ReportingSubjectId, IsAssign) {
    return this.http.post<any>(`${this.url}AssignRemoveReportingSetSubject`, {
      ISCIReportingGroupId: +ISCIReportingGroupId,
      ReportingSubjectId: +ReportingSubjectId,
      IsAssign: +IsAssign,
    });
  }

  ChangeGlobalEnvironmentStatus(GlobalEnvironmentID: any) {
    let postData = { GlobalEnvironmentID: GlobalEnvironmentID };
    this.observable = this.http.post(
      `${this.url}ChangeGlobalEnvironmentStatus`,
      postData
    );
    return this.observable;
  }

  displayTitle(selectedGlobalEnvironmentName) {
    this.displayedTitle = selectedGlobalEnvironmentName;
  }

  GetISCIReportingSubjectList(
    ParentID: any,
    GlobalEnvironmentID: any,
    ReportingSetID: any,
    Level: any
  ) {
    let postData = {
      ParentID: ParentID,
      GlobalEnvironmentID: GlobalEnvironmentID,
      ReportingSetID: ReportingSetID,
      Level: Level,
    };
    this.observable = this.http.post(
      `${this.url}GetISCIReportingSubjectList`,
      postData
    );
    return this.observable;
  }

  deleteReportingSet(ISCIReportingGroupID: any) {
    let options = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
      }),
      body: {
        ...ISCIReportingGroupID,
      },
    };
    // return this.http.delete<any>(
    //   `http://localhost:1601/api/DeleteReportingSet`,
    //   options
    // );
    return this.http.delete<any>(`${this.url}DeleteReportingSet`, options);
  }

  toggleActiveInactive(ReportingSetID: any) {
    let data = {
      ISCIReportingGroupID: ReportingSetID,
    };
    // return this.http.post<any>(
    //   `http://localhost:1601/api/ReportingSetStatus`,
    //   data
    // );
    return this.http.post<any>(`${this.url}ReportingSetStatus`, data);
  }

  getReportingSetListDonwloadByGOEID(GlobalEnvironmentID: any) {
    let data = {
      GlobalEnvironmentID: GlobalEnvironmentID,
    };

    return this.http.post<any>(
      `${this.url}GetReportingSetListDonwloadByGOEID`,
      data
    );
  }

  // Export Reporting Set Data
  async exportAsExcelFile(json: any[]) {
    const title = "Reporting Set Exported Data";
    const header = [
      "Reporting Set Name",
      "Incident Subject",
      "Description",
      "High Response Priority",
      "Show  On Just Happned",
      "Include In Query Option",
      "Status",
    ];

    // Create workbook and worksheet
    const workbook = new Workbook();
    const worksheetOne = workbook.addWorksheet("Instructions");
    const worksheet = workbook.addWorksheet("Reporting Set Data");
    const worksheetTwo = workbook.addWorksheet("System Pick Values");

    let objectList = [];

    json.map((data) => {
      if (data.IsActive) {
        data.IsActive = "Active";
      } else {
        data.IsActive = "InActive";
      }
    });

    objectList = json.map((ob) => Object.values(ob));
    console.log("what are we getting here", objectList);

    // Add the Header Image
    worksheet.mergeCells("A1:B1");
    const imageRow = worksheet.getRow(1);
    imageRow.height = 110;

    // Add Image
    const logo = workbook.addImage({
      base64: logoFile.logoBase64,
      extension: "png",
    });

    worksheet.addImage(logo, {
      tl: { col: 0.5, row: 0.5 },
      ext: { width: 350, height: 85 },
    });
    const titleRow = worksheet.addRow([title]);
    titleRow.font = { name: "Calibri", family: 4, size: 16, bold: true };
    worksheet.mergeCells("A2:C2");
    worksheet.getRow(2).height = 30;
    // Add Header Row
    const headerRow = worksheet.addRow(header);

    // Set a specific row height
    headerRow.height = 42.5;

    headerRow.font = { name: "Calibri", family: 4, size: 11, bold: true };
    headerRow.alignment = {
      vertical: "middle",
      horizontal: "center",
    };

    // Cell Style : Fill and Border
    headerRow.eachCell((cell, number) => {
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "0xEAF1DD" },
        bgColor: { argb: "FF0000FF" },
      };
      cell.border = {
        top: { style: "thin" },
        left: { style: "thin" },
        bottom: { style: "thin" },
        right: { style: "thin" },
      };
    });
    // worksheet.addRows(data);
    worksheet.getCell("C3").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "" },
      bgColor: { argb: "" },
    };
    worksheet.getCell("D3").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "" },
      bgColor: { argb: "" },
    };
    worksheet.getCell("E3").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "" },
      bgColor: { argb: "" },
    };
    worksheet.getCell("F3").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "" },
      bgColor: { argb: "" },
    };

    // Add Data and Conditional Formatting
    objectList.forEach((d) => {
      const row = worksheet.addRow(d);
      row.alignment = { horizontal: "center", wrapText: true };
      const qty = row.getCell(4);
    });

    worksheet.getColumn(1).width = 30;
    worksheet.getColumn(2).width = 30;
    worksheet.getColumn(3).width = 30;
    worksheet.getColumn(4).width = 30;
    worksheet.getColumn(5).width = 30;
    worksheet.getColumn(6).width = 30;
    worksheet.getColumn(7).width = 30;
    worksheet.addRow([]);

    //Worksheet for Instructions Start***********************

    worksheetOne.getColumn(3).width = 13;
    worksheetOne.getColumn(4).width = 13;

    // Add the Header Image
    worksheetOne.mergeCells("D1:H5");
    // Add Image
    const logoOne = workbook.addImage({
      base64: logoFile.logoBase64,
      extension: "png",
    });

    worksheetOne.addImage(logoOne, "D1:H5");
    worksheetOne.addRow([]);

    worksheetOne.mergeCells("C7", "I7");

    worksheetOne.getCell("C7").value =
      "Brookfield Properties Reporting Set Spreadsheet";
    worksheetOne.getCell("C7").font = {
      name: "Calibri",
      family: 4,
      size: 16,
      underline: true,
      bold: true,
    };
    worksheetOne.getCell("C7").alignment = { vertical: "middle",horizontal: "center" };
    worksheetOne.getRow(7).height = 25;
    worksheetOne.addRow([]);
    worksheetOne.addRow([]);

    worksheetOne.getCell("B10").value =
      "Please list the Brookfield Properties, these Properties are customized to represent that company’s organizational structure and related positions of oversight.";
    worksheetOne.getCell("B10").alignment = {
      vertical: "top",
      horizontal: "left",
      wrapText: true,
    };

    worksheetOne.mergeCells("B10", "K13");

    worksheetOne.getCell("B10").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "E2EFD9" },
      bgColor: { argb: "FF0000FF" },
    };

    worksheetOne.getCell("B15").value =
      "Set of Instructions for the Spreadsheet:";
    worksheetOne.getCell("B15").font = {
      name: "Calibri",
      family: 4,
      size: 12,
      bold: true,
    };
    worksheetOne.addRow([]);
    worksheetOne.getCell("B17").value = "GENERAL INFO:";
    worksheetOne.getCell("B23").alignment = { horizontal: "center" };
    worksheetOne.getCell("B17").font = {
      name: "Calibri",
      family: 4,
      size: 12,
      bold: true,
    };
    worksheetOne.getCell("B18").value = "-";
    worksheetOne.getCell("B18").alignment = { horizontal: "right" };
    worksheetOne.getCell("C18").value =
      "Please fill in the required fields to upload data into MAXIMUS.";
    worksheetOne.addRow([]);
    worksheetOne.getCell("B20").value = "-";
    worksheetOne.getCell("B20").alignment = { horizontal: "right" };
    worksheetOne.getCell("C20").value =
      "Dropdown values will appear in each cell if there is a selection to be made,";
    worksheetOne.getCell("C21").value = " otherwise enter appropriate data.";
    worksheetOne.addRow([]);
    worksheetOne.getCell("B23").value = "-";
    worksheetOne.getCell("B23").alignment = { horizontal: "right" };
    worksheetOne.getCell("C23").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "E2EFD9" },
      bgColor: { argb: "FF0000FF" },
    };
    worksheetOne.getCell("C23").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheetOne.getCell("D23").value =
      "Headers in Light Green are Mandatory or Required fields.";
    worksheetOne.getCell("B24").value = "-";
    worksheetOne.getCell("B24").alignment = { horizontal: "right" };
    worksheetOne.getCell("C24").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "" },
      bgColor: { argb: "" },
    };
    worksheetOne.getCell("C24").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheetOne.getCell("D24").value =
      "Headers in White are not Required entry fields.";
    worksheetOne.addRow([]);
    worksheetOne.getCell("B26").value = "-";
    worksheetOne.getCell("B26").alignment = { horizontal: "right" };
    worksheetOne.getCell("C26").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "" },
      bgColor: { argb: "" },
    };
    worksheetOne.getCell("C26").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheetOne.getCell("D26").value =
      "Header cells that include a red triangle at top right provide";
    worksheetOne.getCell("D27").value =
      "information about the field when you mouse over the cell.";

    //Worksheet for Instructions Ends***********************

    //WorkSheet for System Pick Values Starts***********************

    worksheetTwo.getCell("C2").value = "Active";
    worksheetTwo.getCell("C3").value = "InActive";
    worksheetTwo.getCell("D2").value = "Yes";
    worksheetTwo.getCell("D3").value = "No";

    //WorkSheet for System Pick Values Ends*************************

    // Generate Excel File with given name
    workbook.xlsx.writeBuffer().then((data: any) => {
      const blob = new Blob([data], {
        type:
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });
      fs.saveAs(blob, "ReportingSetExportData.xlsx");
    });
  }

  //New Upload list Download
  // Export Reporting Set Data
  async exportUploadExcelFile(json: any[]) {
    const title = "Location Exported Data";
    const header = [
      "ReportingSet Name",
      "Incident Subject",
      "Description",
      "High Response Priority",
      "Show  On Just Happned",
      "Include In Query Option",
      "Status",
    ];

    // Create workbook and worksheet
    const workbook = new Workbook();

    const worksheetOne = workbook.addWorksheet("Instructions");
    const worksheet = workbook.addWorksheet("Reporting Set Data");
    const worksheetTwo = workbook.addWorksheet("System Pick Values");

    let objectList = [];

    // json.map((data) => {
    //   if (data.IsActive) {
    //     data.IsActive = "Active";
    //   } else {
    //     data.IsActive = "InActive";
    //   }
    // });

    objectList = json.map((ob) => Object.values(ob));

    // Add the Header Image
    worksheet.mergeCells("A1:B1");
    const imageRow = worksheet.getRow(1);
    imageRow.height = 110;

    // Add Image
    const logo = workbook.addImage({
      base64: logoFile.logoBase64,
      extension: "png",
    });

    worksheet.addImage(logo, {
      tl: { col: 0.5, row: 0.5 },
      ext: { width: 350, height: 85 },
    });
    const titleRow = worksheet.addRow([title]);
    titleRow.font = { name: "Calibri", family: 4, size: 16, bold: true };
    worksheet.mergeCells("A2:C2");
    // Add Header Row
    const headerRow = worksheet.addRow(header);

    // Set a specific row height
    headerRow.height = 42.5;

    headerRow.font = { name: "Calibri", family: 4, size: 11, bold: true };
    headerRow.alignment = {
      vertical: "middle",
      horizontal: "center",
    };

    // Cell Style : Fill and Border
    headerRow.eachCell((cell, number) => {
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "0xEAF1DD" },
        bgColor: { argb: "FF0000FF" },
      };
      cell.border = {
        top: { style: "thin" },
        left: { style: "thin" },
        bottom: { style: "thin" },
        right: { style: "thin" },
      };
    });
    // worksheet.addRows(data);
    worksheet.getCell("C3").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "" },
      bgColor: { argb: "" },
    };
    worksheet.getCell("D3").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "" },
      bgColor: { argb: "" },
    };
    worksheet.getCell("E3").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "" },
      bgColor: { argb: "" },
    };
    worksheet.getCell("F3").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "" },
      bgColor: { argb: "" },
    };

    // Add Data and Conditional Formatting
    objectList.forEach((d) => {
      const row = worksheet.addRow(d);
      row.alignment = { horizontal: "center", wrapText: true };
      const qty = row.getCell(4);
    });

    worksheet.getColumn(1).width = 30;
    worksheet.getColumn(2).width = 30;
    worksheet.getColumn(3).width = 30;
    worksheet.getColumn(4).width = 30;
    worksheet.getColumn(5).width = 30;
    worksheet.getColumn(6).width = 30;
    worksheet.getColumn(7).width = 30;
    worksheet.getColumn(8).width = 30;
    worksheet.getColumn(9).width = 30;
    worksheet.addRow([]);

    //Worksheet for Instructions Start***********************

    worksheetOne.getColumn(3).width = 13;
    worksheetOne.getColumn(4).width = 13;

    // Add the Header Image
    worksheetOne.mergeCells("D1:H5");
    // Add Image
    const logoOne = workbook.addImage({
      base64: logoFile.logoBase64,
      extension: "png",
    });

    worksheetOne.addImage(logoOne, "D1:H5");
    worksheetOne.addRow([]);

    worksheetOne.getCell("C7").value =
      "Brookfield Properties Reporting Set Spreadsheet";
    worksheetOne.getCell("C7").font = {
      name: "Calibri",
      family: 4,
      size: 16,
      underline: true,
      bold: true,
    };

    worksheetOne.addRow([]);
    worksheetOne.addRow([]);

    worksheetOne.getCell("B10").value =
      "Please list the Brookfield Properties Report set these Report set are an occurence of an action or situation that is a separate unit of experience on any Property.";
    worksheetOne.getCell("B10").alignment = {
      vertical: "top",
      horizontal: "left",
      wrapText: true,
    };

    worksheetOne.mergeCells("B10", "K13");

    worksheetOne.getCell("B10").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "E2EFD9" },
      bgColor: { argb: "FF0000FF" },
    };

    worksheetOne.getCell("B15").value =
      "Set of Instructions for the Spreadsheet:";
    worksheetOne.getCell("B15").font = {
      name: "Calibri",
      family: 4,
      size: 12,
      bold: true,
    };
    worksheetOne.addRow([]);
    worksheetOne.getCell("B17").value = "GENERAL INFO:";
    worksheetOne.getCell("B23").alignment = { horizontal: "center" };
    worksheetOne.getCell("B17").font = {
      name: "Calibri",
      family: 4,
      size: 12,
      bold: true,
    };
    worksheetOne.getCell("B18").value = "-";
    worksheetOne.getCell("B18").alignment = { horizontal: "right" };
    worksheetOne.getCell("C18").value =
      "Please fill in the required fields to upload data into MAXIMUS.";
    worksheetOne.addRow([]);
    worksheetOne.getCell("B20").value = "-";
    worksheetOne.getCell("B20").alignment = { horizontal: "right" };
    worksheetOne.getCell("C20").value =
      "Dropdown values will appear in each cell if there is a selection to be made,";
    worksheetOne.getCell("C21").value = " otherwise enter appropriate data.";
    worksheetOne.addRow([]);
    worksheetOne.getCell("B23").value = "-";
    worksheetOne.getCell("B23").alignment = { horizontal: "right" };
    worksheetOne.getCell("C23").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "E2EFD9" },
      bgColor: { argb: "FF0000FF" },
    };
    worksheetOne.getCell("C23").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheetOne.getCell("D23").value =
      "Headers in Light Green are Mandatory or Required fields.";
    worksheetOne.getCell("B24").value = "-";
    worksheetOne.getCell("B24").alignment = { horizontal: "right" };
    worksheetOne.getCell("C24").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "" },
      bgColor: { argb: "" },
    };
    worksheetOne.getCell("C24").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheetOne.getCell("D24").value =
      "Headers in White are not Required entry fields.";
    worksheetOne.addRow([]);
    worksheetOne.getCell("B26").value = "-";
    worksheetOne.getCell("B26").alignment = { horizontal: "right" };
    worksheetOne.getCell("C26").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "" },
      bgColor: { argb: "" },
    };
    worksheetOne.getCell("C26").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheetOne.getCell("D26").value =
      "Header cells that include a red triangle at top right provide";
    worksheetOne.getCell("D27").value =
      "information about the field when you mouse over the cell.";

    //Worksheet for Instructions Ends***********************

    //WorkSheet for System Pick Values Starts***********************

    worksheetTwo.getCell("C2").value = "Active";
    worksheetTwo.getCell("C3").value = "InActive";
    worksheetTwo.getCell("D2").value = "Yes";
    worksheetTwo.getCell("D3").value = "No";

    //WorkSheet for System Pick Values Ends*************************

    // Generate Excel File with given name
    workbook.xlsx.writeBuffer().then((data: any) => {
      const blob = new Blob([data], {
        type:
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });
      fs.saveAs(blob, "ReportingSetExportData.xlsx");
    });
  }
}
