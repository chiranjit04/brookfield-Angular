import { Component, OnInit, ViewChild } from "@angular/core";
import {
  FormGroup,
  FormControl,
  Validators,
  FormBuilder,
} from "@angular/forms";
import { MatTableDataSource } from "@angular/material/table";
import { MatSort } from "@angular/material/sort";
import { GlobalService } from "./reportingsets.service";
import Swal from "sweetalert2";
import { Router } from "@angular/router";
import * as XLSX from "xlsx";
import { ToastrService } from "ngx-toastr";
import { UserPermissionService } from "../../../services/user-permission.service";
import { StorageService } from "../../../services/storage.service";
import { ServiceService } from "./../service/service.service";
@Component({
  selector: "app-reportingsets",
  templateUrl: "./reportingsets.component.html",
  styleUrls: ["./reportingsets.component.scss"],
})
export class ReportingsetsComponent implements OnInit {
  reportingSets: any = [];
  ISCITypeList: any = [];
  ISCISubjectList: any = [];
  breadCrums: any = [];
  categoryList: any = [];
  subjectList: any = [];
  subjectListFromCategory: any = [];

  addgoprs = false;
  editform = false;
  propertiesassignedrs = false;
  propertytypers = false;
  incidentsubjectrs = false;
  selectedISCIReportingGroupID = false;
  selectedISCICategoryID = false;
  selectedISCICategoryIDI = false;
  selectedISCICategoryIDIN = false;
  selectedISCICategoryIDIL = false;
  statusgroup = false;
  addSubmitted = false;
  submitted = false;
  locationDisplay = false;
  showUploadTable = false;
  selectedItem: any = false;

  IsHighProfile = "";
  IsJustHappened = "";
  IsHideReportingSet = "";
  ReportingSetID = "";
  ISCICategoryID = "";
  editRepotingTitle = "";
  editReportingDesc = "";
  editIsHighProfile;
  editIsJustHappened;
  editIsHideReportingSet;

  authToken = null;
  userData = null;
  currentUserID = false;

  ReportingSetImportList: any = [];
  UploadedReportingList = [];
  ReportingList: any = [];
  newReportingList: any = [];

  hideTableMain = true;
  dataSourceOne: MatTableDataSource<any>;
  dataSourceTwo: MatTableDataSource<any>;
  @ViewChild("TableOneSort", { static: false }) tableOneSort: MatSort;

  /* GlobalEnvironmentID = 1
  globalEnvironmentName = "Brookfield Properties Retail Environment"
  GOENumber = "GOE-20-001" */
  GlobalEnvironmentID = 0;
  GlobalEnvironmentName = "";
  GOENumber = "";

  GlobalEnvironmentDetails = null;

  displayedColumnsOne: string[] = [
    "ReportingTitle",
    "Description",
    "ShowOnJustHapppened",
    "HighResponseProfile",
    "IncludeInQueryOption",
    "CreatedDate",
    "IsActive",
  ];

  displayedColumnsTwo: string[] = [
    "ReportingSetName",
    "IncidentSubject",
    "Description",
    "HighResponsePriority",
    "ShowJustHappned",
    "QueryOptions",
    "ReportingSetStatus",
    "Status",
    "Message",
  ];

  data = {
    UserID: 0,
    PropertyID: 0,
    ISCITypeID: 3870,
    ISCICategoryID: null,
  };
  reportingListForm = new FormGroup({
    _Search: new FormControl(""),
  });
  addForm = new FormGroup({
    ReportingSetID: new FormControl(""),
    ReportingTitle: new FormControl("", Validators.required),
    ReportingSetDesc: new FormControl(""),
    ISCICategoryId: new FormControl(),
    IsHighProfile: new FormControl(),
    IsJustHappened: new FormControl(),
    IsHideReportingSet: new FormControl(),
    IsDefaultReportFile: new FormControl(),
    IsProhibitReportFile: new FormControl(),
    IsActive: new FormControl(),
  });

  get addReportingF() {
    return this.addForm.controls;
  }

  editForm = new FormGroup({
    ReportingSetID: new FormControl(""),
    ReportingTitle: new FormControl("", Validators.required),
    ReportingSetDesc: new FormControl(""),
    ISCICategoryId: new FormControl(),
    IsHighProfile: new FormControl(),
    IsJustHappened: new FormControl(),
    IsHideReportingSet: new FormControl(),
    IsDefaultReportFile: new FormControl(),
    IsProhibitReportFile: new FormControl(),

    IsActive: new FormControl(),
  });

  get editReportingF() {
    return this.editForm.controls;
  }

  constructor(
    private GlobalService: GlobalService,
    public router: Router,
    private tostre: ToastrService,
    public UserPermission: UserPermissionService,
    private storage: StorageService,
    private adminService: ServiceService
  ) {
    //... Read User Data ...
    this.authToken = this.storage.getData("token");
    this.userData = JSON.parse(this.storage.getData("UserData"));
    if (this.authToken == null) {
      this.router.navigate(["/login"]);
    }

    /* check module permission of the user */
    // console.log("Perm",this.UserPermission.checkPermission("access_reporting_set", '','',''))
    if (
      this.UserPermission.checkPermission("access_reporting_set", "", "", "") ==
      false
    ) {
      this.router.navigate(["/products/list"]);
      this.tostre.warning(
        "You don't have permission to access this module.",
        "",
        {
          positionClass: "toast-top-right",
        }
      );
    }

    this.GlobalEnvironmentDetails = JSON.parse(
      this.storage.getData("GlobalEnvironmentDetails")
    );
    // console.log(this.GlobalEnvironmentDetails);
    if (this.GlobalEnvironmentDetails) {
      this.GlobalEnvironmentID = this.GlobalEnvironmentDetails.GlobalEnvironmentId;
      this.GlobalEnvironmentName = this.GlobalEnvironmentDetails.GlobalEnvironmentName;
      this.GOENumber = this.GlobalEnvironmentDetails.GOENo;
    }

    this.currentUserID = this.userData[0].UserID;

    this.dataSourceOne = new MatTableDataSource();
    this.dataSourceTwo = new MatTableDataSource();
  }

  checkGoe() {
    if (this.GlobalEnvironmentID) {
      return true;
    } else {
      // Swal.fire({
      //   text: "Please first select a Global Operations Environment.",
      //   timer: 3000,
      // }).then((result) => {
      //   //this.router.navigate(["products/administration/goe/mygoe"]);
      // });
      this.tostre.error(
        "Please first select a Global Operations Environment.",
        "",
        {
          positionClass: "toast-top-right",
        }
      );
      this.router.navigate(["products/administration/goe/mygoe"]);
      return false;
    }
  }

  ngOnInit() {
    if (this.checkGoe()) {
      this.getReportingSets(this.GlobalEnvironmentID);
      this.getISCITypeList(this.GlobalEnvironmentID, 1, 0, 0);
      this.GetISCIReportingSubjectList(0, this.GlobalEnvironmentID, 0, 0);
      this.getReportingSetOnScreenList();
      this.getReportingSetListDonwloadByGOEID();
    }
  }

  openReportingAddForm() {
    this.selectedISCIReportingGroupID = false;
    this.GetISCIReportingSubjectList(0, this.GlobalEnvironmentID, 0, 0);
    this.addgoprs = !this.addgoprs;
    this.addForm.reset();
    // need to remove this one
    let shadesEl = document.querySelectorAll(".show");
    for (let i = 0; i < shadesEl.length; i++) {
      shadesEl[i].classList.remove("show");
    }
  }

  getReportingSetOnScreenList() {
    this.GlobalService.getReportingSetOnScreenList(
      this.GlobalEnvironmentID
    ).subscribe((data) => {
      this.dataSourceOne.data = data.getReportingSetOnScreenList;
      this.dataSourceOne.sort = this.tableOneSort;
      this.tableOneSort.disableClear = true;
      this.ReportingList = data.getReportingSetOnScreenList;
      // console.log("On Screen Table data", data);
    });
  }

  //Getting Reporting Set List
  getReportingSets(GlobalEnvironmentID: any) {
    this.GlobalService.getReportingSetList(GlobalEnvironmentID).subscribe(
      (data) => {
        this.reportingSets = data;
        this.reportingSets = this.reportingSets.GetReportingSetList;
        // console.log("display list", this.reportingSets);
      }
    );
  }

  //Getting ISCI Type List
  getISCITypeList(
    GlobalEnvironmentID: any,
    ReportingSetID: any,
    ParentID: any,
    Level: any
  ) {
    this.GlobalService.getISCIReportingSetSubjectListByLevel(
      GlobalEnvironmentID,
      ReportingSetID,
      ParentID,
      Level
    ).subscribe((data) => {
      let listData = data.GetISCIReportingSetSubjectListByLevel;
      this.ISCITypeList = listData;
    });
  }

  // Getting Subject List
  GetISCIReportingSubjectList(
    ParentID: any,
    GlobalEnvironmentID: any,
    ReportingSetID: any,
    Level: any
  ) {
    this.GlobalService.GetISCIReportingSubjectList(
      ParentID,
      GlobalEnvironmentID,
      ReportingSetID,
      Level
    ).subscribe((result) => {
      this.subjectListFromCategory = result;
      this.subjectListFromCategory = this.subjectListFromCategory.getISCIReportingSubjectList;
    });
  }

  changeCheck(form,conrl) {
    if (conrl == 'IsDefaultReportFile') {
      if(this[form].value.IsDefaultReportFile = true){
        this[form].patchValue({
          IsProhibitReportFile: false
        })
      }
      if(this[form].value.IsProhibitReportFile = false){
        this[form].patchValue({
          IsDefaultReportFile: true
        })
      }
    } else {
      if(this[form].value.IsProhibitReportFile = true){
        this[form].patchValue({
          IsDefaultReportFile: false
        })
      }
      if(this[form].value.IsDefaultReportFile = false){
        this[form].patchValue({
          IsProhibitReportFile: true
        })
      }
    }
    setTimeout(() => {
      console.log(this[form].value)
    }, 1000);
    
  }

  submitAddForm() {
    this.addSubmitted = true;
    if (this.addForm.invalid) {
      return;
    }

    let postData = this.addForm.value;
    // console.log("hello runtikme", this.reportingSets);

    if (postData.ReportingTitle.trim() == "") {
      let msg = `Please enter into the required fields.`;
      this.showInvalid(msg);
      // Swal.fire({
      //   title: `Please enter into the required fields.`,
      // });
      return;
    }

    if (
      !this.reportingSets.find(
        (elem) => postData.ReportingTitle.trim() == elem.ReportingTitle.trim()
      )
    ) {
      postData.IsActive = 1;
      postData.GlobalEnvironmentID = this.GlobalEnvironmentID;
      postData.Level = 0;
      postData.DisplayOrder = 0;
      this.GlobalService.updateReportingSet(postData).subscribe((data) => {
        this.getReportingSets(this.GlobalEnvironmentID);
        this.addgoprs = !this.addgoprs;
        this.addSubmitted = false;
        this.addForm.reset();
      });
    } else {
      let msg = `${postData.ReportingTitle} already exists in Reporting Sets.`;
      this.showInvalid(msg);
      return;
      // Swal.fire({
      //   // title: "This Reporting Set already exists"
      //   title: `${postData.ReportingTitle} already exists in Reporting Sets.`,
      // });
    }
  }

  resetAddForm() {
    this.addForm.reset();
    this.addgoprs = false;
    this.addSubmitted = false;
  }

  editReportingSet(data: any) {
    this.selectedISCIReportingGroupID = data.ISCIReportingGroupID;
    this.addgoprs = false;
    this.editForm.patchValue({ ReportingSetID: data.ISCIReportingGroupID });
    this.editForm.patchValue({ ReportingTitle: data.ReportingTitle });
    this.editForm.patchValue({ ReportingSetDesc: data.ReportingSetDesc });
    this.editForm.patchValue({ IsHighProfile: data.IsHighProfile });
    this.editForm.patchValue({ IsJustHappened: data.IsJustHappened });
    this.editForm.patchValue({ IsHideReportingSet: data.IsHideReportingSet });
    this.editForm.patchValue({ IsDefaultReportFile: data.IsDefaultReportFile });
    this.editForm.patchValue({
      IsProhibitReportFile: data.IsProhibitReportFile,
    });
    this.editForm.patchValue({ IsActive: data.IsActive });
    this.statusgroup = data.IsActive;
  }

  onToggle(ReportingSetID: any) {
    // console.log("This is here", ReportingSetID);
    this.GlobalService.toggleActiveInactive(ReportingSetID).subscribe(
      (data) => {
        this.getReportingSets(this.GlobalEnvironmentID);
        // console.log("Toggle Activated");
        this.tostre.success(this.adminService.statusMsg);
      }
    );
    let element: HTMLElement = document.getElementById(
      "status-group-" + ReportingSetID
    ) as HTMLElement;
    element.click();
    this.statusgroup = !this.statusgroup;
  }

  onEditReportSetSave(id: any, item: any) {
    this.submitted = true;
    if (this.editForm.invalid) {
      return;
    }

    let data = this.editForm.value;
    data.GlobalEnvironmentID = this.GlobalEnvironmentID;
    data.Level = item.Level;
    data.DisplayOrder = item.DisplayOrder;

    this.GlobalService.updateReportingSet(data).subscribe((data1) => {
      let obj = this.reportingSets.find((o) => o.ISCIReportingGroupID == id);

      let index = this.reportingSets.indexOf(obj);

      this.reportingSets.fill(
        (obj.IsActive = this.statusgroup),
        index,
        index++
      );
      this.reportingSets.fill(
        (obj.ReportingTitle = data.ReportingTitle),
        index,
        index++
      );
      this.reportingSets.fill(
        (obj.ReportingSetDesc = data.ReportingSetDesc),
        index,
        index++
      );
      this.reportingSets.fill(
        (obj.IsJustHappened = data.IsJustHappened),
        index,
        index++
      );
      this.reportingSets.fill(
        (obj.IsHighProfile = data.IsHighProfile),
        index,
        index++
      );
      this.reportingSets.fill(
        (obj.IsHideReportingSet = data.IsHideReportingSet),
        index,
        index++
      );
      this.reportingSets.fill(
        (obj.IsDefaultReportFile = data.IsDefaultReportFIle),
        index,
        index++
      );
      this.reportingSets.fill(
        (obj.IsProhibitReportFile = data.IsProhibitReportFile),
        index,
        index++
      );
      // IsProhibitReportFile

      this.getReportingSets(this.GlobalEnvironmentID);
      this.submitted = false;
      let element: HTMLElement = document.getElementById(
        "close-tab-" + id
      ) as HTMLElement;
      element.click();

      // Swal.fire({
      //   text: "Record updated successfully."
      // });
    });
  }

  onClickReportingSets(
    ReportingSetID: any,
    ReportingTitle: any,
    ReportingSetDesc: any,
    IsHighProfile: any,
    IsJustHappened: any,
    IsHideReportingSet: any
  ) {
    this.categoryList = [];
    this.selectedISCICategoryIDIL = false;
    this.addgoprs = false;
    this.editRepotingTitle = ReportingTitle;
    this.editReportingDesc = ReportingSetDesc;
    this.editIsHighProfile = IsHighProfile;
    this.editIsJustHappened = IsJustHappened;
    this.editIsHideReportingSet = IsHideReportingSet;

    this.ReportingSetID = ReportingSetID;
    let RepoSetID: any;
    if (ReportingSetID == this.selectedISCIReportingGroupID) {
      this.selectedISCIReportingGroupID = false;
      RepoSetID = 0;
      //for removing breadcrumbs after deselection of the reporting set
      ReportingSetID = 0;
    } else {
      this.selectedISCIReportingGroupID = ReportingSetID;
      RepoSetID = ReportingSetID;
    }

    this.GlobalService.getReportingSetSubjectBreadCrumb(
      ReportingSetID
    ).subscribe((data) => {
      this.breadCrums = data;
      this.breadCrums = this.breadCrums.GetReportingSetSubjectBreadCrumb;
    });
    this.GetISCIReportingSubjectList(0, this.GlobalEnvironmentID, RepoSetID, 0);
  }

  /**
   *
   * @param ISCICategoryID
   */
  getSubjectFilterList(ISCICategoryID: any) {
    this.data.ISCICategoryID = +ISCICategoryID;
    this.GlobalService.getISCISubject(this.data).subscribe((data) => {
      this.ISCISubjectList = data.GetISCISubject;
    });
  }

  //.... Select Incident Type ...
  onIncidentTypeSelect(ISCICategoryID: any) {
    this.selectedISCICategoryIDI = false;

    if (ISCICategoryID == this.selectedISCICategoryIDIL) {
      this.selectedISCICategoryIDIL = false;
      this.categoryList = [];

      let repoID = this.selectedISCIReportingGroupID
        ? this.selectedISCIReportingGroupID
        : 0;
      this.GetISCIReportingSubjectList(0, this.GlobalEnvironmentID, repoID, 0);
    } else {
      this.selectedISCICategoryIDIL = ISCICategoryID;

      this.GlobalService.getISCICategoryList(ISCICategoryID).subscribe(
        (data) => {
          this.categoryList = data;
          this.categoryList = this.categoryList.GetISCICategoryList;
        }
      );

      let repoID = this.selectedISCIReportingGroupID
        ? this.selectedISCIReportingGroupID
        : 0;
      this.GetISCIReportingSubjectList(
        ISCICategoryID,
        this.GlobalEnvironmentID,
        repoID,
        0
      );
    }
  }

  //.... Select Incident Category ...
  curatedSubjectList(ISCICategoryID: any) {
    if (ISCICategoryID == this.selectedISCICategoryIDI) {
      this.selectedISCICategoryIDI = false;
      this.subjectListFromCategory = [];

      let repoID = this.selectedISCIReportingGroupID
        ? this.selectedISCIReportingGroupID
        : 0;
      if (this.selectedISCICategoryIDIL) {
        this.GetISCIReportingSubjectList(
          this.selectedISCICategoryIDIL,
          this.GlobalEnvironmentID,
          repoID,
          0
        );
      } else {
        this.GetISCIReportingSubjectList(
          0,
          this.GlobalEnvironmentID,
          repoID,
          0
        );
      }
    } else {
      this.selectedISCICategoryIDI = ISCICategoryID;

      let repoID = this.selectedISCIReportingGroupID
        ? this.selectedISCIReportingGroupID
        : 0;
      this.GetISCIReportingSubjectList(
        ISCICategoryID,
        this.GlobalEnvironmentID,
        repoID,
        1
      );
    }
  }

  onSelectSubjectItem(ReportingSubjectId: any, IsAssigned: any) {
    if (this.selectedISCIReportingGroupID) {
      let assign: any;
      assign = IsAssigned ? 0 : 1;

      this.GlobalService.removeAssignedSubjects(
        this.selectedISCIReportingGroupID,
        ReportingSubjectId,
        assign
      ).subscribe((data) => {
        let repoID = this.selectedISCIReportingGroupID
          ? this.selectedISCIReportingGroupID
          : 0;
        let typeID = this.selectedISCICategoryIDIL
          ? this.selectedISCICategoryIDIL
          : 0;
        let cateID = this.selectedISCICategoryIDI
          ? this.selectedISCICategoryIDI
          : 0;
        if (this.selectedISCICategoryIDI) {
          this.GetISCIReportingSubjectList(
            cateID,
            this.GlobalEnvironmentID,
            repoID,
            1
          );
        } else {
          this.GetISCIReportingSubjectList(
            typeID,
            this.GlobalEnvironmentID,
            repoID,
            0
          );
        }
      });
    } else {
      let msg = "Please choose a Reporting Set first.";
      this.showValid(msg);
      // Swal.fire({
      //   text: "Please choose a Reporting Set first.",
      // });
    }
  }

  onReportingsetDelete(ISCIReportingGroupID: any) {
    Swal.fire({
      // text: "Are you sure you want to remove this?",
      text: this.adminService.deleteMsg,
      showCancelButton: true,
      confirmButtonText: "Yes",
      cancelButtonText: "No",
    }).then((result) => {
      if (result.value) {
        this.GlobalService.deleteReportingSet({
          ISCIReportingGroupID: +ISCIReportingGroupID,
        }).subscribe((resp) => {
          this.getReportingSets(this.GlobalEnvironmentID);
        });
      }
    });
  }

  getReportingSetListDonwloadByGOEID() {
    this.GlobalService.getReportingSetListDonwloadByGOEID(
      this.GlobalEnvironmentID
    ).subscribe((data) => {
      this.newReportingList = data.data.getReportingSetListDonwloadByGOEID;
    });
  }

  onReportingItemClick(data: any) {
    if (this.selectedItem == data.ISCIReportingGroupID) {
      this.selectedItem = !this.selectedItem;
    } else {
      this.selectedItem = data.ISCIReportingGroupID;
    }
  }

  //Download Here

  downloadReportingSet() {
    let data = [];

    // console.log("wht is in there", this.ReportingList);
    // console.log(this.LocationList)
    this.newReportingList.forEach(function (item, i) {
      // console.log("data downloadable", item);
      delete item["ISCIReportingGroupID"];
      delete item["CreatedDate"];
      delete item["ISCICategoryID"];
      data.push(item);
    });
    // console.log(data);
    this.GlobalService.exportAsExcelFile(data);
  }

  downloadUploadedReportingSet() {
    let newData = [];

    // console.log(this.LocationList)
    this.UploadedReportingList.forEach(function (item, i) {
      // console.log("data downloadable", item);
      delete item["RecNo"];
      delete item["GlobalEnvironmentID"];
      delete item["UserID"];
      delete item["Message"];
      delete item["Status"];

      newData.push(item);
    });
    // console.log("logan", newData);
    this.GlobalService.exportUploadExcelFile(newData);
  }

  //upload here

  title = "read-excel-in-angular8";
  storeData: any;
  jsonData: any;
  fileUploaded: File;
  worksheet: any;
  htmlData: any;

  uploadedFile(event) {
    this.fileUploaded = event.target.files[0];
    // console.log("file upload", this.fileUploaded);
    if (!this.validateFile(this.fileUploaded.name)) {
      // console.log("Selected file format is not supported");
      let msg = "Selected file format is not supported.";
      this.showInvalid(msg);
      setTimeout(() => {
        // console.log("Little notification delay");
        window.location.reload();
      }, 2000);

      return false;

      // Swal.fire({
      //   text: "Selected file format is not supported.",
      // }).then((result) => {
      //   window.location.reload();
      // });
      // return false;
    }
    this.readExcel();
  }

  validateFile(name: any) {
    var ext = name.substring(name.lastIndexOf(".") + 1);
    if (ext.toLowerCase() == "xlsx") {
      return true;
    } else {
      return false;
    }
  }

  readExcel() {
    let readFile = new FileReader();

    readFile.onload = (e) => {
      this.storeData = readFile.result;

      // console.log("this.storeData", this.storeData);

      var data = new Uint8Array(this.storeData);

      // console.log("data", data);
      var arr = new Array();

      for (var i = 0; i != data.length; ++i)
        arr[i] = String.fromCharCode(data[i]);

      var bstr = arr.join("");

      var workbook = XLSX.read(bstr, { type: "binary" });

      var first_sheet_name = workbook.SheetNames[1];

      this.worksheet = workbook.Sheets[first_sheet_name];

      var range = XLSX.utils.decode_range(this.worksheet["!ref"]);
      range.s.r = 2; // <-- zero-indexed, so setting to 1 will skip row 0
      this.worksheet["!ref"] = XLSX.utils.encode_range(range);

      // console.log("worksheet======>>>", this.worksheet);

      this.readAsJson(this.currentUserID, this.GlobalEnvironmentID);
    };

    readFile.readAsArrayBuffer(this.fileUploaded);
  }

  // Upload Excel End

  /** Read As Json */

  readAsJson(currentUserID: any, GlobalEnvironmentID: any) {
    this.jsonData = XLSX.utils.sheet_to_json(this.worksheet, { raw: false });

    //this.jsonData = JSON.stringify(this.jsonData);

    var arrofobj = (this.ReportingSetImportList = this.jsonData);

    var result = arrofobj.map(function (el) {
      var o = Object.assign({}, el);
      o.GlobalEnvironmentID = GlobalEnvironmentID;
      o.UserID = currentUserID;
      // o.Status = "";
      o.Message = "";
      o.RecNo = "";
      return o;
    });
    let length = Object.keys(result).length;
    // console.log("resultt", result);
    //

    // console.log("result===>>>>>Final", result);
    // this.dataSourceTwo = result;
    this.LocationImport(result);
  }

  /**
   * Import Reporting Set List
   *
   */

  newObjArr = [];

  LocationImport(obj) {
    // console.log("object in array or not before", Object.keys(obj[0]));
    // if(obj[0].)
    // console.log("location", obj);
    let KeyMtch = Object.keys(obj[0]);
    if (KeyMtch.includes("ReportingSet Name")) {
      for (var i = 0; i < obj.length; i++) {
        let newObj = {
          RecNo: obj[i]["RecNo"],
          GlobalEnvironmentID: obj[i]["GlobalEnvironmentID"],
          ReportingSetName: obj[i]["ReportingSet Name"],
          Description: obj[i]["Description"],
          IncidentSubject: obj[i]["Incident Subject"],
          HighResponsePriority: obj[i]["High Response Priority"],
          ShowJustHappned: obj[i]["Show  On Just Happned"],
          QueryOptions: obj[i]["Include In Query Option"],
          ReportingSetStatus: obj[i]["Status"],
          UserID: this.currentUserID,
          Status: "",
          Message: "",
        };
        this.newObjArr.push(newObj);
      }

      let passingArray = this.newObjArr;
      // console.log("passing", passingArray);
      // console.log("object in array or not after", obj);
      this.GlobalService.ReportingImport(passingArray).subscribe((res) => {
        this.dataSourceTwo = res.reportingSetImport;
        this.UploadedReportingList = res.reportingSetImport;
        // console.log("Noice", this.dataSourceTwo);
        this.showValid("Processed successfully. Please check the table.");
        // this.GetLocationList();
      });
    } else {
      this.showInvalid(
        "Uploaded Excel Sheet is Invalid. Please put the right one."
      );
    }
  }

  // Excel Import
  openFileBrowser(event: any) {
    this.hideTableMain = false;
    this.showUploadTable = true;
    this.locationDisplay = false;
    // console.log("Global ID", this.GlobalEnvironmentID);
    // console.log("User ID", this.currentUserID);
    event.preventDefault();
    let element: HTMLElement = document.getElementById("file") as HTMLElement;
    element.click();
  }

  toggleDisplay(value) {
    if (value) {
      this.getReportingSetOnScreenList();
    }
    this.locationDisplay = !this.locationDisplay;
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSourceOne.filter = filterValue.trim().toLowerCase();
  }

  cancelUploadView() {
    // this.hideTableMain = true;
    // this.showUploadTable = false;
    window.location.reload();
  }

  // toastr warning/success message
  showInvalid(msg) {
    this.tostre.warning(msg, "", {
      positionClass: "toast-top-right",
    });
  }

  showValid(validMsg) {
    this.tostre.success(validMsg, "", {
      positionClass: "toast-top-right",
    });
  }

  ClearList() {
    this.dataSourceOne.filter = "";
    this.reportingListForm.patchValue({ _Search: "" });
  }
}
