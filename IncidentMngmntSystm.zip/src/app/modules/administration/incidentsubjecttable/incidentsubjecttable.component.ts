import { Component, OnInit, ViewChild } from "@angular/core";
import { IncidentsubjectService } from "./incidentsubject.service";
import { FormGroup, FormControl, Validators } from "@angular/forms";
import Swal from "sweetalert2";
import { MatSort } from "@angular/material/sort";
import { Router } from "@angular/router";
import { MatTableDataSource } from "@angular/material/table";
import * as XLSX from "xlsx";
import { ToastrService } from "ngx-toastr";
import { UserPermissionService } from "../../../services/user-permission.service";
import { StorageService } from "../../../services/storage.service";
import { ServiceService } from "./../service/service.service";

@Component({
  selector: "app-incidentsubjecttable",
  templateUrl: "./incidentsubjecttable.component.html",
  styleUrls: ["./incidentsubjecttable.component.scss"],
})
export class IncidentsubjecttableComponent implements OnInit {
  catagorylist: any;
  subjectlist: any;
  iscitype: any;
  addgop = false;
  propertytype = false;
  incidentsubject = false;
  hideEditForm = false;
  // propertiesassigned = false;
  ParentID = "";
  addFormSubmitted = false;
  editFormSubmitted = false;
  isShown = false;
  btntext = "Edit ISCI";
  locationDisplay = false;
  selectedItem: any = false;

  ISCITypeList: any;
  getISCList: any;
  getISCISList: any;

  IncidentName_: string = "";
  IncidentDecs_: string = "";

  selectedISCITypeID = false;
  selectedCategoryID = false;
  selectedSubjectID = false;

  ISCITypeEditable = false;
  ISCICategoryEditable = false;
  ISCISubjectEditable = false;

  GlobalEnvironmentID = 0;
  GlobalEnvironmentName = "";
  GOENumber = "";
  GlobalEnvironmentDetails = null;
  allcategorylist = [];
  allsubjectlist = [];
  LocationImportList: any = [];
  UploadedLocationList = [];
  groupData: any;
  exportreport: any;
  dataSourceOne: MatTableDataSource<any>;
  dataSourceTwo: MatTableDataSource<any>;
  showUploadTable = false;
  hideTableMain = true;
  currentUserID = false;
  authToken = null;
  userData = null;

  displayedColumnsOne: string[] = [
    "IncidentType",
    "IncidentCategory",
    "IncidentSubject",
    "Status",
  ];

  displayedColumnsTwo: string[] = [
    "IncidentType",
    "IncidentCategory",
    "IncidentSubject",
    "IncidentDescription",
    "Status",
    "Message",
  ];

  @ViewChild("TableOneSort", { static: false }) tableOneSort: MatSort;
  @ViewChild("TableTwoSort", { static: false }) tableTwoSort: MatSort;

  constructor(
    private IncidentsubjectService: IncidentsubjectService,
    public router: Router,
    private tostre: ToastrService,
    public UserPermission: UserPermissionService,
    private storage: StorageService,
    private adminService: ServiceService
  ) {
    //... Read User Data ...
    this.authToken = this.storage.getData("token");
    this.userData = JSON.parse(this.storage.getData("UserData"));
    if (this.authToken == null) {
      this.router.navigate(["/login"]);
      return;
    }

    /* check module permission of the user */
    if (
      this.UserPermission.checkPermission(
        "access_incident_subject",
        "",
        "",
        ""
      ) == false
    ) {
      this.router.navigate(["/products/list"]);
      this.tostre.warning(
        "You don't have permission to access this module.",
        "",
        {
          positionClass: "toast-top-right",
        }
      );
      return;
    }

    this.GlobalEnvironmentDetails = JSON.parse(
      this.storage.getData("GlobalEnvironmentDetails")
    );
    if (this.GlobalEnvironmentDetails) {
      //this.groupData = this.organise(this.exportreport);
      this.GlobalEnvironmentID = this.GlobalEnvironmentDetails.GlobalEnvironmentId;
      this.GlobalEnvironmentName = this.GlobalEnvironmentDetails.GlobalEnvironmentName;
      this.GOENumber = this.GlobalEnvironmentDetails.GOENo;
    }

    this.currentUserID = this.userData[0].UserID;
    this.dataSourceOne = new MatTableDataSource();
    this.dataSourceTwo = new MatTableDataSource();
  }

  checkGoe() {
    if (this.GlobalEnvironmentID) {
      return true;
    } else {
      /* Swal.fire({
        text: "Please first select a Global Operations Environment.",
        // position:'top-end',
        timer: 3000,
      }).then((result) => {
        // this.router.navigate(["products/administration/goe/mygoe"]);
      }); */
      this.router.navigate(["products/administration/goe/mygoe"]);
      this.tostre.error(
        "Please first select a Global Operations Environment.",
        "",
        {
          positionClass: "toast-top-right",
        }
      );
      return false;
    }
  }

  ngOnInit() {
    if (this.checkGoe()) {
      this.getISCIExportReport(this.GlobalEnvironmentID);
      this.getISCIAllSubjectList();
      // this.getISCIAllCategoryList();
      this.getISCITypeList(this.GlobalEnvironmentID);
      this.getISCITypeListForCheckingOnly(null); // for checking single selected list in list column of type list
      /* let result: any;
      this.IncidentsubjectService.getISCISubjectList(
        null,
        this.GlobalEnvironmentID,
        this.selectedISCITypeID
      ).subscribe((res) => {
        result = res;
        this.subjectlist = result.GetISCICategoryList;
      }); */
    }
  }

  /**
   * To Export to Excel file
   *
   */

  /*name of the excel-file which will be downloaded. */
  //fileName = 'ExcelSheet.xlsx';

  // exportexcel(): void {
  //   this.IncidentsubjectService.exportAsExcelFile(
  //     this.exportreport,
  //     "download-excel"
  //   );
  // }
  organise(arr) {
    var headers = [], // an Array to let us lookup indicies by group
      objs = [], // the Object we want to create
      i,
      j;
    for (i = 0; i < arr.length; ++i) {
      j = headers.indexOf(arr[i].id); // lookup
      if (j === -1) {
        // this entry does not exist yet, init
        j = headers.length;
        headers[j] = arr[i].id;
        objs[j] = {};
        objs[j].id = arr[i].id;
        objs[j].data = [];
      }
      objs[j].data.push(
        // create clone
        {
          case_worked: arr[i].case_worked,
          note: arr[i].note,
          id: arr[i].id,
        }
      );
    }
    return objs;
  }

  // this.excelService.exportAsExcelFile(this.data, 'export-to-excel');
  /* table id is passed over here */

  // let element = document.getElementById('excel-table');
  // const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(element);

  // // /* generate workbook and add the worksheet */
  // const wb: XLSX.WorkBook = XLSX.utils.book_new();
  // XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

  // // /* save to file */
  // XLSX.writeFile(wb, this.fileName);

  //}

  /**
   *
   * Add ISCI Type Form
   *
   */

  ISCITypeForm = new FormGroup({
    ISCICategoryName: new FormControl("", [Validators.required]),
    ISCICategoryDescription: new FormControl(""),
  });
  get addISCIType() {
    return this.ISCITypeForm.controls;
  }

  /**
   *
   * Edit ISCI Type Form
   *
   */

  editISCITypeForm = new FormGroup({
    ISCICategoryName: new FormControl("", [Validators.required]),
    ISCICategoryDescription: new FormControl(""),
  });

  get editTypeForm() {
    return this.editISCITypeForm.controls;
  }

  /**
   *
   * Add ISCI Category Form
   *
   */

  ISCICategoryForm = new FormGroup({
    ISCICategoryName: new FormControl("", [Validators.required]),
    ISCICategoryDescription: new FormControl(""),
  });

  get addCategoryType() {
    return this.ISCICategoryForm.controls;
  }

  /**
   *
   * Edit ISCI Category Form
   *
   */

  editISCICategoryForm = new FormGroup({
    ISCICategoryName: new FormControl("", [Validators.required]),
    ISCICategoryDescription: new FormControl(""),
  });

  get editCategoryForm() {
    return this.editISCICategoryForm.controls;
  }

  /**
   *
   * Add ISCI Subject Form
   *
   */
  angForm = new FormGroup({
    ISCICategoryName: new FormControl("", [Validators.required]),
    ISCICategoryDescription: new FormControl(""),
  });

  get sf() {
    return this.angForm.controls;
  }

  /**
   *
   * Edit Subject Form
   */

  editSubjectForm = new FormGroup({
    ISCICategoryName: new FormControl("", [Validators.required]),
    ISCICategoryDescription: new FormControl(""),
    IsActive: new FormControl(""),
  });

  get esf() {
    return this.editSubjectForm.controls;
  }

  /** Get ISCI Type List  */

  getISCITypeList(param) {
    let result: any;
    this.IncidentsubjectService.getISCITypeList(
      this.GlobalEnvironmentID
    ).subscribe((res) => {
      result = res;

      this.ISCITypeList = result.GetISCITypeList;

      // this.checkAndSelectISCITypeList(this.ISCITypeList);
    });
  }

  /** Get ISCI All Category List  */

  getISCIAllCategoryList() {
    let result: any;
    this.IncidentsubjectService.getISCICategoryList(null).subscribe((res) => {
      result = res;

      this.allcategorylist = result.GetISCICategoryList;
    });
  }
  /** Get ISCI All Subejct List  */

  getISCIAllSubjectList() {
    let result: any;
    this.IncidentsubjectService.getISCISubjectList(
      null,
      this.GlobalEnvironmentID,
      this.selectedISCITypeID
    ).subscribe((res) => {
      result = res;
      this.allsubjectlist = result.GetISCICategoryList;
      this.subjectlist = result.GetISCICategoryList;
    });
  }

  /**
   * Edit ISCITypeList
   */

  editISCITypeList(obj) {
    this.selectedISCITypeID = obj.ISCICategoryID;
    this.ISCITypeEditable = obj.ISCICategoryID;
    this.IncidentName_ = obj.ISCICategoryName;
    this.IncidentDecs_ = obj.ISCICategoryDescription;
    this.addgop = false;
    this.addFormSubmitted = false;
    this.ISCICategoryEditable = false;
    this.ISCISubjectEditable = false;
    this.propertytype = false;
    this.ISCICategoryForm.reset();
    this.angForm.reset();
    this.incidentsubject = false;
    let shadesEl = document.querySelectorAll(".show");
    for (let i = 0; i < shadesEl.length; i++) {
      shadesEl[i].classList.remove("show");
    }
  }

  /**
   * Edit ISCITypeCategoryList
   */

  editISCICategoryList(obj) {
    this.selectedCategoryID = obj.ISCICategoryID;
    this.incidentsubject = false;
    this.addgop = false;
    this.ISCITypeForm.reset();
    this.addFormSubmitted = false;
    this.ISCICategoryEditable = false;
    // this.ISCITypeForm.reset()
    this.ISCICategoryEditable = obj.ISCICategoryID;
    this.editISCICategoryForm.patchValue({
      ISCICategoryName: obj.ISCICategoryName,
    });
    this.editISCICategoryForm.patchValue({
      ISCICategoryDescription: obj.ISCICategoryDescription,
    });
    this.propertytype = false;
    this.ISCITypeEditable = false;
    this.ISCISubjectEditable = false;
    let shadesEl = document.querySelectorAll(".show");
    for (let i = 0; i < shadesEl.length; i++) {
      shadesEl[i].classList.remove("show");
    }
  }

  /**
   *
   * Edit ISCISubjectList
   *
   *
   */
  statusShowSub = false;
  editISCISubject(obj) {
    this.activeSubjectID = obj.ISCICategoryID;
    this.ISCISubjectEditable = obj.ISCICategoryID;
    this.editSubjectForm.patchValue({ ISCICategoryName: obj.ISCICategoryName });
    this.editSubjectForm.patchValue({
      ISCICategoryDescription: obj.ISCICategoryDescription,
    });
    this.editSubjectForm.patchValue({ IsActive: obj.IsActive });
    this.incidentsubject = false;
    this.addFormSubmitted = false;
    this.statusShowSub = obj.IsActive;
    this.ISCITypeEditable = false;
    this.addgop = false;
    this.propertytype = false;
    this.ISCICategoryEditable = false;
    let shadesEl = document.querySelectorAll(".show");
    for (let i = 0; i < shadesEl.length; i++) {
      shadesEl[i].classList.remove("show");
    }
  }
  /**
   *
   * Select ISCI Type
   */

  typeSelected(ISCICategoryID) {
    //this.hideEditForm = true;
    this.addgop = false;
    this.propertytype = false;

    this.incidentsubject = false;
    if (this.selectedISCITypeID == ISCICategoryID) {
      this.selectedISCITypeID = false;
      this.catagorylist = [];
      this.activeSubjectID = false;
      this.propertytype = false;
      this.incidentsubject = false;
      this.ISCICategoryForm.reset();

      this.selectedCategoryID = false;
    } else {
      this.selectedISCITypeID = ISCICategoryID;
      this.getIsciCategoryLists(ISCICategoryID);
    }
    this.incidentsubject = false;
    this.ISCISubjectEditable = false;
    let result1: any;
    this.IncidentsubjectService.getISCISubjectList(
      null,
      this.GlobalEnvironmentID,
      this.selectedISCITypeID
    ).subscribe((res) => {
      result1 = res;
      this.subjectlist = result1.GetISCICategoryList;
    });
    this.activeSubjectID = false;
  }

  /**
   *
   * Select ISCI Category
   */

  categorySelected(ISCICategoryID) {
    this.addgop = false;
    this.propertytype = false;
    this.incidentsubject = false;
    // this.propertytype = false
    this.ISCISubjectEditable = false;
    this.activeSubjectID = false;
    this.angForm.reset();
    this.addgop = false;

    if (this.selectedCategoryID == ISCICategoryID) {
      this.selectedCategoryID = false;
      this.incidentsubject = false;
      let result1: any;
      this.IncidentsubjectService.getISCISubjectList(
        null,
        this.GlobalEnvironmentID,
        this.selectedISCITypeID
      ).subscribe((res) => {
        result1 = res;
        this.subjectlist = result1.GetISCICategoryList;
        /** single selected Only */
        // this.subjectListSingleSelectedOnly(this.subjectlist);
      });
    } else {
      this.selectedCategoryID = ISCICategoryID;
      let result: any;
      this.IncidentsubjectService.getISCISubjectList(
        this.selectedCategoryID,
        this.GlobalEnvironmentID,
        this.selectedISCITypeID
      ).subscribe((res) => {
        result = res;
        this.subjectlist = result.GetISCICategoryList;
        /** single selected Only */
        // this.subjectListSingleSelectedOnly(this.subjectlist);
      });
    }
  }

  /**
   *
   * Select ISCI Subject
   */

  activeSubjectID = false;

  subjectSelected(ISCICategoryID, data) {
    this.incidentsubject = false;
    this.addgop = false;
    this.propertytype = false;
    // this.incidentsubject = false
    if (this.activeSubjectID == ISCICategoryID) {
      this.activeSubjectID = false;
      this.selectedCategoryID = false;
      this.selectedISCITypeID = false;
    } else {
      data = {
        ParentID: data,
      };
      let result: any;
      this.IncidentsubjectService.getISCItypeIDAndCategoryID(data).subscribe(
        (res) => {
          result = res;
          this.selectedISCITypeID = result.GetISCItypeIDAndCategoryID[0].TypeID;
          this.getIsciCategoryLists(
            result.GetISCItypeIDAndCategoryID[0].TypeID
          );
          this.selectedCategoryID =
            result.GetISCItypeIDAndCategoryID[0].CategoryID;
        }
      );
      this.activeSubjectID = ISCICategoryID;
    }
  }

  /**
   * Get ISCI Category List
   * @param parentID
   *
   */
  getIsciCategoryLists(parentID) {
    let result: any;
    this.IncidentsubjectService.getISCICategoryList(parentID).subscribe(
      (res) => {
        result = res;
        this.catagorylist = result.GetISCICategoryList;
        this.selectedISCITypeID = parentID;

        /** for checking single list in subject list */
        // debugger;
        // this.ISCICategoryListForSingleSelection(this.catagorylist);
      }
    );
  }

  getIsciCategoryList(ISCICategoryID) {
    let result: any;
    this.IncidentsubjectService.getISCICategoryList(ISCICategoryID).subscribe(
      (res) => {
        result = res;
        this.catagorylist = result.GetISCICategoryList;
        this.selectedISCITypeID = ISCICategoryID;
      }
    );
  }

  getIsciSubjectList(ISCICategoryID) {
    let result: any;
    this.IncidentsubjectService.getISCICategoryList(ISCICategoryID).subscribe(
      (res) => {
        result = res;

        this.subjectlist = result.GetISCICategoryList;
      }
    );
  }

  /**
   *
   * Update ISCI Category
   *
   * @param ISCICategoryID
   * @param formData
   */

  updateISCICategory(ISCICategoryID, IsActive, formData) {
    this.editFormSubmitted = true;
    if (this.editISCICategoryForm.invalid) {
      return;
    }

    const obj = {
      ISCICategoryId: ISCICategoryID,
      ISCICategoryName: formData.ISCICategoryName,
      ISCICategoryDescription: formData.ISCICategoryDescription,
      Level: 1,
      ParentId: ISCICategoryID,
      UserId: 4,
      IsActive: IsActive,
    };

    if (obj.Level == 1) {
      let result: any;
      this.IncidentsubjectService.updateISCI(obj).subscribe((res) => {
        result = res;
        this.getISCList = result.getISCICategoryList;
        this.getIsciCategoryList(this.selectedISCITypeID);
        this.ISCICategoryEditable = false;
      });
    } else {
      let result: any;
      this.IncidentsubjectService.updateISCI(obj).subscribe((res) => {
        result = res;
        this.getISCISList = result.getISCICategoryList;
        this.incidentsubject = !this.incidentsubject;
        this.editISCICategoryForm.reset();
        this.getIsciSubjectList(this.selectedCategoryID);
        this.ISCICategoryEditable = false;
      });
    }
  }

  /**
   *
   *  Udpate ISCI Subject
   *
   */

  updateISCISubject(ISCICategoryID, ISCICName, ISCICDesc, formData) {
    this.editFormSubmitted = true;
    if (this.editSubjectForm.invalid) {
      return;
    }

    const obj = {
      ISCICategoryId: ISCICategoryID,
      ISCICategoryName: ISCICName,
      ISCICategoryDescription: ISCICDesc,
      Level: 2,
      ParentId: ISCICategoryID,
      UserId: 4,
      IsActive: formData.IsActive ? 1 : 0,
    };

    let result: any;

    this.IncidentsubjectService.updateISCI(obj).subscribe((res) => {
      if (this.selectedCategoryID) {
        let result1: any;
        this.IncidentsubjectService.getISCISubjectList(
          null,
          this.GlobalEnvironmentID,
          this.selectedISCITypeID
        ).subscribe((res) => {
          result1 = res;
          this.subjectlist = result1.GetISCICategoryList;
          this.ISCISubjectEditable = false;
        });
      } else {
        let result1: any;
        this.IncidentsubjectService.getISCISubjectList(
          null,
          this.GlobalEnvironmentID,
          this.selectedISCITypeID
        ).subscribe((res) => {
          result1 = res;
          this.subjectlist = result1.GetISCICategoryList;
          this.ISCISubjectEditable = false;
        });
      }
    });
  }

  /**
   * Edit ISCI Type List
   * @param ISCICategoryId
   * @param ISCICategoryName
   * @param ISCICategoryDescription
   * @param Level
   * @param ParentId
   */

  editISCIType(item) {
    this.editFormSubmitted = true;
    if (this.editISCITypeForm.invalid) {
      return;
    }

    const obj = {
      ISCICategoryId: item.ISCICategoryID,
      ISCICategoryName: this.IncidentName_,
      ISCICategoryDescription: this.IncidentDecs_,
      Level: item.Level,
      ParentId: 0,
      UserId: 4,
      IsActive: item.IsActive,
    };

    let result: any;

    this.IncidentsubjectService.updateISCI(obj).subscribe((res) => {
      result = res;
      this.getISCISList = result.GetISCICategoryList;
      this.getISCITypeList(this.GlobalEnvironmentID);
      this.angForm.reset();
      this.ISCITypeEditable = false;
      this.editFormSubmitted = false;
    });
  }

  /**
   *  To Add ISCI Type/Category/Subejct
   * @param ISCICategoryId
   * @param ISCICategoryName
   * @param ISCICategoryDescription
   * @param Level
   * @param ParentId
   */

  addISCI(
    ISCICategoryId: any,
    ISCICategoryName: any,
    ISCICategoryDescription: any,
    Level: any,
    ParentId: any,
    IsActive: any
  ) {
    const obj = {
      GlobalEnvironmentID: this.GlobalEnvironmentID,
      ISCICategoryId: ISCICategoryId,
      ISCICategoryName: ISCICategoryName.trim(),
      ISCICategoryDescription: ISCICategoryDescription,
      Level: Level,
      ParentId: ParentId,
      UserId: 4,
      IsActive: IsActive,
    };

    if (Level == 0) {
      this.addFormSubmitted = true;
      if (this.ISCITypeForm.invalid) {
        return;
      }

      if (obj.ISCICategoryName.trim() == "") {
        let msg = "Incident Type Name is required";
        this.showInvalid(msg);
        return false;
      }

      if (
        !this.ISCITypeList.find(
          (elem) => obj.ISCICategoryName.trim() == elem.ISCICategoryName.trim()
        )
      ) {
        let result: any;

        this.IncidentsubjectService.updateISCI(obj).subscribe((res) => {
          result = res;
          this.getISCISList = result.GetISCICategoryList;
          this.addgop = !this.addgop;
          this.ISCITypeForm.reset();
          this.addFormSubmitted = false;
          // this.getISCITypeList(this.GlobalEnvironmentID);
          /* Push new added row to the list */
          let ID = result.UpdateISCI[0].ReturnMessage;
          let newRow = {
            ISCICategoryDescription: ISCICategoryDescription,
            ISCICategoryID: ID,
            ISCICategoryName: obj.ISCICategoryName,
            IsActive: true,
            IsAllowDelete: 1,
            Level: 0,
          };
          this.ISCITypeList.push(newRow);
        });
      } else {
        let msg = ` ${obj.ISCICategoryName} Incident type already exists`;
        this.showInvalid(msg);
      }
    } else if (Level == 1) {
      this.addFormSubmitted = true;
      if (this.ISCICategoryForm.invalid) {
        return;
      }
      if (obj.ISCICategoryName.trim() == "") {
        let msg = "Incident Category Name is required";
        this.showInvalid(msg);
        return false;
      }
      // this.getISCIAllCategoryList();
      if (
        !this.catagorylist.find(
          (elem) => obj.ISCICategoryName.trim() == elem.ISCICategoryName.trim()
        )
      ) {
        let result: any;
        this.IncidentsubjectService.updateISCI(obj).subscribe((res) => {
          result = res;

          if (result.UpdateISCI[0].ReturnMessage.includes("already exist")) {
            let msg = `${obj.ISCICategoryName} Incident category already exists`;
            this.showInvalid(msg);
          } else {
            this.getISCList = result.getISCICategoryList;
            this.propertytype = !this.propertytype;
            this.ISCICategoryForm.reset();

            // this.getIsciCategoryList(this.selectedISCITypeID);
            this.addFormSubmitted = false;
            let ID = result.UpdateISCI[0].ReturnMessage;
            let newRow = {
              ISCICategoryDescription: ISCICategoryDescription,
              ISCICategoryID: ID,
              ISCICategoryName: obj.ISCICategoryName,
              IsActive: true,
              IsIconDelete: 0,
              IsAllowDelete: 1,
              ParentID: ParentId,
            };
            this.catagorylist.push(newRow);

            // disabled delete from iscii type
            let typeobj = this.ISCITypeList.find(
              (x) => x.ISCICategoryID == ParentId
            );
            let index = this.ISCITypeList.indexOf(typeobj);
            if (index != -1) {
              this.ISCITypeList.fill(
                (typeobj.IsAllowDelete = 0),
                index,
                index++
              );
            }
          }
        });
      } else {
        let msg = `${obj.ISCICategoryName} Incident category already exists`;
        this.showInvalid(msg);
      }
    } else {
      this.addFormSubmitted = true;
      if (this.angForm.invalid) {
        return;
      }
      if (obj.ISCICategoryName.trim() == "") {
        let msg = "Incident Subject Name is required";
        this.showInvalid(msg);
        return false;
      }
      // this.getISCIAllSubjectList();
      if (
        !this.subjectlist.find(
          (elem) => obj.ISCICategoryName.trim() == elem.ISCICategoryName.trim()
        )
      ) {
        let result: any;
        this.IncidentsubjectService.updateISCI(obj).subscribe((res) => {
          result = res;

          if (result.UpdateISCI[0].ReturnMessage.includes("already exist")) {
            let msg = `${obj.ISCICategoryName} Incident category already exists`;
            this.showInvalid(msg);
          } else {
            this.getISCISList = result.getISCICategoryList;
            this.incidentsubject = !this.incidentsubject;
            this.angForm.reset();

            this.addFormSubmitted = false;
            /* this.IncidentsubjectService.getISCISubjectList(
              this.selectedCategoryID,
              this.GlobalEnvironmentID,
              this.selectedISCITypeID
            ).subscribe((res: any) => {
              this.subjectlist = res.GetISCICategoryList;
            }); */
            let ID = result.UpdateISCI[0].ReturnMessage;
            let newRow = {
              ISCICategoryDescription: ISCICategoryDescription,
              ISCICategoryID: ID,
              ISCICategoryName: obj.ISCICategoryName,
              IsActive: true,
              IsIconDelete: 0,
              IsAllowDelete: 0,
              ParentID: ParentId,
            };
            this.subjectlist.push(newRow);

            // disabled delete from iscii category
            let typeobj = this.catagorylist.find(
              (x) => x.ISCICategoryID == ParentId
            );
            let index = this.catagorylist.indexOf(typeobj);
            if (index != -1) {
              this.catagorylist.fill(
                (typeobj.IsAllowDelete = 0),
                index,
                index++
              );
            }
          }
        });
      } else {
        let msg = `${obj.ISCICategoryName} Incident subject already exists`;
        this.showInvalid(msg);
      }
    }
  }

  /**
   *
   * Check ISCI Type
   */

  checkTypeSelected() {
    this.addgop = false;
    this.incidentsubject = false;
    this.addFormSubmitted = false;
    this.ISCICategoryEditable = false;
    this.ISCISubjectEditable = false;
    this.ISCITypeEditable = false;
    this.angForm.reset();
    this.ISCITypeForm.reset();
    this.ISCICategoryForm.reset();

    if (this.selectedISCITypeID) {
      this.propertytype = !this.propertytype;

      let shadesEl = document.querySelectorAll(".show");
      for (let i = 0; i < shadesEl.length; i++) {
        shadesEl[i].classList.remove("show");
      }
    } else {
      // let msg = "Please Select Incident Type First";
      // this.showInvalid(msg);
      this.tostre.error("Please Select Incident Type First", "", {
        positionClass: "toast-top-right",
      });
      // Swal.fire({
      //   text: "Please Select Incident Type First",
      // });
    }
  }
  /**
   * Check ISCI Category
   *
   */
  checkCategorySelected() {
    this.addgop = false;
    this.propertytype = false;
    this.addFormSubmitted = false;
    this.ISCISubjectEditable = false;
    this.ISCICategoryEditable = false;
    this.ISCITypeForm.reset();
    this.ISCICategoryForm.reset();
    this.angForm.reset();

    if (this.selectedCategoryID) {
      this.incidentsubject = !this.incidentsubject;

      let shadesEl = document.querySelectorAll(".show");
      for (let i = 0; i < shadesEl.length; i++) {
        shadesEl[i].classList.remove("show");
      }
    } else {
      // let msg = "Please Select Incident Category First";
      // this.showInvalid(msg);
      this.tostre.error("Please Select Incident Category First", "", {
        positionClass: "toast-top-right",
      });
      // Swal.fire({
      //   text: "Please Select Incident Category First",
      // });
    }
  }

  /**
   *
   * Reset ISCI Type Form
   */
  resetISCITypeForm() {
    this.addgop = !this.addgop;
    this.ISCITypeForm.reset();
    this.addFormSubmitted = false;
  }

  /**
   *
   * Reset ISCI Category Form
   */

  resetISCICategoryForm() {
    this.propertytype = !this.propertytype;
    this.ISCICategoryForm.reset();
    this.addFormSubmitted = false;
    this.propertytype = false;
  }

  resetISCISubjectform() {
    this.incidentsubject = !this.incidentsubject;
    this.angForm.reset();
    this.addFormSubmitted = false;
    this.incidentsubject = false;
  }

  /**
   * Reset Form
   * @param ISCICategoryID
   *
   */

  resetEditform(ISCICategoryID: any) {
    this.ISCITypeEditable = false;
    this.editISCITypeForm.reset();
    this.editFormSubmitted = false;
  }
  resetCategoryEditform(ISCICategoryID: any) {
    this.ISCICategoryEditable = false;
    this.editISCICategoryForm.reset();
    this.editFormSubmitted = false;
    this.propertytype = false;
  }
  resetSubjectEditform(ISCICategoryID: any) {
    this.ISCISubjectEditable = false;
    this.editSubjectForm.reset();
    this.editFormSubmitted = false;
  }

  /**
   *  Delete ISCI Type
   * @param param
   *
   */

  deleteISCIType(param) {
    const obj = {
      ISCICategoryID: param,
    };
    Swal.fire({
      // text: "Are you sure you want to remove this?",
      text: this.adminService.deleteMsg,
      showCancelButton: true,
      confirmButtonText: "Yes",
      cancelButtonText: "No",
    }).then((result) => {
      if (result.value) {
        this.IncidentsubjectService.deleteISCISubject(obj).subscribe((res) => {
          // this.getISCITypeList(this.GlobalEnvironmentID);
          /* find index and remove subject from subject list */
          let sobj = this.ISCITypeList.find((x) => x.ISCICategoryID == param);
          let sindex = this.ISCITypeList.indexOf(sobj);
          
          if (sindex != -1) {
            this.ISCITypeList.splice(sindex, 1);
          }
        });
      }
    });
  }

  /**
   *  Delete ISCI Category
   * @param param
   *
   */

  deleteISCICategory(param) {
    const obj = {
      ISCICategoryID: param.ISCICategoryID,
    };
    Swal.fire({
      // text: "Are you sure you want to remove this?",
      text: this.adminService.deleteMsg,
      showCancelButton: true,
      confirmButtonText: "Yes",
      cancelButtonText: "No",
    }).then((result) => {
      if (result.value) {
        this.IncidentsubjectService.deleteISCISubject(obj).subscribe((res) => {
          // this.getIsciCategoryLists(this.selectedISCITypeID);
          //this.getISCITypeList(this.GlobalEnvironmentID);

          /* find index and remove subject from subject list */
          let sobj = this.catagorylist.find(
            (x) => x.ISCICategoryID == param.ISCICategoryID
          );
          let sindex = this.catagorylist.indexOf(sobj);
          if (sindex != -1) {
            this.catagorylist.splice(sindex, 1);
          }

          /* Check if category has more subject otherwise enable delete icon */
          let sobj2 = this.catagorylist.find(
            (x) => x.ParentID == param.ParentID
          );
          let sindex2 = this.catagorylist.indexOf(sobj2);
          if (sindex2 == -1) {
            let cobj = this.ISCITypeList.find(
              (x) => x.ISCICategoryID == param.ParentID
            );
            let cindex = this.ISCITypeList.indexOf(cobj);
            this.ISCITypeList.fill((cobj.IsAllowDelete = 1), cindex, cindex++);
          }
        });
      }
    });
  }

  /**
   *
   * Delete ISCI Subject
   *
   */

  deleteISCISubject(param) {
    const obj = {
      ISCICategoryID: param.ISCICategoryID,
    };
    const parentID = param.ParentID;
    Swal.fire({
      // text: "Are you sure you want to remove this?",
      text: this.adminService.deleteMsg,
      showCancelButton: true,
      confirmButtonText: "Yes",
      cancelButtonText: "No",
    }).then((result) => {
      if (result.value) {
        this.IncidentsubjectService.deleteISCISubject(obj).subscribe((res) => {
          /* find index and remove subject from subject list */
          let sobj = this.subjectlist.find(
            (x) => x.ISCICategoryID == param.ISCICategoryID
          );
          let sindex = this.subjectlist.indexOf(sobj);
          if (sindex != -1) {
            this.subjectlist.splice(sindex, 1);
          }

          /* Check if category has more subject otherwise enable delete icon */
          let sobj2 = this.subjectlist.find((x) => x.ParentID == parentID);
          let sindex2 = this.subjectlist.indexOf(sobj2);
          if (sindex2 == -1) {
            let cobj = this.catagorylist.find(
              (x) => x.ISCICategoryID == parentID
            );
            let cindex = this.catagorylist.indexOf(cobj);
            this.catagorylist.fill((cobj.IsAllowDelete = 1), cindex, cindex++);
          }

          /* if (this.selectedCategoryID) {
            let result1: any;
            this.IncidentsubjectService.getISCISubjectList(
              this.selectedCategoryID,
              this.GlobalEnvironmentID,
              this.selectedISCITypeID
            ).subscribe((res) => {
              result1 = res;
              this.subjectlist = result1.GetISCICategoryList;
            });
          } else {
            let result1: any;
            this.IncidentsubjectService.getISCISubjectList(
              null,
              this.GlobalEnvironmentID,
              this.selectedISCITypeID
            ).subscribe((res) => {
              result1 = res;
              this.subjectlist = result1.GetISCICategoryList;
            });
          } */
        });
      }
    });
  }

  toggleDisplay(value) {
    if (value) {
      this.getISCIExportReport(this.GlobalEnvironmentID);
    }
    this.locationDisplay = !this.locationDisplay;
  }

  /**
   *
   * Change ISCI Category Status
   * @param param
   *
   *
   */

  changeISCITypeStatus(param) {
    const obj = {
      ISCICategoryID: param,
    };

    this.IncidentsubjectService.changeISCIStatus(obj).subscribe((res) => {
      let obj1 = this.ISCITypeList.find(
        (o) => o.ISCICategoryID == obj.ISCICategoryID
      );

      let index = this.ISCITypeList.indexOf(obj1);
      this.ISCITypeList.fill((obj1.IsActive = !obj1.IsActive), index, index++);
      //this.getISCITypeList(this.GlobalEnvironmentID)
      this.tostre.success(this.adminService.statusMsg);
    });
  }

  /**
   *
   * Change ISCI Category Status
   * @param param
   *
   *
   */

  changeISCICategoryStatus(param) {
    const obj = {
      ISCICategoryID: param,
    };

    this.IncidentsubjectService.changeISCIStatus(obj).subscribe((res) => {
      let obj1 = this.catagorylist.find(
        (o) => o.ISCICategoryID == obj.ISCICategoryID
      );

      let index = this.catagorylist.indexOf(obj1);
      this.catagorylist.fill((obj1.IsActive = !obj1.IsActive), index, index++);

      //this.getIsciCategoryList(this.selectedISCITypeID)
      this.tostre.success(this.adminService.statusMsg);
    });
  }

  /**
   *
   * Change ISCI Subject Status
   * @param param
   *
   *
   */
  changeISCISubjectStatus(param, ParentID) {
    const obj = {
      ISCICategoryID: param,
    };

    this.IncidentsubjectService.changeISCIStatus(obj).subscribe((res) => {
      if (this.selectedCategoryID) {
        // this.getIsciSubjectList(this.selectedCategoryID);
        let result1: any;
        this.IncidentsubjectService.getISCISubjectList(
          this.selectedCategoryID,
          this.GlobalEnvironmentID,
          this.selectedISCITypeID
        ).subscribe((res) => {
          result1 = res;
          this.subjectlist = result1.GetISCICategoryList;
        });
      } else {
        let result2: any;
        this.IncidentsubjectService.getISCISubjectList(
          null,
          this.GlobalEnvironmentID,
          this.selectedISCITypeID
        ).subscribe((res) => {
          result2 = res;
          this.subjectlist = result2.GetISCICategoryList;
        });
      }
      this.tostre.success(this.adminService.statusMsg);
    });
  }

  changeSubjectShowStatus(id: any) {
    let element: HTMLElement = document.getElementById(
      "status-subject-" + id
    ) as HTMLElement;
    element.click();
    this.statusShowSub = !this.statusShowSub;
  }

  closeCategorySubject() {
    this.addFormSubmitted = false;
    this.propertytype = false;
    this.incidentsubject = false;
    this.addgop = !this.addgop;
    this.ISCITypeEditable = false;
    this.ISCICategoryEditable = false;
    this.ISCISubjectEditable = false;
    this.angForm.reset();
    this.ISCICategoryForm.reset();
    this.ISCITypeForm.reset();
    let shadesEl = document.querySelectorAll(".show");
    for (let i = 0; i < shadesEl.length; i++) {
      shadesEl[i].classList.remove("show");
    }
  }

  toggleShow() {
    this.getISCIExportReport(this.GlobalEnvironmentID);
    this.isShown = !this.isShown;
  }

  getISCIExportReport(GlobalEnvironmentID) {
    const obj = {
      GlobalEnvironmentID: GlobalEnvironmentID,
    };

    let result;
    this.IncidentsubjectService.getISCIExportReport(obj).subscribe((res) => {
      result = res;
      this.exportreport = result.ISCIExportReport;
      
      this.dataSourceOne.data = result.ISCIExportReport;
      this.dataSourceOne.sort = this.tableOneSort;
      this.tableOneSort.disableClear = true;
    });
  }

  SubjectlistClick(data: any) {
    if (this.selectedItem == data.ISCICategoryID) {
      this.selectedItem = !this.selectedItem;
    } else {
      this.selectedItem = data.ISCICategoryID;
    }
  }

  //upload here

  title = "read-excel-in-angular8";
  storeData: any;
  jsonData: any;
  fileUploaded: File;
  worksheet: any;
  htmlData: any;

  uploadedFile(event) {
    this.fileUploaded = event.target.files[0];
    if (!this.validateFile(this.fileUploaded.name)) {
      let msg = "Selected file format is not supported.";
      this.showValid(msg);
      // setTimeout((data) => {
      //   window.location.reload();
      // }, 2000);
      // Swal.fire({
      //   text: "Selected file format is not supported.",
      // }).then((result) => {
      //   window.location.reload();
      // });
      return false;
    }
    this.hideTableMain = false;
    this.showUploadTable = true;
    this.readExcel();
  }

  validateFile(name: any) {
    var ext = name.substring(name.lastIndexOf(".") + 1);
    if (ext.toLowerCase() == "xlsx") {
      return true;
    } else {
      return false;
    }
  }

  readExcel() {
    let readFile = new FileReader();

    readFile.onload = (e) => {
      this.storeData = readFile.result;
      var data = new Uint8Array(this.storeData);

      var arr = new Array();

      for (var i = 0; i != data.length; ++i)
        arr[i] = String.fromCharCode(data[i]);

      var bstr = arr.join("");

      var workbook = XLSX.read(bstr, { type: "binary" });

      var first_sheet_name = workbook.SheetNames[1];

      this.worksheet = workbook.Sheets[first_sheet_name];

      var range = XLSX.utils.decode_range(this.worksheet["!ref"]);
      range.s.r = 2; // <-- zero-indexed, so setting to 1 will skip row 0
      this.worksheet["!ref"] = XLSX.utils.encode_range(range);

      this.readAsJson(this.GlobalEnvironmentID, this.currentUserID);
    };

    readFile.readAsArrayBuffer(this.fileUploaded);
  }

  // Upload Excel End

  /** Read As Json */

  readAsJson(GlobalEnvironmentID, currentUserID) {
    this.jsonData = XLSX.utils.sheet_to_json(this.worksheet, { raw: false });

    //this.jsonData = JSON.stringify(this.jsonData);

    var arrofobj = (this.LocationImportList = this.jsonData);

    var result = arrofobj.map(function (el) {
      var o = Object.assign({}, el);

      o.UserID = currentUserID;
      o.GlobalEnvironmentID = GlobalEnvironmentID;
      o.Status = "";
      o.Message = "";
      o.RecNo = "";
      o.ISCIStatus = el.Status;
      return o;
    });

    let length = Object.keys(result).length;
    this.IncidentImport(result);
  }

  /**
   * Import Location List
   *
   */
  newObjArr = [];

  IncidentImport(obj) {
    let KeyMtch = Object.keys(obj[0]);
    if (
      KeyMtch.includes("Incident Category") &&
      KeyMtch.includes("Incident Type")
    ) {
      for (var i = 0; i < obj.length; i++) {
        let newObj = {
          RecNo: obj[i]["RecNo"],
          GlobalEnvironmentID: obj[i]["GlobalEnvironmentID"],
          IncidentType: obj[i]["Incident Type"],
          IncidentCategory: obj[i]["Incident Category"],
          IncidentSubject: obj[i]["Incident Subject"],
          IncidentDescription: obj[i]["Incident Description"],
          ISCIStatus: obj[i]["ISCIStatus"],
          UserID: +obj[i]["UserID"],
          Status: "",
          Message: "",
        };
        this.newObjArr.push(newObj);
      }

      let passingArray = this.newObjArr;
      this.IncidentsubjectService.IncidentImport(passingArray).subscribe(
        (res) => {
          this.dataSourceTwo = res.iSCIImport.recordset;
          this.dataSourceTwo.sort = this.tableTwoSort;
          this.tableTwoSort.disableClear = true;
          this.UploadedLocationList = res.iSCIImport.recordset;
          this.showValid("Processed successfully. Please check the table.");
          // this.GetLocationList();
        }
      );
    } else {
      this.showInvalid(
        "Uploaded Excel Sheet is Invalid. Please put the right one."
      );
    }
  }

  /* Upload file */
  openFileBrowser(event: any) {
    // event.preventDefault();
    let element: HTMLElement = document.getElementById("file") as HTMLElement;
    element.click();
    // setTimeout(() => {
    //   this.locationDisplay = false;
    // }, 1000);
    this.locationDisplay = false;
  }
  onFileChange(event: any) {
    let files = event.target.files[0];
    let tenantIDFileName = files.name;
  }
  cancelUploadView() {
    // this.hideTableMain = true;
    // this.showUploadTable = false;
    window.location.reload();
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSourceOne.filter = filterValue.trim().toLowerCase();
  }

  //download here

  downloadISCI() {
    let data = [];

    this.exportreport.forEach(function (item, i) {
      delete item["ISCICategoryID"];
      data.push(item);
    });
    this.IncidentsubjectService.exportAsExcelFile(data);
  }

  downloadUploadedISCI() {
    let newData = [];
    this.UploadedLocationList.forEach(function (item, i) {
      delete item["RecNo"];
      delete item["GlobalEnvironmentID"];
      delete item["Status"];
      // delete item["ISCIStatus"];
      delete item["UserID"];
      delete item["Message"];
      newData.push(item);
    });
    this.IncidentsubjectService.exportUploadExcelFile(newData);
  }

  // toastr warning/success message
  showInvalid(msg) {
    this.tostre.warning(msg, "", {
      positionClass: "toast-top-right",
    });
  }

  showValid(validMsg) {
    this.tostre.success(validMsg, "", {
      positionClass: "toast-top-right",
    });
  }

  /**
   * this area of select tyoe list if single list in column ISCIType LIST
   * for checking purpose only no modification in editing and something
   */
  private checkAndSelectISCITypeList(ISCITypeListForChecking: any) {
    if (Array.isArray(ISCITypeListForChecking)) {
      // ISCITypeListForChecking = [ISCITypeListForChecking[0]];
      if (ISCITypeListForChecking.length === 1) {
        this.selectedISCITypeID = ISCITypeListForChecking[0].ISCICategoryID;
        this.getIsciCategoryListsCheckingOnly(
          ISCITypeListForChecking[0].ISCICategoryID
        );
      }
    }
  }

  private ISCICategoryListForSingleSelection(catagorylistForChecking: any) {
    if (Array.isArray(catagorylistForChecking)) {
      // catagorylistForChecking = [catagorylistForChecking[0]];
      if (catagorylistForChecking.length === 1) {
        this.selectedCategoryID = null;
        // this.selectedCategoryID = catagorylistForChecking[0].ISCICategoryID;
        this.categorySelectedCheckingOnly(
          catagorylistForChecking[0].ISCICategoryID
        );
      }
    }
  }

  private subjectListSingleSelectedOnly(subjectlistForCheckingList: any) {
    if (Array.isArray(subjectlistForCheckingList)) {
      // subjectlistForCheckingList = [subjectlistForCheckingList[0]];
      if (subjectlistForCheckingList.length === 1) {
        this.activeSubjectID = subjectlistForCheckingList[0].ISCICategoryID;
        // this.subjectSelected(
        //   subjectlistForCheckingList[0].ISCICategoryID,
        //   subjectlistForCheckingList[0].ParentID
        // );
      }
    }
  }

  /**
   * for checking for single status of list because subject list dependent on each two other
   * so checking in other api side it is neccessary type not affect the running type cycle
   */
  private getISCITypeListForCheckingOnly(param) {
    let result: any;
    this.IncidentsubjectService.getISCITypeList(
      this.GlobalEnvironmentID
    ).subscribe((res) => {
      result = res;

      const ISCITypeListCheck = result.GetISCITypeList;

      this.checkAndSelectISCITypeList(ISCITypeListCheck);
    });
  }

  private getIsciCategoryListsCheckingOnly(parentID) {
    let result: any;
    this.IncidentsubjectService.getISCICategoryList(parentID).subscribe(
      (res) => {
        result = res;
        this.catagorylist = result.GetISCICategoryList;
        // this.selectedISCITypeID = parentID;

        /** for checking single list in subject list */
        // debugger;
        this.ISCICategoryListForSingleSelection(this.catagorylist);
      }
    );
  }

  private categorySelectedCheckingOnly(ISCICategoryID) {
    this.addgop = false;
    this.propertytype = false;
    this.incidentsubject = false;
    // this.propertytype = false
    this.ISCISubjectEditable = false;
    this.activeSubjectID = false;
    this.angForm.reset();
    this.addgop = false;

    if (this.selectedCategoryID == ISCICategoryID) {
      this.selectedCategoryID = false;
      this.incidentsubject = false;
      let result1: any;
      this.IncidentsubjectService.getISCISubjectList(
        null,
        this.GlobalEnvironmentID,
        this.selectedISCITypeID
      ).subscribe((res) => {
        result1 = res;
        this.subjectlist = result1.GetISCICategoryList;
        /** single selected Only */
        // this.subjectListSingleSelectedOnly(this.subjectlist);
      });
    } else {
      this.selectedCategoryID = ISCICategoryID;
      let result: any;
      this.IncidentsubjectService.getISCISubjectList(
        this.selectedCategoryID,
        this.GlobalEnvironmentID,
        this.selectedISCITypeID
      ).subscribe((res) => {
        result = res;
        this.subjectlist = result.GetISCICategoryList;
        /** single selected Only */
        this.subjectListSingleSelectedOnly(this.subjectlist);
      });
    }
  }
}
