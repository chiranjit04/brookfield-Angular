import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IncidentsubjecttableComponent } from './incidentsubjecttable.component';

describe('IncidentsubjecttableComponent', () => {
  let component: IncidentsubjecttableComponent;
  let fixture: ComponentFixture<IncidentsubjecttableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IncidentsubjecttableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IncidentsubjecttableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
