import { Component, OnInit, Inject } from "@angular/core";
import { userService } from "../user.service";
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from "@angular/material/dialog";
import { FormControl } from "@angular/forms";
import { startWith, map, debounceTime, switchMap } from "rxjs/operators";
import { LoginComponent } from "src/app/modules/auth/login/login.component";
import Swal from "sweetalert2";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-tranceferuser",
  templateUrl: "./tranceferuser.component.html",
  styleUrls: ["./tranceferuser.component.scss"],
  providers: [userService, LoginComponent],
})
export class TranceferuserComponent implements OnInit {
  UID: any;
  userName: string;
  propertyName: string;
  propertyID: any;
  propertyDetail: Array<any> = [];
  TransferredProperty: any;
  loginUserid: any;
  constructor(
    private dialogRef: MatDialogRef<TranceferuserComponent>,
    public dialog: MatDialog,
    private user: userService,
    private locg: LoginComponent,
    public tostre: ToastrService,
    @Inject(MAT_DIALOG_DATA) public duid: any
  ) {
    this.locg.currentUser.subscribe((res) => {
      this.loginUserid = res[0].UserID;
    });
    console.log(duid, "id...issssss........");
    this.UID = duid.id;
    console.log(this.UID, " this.UID...........");
  }

  ngOnInit() {
    if (this.UID) {
      this.GetPropertylistfortransfer();
    } else {
    }
  }

  formControlobj = {
    filterByPropertySearch: new FormControl(),
  };

  obj = {
    PropertyObj: [],
  };

  filtered = {
    filterByProperty: null,
  };

  private _filter(value: any, keyName: string, filterName: string): string[] {
    if (value == null || value == undefined) {
    } else {
      const filterValue = value.toLowerCase();
      return this.obj[keyName].filter((option) =>
        option[filterName].toLowerCase().includes(filterValue)
      );
    }
  }

  initiate(keyNameFilter, listFromServer, keyNameObj, formControlKeyName) {
    this.filtered[keyNameFilter] = this.formControlobj[
      formControlKeyName
    ].valueChanges.pipe(
      debounceTime(300),
      //  startWith(""),
      // switchMap(value => this._filter(value, listFromServer, keyNameObj))
      //  startWith(""),
      map((value) => this._filter(value, listFromServer, keyNameObj))
    );
  }

  GetPropertylistfortransfer() {
    const pbody = {
      UserID: this.UID,
    };
    this.user.GetPropertylistfortransfer(pbody).subscribe((res) => {
      console.log(
        res,
        "res...........",
        this.propertyDetail,
        "this.propertyDetail..."
      );
      if (res.AddTransferUser.recordsets[0].length > 0) {
        this.userName = res.AddTransferUser.recordsets[0][0].UserName;
        this.propertyName = res.AddTransferUser.recordsets[0][0].PropertyName;
        this.propertyID = res.AddTransferUser.recordsets[0][0].PropertyID;
        this.propertyDetail = res.AddTransferUser.recordsets[1];

        this.obj.PropertyObj = this.propertyDetail;
        this.initiate(
          "filterByProperty",
          "PropertyObj",
          "PropertyName",
          "filterByPropertySearch"
        );
      } else {
      }
    });
  }
  GetPropertyid(d) {
    this.TransferredProperty = d;
    console.log(
      this.TransferredProperty,
      this.propertyID,
      "this.TransferredProperty...."
    );
  }
  Transfer() {
    if (this.TransferredProperty > 0) {
      const pbody = {
        UserID: this.UID,
        CurrentAssignPropertyID: this.propertyID,
        TransferredPropertyID: this.TransferredProperty,
        TransferrdByUserID: this.loginUserid,
        UserTransferID: 0,
      };
      this.user.UserTransferProperty(pbody).subscribe((res) => {
        if (res.GetUserTransferProperty.recordsets[0][0].ReturnMessage > 0) {
          /* Swal.fire({
            text: "Transfer request has been sent",
          }).then((result) => {
            this.dialogRef.close({ UserTransferStatus: 0 });
          }); */
          this.tostre.success("Transfer request has been sent.");
          this.dialogRef.close({ UserTransferStatus: 0 });
          // this.user
          //   .UpdateUserPropertyRegistry({
          //     UserID: this.UID,
          //     PropertyID: this.propertyID,
          //     WorkgroupID: 0,
          //     UpdatedFrom: "Property",
          //   })
          // .subscribe((elem) => {});
        } else {
          /* Swal.fire({
            text: "There is some eror",
          }).then((result) => {
            this.dialog.closeAll();
          }); */
          this.tostre.error("There is some eror.");
          this.dialog.closeAll();
        }
        console.log(
          res.GetUserTransferProperty.recordsets[0][0].ReturnMessage,
          "UserTransferProperty...."
        );
      });
    } else {
      /* Swal.fire({
        text: "Please select Transfer Property",
      }).then((result) => {}); */
      this.tostre.warning("Please select Transfer Property.");
    }
  }

  onkeyUpSelection(d) {
    if ("Property" == d) {
      this.TransferredProperty = 0;
    } else {
    }
  }
}
