import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TranceferuserComponent } from './tranceferuser.component';

describe('TranceferuserComponent', () => {
  let component: TranceferuserComponent;
  let fixture: ComponentFixture<TranceferuserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TranceferuserComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TranceferuserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
