import {
  Component,
  OnInit,
  ViewChild,
  Input,
  Output,
  EventEmitter,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  HostListener,
} from "@angular/core";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { userService } from "../user.service";
import { Router, ActivatedRoute } from "@angular/router";
import { TranceferuserComponent } from "../tranceferuser/tranceferuser.component";
import { AccepttranceferuserComponent } from "../accepttranceferuser/accepttranceferuser.component";
import { MatDialog, MAT_DIALOG_DATA } from "@angular/material/dialog";
import Swal from "sweetalert2";
import { filter, map } from "rxjs/operators";
import { UserPermissionService } from "src/app/services/user-permission.service";
import { StorageService } from "../../../../../services/storage.service";
import { ToastrService } from "ngx-toastr";
import { ServiceService } from "./../../../service/service.service";

import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";

@Component({
  selector: "app-userlist",
  templateUrl: "./userlist.component.html",
  styleUrls: ["./userlist.component.scss"],
  providers: [userService],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class UserlistComponent implements OnInit {
  sid: any;
  selectedUserID = false;
  dataSourceOne: MatTableDataSource<any>;
  wholeSourceData = [];
  searchParamObjGlob: any;
  loading = false;
  r$;
  _limit: number = 0;
  _limitFixed: number = 10000;
  lim = 0;
  inter;

  @ViewChild(MatSort, { static: true }) sort: MatSort;

  /**
   * output emitter to send back to parent
   */
  @Output() userList = new EventEmitter<Array<any>>();
  /**
   * this.userlist.emit(this)
   * end
   */
  displayedColumns: string[] = [
    "EmployeeCode",
    "Name",
    "Email",
    "Role",
    "PositionTitle",
    "Company",
    "Property",
    "WorkGroupName",
    "keycontactaction",
  ];

  LoggedInUserData: any = null;
  currentUserID: any;
  IsActivesUser: any = 1;

  constructor(
    private user: userService,
    private route: Router,
    private actr: ActivatedRoute,
    public dialog: MatDialog,
    public UserPermission: UserPermissionService,
    private storage: StorageService,
    private cdr: ChangeDetectorRef,
    public tostre: ToastrService,
    private adminService: ServiceService
  ) {

    this.LoggedInUserData = JSON.parse(this.storage.getData("UserData"));
    this.currentUserID = this.LoggedInUserData[0].UserID;
    console.log("currentUserID", this.currentUserID);

    // this.cdr.detach();
    this.dataSourceOne = new MatTableDataSource();
    this.dataSourceOne.sort = this.sort;
  }
  ngOnInit() {
    this.sid = JSON.parse(this.storage.getData("edituserid"));

    if (this.sid > 0) {
      this.selectedUserID = this.sid;
    }
    // this.selectedUserID =this.sid;
    this.storage.setData("edituserid", null);
    this.sid = null;

    // this.checkWorker();
  }

  ngAfterViewInit() {
    this.dataSourceOne.sort = this.sort;
    this.sort.disableClear = true;

    // this.detectScrollEnd();
    // this.user.GetUserPropertyRegistry({}).subscribe((elem) => {
    //   console.log(elem);
    // });
  }

  alphabets = [];
  UserList: any;
  Length: any;
  dd: any;
  id: any;
  message: any;
  userdata: boolean = true;
  beforeReleas: boolean = false;
  afterReleas: boolean = false;

  @Input("ActiveInactive") public set values(ActiveInactive: any) {
    this.IsActivesUser = ActiveInactive;
    if (ActiveInactive) {
      console.log(ActiveInactive)
      if (ActiveInactive == 1) {
        this.dataSourceOne = new MatTableDataSource([]);
        let tile = [];
        this._GetUserList.forEach(element => {
          if (element.Status == true) {
            element.modifyPermission = this.UserPermission.checkPermission('modify_user');
            tile.push(element)
          }
        });
        if (!tile.length) {
          this.loading = false;
          this.userdata = true;
          this.cdr.detectChanges();
          return;
        }
        this.dataSourceOne = new MatTableDataSource(tile);
        this.dataSourceOne.sort = this.sort;
        console.log(this.dataSourceOne)
      } else if (ActiveInactive == 0) {
        this.dataSourceOne = new MatTableDataSource([]);
        let tile = [];
        this._GetUserList.forEach(element => {
          if (element.Status == false) {
            element.modifyPermission = this.UserPermission.checkPermission('modify_user');
            tile.push(element)
          }
        });
        if (!tile.length) {
          this.loading = false;
          this.userdata = true;
          this.cdr.detectChanges();
          return;
        }
        this.dataSourceOne = new MatTableDataSource(tile);
        this.dataSourceOne.sort = this.sort;
      } else if (ActiveInactive == 10) {
        this._GetUserList.forEach(element => {
          element.modifyPermission = this.UserPermission.checkPermission('modify_user');
        });
        this.dataSourceOne = new MatTableDataSource(this._GetUserList);
        this.dataSourceOne.sort = this.sort;
      }

    } else {
      console.log("else")
    }
  }

  @Input("childmessage")
  public set value(childmessage: any) {
    /** re - attach change detection from component tree */

    if (childmessage) {
      if (!childmessage.length) {
        // this.userdata = true;
      } else {
      }
      this.dd = childmessage;

      if (this.r$) {
        this.r$.unsubscribe();
      }
      if (this.inter) {
        clearInterval(this.inter);
      }

      // this.userdata = true;
      this._limit = 0;
      this.wholeSourceData = [];
      this.dataSourceOne.connect().next([]);
      this.dataSourceOne.disconnect();
      this.dataSourceOne.data = [];
      this.searchParamObjGlob = childmessage;

      let data: any = this.storage.getData("UserData");
      if (!data) {
        return;
      }

      data = JSON.parse(data);

      // this.user
      //   .userDeactivate({
      //     ProfileID: data[0].ProfileID,
      //     UserID: data[0].UserID,
      //   })
      //   .subscribe((elem: any) => {
      console.log(childmessage)
      this.getUserList(childmessage);
      // });
      // this.userList.emit(["hello"]);
    }
  }

  downloadPDF(element: any) {
    let obj = {
      UserID: element.UserID,
    };
    this.user.getUserPropertyRegistry(obj).subscribe(
      (res: any) => {
        let data = res.data;
        // console.log("data -->", data);
        let dataArr = [];
        if (res.data.length > 0) {
          for (let i = 0; i < data.length; i++) {
            let rowArr = [];
            rowArr.push(data[i].UserName);
            rowArr.push(data[i].CompanyName);
            rowArr.push(data[i].ProfileTitle);
            rowArr.push(data[i].JobTitle);
            rowArr.push(data[i].WorkGroupName);
            rowArr.push(data[i].PropertyName);
            // rowArr.push(data[i].ModifyDate);
            if (data[i].IsCurrent) {
              rowArr.push("Current");
            } else {
              rowArr.push("Previous");
            }
            rowArr.push(data[i].CreatedBy);
            rowArr.push(
              `${data[i].CreatedDate} - ${data[i].CreatedTime} Hours`
            );
            dataArr.push(rowArr);
          }
        }
        /* code for pdf file*/
        let doc = new jsPDF("l", "pt", "a4");
        /*add logo*/
        var img = new Image();
        img.src = "assets/images/logo/new_logo.png";
        doc.addImage(img, "png", 0, 0, 200, 100);
        /**/
        autoTable(doc, {
          head: [
            [
              "UserName",
              "CompanyName",
              "ProfileTitle",
              "JobTitle",
              "WorkGroup",
              "Property",
              "CurrentAssignment",
              "CreatedBy",
              "CreatedDate",
            ],
          ],
          body: dataArr,
          theme: "grid",
          styles: { overflow: "linebreak", cellWidth: "auto" },
          margin: { top: 100, left: 0, right: 0, bottom: 0 },
          headStyles: {
            fontSize: 10,
            halign: "center",
            textColor: "#000000",
            fontStyle: "bold",
            fillColor: "#aad9fc",
          },
        });
        let fname = "User_Property";
        doc.save(`${fname}-${Date.now()}.pdf`);
        /**/
        //}
      },
      (err) => {
        console.log("error", err);
      }
    );
  }
  changeUserStatus(d, c) {
    const pbody = {
      UserID: parseInt(c.UserID),
    };
    let msg = c.Status ? "deactivate" : "activate";

    // Swal.fire({
    //   //title: 'Are you sure you want to delete ?',
    //   text: "Are you sure you want to " + msg + " this ?",
    //   showCancelButton: true,
    //   confirmButtonText: "OK",
    //   cancelButtonText: "Cancel",
    // }).then((result) => {
    //   if (result.value) {
    //     let changePer$ = this.user.deactiveuser(pbody).subscribe((res) => {
    //       if (
    //         res.data.DeactiveUser.returnValue > 0 ||
    //         res.message == "Deactive user successfully."
    //       ) {
    //         c.Status = !c.Status;
    //       } else {
    //       }
    //       changePer$.unsubscribe();
    //       this.cdr.detectChanges();
    //     });
    //   }
    // });
    let changePer$ = this.user.deactiveuser(pbody).subscribe((res) => {
      if (
        res.data.DeactiveUser.returnValue > 0 ||
        res.message == "Deactive user successfully."
      ) {
        c.Status = !c.Status;
        this.tostre.success(this.adminService.statusMsg);
      } else {
      }
      changePer$.unsubscribe();
      this.cdr.detectChanges();
    });
  }

  Release(d, elem) {
    this.cdr.reattach();
    const pbody = {
      UserID: d,
    };
    let release$ = this.user.Releasetouser(pbody).subscribe((res) => {
      elem.IsLoggedIn = !elem.IsLoggedIn;
      this.cdr.detectChanges();
      if (res.ReleaseUser.returnValue == 1) {
        Swal.fire({
          text: "User has been Relesed",
        }).then((result) => { });
      }
      release$.unsubscribe();
    });
  }

  edit(d) {
    this.id = d;
    this.selectedUserID = this.id;
    // this.route.navigate(["/products/administration/organizationmanagement/addusers/",d], { queryParams: { "UserID": d } });
    var myurl = `/products/administration/organizationmanagement/users/addusers/${this.id}`;
    this.route.navigateByUrl(myurl).then((e) => { });
  }

  openTranceferuser(d, elem) {
    const dialogRef = this.dialog.open(TranceferuserComponent, {
      width: "30%",
      maxWidth: "100vw",
      data: { id: d },
    });

    let dialogOpenTransfer$ = dialogRef
      .afterClosed()
      .pipe(filter((name) => name))
      .subscribe((name) => {
        //elem.UserTransferStatus = 0;
        dialogOpenTransfer$.unsubscribe();
        this.cdr.detectChanges();
      });
  }

  openAccepttranceferuser(d, elem, index) {

    const dialogRef = this.dialog.open(AccepttranceferuserComponent, {
      width: "30%",
      maxWidth: "100vw",
      data: { id: d, tblRow: index + 1 },
    });

    // let openAccpetTransfer$ = dialogRef.afterClosed().pipe(filter((name) => name)).subscribe((name) => {
    let openAccpetTransfer$ = dialogRef.afterClosed().subscribe((name) => {
      // console.log("accept user transer log:", name)
      if (name.action && name.action == "cancel") {
        elem.Property = name.property;
        this.hideTblRow(d);
      }
      if (name != '') {
        elem.UserTransferStatus = null;
        elem.Property = name
        openAccpetTransfer$.unsubscribe();
        this.cdr.detectChanges();
      }
      // this.dataSourceOne = new MatTableDataSource(this.UserList);
    });
  }

  hideTblRow(index) {
    let obj = this._GetUserList.find((x) => x.UserID == index);
    let indx = this._GetUserList.indexOf(obj);
    this._GetUserList.splice(indx, 1)
    this.dataSourceOne.data = this._GetUserList
  }

  setuser(data: any) {
    if (this.selectedUserID == data.UserID) {
      this.selectedUserID = !this.selectedUserID;
    } else {
      this.selectedUserID = data.UserID;
    }
  }

  /**
   * call Data to server to extract Data
   */
  _GetUserList: any = [];
  pre = 0;
  async getUserList(searchParamObj) {
    this.loading = true;
    this.userdata = false;
    this.cdr.detectChanges();

    // searchParamObj._limit_ = this._limit;
    // searchParamObj._limitFixed = this._limitFixed;
    /**
     * this is merged and it will do as Observable of RXJS Timer Functions
     */
    // if (Date.now() - this.pre < 1000 && this.pre !== 0) {
    //   this.pre = Date.now();
    //   this.loading = false;
    //   // this.obs$.push(this.user.getChunkedLimitUserList(searchParamObj))
    //   return;
    // }

    // this.pre = Date.now();
    // searchParamObj.CompanyId = null;
    this.r$ = this.user
      // .getChunkedLimitUserList(searchParamObj)
      .GetUserListFilter(searchParamObj)

      .subscribe((data: any) => {
        let tile = [];
        this._GetUserList = data.GetUserList;

        if (!this._GetUserList.length) {
          this.loading = false;
          this.userdata = true;
          this.cdr.detectChanges();
          this.dataSourceOne = new MatTableDataSource(tile);
          this.dataSourceOne.sort = this.sort;

          return;
        }
        if (this.IsActivesUser == 1) {
          this._GetUserList.forEach(element => {
            if (element.Status == true) {
              element.modifyPermission = this.UserPermission.checkPermission('modify_user');
              tile.push(element);
            }
          });
          this.dataSourceOne = new MatTableDataSource(tile);
          this.dataSourceOne.sort = this.sort;
          this.intervalFunction(tile);
          this.userList.emit(tile);
        } else {
          this._GetUserList.forEach(element => {
            element.modifyPermission = this.UserPermission.checkPermission('modify_user');
          });
          this.dataSourceOne = new MatTableDataSource(this._GetUserList);
          this.dataSourceOne.sort = this.sort;
          this.intervalFunction(this._GetUserList);
          this.userList.emit(this._GetUserList);
        }
        this.dataSourceOne.sortingDataAccessor = (data: any, sortHeaderId: any): any => {
          if (sortHeaderId != 'EmployeeCode') {
            if (typeof data[sortHeaderId] === 'string') {
              return data[sortHeaderId].toLocaleLowerCase();
            }
          }
          return parseInt(data[sortHeaderId]);
        };
        // this._limit = this._limit + this._limitFixed;
        // this.loading = false;
        this.userdata = false;
        this.cdr.detectChanges();
        this.r$.unsubscribe();
        // return this.getUserList(searchParamObj);
      });
  }

  /**
   * outSide Interval
   */
  async intervalFunction(tile) {
    let datas = [];
    this.lim = 0;
    this.wholeSourceData.push(...tile);
    // this.inter = setInterval(() => {
    // let d = this.wholeSourceData.slice(this.lim, this.lim + 500);
    // this.lim = this.lim + 500;

    // if (!d.length) {
    this.loading = false;
    // this.lim = 0;
    // this.cdr.detectChanges();
    // this.dataSourceOne.disconnect();
    // clearInterval(this.inter);
    // return;
    // }
    this.dataSourceOne.connect().next(this.wholeSourceData);

    // datas.push(...d);
    // this.dataSourceOne.connect().next(datas);
    this.dataSourceOne.disconnect();
    // }, 500);
  }
  /**
   * scroll end checking
   * please don't remove this code
   */

  // detectScrollEnd() {
  //   // window.addEventListener("scroll", this.scrollEvent.bind(this));
  // }
  // please dnt remove this code
  // scrollEvent(event) {
  //   let total = document.body.scrollHeight;

  //   if (window.scrollY + window.innerHeight >= total - 50) {
  //     // this.getUserList(this.searchParamObjGlob);
  //   }
  // }

  ngOnDestroy(): void {
    // window.removeEventListener("scroll", this.scrollEvent.bind(this));
  }
}
