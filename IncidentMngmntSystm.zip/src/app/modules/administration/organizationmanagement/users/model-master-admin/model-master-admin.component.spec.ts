import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModelMasterAdminComponent } from './model-master-admin.component';

describe('ModelMasterAdminComponent', () => {
  let component: ModelMasterAdminComponent;
  let fixture: ComponentFixture<ModelMasterAdminComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModelMasterAdminComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModelMasterAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
