import { Component, OnInit, Inject, Optional } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { ToastrService } from "ngx-toastr";
import { userService } from "../user.service";

@Component({
  selector: "app-model-master-admin",
  templateUrl: "./model-master-admin.component.html",
  styleUrls: ["./model-master-admin.component.scss"],
})
export class ModelMasterAdminComponent implements OnInit {

  UserID: any;
  permissionData: any = [];
  permissions;
  selectedPermissions: any = [];
  permission1: any = false;
  permission2: any = false;
  permission3: any = false;
  UserRestrictions:any = [];

  constructor(
    public dialogRef: MatDialogRef<ModelMasterAdminComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: any,
    public tostre: ToastrService,
    private user: userService
  ) {}

  ngOnInit() {
    this.UserID = this.data.UserID;
    // this.permissionData = this.data.permissionData;
    // console.log(this.UserID)
    this.GetUserSpacialPermission();
    this.GetMasterAdminRestriction();
  }

  GetUserSpacialPermission() {
    console.log(this.UserID);
    if (this.UserID) {
      let param = {
        UserID: this.UserID,
        ApplyON: "OM",
      };
      this.user.GetUserSpacialPermission(param).subscribe((resp) => {
        console.log(resp);
        // console.log(resp.GetUserSpacialPermission)
        if (resp.GetUserSpacialPermission.length) {
          let permissionData = resp.GetUserSpacialPermission[0].PermissionIds;
          this.permissionData = permissionData.split(",");
          /* this.permission1 = this.permissionData.includes("1") ? true: false;
          this.permission2 = this.permissionData.includes("2") ? true: false;
          this.permission3 = this.permissionData.includes("3") ? true: false;  */
        }
      });
    }
  }

  GetMasterAdminRestriction(){
    this.user.GetMasterAdminRestriction().subscribe((result:any)=> {
      this.UserRestrictions = result.data.GetMasterAdminRestriction;
    })
  }

  setPermission(evt, val) {
    // console.log(evt, val)

    if (evt.source.checked) {
      // if (!this.permissionData.includes(val)) {
      this.permissionData = val;
      // }
    } else {
      // let indx = this.permissionData.indexOf(val);
      // this.permissionData.splice(indx, 1);
    }
    // console.log(this.selectedPermissions)
  }

  SavePermission() {
    if (this.permissionData.length == 0) {
      this.tostre.warning("Please select at least one permisson.", "", {
        positionClass: "toast-top-right",
      });
      return;
    } else {
      if (this.UserID) {
        let param = {
          UserID: this.UserID,
          PermissionIds: this.permissionData,
          ApplyOn: "OM",
        };
        this.user.UpdateSpacialPermission(param).subscribe((resp) => {
          console.log("edit permission updated");
        });
        this.dialogRef.close(null);
      } else {
        this.dialogRef.close(this.permissionData);
      }
    }
  }
}
