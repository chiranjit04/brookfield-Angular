import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { map, debounceTime } from "rxjs/operators";
import * as XLSX from "xlsx";
import { environment } from "../../../../../environments/environment";
import { HttpClient } from "@angular/common/http";
// import * as logoFile from "../../propertymanagement/patrolzonemanagement/brookfieldlogo1.js";
import  * as logoFile from "src/assets/images/logo/brookfieldlogo";
import { Workbook } from "exceljs";
import * as fs from "file-saver";
import { BehaviorSubject } from "rxjs";

@Injectable({
  providedIn: "root",
})
export class userService {
  Url: any;
  observable: Observable<any>;

  // private messageSource = new BehaviorSubject("default message");
  // currentMessage = this.messageSource.asObservable();

  constructor(private http: HttpClient) {
    this.Url = environment.origin;
  }

  // changeMessage(message: any) {
  //   this.messageSource.next(message);
  // }

  GetUserList() {
    return this.http
      .get(this.Url + "api/getUserList")
      .pipe(map((x) => x as any));
  }

  GetUserListFilter(d) {
    return (
      this.http
        .post(this.Url + "api/getUserListFilter", d)
        //.pipe(map(x=> x as any));

        .pipe(
          debounceTime(500), // WAIT FOR 500 MILISECONDS ATER EACH KEY STROKE.
          map((x) => x as any)
        )
    );
  }

  GetTimeZone() {
    return this.http
      .get(this.Url + "api/getTimeZone")
      .pipe(map((x) => x as any));
  }

  GetpositionTitle(d) {
    return this.http
      .post(this.Url + "api/getpositionTitle", d)
      .pipe(map((x) => x as any));
  }

  GetLocale() {
    return this.http.get(this.Url + "api/getLocale").pipe(map((x) => x as any));
  }

  GetUserProfile(d) {
    return this.http
      .post(this.Url + "api/getUserProfileByCompanyId", d)
      .pipe(map((x) => x as any));
  }

  GetWorkgroup(d) {
    return this.http
      .post(this.Url + "api/getWorkGroupForUserByCompanyID", d)
      .pipe(map((x) => x as any));
  }

  GetCompany(param: any) {
    // old -> GetActiveCompanyList
    return this.http.post(this.Url + "api/GetActiveCompanyListOM", param).pipe(
      map((x: any) => {
        return x;
      })
    );
  }

  GetProperty() {
    return this.http
      .get(this.Url + "api/getproperty")
      .pipe(map((x) => x as any));
  }

  GetpropertyByCompanyID(data: any) {
    return this.http
      .post(this.Url + "api/GetpropertyByCompanyID", data)
      .pipe(map((x) => x as any));
  }

  GetCountry() {
    return this.http
      .get(this.Url + "api/getCountry")
      .pipe(map((x) => x as any));
  }

  GetState(d) {
    return this.http
      .post(this.Url + "api/getState", d)
      .pipe(map((x) => x as any));
  }

  GetCity(d) {
    return this.http
      .post(this.Url + "api/getCity", d)
      .pipe(map((x) => x as any));
  }

  updateuser(d) {
    return this.http
      .post(this.Url + "api/updatemanageuser", d)
      .pipe(map((x) => x as any));
  }

  GetUserListForUpdate(d) {
    return this.http
      .post(this.Url + "api/getUserListForUpdate", d)
      .pipe(map((x) => x as any));
  }

  GetCompanySubdivision(param) {
    // return this.http.post(this.Url + "api/getSubdivision", param).pipe(map((x) => x as any));
    return this.http
      .post(this.Url + "api/GetSubDivisionByCompany", param)
      .pipe(map((x) => x as any));
  }

  generateFileName(): string {
    return `UserManagement${Date.now()}.xlsx`;
  }
  exportToExecl(json: any, filename: string) {
    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(json);
    const workbook: XLSX.WorkBook = {
      Sheets: { data: worksheet },
      SheetNames: ["data"],
    };
    XLSX.writeFile(workbook, filename);
  }

  checkUser(d) {
    return this.http
      .post(this.Url + "api/checkUserAvailability", d)
      .pipe(map((x) => x as any));
  }

  getSubdivisionbyPropertyId(d) {
    return this.http
      .post(this.Url + "api/getSubdivisionbyPropertyId", d)
      .pipe(map((x) => x as any));
  }

  CheckSocialSecurityNumber(d) {
    return this.http
      .post(this.Url + "api/CheckSocialSecurityNumber", d)
      .pipe(map((x) => x as any));
  }

  CheckEmailAvailablety(d) {
    return this.http
      .post(this.Url + "api/checkEmailAvailablety", d)
      .pipe(map((x) => x as any));
  }

  CheckIsAdminProfile(d) {
    return this.http
      .post(this.Url + "api/checkIsAdminProfile", d)
      .pipe(map((x) => x as any));
  }

  Releasetouser(d) {
    return this.http
      .post(this.Url + "api/releaseUser", d)
      .pipe(map((x) => x as any));
  }

  GetPropertylistfortransfer(d) {
    return this.http
      .post(this.Url + "api/addTransferUser", d)
      .pipe(map((x) => x as any));
  }

  UserTransferProperty(d) {
    return this.http
      .post(this.Url + "api/userTransferProperty", d)
      .pipe(map((x) => x as any));
  }

  PropertyAcceptlist(d) {
    return this.http
      .post(this.Url + "api/propertyAcceptlist", d)
      .pipe(map((x) => x as any));
  }

  UserAcceptProperty(d) {
    return this.http
      .post(this.Url + "api/userAcceptProperty", d)
      .pipe(map((x) => x as any));
  }

  userImport(d) {
    return this.http
      .post(this.Url + "api/userImport", d)
      .pipe(map((x) => x as any));
  }

  sendCredentials(d) {
    return this.http
      .post(this.Url + "api/sendCredentials", d)
      .pipe(map((x) => x as any));
  }
  deactiveuser(d) {
    return this.http
      .post(this.Url + "api/deactiveUser", d)
      .pipe(map((x) => x as any));
  }

  GetUserSpacialPermission(param: any) {
    return this.http
      .post(this.Url + "api/GetUserSpacialPermission", param)
      .pipe(map((x) => x as any));
  }

  UpdateSpacialPermission(param: any) {
    return this.http
      .post(this.Url + "api/UpdateSpacialPermission", param)
      .pipe(map((x) => x as any));
  }
  /**
   *
   */
  GetCompanyByUser(param) {
    // GetCompanyByUser
    return this.http.post(this.Url + "api/GetCompanyByUserOM", param);
  }

  async exportAsExcelFile(json: any[]) {
    const title = "User Uploading Form";

    const i1 = "Brookfield Properties Users Spreadsheet";
    const i2 =
      "Please list the Brookfield Properties, these Properties are customized to represent that company’s organizational structure and related positions of oversight.";

    const i3 = "Set of Instructions for the Spreadsheet:";
    const i4 = "GENERAL INFO:";
    const i5 =
      " - 	Please fill in the required fields to upload data into MAXIMUS.";
    const i6 =
      " - 	Dropdown values will appear in each cell if there is a selection to be made, ";
    const i7 = "	 otherwise enter appropriate data. ";
    const i8 = "- Headers in Light Green are Mandatory or Required fields. ";
    const i9 = "- Headers in White are not Required entry fields. ";
    const i10 =
      "- Header cells that include a red triangle at top right provide ";
    const i11 = "information about the field when you mouse over the cell.	";

    const header = [
      "Prefix",
      "First Name",
      "Middle Name",
      "Last Name",
      "NI Number",
      "Email",
      "Phone Number (000-000-0000)",
      "Address",
      "Country Name",
      "State Name",
      "City Name",
      "ZipCode",
      "User ID",
      "Unit # (Radio ID)",
      "Company Name",
      "User Profile",
      "Job Title",
      "Is this user assigned to a specific workgroup?",
      "If yes, select specific workgroup",
      "Is this user assigned to a specific property?",
      "Select Specific Property Name",
      "Time Zone",
      "Language",
      "Is this user the primary contact for property or workgroup?",
      "Is this user a Responding Officer?",
      "User Login",
      "Password",
      "Status",
    ];

    // Create workbook and worksheet
    const workbook = new Workbook();
    const worksheet1 = workbook.addWorksheet("Instruction");
    const worksheet = workbook.addWorksheet("Upload Sheet");
    const worksheet2 = workbook.addWorksheet("SystemPickValues");

    let objectList = [];
    objectList = json.map((ob) => Object.values(ob));
    //  worksheet 1
    ///////////////////////////////////////
    // Add the Header Image in worksheet1
    worksheet1.mergeCells("D1:H1");
    const imageRow1 = worksheet1.getRow(1);

    imageRow1.height = 60;

    const logo1 = workbook.addImage({
      base64: logoFile.logoBase64,
      extension: "png",
    });

    worksheet1.addImage(logo1, "D1:H1");

    worksheet1.mergeCells("C3:J3");

    worksheet1.getCell("C3").value = i1;
    worksheet1.getCell("C3").font = {
      name: "Calibri",
      family: 4,
      size: 16,
      bold: true,
      underline: true,
    };
    worksheet1.getRow(3).height = 25;
    // titleRow1.height=20;

    worksheet1.mergeCells("B7:K10");
    worksheet1.getCell("B7").value = i2;

    worksheet1.getCell("B7").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "C9DEC9" }, //C9DEC9
      bgColor: { argb: "FF0000FF" }, //FF0000FF
    };

    worksheet1.getCell("B7").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheet1.getCell("B7").alignment = {
      vertical: "top",
      horizontal: "left",
      wrapText: true,
    };
    worksheet1.mergeCells("B12:E12");
    worksheet1.getCell("B12").value = i3;
    worksheet1.getCell("B12").font = {
      name: "Calibri",
      family: 4,
      size: 12,
      bold: true,
    };

    worksheet1.getCell("B14").value = i4;
    worksheet1.getCell("B14").font = {
      name: "Calibri",
      family: 4,
      size: 12,
      bold: true,
    };

    worksheet1.getCell("C16").value = i5;
    worksheet1.getCell("C18").value = i6;
    worksheet1.getCell("C19").value = i7;
    worksheet1.getCell("D21").value = i8;
    worksheet1.getCell("D22").value = i9;
    worksheet1.getCell("D24").value = i10;
    worksheet1.getCell("D25").value = i11;

    worksheet1.addRow([]);

    /////////////////////////////////////////
    const j1 = [
      "Mr.",
      "American Property",
      "Active",
      "Yes",
      "(UTC – 4:00) Puerto Rico, US Virgin Islands",
      "English",
    ];
    const j2 = [
      "Mrss.",
      "ASD  Company",
      "InActive",
      "No",
      "(UTC – 5:00) Eastern Time Zone (US & Canada)",
      "Spanish",
    ];
    const j3 = [
      "Mis.",
      "Brook Field  Company",
      " ",
      " ",
      "(UTC – 6:00) Central Time Zone (US & Canada)",
      "French",
    ];
    const j4 = [
      "Ms.",
      "Brookfield Asset Management",
      " ",
      " ",
      "(UTC – 7:00) Mountain Time Zone (US & Canada)",
    ];
    const j5 = [
      "",
      "Company1",
      "",
      "",
      "(UTC – 8:00) Pacific Time Zone (US & Canada)",
    ];
    const j6 = [
      "",
      "Financial services Company",
      "",
      "",
      "(UTC – 9:00) Alaska Time Zone",
    ];
    const j7 = [
      "",
      "Live Test Management Company",
      "",
      "",
      "(UTC – 10:00) Hawaii Time Zone",
    ];
    const j8 = ["", "Live Test Owner Company"];

    const j9 = ["", "Live Test Security Company"];
    const j10 = ["", "Sub division Live Test Owner Company"];
    const j11 = ["", "Sub division Live Test Security Company"];
    const j12 = ["", "Sub-Company1"];

    worksheet1.mergeCells("A2");
    const titleRo = worksheet2.addRow(j1);
    worksheet2.addRow(j2);
    worksheet2.addRow(j3);
    worksheet2.addRow(j4);
    worksheet2.addRow(j5);
    worksheet2.addRow(j6);
    worksheet2.addRow(j7);
    worksheet2.addRow(j8);
    worksheet2.addRow(j9);
    worksheet2.addRow(j10);
    worksheet2.addRow(j11);
    worksheet2.addRow(j12);
    //titleRo.font = { name: "Calibri", family: 4, size: 16, bold: true };
    // titleRo.height=20;
    titleRo.eachCell((cell, number) => {});

    worksheet2.getColumn(1).width = 10;
    worksheet2.getColumn(2).width = 40;
    worksheet2.getColumn(3).width = 10;
    worksheet2.getColumn(4).width = 10;
    worksheet2.getColumn(5).width = 60;
    worksheet2.getColumn(6).width = 10;

    ///////////////////////////////////////

    // Add the Header Image
    worksheet.mergeCells("A1:B1");
    const imageRow = worksheet.getRow(1);
    imageRow.height = 80;

    // Add Image
    const logo = workbook.addImage({
      base64: logoFile.logoBase64,
      extension: "png",
    });

    worksheet.addImage(logo, {
      tl: { col: 0.5, row: 0.5 },
      ext: { width: 350, height: 85 },
    });
    const titleRow = worksheet.addRow([title]);
    titleRow.font = { name: "Calibri", family: 4, size: 16, bold: true };
    worksheet.mergeCells("A2:C2");
    worksheet.getRow(2).height = 30;
    // Add Header Row
    const headerRow = worksheet.addRow(header);

    // Set a specific row height
    headerRow.height = 42.5;

    headerRow.font = { name: "Calibri", family: 4, size: 11, bold: true };
    headerRow.alignment = {
      vertical: "middle",
      horizontal: "center",
    };

    // Cell Style : Fill and Border

    headerRow.eachCell((cell, number) => {
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "0xEAF1DD" }, //C9DEC9
        bgColor: { argb: "" }, //FF0000FF
      };
      cell.border = {
        top: { style: "thin" },
        left: { style: "thin" },
        bottom: { style: "thin" },
        right: { style: "thin" },
      };
    });
    worksheet.getCell("A3").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "C9DEC9" }, //C9DEC9
      bgColor: { argb: "FF0000FF" }, //FF0000FF
    };
    worksheet.getCell("A3").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };

    worksheet.getCell("B3").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "C9DEC9" }, //C9DEC9
      bgColor: { argb: "FF0000FF" }, //FF0000FF
    };
    worksheet.getCell("B3").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheet.getCell("D3").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "C9DEC9" }, //C9DEC9
      bgColor: { argb: "FF0000FF" }, //FF0000FF
    };
    worksheet.getCell("D3").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheet.getCell("F3").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "C9DEC9" }, //C9DEC9
      bgColor: { argb: "FF0000FF" }, //FF0000FF
    };
    worksheet.getCell("F3").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheet.getCell("M3").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "C9DEC9" }, //C9DEC9
      bgColor: { argb: "FF0000FF" }, //FF0000FF
    };
    worksheet.getCell("M3").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheet.getCell("O3").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "C9DEC9" }, //C9DEC9
      bgColor: { argb: "FF0000FF" }, //FF0000FF
    };
    worksheet.getCell("O3").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheet.getCell("P3").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "C9DEC9" }, //C9DEC9
      bgColor: { argb: "FF0000FF" }, //FF0000FF
    };
    worksheet.getCell("P3").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheet.getCell("R3").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "C9DEC9" }, //C9DEC9
      bgColor: { argb: "FF0000FF" }, //FF0000FF
    };
    worksheet.getCell("R3").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheet.getCell("T3").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "C9DEC9" }, //C9DEC9
      bgColor: { argb: "FF0000FF" }, //FF0000FF
    };
    worksheet.getCell("T3").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheet.getCell("Z3").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "C9DEC9" }, //C9DEC9
      bgColor: { argb: "FF0000FF" }, //FF0000FF
    };
    worksheet.getCell("Z3").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheet.getCell("AA3").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "C9DEC9" }, //C9DEC9
      bgColor: { argb: "FF0000FF" }, //FF0000FF
    };
    worksheet.getCell("AA3").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheet.getCell("AB3").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "C9DEC9" }, //C9DEC9
      bgColor: { argb: "FF0000FF" }, //FF0000FF
    };
    worksheet.getCell("AB3").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    // worksheet.addRows(data);

    // Add Data and Conditional Formatting
    objectList.forEach((d) => {
      if (d[27] == true) {
        d[27] = "Active";
      }
      if (d[27] == false) {
        d[27] = "InActive";
      }
      if (d[20] == "None") {
        d[20] = "";
      } else {
      }
      if (d[18] == "None") {
        d[18] = null;
      } else {
      }

      if (d[29]) {
        delete d[29];
      }
      if (d[30]) {
        delete d[30];
      }
      if (d[28]) {
        delete d[28];
      }
      const row = worksheet.addRow(d);
      const qty = row.getCell(4);
    });

    worksheet.getColumn(1).width = 20;
    worksheet.getColumn(2).width = 30;
    worksheet.getColumn(3).width = 30;
    worksheet.getColumn(4).width = 30;
    worksheet.getColumn(5).width = 30;

    worksheet.getColumn(6).width = 30;
    worksheet.getColumn(7).width = 30;
    worksheet.getColumn(8).width = 30;
    worksheet.getColumn(9).width = 30;
    worksheet.getColumn(10).width = 30;

    worksheet.getColumn(11).width = 30;
    worksheet.getColumn(12).width = 30;
    worksheet.getColumn(13).width = 30;
    worksheet.getColumn(14).width = 30;
    worksheet.getColumn(15).width = 30;

    worksheet.getColumn(16).width = 30;
    worksheet.getColumn(17).width = 30;
    worksheet.getColumn(18).width = 30;
    worksheet.getColumn(19).width = 30;
    worksheet.getColumn(20).width = 30;

    worksheet.getColumn(21).width = 30;
    worksheet.getColumn(22).width = 30;
    worksheet.getColumn(23).width = 20;

    worksheet.getColumn(24).width = 30;
    worksheet.getColumn(25).width = 30;
    worksheet.getColumn(26).width = 30;
    worksheet.getColumn(27).width = 30;
    worksheet.getColumn(28).width = 30;
    if (header["Status"] == "TRUE") {
      header["Status"] == "Active";
    }
    worksheet.addRow([]);

    // delete item['Message'];
    //   // delete item['Status'];
    // Generate Excel File with given name
    workbook.xlsx.writeBuffer().then((data: any) => {
      const blob = new Blob([data], {
        type:
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });
      const fnam = Date.now();

      fs.saveAs(blob, `DownloadUser${fnam}.xlsx`);
    });
  }

  GetCityListforAddUser(param) {
    return this.http.post(this.Url + "api/getCity", param);
  }

  /**
   * chunked limit of data Response user table array
   */

  getChunkedLimitUserList(param) {
    return this.http.post(this.Url + "api/getUserListFilterByLimit", param);
  }

  userDeactivate(param) {
    return this.http.post(this.Url + "api/GetUserDeactivation", param);
  }

  UpdateUserPropertyRegistry(param) {
    return this.http.post(this.Url + "api/UpdateUserPropertyRegistry", param);
  }

  getUserPropertyRegistry(param){
     return this.http.post(this.Url + "api/GetUserPropertyRegistry",param);
  }

  GetMasterAdminRestriction(){
     return this.http.get(this.Url + "api/GetMasterAdminRestriction");
  }

  DeleteUserTransferRequest(params:any){
     return this.http.post(this.Url + "api/DeleteUserTransferRequest", params);
  }
}
