import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccepttranceferuserComponent } from './accepttranceferuser.component';

describe('AccepttranceferuserComponent', () => {
  let component: AccepttranceferuserComponent;
  let fixture: ComponentFixture<AccepttranceferuserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccepttranceferuserComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccepttranceferuserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
