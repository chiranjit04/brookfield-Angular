import { Component, OnInit, Inject } from "@angular/core";
import { userService } from "../user.service";
import { LoginComponent } from "src/app/modules/auth/login/login.component";
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from "@angular/material/dialog";
import { FormControl } from "@angular/forms";
import { startWith, map } from "rxjs/operators";
import Swal from "sweetalert2";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-accepttranceferuser",
  templateUrl: "./accepttranceferuser.component.html",
  styleUrls: ["./accepttranceferuser.component.scss"],
  providers: [userService, LoginComponent],
})
export class AccepttranceferuserComponent implements OnInit {
  UID: any;
  userid: any;
  userName: string;
  propertyName: string;
  newProName: string;
  loginUserid: any;
  propertyDetail: Array<any> = [];
  TransferredProperty: any;
  responseData:any;
  TransferrdByUserID:any
  tblRowIndex:any
  UserTransferID:any;
  UserProfileID:any;

  constructor(
    private dialogRef: MatDialogRef<AccepttranceferuserComponent>,
    public dialog: MatDialog,
    private user: userService,
    private locg: LoginComponent,
    public tostre: ToastrService,
    @Inject(MAT_DIALOG_DATA) public duid: any
  ) {
    this.locg.currentUser.subscribe((res) => {
      // console.log(res[0])
      this.loginUserid = res[0].UserID;
      this.UserProfileID = res[0].ProfileID;
    });
    this.UID = duid.id;
    this.tblRowIndex = duid.tblRow;
    console.log(this.tblRowIndex) 
    if (this.UID) {
      this.PropertyAcceptlist();
    } else {
    }
  }

  ngOnInit() { }
  formControlobj = {
    filterByPropertySearch: new FormControl(),
  };

  obj = {
    PropertyObj: [],
  };

  filtered = {
    filterByProperty: null,
  };

  PropertyAcceptlist() {
    const pbody = {
      UserID: parseInt(this.UID),
    };
    this.user.PropertyAcceptlist(pbody).subscribe((res) => {
      if (res.PropertyAcceptlist.recordsets[0].length > 0) {
        this.userName = res.PropertyAcceptlist.recordsets[0][0].UserName;
        this.propertyName = res.PropertyAcceptlist.recordsets[0][0].PropertyName;
        this.newProName = res.PropertyAcceptlist.recordsets[1][0].PropertyName;
        this.TransferredProperty = res.PropertyAcceptlist.recordsets[1][0].PropertyID;
        this.userid = res.PropertyAcceptlist.recordsets[1][0].UserTransferID;
        this.UserTransferID = res.PropertyAcceptlist.recordsets[1][0].UserTransferID;
        this.responseData = res.PropertyAcceptlist.recordsets[1][0];        
        this.TransferrdByUserID = this.responseData.TransferrdByUserID;
        
        // this.obj.PropertyObj = this.propertyDetail;
        // this.initiate(
        //   "filterByProperty",
        //   "PropertyObj",
        //   "PropertyName",
        //   "filterByPropertySearch"
        // );
      } else {
      }
      // console.log(res,res.PropertyAcceptlist.recordsets[0].length,this.propertyDetail, this.propertyName, this.userName, 'PropertyAcceptlist...............');
    });
  }

  private _filter(value: any, keyName: string, filterName: string): string[] {
    if (value == null || value == undefined) {
    } else {
      const filterValue = value.toLowerCase();
      return this.obj[keyName].filter((option) =>
        option[filterName].toLowerCase().includes(filterValue)
      );
    }
  }

  initiate(keyNameFilter, listFromServer, keyNameObj, formControlKeyName) {
    this.filtered[keyNameFilter] = this.formControlobj[
      formControlKeyName
    ].valueChanges.pipe(
      startWith(""),
      map((value) => this._filter(value, listFromServer, keyNameObj))
    );
  }

  // GetPropertyid(d) {
  //   this.TransferredProperty = d;
  //   console.log(this.TransferredProperty, 'this.TransferredProperty....')
  // }

  Confirm() {
    const pbody = {
      UserTransferID: this.userid,
      UserID: this.loginUserid,
      TransferredPropertyID: this.TransferredProperty,
    };
    this.user.UserAcceptProperty(pbody).subscribe((res) => {
      if (res.userAcceptProperty.length > 0) {
        this.tostre.success("Property has been Accepted.");
        this.dialogRef.close(this.newProName);
        /* Swal.fire({
          text: "Property has been Accepted",
        }).then((result) => {
          this.dialogRef.close(this.newProName);
        }); */
        // Following functionality maintained in sp
        // this.user
        //   .UpdateUserPropertyRegistry({
        //     UserID: this.userid,
        //     PropertyID: this.TransferredProperty,
        //     WorkgroupID: 0,
        //     UpdatedFrom: "Property",
        //   })
        //   .subscribe((elem) => {});
      } else {
       /*  Swal.fire({
          text: "There is some error",
        }).then((result) => {
          this.dialog.closeAll();
        }); */
        this.tostre.error("Property has been Accepted.");
        this.dialog.closeAll();
      }
    });
  }

  CancelTransfer() {
    /* const pbody = {
      UserTransferID: this.userid,
      UserID: this.loginUserid,
      TransferredPropertyID: this.TransferredProperty,
    }; */
    // console.log(pbody);
     Swal.fire({
      text: "Are you sure you want to cancel this?",
      showCancelButton: true,
      confirmButtonText: "Yes",
      cancelButtonText: "NO",
    }).then((result) => {
      if (result.value) {
        this.user.DeleteUserTransferRequest({UserTransferID: this.UserTransferID}).subscribe((result:any)=>{
          this.tostre.success("Transfer cancelled.");
          if(this.TransferrdByUserID != this.loginUserid){
            this.dialogRef.close({property: this.propertyName, action:'cancel'});
          }else{
            this.dialogRef.close(this.propertyName);
          }
        })        
      }
    });
  }
}
