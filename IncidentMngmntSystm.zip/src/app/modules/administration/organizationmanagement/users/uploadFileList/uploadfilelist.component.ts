import {Component, OnInit, ViewChild, Input} from '@angular/core'
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import Swal from 'sweetalert2';
import { userService } from '../user.service';


@Component({
    selector:'app-uploadfilelist',
templateUrl:'./uploadfilelist.component.html',
styleUrls:['./uploadfilelist.component.scss'],
providers: [userService]
})
export class UploadFileListComponent  implements OnInit{
    message:any;
    userdata:boolean=false;
    UserList:any;
    XLUserList:any;
    Length:any;
    dd:any;

    dataSourceOne: MatTableDataSource<any>;
    @ViewChild(MatSort, { static: true }) sort: MatSort;
    displayedColumns: string[] = [
      "EmployeeCode",
      "FirstName",
      "Email",
      "ProfileName",
      "JobTitle",
      "CompanyName",
      "PropertyName",
      "WorkGroupName",
      "Status",
     "Message"
    ];

constructor(private user:userService){
    this.dataSourceOne = new MatTableDataSource();
    this.dataSourceOne.sort = this.sort;
}
    ngOnInit(){

    }

    ngAfterViewInit() {
        this.dataSourceOne.sort = this.sort;
       }

    
 @Input('babymessage')


 public set value(babymessage : any) {
  if(babymessage){
  if(babymessage.length==0){
    this.message='There is no data found......'
    this.userdata=true;   
  } else{
    this.userdata=false;
  }
   this.dd = babymessage;
   this.UserList =this.dd;
     
   this.dataSourceOne =  new MatTableDataSource(this.UserList);
   this.dataSourceOne.sort = this.sort;
console.log( this.UserList,' this.UserList....................................')
  // this.Length=this.UserList.length; 
 }

}
   


exportUserList() {
  let data = [];
  this.XLUserList= this.UserList;
   console.log(this.UserList, 'this.UserListthis',this.XLUserList,'this.XLUserList')
  this.XLUserList.forEach(function (item, i) {
    console.log('data downloadable', item);
   
    delete item['PasswordSalt'];
    delete item['RealPassword'];
    delete item['UserID'];
    delete item['LastModifyDate'];
    delete item['LastActivatedDate'];
    delete item['LastDeActivatedDate'];
    delete item['IsLoggedIn'];
    delete item['PropertyID'];
    delete item['Photograph'];
    delete item['CountryID'];
    delete item['City'];
    delete item['UserTransferStatus']; 
    delete item['RecNo'];
   
//console.log('item', item);
    data.push(item);
  });
 // console.log( data,'data');
  this.dataSourceOne =  new MatTableDataSource(this.XLUserList);
 // console.log(this.UserList, 'this.UserListthis',this.XLUserList,'this.XLUserList')
  // this.PatrolService.exportAsExcelFile(this.patrolzonelist, this.PatrolExcelFormt);
  this.user.exportAsExcelFile(data);    
   
}


    
}