import {
  Component,
  OnInit,
  Inject,
  Input,
  ViewChild,
  HostListener,
} from "@angular/core";
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from "@angular/material/dialog";
import { MatSlideToggleModule } from "@angular/material/slide-toggle";
import { userService } from "./user.service";
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators,
  FormControl,
} from "@angular/forms";

import { ActivatedRoute, Router } from "@angular/router";
import Swal from "sweetalert2";
import { promise } from "protractor";
import { resolve } from "dns";
import { UserModalComponent } from "./adduser.component";
import {
  MatAutocompleteModule,
  MatAutocompleteTrigger,
} from "@angular/material/autocomplete";
import { startWith, map } from "rxjs/operators";
import * as XLSX from "xlsx";
import { LoginComponent } from "src/app/modules/auth/login/login.component";
import { ToastrService } from "ngx-toastr";
import * as FileSaver from "file-saver";
import { INSERT } from "@angular/cdk/keycodes";
import { getLocaleDateTimeFormat } from "@angular/common";
import { reject } from "q";
import { UserPermissionService } from "../../../../services/user-permission.service";
import { StorageService } from "../../../../services/storage.service";
import { TierProgramChartService } from "src/app/modules/tiermanagement/services/tier-program-chart.service";
import { stringify } from 'querystring';
@Component({
  selector: "app-users",
  templateUrl: "./users.component.html",
  styleUrls: ["./users.component.scss"],
  providers: [userService, LoginComponent],
})
export class UsersComponent implements OnInit {
  isSubdivision: any = false;
  CountryId: any;
  ActiveInactive: any = "1";

  constructor(
    public tostre: ToastrService,
    public dialog: MatDialog,
    private locg: LoginComponent,
    public toggle: MatSlideToggleModule,
    private fb: FormBuilder,
    private user: userService,
    private route: Router,
    public UserPermission: UserPermissionService,
    private storage: StorageService
  ) {
    for (let i = 65; i <= 90; i++) {
      this.alphabets.push(String.fromCharCode(i));
    }

    this.usersearch = this.fb.group({
      LastName: [""],
      Name: [""],
      Email: [""],
      UserID: [""],
      Country: [""],
      City: [""],
      State: [""],
      PositionTitle: [""],
      ProfileId: [""],
      WorkGroupName: [""],
      Company: [""],
      PropertyId: [""],
      SubPropertyId: [""],
      subdivision: [""],
    });
    this.companyDetail = JSON.parse(this.storage.getData("CompanyDetails"));
    console.log(this.companyDetail);
    if (this.companyDetail) {
      this.CompanyId = this.companyDetail.CompanyID;
      if (this.companyDetail.CompanySubdivision == "Company Sub-Division") {
      }

      // this.GetCompanySubdivision(this.CompanyId);
      this.companynameCheck = this.companyDetail.CompanyName;
      this.CompanyNameHeader =
        this.companyDetail.CompanyName +
        " - " +
        this.companyDetail.CompanyIndentNumber;

      if (this.companyDetail.ParentName) {
        // this.SubCompanyHeader =
        //   "This is a Company Subdivision of Company : " +
        //   this.companyDetail.ParentName +
        //   " - ";
        //  +
        // this.companyDetail.ParentIdentNumber;
        if (
          this.companyDetail.ParentName === this.companyDetail.ParentCompanyName
        ) {
          this.SubCompanyHeader =
            "This is a Company Subdivision of Company: " +
            this.companyDetail.ParentCompanyName +
            " - " +
            this.companyDetail.ParentCompanyIndentNumber;
        } else {
          /**
           * if not same
           */
          this.SubCompanyHeader =
            "This is a Subdivision of Company Subdivision: " +
            this.companyDetail.ParentCompanyName +
            " - " +
            this.companyDetail.ParentCompanyIndentNumber;
        }
        this.subdivisionName = this.SubCompanyHeader;
      }
    }

    this.locg.currentUser.subscribe((res) => {
      this.loginUserid = res[0].UserID;
    });
  }
  advanvces = false;
  searchEmployee: any;
  id: number;
  cid: number;
  sid: number;
  getcompanylistdata: any;
  imprtuserReport: Array<string>;
  usersearch: FormGroup;
  ContryList: Array<any>;
  StateList = [];
  CityList: [];
  Disable = true;
  UserList: Array<any>;
  UserProfile: Array<any>;
  Workgroup: any;
  //CompanyNames: Array<any>;
  PropertyName: Array<any>;
  CityNames: Array<any>;
  City: Array<any>;
  PositionTitle: Array<any>;
  subdivisionlist: any;
  subdivisionName: any;
  PropertyId: any;
  SubPropertyId: any;
  CityName: any;
  CompanyId: any = false;
  WorkGroupNameValue: any;
  ProfileIDvalue: any;
  PositionTitlevalue: any;
  Length: any;
  downloadToExcels: Array<any> = [];
  alphabets = [];
  parentmessage: any;
  fathermessage: any;
  ProfileId: any;
  NoLength = false;
  selectedlist: string;
  fileUploaded: File;
  storeData: any;
  jsonData: any;
  worksheet: any;
  htmlData: any;
  UserImportList: any = [];
  loginUserid: any;
  ss: string;
  uploadfileList: boolean = false;
  showuser: boolean = true;
  userdownloadDataformate: any;
  companyDetail: any;
  companynameCheck: string;
  searchEmployeeID: any;
  SubCompanyHeader = "";
  CompanyNameHeader = "";
  subDivisionCompanyID: any;
  userFormate: any = {
    // RecNo:"",
    // Salutation: "" ,
    // FirstName:"",
    // MiddleName:"",
    // LastName:"",
    // SocialSecurityNumber:"",
    // Email:"",
    // PhoneNumber:"",
    // EmployeeCode:"",
    // UnitNumber: "",
    // CompanyName:"" ,
    // ProfileName:"",
    // JobTitle:"",
    // WorkGroupName: "",
    // PropertyName:"",
    // WorkGroupOrProperty: "",
    // TimeZone: "",
    // Locale: "",
    // IsPrimaryContact: "",
    // IsRespondingOfficer: "",
    // UserLogin: "",
    // Password: "",
    // PasswordSalt: "",
    // RealPassword: "",
    // UserStatus: ""
  };
  // formCOntrol type scrarch

  LastName = new FormControl("");

  inteliTypeFilters: Array<any> = [
    "WorkGroupName",
    "filterByCompanySearch",
    "filterBysubdivisionSearch",
    "filterByPropertySearch",
    "filterBySubPropertySearch",
  ];

  formControlobj = {
    filterBysubdivisionSearch: new FormControl(),
    filterByPropertySearch: new FormControl(),
    filterBySubPropertySearch: new FormControl(),
    filterByCitySearch: new FormControl(),
    filterByCompanySearch: new FormControl(),
    filterByStateSearch: new FormControl(),
    WorkGroupName: new FormControl(),
  };

  obj = {
    subdivision: [],
    PropertyObj: [],
    SubPropertyObj: [],
    Cityobj: [],
    Companyobj: [],
    Stateobj: [],
    Workgroup: [],
  };

  filtered = {
    filterBySubdivisionFiltered: null,
    filterByProperty: null,
    filterBySubProperty: null,
    filterByCityFiltered: null,
    filterByCompanyFiltered: null,
    filterByStateFiltered: null,
    filterByWorkGroup: null,
  };
  matchCompanyDetails: any = {};

  checkcompany() {
    if (!this.CompanyId) {
      this.tostre.error("Please first select a Company.", "", {
        positionClass: "toast-top-right",
      });
      this.route.navigate([
        "products/administration/organizationmanagement/companies",
      ]);
      return false;
    }
    if (this.CompanyId && !this.companyDetail.IsActive) {
      // Swal.fire({
      //   text: "Selected company is inactive. Please select an active company",
      // });
      this.showInvalid(
        "Selected company is inactive. Please select an active company"
      );
      this.route.navigate([
        "products/administration/organizationmanagement/companies",
      ]);
      return false;
    }
    if (this.CompanyId && this.companyDetail.IsArchive) {
      Swal.fire({
        text: "Selected company is archived. Please select an active company",
      });
      this.route.navigate([
        "products/administration/organizationmanagement/companies",
      ]);
      return false;
    } else {
      return true;
    }
  }

  ngOnInit() {
    this.storage.removeData("justCreated");

    if (this.checkcompany()) {
      this.GetUserProfileByCompanyId(0);
      this.GetpositionTitleByCompanyId(0);
      this.GetProperty();
      this.GetCompany();
      this.GetCountry();

      // this.GetCompanySubdivision();
      if (this.CompanyId) {
        // const forbod={
        //   CompanyId:this.CompanyId
        // }

        /**
         * for company selection term
         */
        this.gettingCompanyInfo(this.companyDetail);
        /**
         * end
         */

        this.GetpositionTitleByCompanyId(this.CompanyId);
        this.GetUserProfileByCompanyId(this.CompanyId);

        // this.formControlobj.filterByCompanySearch.setValue(
        //   this.companynameCheck
        // );
        //   this.sendingEmployeeData();
      }
    } else {
    }
  }

  ngAfterViewInit() {
    this.usersearch.get("LastName").valueChanges.subscribe((elem) => {
      this.usersearch.value.LastName = elem;
      this.SearchUserList(this.usersearch.value);
    });
    this.usersearch.get("Name").valueChanges.subscribe((elem) => {
      this.usersearch.value.Name = elem;
      this.SearchUserList(this.usersearch.value);
    });
    this.usersearch.get("Email").valueChanges.subscribe((elem) => {
      this.usersearch.value.Email = elem;
      this.SearchUserList(this.usersearch.value);
    });
    this.usersearch.get("UserID").valueChanges.subscribe((elem) => {
      this.usersearch.value.UserID = elem;
      this.SearchUserList(this.usersearch.value);
    });
  }
  /**
   * getting selected company value
   */
  enableCross = true;
  enableCrossSub = true;
  gettingCompanyInfo(obj) {
    const userIdsBased = this.storage.getData("UserData");
    const parsed = JSON.parse(userIdsBased || "{}");

    //  check parentID -> Obj, is 0, if 0 then it is Company.

    if (obj.ParentID == 0) {
      // set name in company Input Bar
      this.matchCompanyDetails = obj;
      this.formControlobj.filterByCompanySearch.setValue(obj.CompanyName);
      /** return company id only */
      // this.GetUserListAll({ CompanyId: obj.CompanyID });
      this.SearchUserList(this.usersearch.value , true)
      this.GetCompanySubdivision(obj.CompanyID);
      this.GetWorkgroupbyCompanyid(obj.CompanyID);

      this.GetUserProfileByCompanyId(this.CompanyId);
      this.GetpositionTitleByCompanyId(0);
      let userId = this.storage.getData("UserID");
      this.user
        .GetUserSpacialPermission({
          UserID: userId,
          ApplyON: "OM",
        })
        .subscribe((elem) => {
          let obj = elem.GetUserSpacialPermission;

          if (parsed[0].ProfileID == 1) {
            if (Array.isArray(obj)) {
              if (obj[0].PermissionIds == "2") {
                this.enableCross = false;
                this.enableCrossSub = false;
                this.formControlobj.filterByCompanySearch.disable();
                this.formControlobj.filterBysubdivisionSearch.disable();
              }
              if (obj[0].PermissionIds == "3") {
                this.enableCross = false;

                this.formControlobj.filterByCompanySearch.disable();
                // this.formControlobj.filterBysubdivisionSearch.disable();
              }
              // if (obj[0].PermissionIds == "2") {
              //   this.enableCross = false;
              //   this.formControlobj.filterByCompanySearch.disable();
              // }
            }
          } else {
            this.enableCross = false;
            this.enableCrossSub = false;
            this.formControlobj.filterByCompanySearch.disable();
            this.formControlobj.filterBysubdivisionSearch.disable();
          }
        });
      // return {
      //   CompanyId: obj.CompanyID,
      // };
    } else {
      //** if parent !0 then it is sub Division and other division */

      /** then find parent first and set it input check box then hit company because if obs$ not
       * resolved first then parent finding will return undefined
       */
      /** updated  */
      this.user
        .GetCompany({ IsCompanyORSubdivision: 0 })
        .subscribe((res: any) => {
          //** Root company List */
          const companyList = res.ComapnyList;

          if (!companyList.length) {
            // return;
          }

          // let companyObj = companyList.find(
          //   (company) => company.CompanyID == obj.RootCompanyID
          // );

          /** company name id set */
          this.formControlobj.filterByCompanySearch.setValue(obj.ParentName);

          // set Company sub - division A/C to Root Company id

          this.GetCompanySubdivision(obj.RootCompanyID);
          /** sub division name set there */
          this.formControlobj.filterBysubdivisionSearch.setValue(
            obj.CompanyName
          );

          this.CompanyId = obj.RootCompanyID;

          this.matchCompanyDetails = obj;

          // this.SubCompanyHeader =
          //   "This is a Company Subdivision of Company : " +
          //   // opt.CompanyName +
          //   this.matchCompanyDetails.CompanyName +
          //   " - " +
          //   // opt.CompanyIndentNumber;
          //   this.matchCompanyDetails.CompanyIndentNumber;
          this.obj.Companyobj = res.ComapnyList;
          this.initiate(
            "filterByCompanyFiltered",
            "Companyobj",
            "CompanyName",
            "filterByCompanySearch"
          );
          this.subDivisionCompanyID = obj.CompanyID;
          // this.GetUserListAll({
          //   // CompanyId: obj.RootCompanyID,
          //   CompanySubDivisionId: obj.CompanyID,
          // });
          this.GetUserProfileByCompanyId(this.CompanyId);
          this.GetWorkgroupbyCompanyid(obj.CompanyID);
          this.GetpositionTitleByCompanyId(0);
          this.SearchUserList(this.usersearch.value , true)
          let userId = this.storage.getData("UserID");
          this.user
            .GetUserSpacialPermission({
              UserID: userId,
              ApplyON: "OM",
            })
            .subscribe((elem) => {
              let obj = elem.GetUserSpacialPermission;
              if (parsed[0].ProfileID == 1) {
                if (Array.isArray(obj)) {
                  if (obj[0].PermissionIds == "2") {
                    this.enableCross = false;
                    this.enableCrossSub = false;
                    this.formControlobj.filterByCompanySearch.disable();
                    this.formControlobj.filterBysubdivisionSearch.disable();
                  }
                  if (obj[0].PermissionIds == "3") {
                    this.enableCross = false;

                    this.formControlobj.filterByCompanySearch.disable();
                    // this.formControlobj.filterBysubdivisionSearch.disable();
                  }
                }
              } else {
                this.enableCross = false;
                this.enableCrossSub = false;
                this.formControlobj.filterByCompanySearch.disable();
                this.formControlobj.filterBysubdivisionSearch.disable();
              }
            });
        });
    }
  }
  /**
   * receive Event of fetched data for user list to use in other purpose like -> download excel etc.
   */
  receiveEvent(event) {
    this.UserList = event;
    this.downloadToExcels = this.UserList;
    this.Length = event.length;
    if (!this.UserList.length) {
      this.NoLength = true;
    } else {
      this.NoLength = false;
    }
  }
  /**
   * end
   */
  // sendingEmployeeData() {
  //   this.user.changeMessage(this.searchEmployeeID);
  // }

  GetUserListAll(value) {
    this.selected = "";
    this.ActiveInactive = "";
    // this.showuser=true;

    this.selectedlist = "";

    // const pbody = {
    //   CompanyId: this.CompanyId,
    // };
    const pbody = {
      LastName: (value.LastName || "").trim(),
      FirstName: (value.Name || "").trim(),
      Email: !(value.Email || "").trim() ? null : (value.Email || "").trim(),
      LoginUserId: value.UserID,
      Country: this.cid,
      State: this.sid,
      City: !this.CityName ? null : this.CityName,
      PositionTitle: !this.PositionTitlevalue ? null : this.PositionTitlevalue,
      ProfileId: this.ProfileIDvalue,
      WorkGroupName: !this.WorkGroupNameValue ? null : +this.WorkGroupNameValue,
      CompanyId: this.subdivisionName ? null : +this.CompanyId,
      PropertyId: this.PropertyId,
      SubPropertyId: this.SubPropertyId,
      CompanySubDivisionId: this.subdivisionName
        ? this.subDivisionCompanyID
        : null,
    };
    /**
     * this code send to child and child will fetch data table
     */
    this.parentmessage = pbody;
    /**
     * end
     */
    // this.user.GetUserListFilter(pbody).subscribe((res) => {
    //   this.UserList = res.GetUserList;
    //   this.downloadToExcels = this.UserList;
    //   this.parentmessage = this.UserList;
    //   this.Length = res.GetUserList.length;
    //   if (res.GetUserList.length == 0) {
    //     this.NoLength = true;
    //   } else {
    //     this.NoLength = false;
    //   }
    // });
  }
  selected = "1";
  toggleChange(event) {
    let toggle = event.source;
    if (toggle) {
      let group = toggle.buttonToggleGroup.value;
      
        console.log(group)
        this.ActiveInactive = group;
    
    }
  }

  GetUserListFilterBy(d) {
    this.selectedlist = d;
    // const pbody = {
    //   ShortFilter: d,
    //   CompanyId: this.CompanyId,
    // };
    let pbody = {};

    if (this.subdivisionName) {
      pbody = {
        ShortFilter: d,
        CompanyId: null,
        CompanySubDivisionId: this.subDivisionCompanyID,
      };
    } else {
      pbody = {
        ShortFilter: d,
        CompanyId: this.CompanyId,
      };
    }

    this.parentmessage = pbody;
    // this.user.GetUserListFilter(pbody).subscribe((res) => {
    //   this.UserList = res.GetUserList;
    //   this.downloadToExcels = this.UserList;
    //   this.parentmessage = this.UserList;
    //   this.Length = res.GetUserList.length;
    //   if (res.GetUserList.length == 0) {
    //     this.NoLength = true;
    //   } else {
    //     this.NoLength = false;
    //   }
    // });
  }

  GetUserListFilterByNumeric() {
    this.selectedlist = "[0-9]";

    // CompanyId: this.subdivisionName ? null : +this.CompanyId,
    // PropertyId: this.PropertyId,
    // SubPropertyId: this.SubPropertyId,
    // CompanySubDivisionId: this.subdivisionName
    //   ? this.subDivisionCompanyID
    //   : null,
    // const pbody = {
    //   ShortFilter: "[0-9]",
    //   // CompanyId: this.CompanyId,
    // };
    let pbody = {};

    if (this.subdivisionName) {
      pbody = {
        ShortFilter: "[0-9]",
        CompanyId: null,
        CompanySubDivisionId: this.subDivisionCompanyID,
      };
    } else {
      pbody = {
        ShortFilter: "[0-9]",
        CompanyId: this.CompanyId,
      };
    }
    // Object.defineProperty(pbody ,  // CompanyId: this.subdivisionName ? null : +this.CompanyId, , {
    //   value :
    // })
    this.parentmessage = pbody;
    // this.user.GetUserListFilter(pbody).subscribe((res) => {
    //   this.UserList = res.GetUserList;
    //   this.downloadToExcels = this.UserList;
    //   this.parentmessage = this.UserList;
    //   this.Length = res.GetUserList.length;
    //   if (res.GetUserList.length == 0) {
    //     this.NoLength = true;
    //   } else {
    //     this.NoLength = false;
    //   }
    // });
  }

  edit(d) {
    this.id = d;
    var myurl = `/products/administration/organizationmanagement/addusers/${this.id}`;
    this.route.navigateByUrl(myurl).then((e) => {
      if (e) {
      } else {
      }
    });
  }

  autoSearchUserList(value, ev) {
    //
    this.selectedlist = "";

    if (ev.length > 0 || ev.length == 0) {
      this.SearchUserList(value);
    } else {
    }
  }

  async SearchUserList(value: any, firstTime?:any) {
    this.selectedlist = "";
    // this.showuser=true;
    /** check for single to set the property of user filter accroding */
    if (firstTime) {
      let cId
      if (this.subdivisionName) {
        cId = this.subDivisionCompanyID;
      }
      let data = {
        CompanyID: cId ? cId : +this.CompanyId,
      };

      const propertyCheck = await this.user.GetpropertyByCompanyID(data).toPromise()

      console.log(propertyCheck)

      let propertyObject = (propertyCheck || {}).getPropertyResponse
      // propertyObject = [propertyObject[0]]
      if ((propertyObject || []).length === 1) {
        /** write if needed */
        this.PropertyId = (propertyObject || [])[0].PropertyID
      }
    }
    let pbody: any = {
      LastName: value.LastName.trim(),
      FirstName: value.Name.trim(),
      Email: !value.Email.trim() ? null : value.Email.trim(),
      LoginUserId: value.UserID,
      Country: this.cid,
      State: this.sid || null,
      City: !this.CityName ? null : this.CityName,
      PositionTitle: !this.PositionTitlevalue ? null : this.PositionTitlevalue,
      ProfileId: this.ProfileIDvalue || null,
      WorkGroupName: !this.WorkGroupNameValue ? null : +this.WorkGroupNameValue,
      CompanyId: this.subdivisionName ? null : +this.CompanyId,
      PropertyId: this.PropertyId || null,
      SubPropertyId: this.SubPropertyId || null,
      CompanySubDivisionId: this.subdivisionName
        ? this.subDivisionCompanyID
        : null,
    };

    console.log(pbody)

    // this.user.GetUserListFilter(pbody).subscribe((res) => {
    //   if (res.GetUserList.length == 0) {
    //     this.NoLength = true;
    //   } else {
    //     this.NoLength = false;
    //   }
    //   this.UserList = res.GetUserList;
    //   this.downloadToExcels = this.UserList;
    //   this.Length = res.GetUserList.length;
    //   this.parentmessage = this.UserList;
    //   // pbody.WorkGroupName = "";
    // });
    this.parentmessage = pbody;
  }

  GetUserProfileByCompanyId(d) {
    if (this.usersearch) {
      this.usersearch.controls["ProfileId"].setValue("");
    } else {
    }
    this.ProfileIDvalue = null;
    let pbody = {};

    if (this.subdivisionName) {
      pbody = {
        CompanyId: this.subDivisionCompanyID,
      };
    } else {
      pbody = {
        CompanyId: this.CompanyId,
      };
    }
    this.user.GetUserProfile(pbody).subscribe((res) => {
      this.UserProfile = res.UserProfileByCompanyId;
      this.UserProfile.sort((x, y) =>
        x.ProfileName !== y.ProfileName
          ? x.ProfileName < y.ProfileName
            ? -1
            : 1
          : 0
      );
    });
  }

  GetCountry() {
    this.user.GetCountry().subscribe((res) => {
      this.ContryList = res.getCountry;
      this.ContryList.forEach((element) => {
        if (element.IsSelected == 1) {
          this.usersearch.patchValue({ Country: element.CountryName });
          this.cid = element.CountryID;
          this.GetState(element.CountryID);
          // this.GetCity1(element.CountryID, 0);
        }
      });
    });
  }

  GetWorkgroupbyCompanyid(d: any) {
    this.usersearch.controls["WorkGroupName"].setValue("");

    this.WorkGroupNameValue = "";
    // const pbody = {
    //   CompanyID: +d,
    // };
    let pbody = {};
    // debugger;
    if (this.subdivisionName) {
      pbody = {
        CompanyID: this.subDivisionCompanyID,
      };
    } else {
      pbody = {
        CompanyID: this.CompanyId,
      };
    }
    this.user.GetWorkgroup(pbody).subscribe((res) => {
      //this.Workgroup = res.Workgroup;
      this.obj.Workgroup = res.Workgroup;
      this.initiate(
        "filterByWorkGroup",
        "Workgroup",
        "WorkGroupName",
        "WorkGroupName"
      );
    });
  }

  GetWorkGroupName(WorkGroupID) {
    this.WorkGroupNameValue = WorkGroupID;
    this.initiate(
      "filterByWorkGroup",
      "Workgroup",
      "WorkGroupName",
      "WorkGroupName"
    );
  }

  GetpositionTitleByCompanyId(d) {
    if (this.usersearch) {
      this.usersearch.controls["PositionTitle"].setValue("");
    } else {
    }
    this.PositionTitlevalue = null;
    let pbody = {};
    if (this.subdivisionName) {
      pbody = {
        CompanyId: this.subDivisionCompanyID || 0,
      };
    } else {
      pbody = {
        CompanyId: this.CompanyId || 0,
      };
    }
    this.user.GetpositionTitle(pbody).subscribe((res) => {
      this.PositionTitle = res.GetpositionTitle;
    });
  }

  private _filter(value: any, keyName: string, filterName: string): string[] {
    if (value == null || value == undefined) {
    } else {
      const filterValue = value.toLowerCase();
      return this.obj[keyName].filter((option) =>
        option[filterName].toLowerCase().includes(filterValue)
      );
    }
  }

  initiate(keyNameFilter, listFromServer, keyNameObj, formControlKeyName) {
    this.filtered[keyNameFilter] = this.formControlobj[
      formControlKeyName
    ].valueChanges.pipe(
      startWith(""),
      map((value) => {
        let list = [];
        if (this.inteliTypeFilters.includes(formControlKeyName)) {
          list =
            String(value).length >= 0
              ? this._filter(value, listFromServer, keyNameObj)
              : [];

          // if (list.length == 1 && list[0][keyNameObj] == value) {
          //   list = [];
          // }
          //
        } else {
          list = this._filter(value, listFromServer, keyNameObj);
        }

        return list;
      })
    );
  }

  GetState(cd) {
    if (this.usersearch) {
      //  this.usersearch.controls['State'].setValue('');
    } else {
    }
    this.usersearch.patchValue({ State: "" });
    this.sid = 0;
    this.cid = parseInt(cd);
    const pbody = {
      countryId: parseInt(cd),
    };

    this.user.GetState(pbody).subscribe((res) => {
      this.obj.Stateobj = res.getState;
      this.initiate(
        "filterByStateFiltered",
        "Stateobj",
        "StateName",
        "filterByStateSearch"
      );

      this.CityList = [];
      this.formControlobj.filterByCitySearch.reset();
      this.CityName = "";
    });
  }

  GetCompany() {
    this.user
      .GetCompany({ IsCompanyORSubdivision: 0 })
      .subscribe((res: any) => {
        this.obj.Companyobj = res.ComapnyList;

        this.obj.Companyobj.sort((x, y) =>
          x.CompanyName !== y.CompanyName
            ? x.CompanyName < y.CompanyName
              ? -1
              : 1
            : 0
        );
        this.initiate(
          "filterByCompanyFiltered",
          "Companyobj",
          "CompanyName",
          "filterByCompanySearch"
        );
      });
  }

  GetCompanySubdivision(id, event?: any) {
    if (event) {
      if (!event.isUserInput) {
        return;
      }
    }
    this.user.GetCompanySubdivision({ CompanyID: id }).subscribe((res) => {
      // if (!res.data.getSubDivisionByCompany.length) {
      // this.formControlobj.filterBysubdivisionSearch.disable();
      // let userId = this.storage.getData("UserID");
      // this.user
      //   .GetUserSpacialPermission({
      //     UserID: userId,
      //     ApplyON: "OM",
      //   })
      //   .subscribe((elem) => {
      //     let obj = elem.GetUserSpacialPermission;
      //     if (Array.isArray(obj)) {
      //       if (obj[0].PermissionIds == "2") {
      //         this.formControlobj.filterByCompanySearch.disable();
      //         this.formControlobj.filterBysubdivisionSearch.disable();
      //       }
      //     }
      //   });
      // }

      // this.obj.subdivision = res.CompanySubdivisionList;
      this.obj.subdivision = res.data.getSubDivisionByCompany;
      console.log("asd", this.obj.subdivision);
      this.obj.subdivision.sort((x, y) =>
        x.CompanyName !== y.CompanyName
          ? x.CompanyName < y.CompanyName
            ? -1
            : 1
          : 0
      );
      this.initiate(
        "filterBySubdivisionFiltered",
        "subdivision",
        "CompanyName",
        "filterBysubdivisionSearch"
      );
    });
  }

  GetProperty(cId?: any, event?: any) {
    // CompanyId: this.subdivisionName ? null : +this.CompanyId,
    // PropertyId: this.PropertyId,
    // SubPropertyId: this.SubPropertyId,
    // CompanySubDivisionId: this.subdivisionName
    //   ? this.subDivisionCompanyID
    //   : null,
    if (this.subdivisionName) {
      cId = this.subDivisionCompanyID;
    }
    let data = {
      CompanyID: cId ? cId : +this.CompanyId,
    };

    this.user.GetpropertyByCompanyID(data).subscribe((res) => {
      this.obj.PropertyObj = res.getPropertyResponse || [];
      // this.obj.PropertyObj = [res.getPropertyResponse[0]];
      
      if (this.obj.PropertyObj.length === 1 && !event) {
        this.formControlobj.filterByPropertySearch.setValue(
          (this.obj.PropertyObj[0] || {}).PropertyName
        );
        this.getSubdivisionbyPropertyId(
          (this.obj.PropertyObj[0] || {}).PropertyID
        );
        this.PropertyId = (this.obj.PropertyObj[0] || {}).PropertyID;
        // this.SearchUserList(this.usersearch.value);
      }
      this.obj.PropertyObj.sort((x, y) =>
        x.PropertyName !== y.PropertyName
          ? x.PropertyName < y.PropertyName
            ? -1
            : 1
          : 0
      );

      this.initiate(
        "filterByProperty",
        "PropertyObj",
        "PropertyName",
        "filterByPropertySearch"
      );
    });
  }

  getSubdivisionbyPropertyId(d) {
    const pbody = {
      PropertyId: !d ? null : d,
    };
    this.user.getSubdivisionbyPropertyId(pbody).subscribe((res) => {
      if (res.SubdivisionbyPropertyId.length != 0) {
        this.obj.SubPropertyObj = res.SubdivisionbyPropertyId;
        this.obj.SubPropertyObj.sort((x, y) =>
          x.PropertyName !== y.PropertyName
            ? x.PropertyName < y.PropertyName
              ? -1
              : 1
            : 0
        );
        this.initiate(
          "filterBySubProperty",
          "SubPropertyObj",
          "PropertyName",
          "filterBySubPropertySearch"
        );
      } else {
        this.filtered.filterBySubProperty = null;
      }
    });
  }

  /* get city   */
  GetCity1(atr, stateID) {
    const body = {
      countryId: this.cid,
      stateId: stateID,
    };
    this.user.GetCityListforAddUser(body).subscribe((res: any) => {
      this.obj.Cityobj = res.getCity;

      this.initiate(
        "filterByCityFiltered",
        "Cityobj",
        "CityName",
        "filterByCitySearch"
      );
    });
  }
  GetStateid(d, ref) {
    this.sid = parseInt(d);
    this.initiate(
      "filterByStateFiltered",
      "Stateobj",
      "StateName",
      "filterByStateSearch"
    );
    ref.blur();
  }
  // GetCity(d) {
  //   this.formControlobj.filterByCitySearch.reset();
  //   this.CityName="";
  // this.sid=parseInt(d);
  // if(this.cid){

  // }else{
  //   this.cid=0;
  // }
  //   const pbody = {
  //     countryId:this.cid,
  //     stateId: parseInt(d)
  //   }
  //   this.user.GetCity(pbody).subscribe(res => {
  //     this.obj.Cityobj = res.getCity;
  //     this.initiate(
  //       "filterByCityFiltered",
  //       "Cityobj",
  //       "CityName",
  //       "filterByCitySearch",

  //     );
  //   });
  // }
  clearCachedCity() {
    this.filtered["filterByCityFiltered"] = this.formControlobj[
      "filterByCitySearch"
    ].valueChanges.pipe(
      startWith(""),
      map((value) => {
        let list = [];
        if (this.inteliTypeFilters.includes("CityName")) {
          list =
            String(value).length >= 1
              ? this._filter("", "Cityobj", "CityName")
              : [];
          if (list.length == 1 && list[0]["CityName"] == value) {
            list = [];
          }
        } else {
          list = this._filter("", "Cityobj", "CityName");
        }

        return list;
      })
    );
  }

  clearCached() {
    this.initiate(
      "filterByStateFiltered",
      "Stateobj",
      "StateName",
      "filterByStateSearch"
    );
    // ref.blur();
  }

  setSubdivision(key, optKey, opt, evt) {
    if (!evt.isUserInput) return;
    this.subdivisionName = +opt.CompanyId;

    this.CompanyNameHeader = opt.CompanyName + " - " + opt.CompanyIndentNumber;

    this.SubCompanyHeader =
      "This is a Company Subdivision of Company : " +
      // opt.CompanyName +
      this.matchCompanyDetails.CompanyName +
      " - " +
      // opt.CompanyIndentNumber;
      this.matchCompanyDetails.CompanyIndentNumber;

    if (this.subdivisionName) {
      this.subDivisionCompanyID = this.subdivisionName;
    }
    this.SearchUserList(this.usersearch.value);

    this.initiate(
      "filterBySubdivisionFiltered",
      "subdivision",
      "CompanyName",
      "filterBysubdivisionSearch"
    );
    this.GetWorkgroupbyCompanyid(opt.CompanyId);
  }
  setPropertyName(key, optKey, opt, evt) {
    if (!evt.isUserInput) return;
    // this.clearSubProperty();
    this.formControlobj.filterBySubPropertySearch.patchValue("");
    this.PropertyId = opt.PropertyID;
    this.initiate(
      "filterByProperty",
      "PropertyObj",
      "PropertyName",
      "filterByPropertySearch"
    );
  }
  setSubPropertyName(key, optKey, opt, evt) {
    if (!evt.isUserInput) return;
    this.SubPropertyId = opt.PropertyID;
  }
  setCityName(key, optKey, opt, evt) {
    if (!evt.isUserInput) return;
    this.CityName = opt.CityName;
  }

  blurCity(val) {
    val.blur();
  }
  setCompanyName(key, optKey, opt, evt) {
    if (!evt.isUserInput) return;

    this.CompanyId = opt.CompanyID;
    this.companyDetail = opt;
    this.subdivisionName = null;
    this.formControlobj.filterBysubdivisionSearch.setValue("");
    this.CompanyNameHeader = opt.CompanyName + " - " + opt.CompanyIndentNumber;

    this.matchCompanyDetails = opt;
    this.SubCompanyHeader = "";
    this.initiate(
      "filterByCompanyFiltered",
      "Companyobj",
      "CompanyName",
      "filterByCompanySearch"
    );
    // this.SearchUserList(this.usersearch.value);
    this.GetProperty();
    // this.companynameCheck=opt.CompanyName;
  }

  GetProfileName(ProfileID, val: any) {
    this.ProfileIDvalue = ProfileID;
    val.blur();

    this.SearchUserList(this.usersearch.value);
  }

  GetPositionTitle(PositionTitleID) {
    this.PositionTitlevalue = PositionTitleID;
  }

  //Clearing all the form Fields
  clearAllFields() {
    this.usersearch.get("ProfileId").setValue("");
    this.usersearch.get("PositionTitle").setValue("");
    this.formControlobj.filterBysubdivisionSearch.setValue("");
    this.formControlobj.filterByPropertySearch.setValue("");
    this.formControlobj.filterBySubPropertySearch.setValue("");
    // this.obj.PropertyObj = []
    // this.formControlobj.filterByCitySearch.setValue("");
    // this.formControlobj.filterByStateSearch.setValue("");
    this.formControlobj.WorkGroupName.setValue("");
    this.PropertyId = null
    // this.formControlobj.filterByPropertySearch.reset();
    // this.formControlobj.filterBySubPropertySearch.reset();
    // this.subdivisionName = null
  }

  clearSubProperty() {
    this.formControlobj.filterBySubPropertySearch.patchValue("");
    this.getSubdivisionbyPropertyId(0);
    // this.filtered.filterBySubProperty = [];
  }

  onkeyUpSelection(d, c) {
    if (d == "CompanyID") {
      this.CompanyNameHeader = "";
      this.subdivisionName = null;
      this.clearAllFields();
      // this.formControlobj.filterBySubPropertySearch.reset();
    }
    if (d == "Subdivision") {
      this.SubCompanyHeader = "";
      this.subdivisionName = undefined;
      const brrrok: any = JSON.parse(
        this.storage.getData("CompanyDetails") || "{}"
      );

      this.CompanyNameHeader =
        brrrok.ParentCompanyName + " - " + brrrok.ParentCompanyIndentNumber;
      this.clearAllFields();
      this.GetUserProfileByCompanyId(null);
    }

    if ("CompanyID" == d) {
      this.CompanyId = null;
      this.Workgroup = null;
      this.WorkGroupNameValue = "";

      this.UserProfile = null;
      this.ProfileIDvalue = "";

      this.PositionTitle = null;
      this.PositionTitlevalue = "";

      // this.GetProperty();
    } else if ("WorkGroupID" == d) {
      this.WorkGroupNameValue = "";
    } else if ("Subdivision" == d) {
      this.subdivisionName = "";
    } else if ("ProfileName" == d) {
      this.ProfileIDvalue = "";
    } else if ("PositionTitle" == d) {
      this.PositionTitlevalue = "";
    } else if ("Property" == d) {
      this.PropertyId = "";
    } else if ("Country" == d) {
      this.cid = null;
      this.usersearch.patchValue({ State: "", City: "" });
      this.formControlobj.filterByStateSearch.setValue("");
    } else if ("State" == d) {
      this.sid = null;
      // this.CityName ='';
      // this.City=[];

      // this.formControlobj.filterByCitySearch.setValue('');
    } else if ("City" == d) {
      this.CityName = "";
    } else {
    }
    this.GetProperty(null, true);

    this.SearchUserList(c);
    this.WorkGroupNameValue = "";
    this.formControlobj.WorkGroupName.setValue("");
    this.GetWorkgroupbyCompanyid(this.CompanyId);
  }
  /* only number and character */
  isNumeric(keyCode) {
    var iKeyCode = keyCode.which ? keyCode.which : keyCode.keyCode;
    if (
      (iKeyCode >= 48 && iKeyCode <= 57) ||
      (iKeyCode >= 97 && iKeyCode <= 122) ||
      (iKeyCode >= 65 && iKeyCode <= 90)
    )
      return true;

    return false;
  }
  /* download data into the Excel */
  downloadToExcel() {
    if (this.fathermessage) {
      this.downloadToExcels = this.fathermessage;
    } else if (this.fathermessage) {
      this.downloadToExcel = this.userFormate;
    } else {
    }
    this.user.exportToExecl(
      this.downloadToExcels,
      this.user.generateFileName()
    );
  }

  //   resetsearch(){
  //     this.advanvces = false;

  //     this.usersearch.reset(
  //       {
  //         LastName: '',
  //         Name: '',
  //         Email: '',
  //         UserID: '',
  //         Country: '',
  //         City: '',
  //         State: '',
  //         PositionTitle: '',
  //         ProfileId: '',
  //         WorkGroupName: '',
  //         Company: '',
  //         PropertyId: '',
  //         subdivision:'',
  //         PropertyObj: '',
  //         Cityobj: '',
  //         Companyobj: '',
  //       }
  //     );

  // this.formControlobj.filterBysubdivisionSearch.reset();
  //     this.formControlobj.filterByPropertySearch.reset();
  //     this.formControlobj.filterByCitySearch.reset();
  //     this.formControlobj.filterByCompanySearch.reset();
  //     this.PositionTitlevalue= "";
  //      this.PositionTitlevalue= "";
  //      this.ProfileIDvalue= "";
  //      this.WorkGroupNameValue= "";
  //      this.CompanyId= "";
  //     this.PropertyId= "";
  //      this.subdivisionName= "";
  //      this.cid=null;
  //      this.sid=null;
  //      this.CityName=""
  //      this.PositionTitle =null;
  //      this.UserProfile =null;
  //      this.Workgroup =null;
  //     this.usersearch.controls['WorkGroupName'].setValue('');
  //     this.usersearch.controls['ProfileId'].setValue('');
  //     this.usersearch.controls['PositionTitle'].setValue('');
  //     this.usersearch.controls['Company'].setValue('');
  //     this.usersearch.controls['PropertyId'].setValue('');
  //     this.usersearch.controls['subdivision'].setValue('');
  //     this.usersearch.controls['City'].setValue('');
  //     this.GetProperty();
  //     this.GetCompany();
  //     this.GetCountry();
  //     this.GetCompanySubdivision();
  //     const cd=0
  //     this.GetState(cd);
  //   }

  uploadedFile(event) {
    this.fileUploaded = event.target.files[0];
    if (
      event.target.files[0].type !==
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" &&
      event.target.files[0].name.split(".").lastIndexOf("xlsx") < 0
    ) {
      Swal.fire("This not excel file");
      return;
    }
    this.readExcel();
  }

  async readExcel() {
    let readFile = new FileReader();

    readFile.onload = (e) => {
      this.storeData = readFile.result;

      var data = new Uint8Array(this.storeData);

      var arr = new Array();

      for (var i = 0; i != data.length; ++i)
        arr[i] = String.fromCharCode(data[i]);
      var bstr = arr.join("");

      var workbook = XLSX.read(bstr, { type: "binary" });

      var first_sheet_name = workbook.SheetNames[1];

      this.worksheet = workbook.Sheets[first_sheet_name];

      var range = XLSX.utils.decode_range(this.worksheet["!ref"]);
      range.s.r = 2; // <-- zero-indexed, so setting to 1 will skip row 0
      this.worksheet["!ref"] = XLSX.utils.encode_range(range);

      this.readAsJson(this.loginUserid);
    };

    readFile.readAsArrayBuffer(this.fileUploaded);
  }

  // Upload Excel End

  /** Read As Json */

  readAsJson(loginUserid) {
    this.jsonData = XLSX.utils.sheet_to_json(this.worksheet, { raw: false });

    //this.jsonData = JSON.stringify(this.jsonData);

    var arrofobj = (this.UserImportList = this.jsonData);

    var result = arrofobj.map(function (el) {
      var o = Object.assign({}, el);

      o.Salutation = o["Prefix"];
      if (o.Salutation == undefined) {
        o.Salutation = " ";
      }
      o.FirstName = o["First Name"];
      if (o.FirstName == undefined) {
        o.FirstName = " ";
      }
      o.MiddleName = o["Middle Name"];
      if (o.MiddleName == undefined) {
        o.MiddleName = " ";
      }
      o.LastName = o["Last Name"];
      if (o.LastName == undefined) {
        o.LastName = " ";
      }
      o.SocialSecurityNumber = o["NI Number"];
      if (o.SocialSecurityNumber == undefined) {
        o.SocialSecurityNumber = " ";
      }
      if (o.Email == undefined) {
        o.Email = " ";
      }
      o.PhoneNumber = o["Phone Number (000-000-0000)"];
      if (
        o.PhoneNumber == undefined ||
        o.PhoneNumber === "" ||
        o.PhoneNumber === ""
      ) {
        o.PhoneNumber = null;
      }
      o.Address = o["Address"];
      if (o.Address == undefined) {
        o.Address = " ";
      }
      o.CountryName = o["CountryName"];
      if (o.CountryName == undefined) {
        o.CountryName = null;
      }
      o.StateName = o["StateName"];
      if (o.StateName == undefined) {
        o.StateName = null;
      }
      o.CityName = o["CityName"];
      if (o.CityName == undefined) {
        o.CityName = null;
      }
      o.ZipCode = o["ZipCode"];
      if (o.ZipCode == undefined) {
        o.ZipCode = " ";
      }

      o.EmployeeCode = o["User ID"];
      if (o.EmployeeCode == undefined) {
        o.EmployeeCode = " ";
      }
      o.UnitNumber = o["Unit # (Radio ID)"];
      if (o.UnitNumber == undefined) {
        o.UnitNumber = " ";
      }
      o.CompanyName = o["Company Name"];
      if (o.CompanyName == undefined) {
        o.CompanyName = " ";
      }
      o.ProfileName = o["User Profile"];
      if (o.ProfileName == undefined) {
        o.ProfileName = " ";
      }
      o.JobTitle = o["Job Title"];
      if (o.JobTitle == undefined) {
        o.JobTitle = null;
      }
      o.WorkGroupOrProperty =
        o["Is this user assigned to a specific workgroup?"];
      if (o.WorkGroupOrProperty == undefined) {
        o.WorkGroupOrProperty = null;
      }
      o.WorkGroupName = o["If yes, select specific workgroup"];
      if (o.WorkGroupName == undefined) {
        o.WorkGroupName = null;
      }
      o.PropertyOrWorkGroup =
        o["Is this user assigned to a specific property?"];
      if (o.PropertyOrWorkGroup == undefined) {
        o.PropertyOrWorkGroup = null;
      }
      o.PropertyName = o["Select Specific Property Name"];
      if (o.PropertyName == undefined) {
        o.PropertyName = " ";
      }
      o.TimeZone = o["Time Zone"];
      if (o.TimeZone == undefined) {
        o.TimeZone = null;
      }
      o.Locale = o["Language"];
      if (o.Locale == undefined) {
        o.Locale = " ";
      }
      o.IsPrimaryContact =
        o["Is this user the primary contact for property or workgroup?"];
      if (o.IsPrimaryContact == undefined) {
        o.IsPrimaryContact = " ";
      }
      o.IsRespondingOfficer = o["Is this user is a Responding Officer?"];
      if (o.IsRespondingOfficer == undefined) {
        o.IsRespondingOfficer = " ";
      }
      o.UserLogin = o["User Login"];
      if (o.UserLogin == undefined) {
        o.UserLogin = " ";
      }
      o.Password = o["Password"];
      if (o.Password == undefined) {
        o.Password = " ";
      }
      o.PasswordSalt = o[""];
      o.RealPassword = o["Password"];
      o.UserStatus = o["Status"];
      if (o.UserStatus == undefined) {
        o.UserStatus = " ";
      }
      o.Status = o["Status"];

      o.Message = "";
      o.RecNo = "1";

      return o;
    });
    let length = Object.keys(result).length;
    this.UserImport(result);
  }

  /**
   * Import User List
   *
   */

  UserImport(obj) {
    let data = [];

    let matchUser =
      Object.keys(obj[0]).includes("Prefix") &&
      Object.keys(obj[0]).includes("SocialSecurityNumber");

    if (matchUser) {
      obj.forEach(function (item, i) {
        // delete item['WorkGroupOrProperty'];

        delete item["First Name"];
        delete item["Prefix"];
        delete item["Middle Name"];
        delete item["Last Name"];
        delete item["NI Number"];
        delete item["Phone Number (000-000-0000)"];
        delete item["Employee ID"];
        delete item["Unit # (Radio ID)"];
        delete item["Company Name"];
        delete item["User Profile"];
        delete item["Job Title"];
        delete item["Is this user assigned to a specific workgroup?"];
        delete item["If yes, select specific workgroup"];
        delete item["Is this user assigned to a specific property?"];
        delete item["Select Specific Property Name"];
        delete item["Time Zone"];
        delete item[
          "Is this user the primary contact for property or workgroup?"
        ];
        delete item["Is this user is a Responding Officer?"];

        data.push(item);
      });

      this.user.userImport(data).subscribe((res) => {
        this.uploadfileList = true;
        this.showuser = false;

        this.fathermessage = res.UserImport.recordsets[0];
        this.showValid("Processed Successfully. Please check the table.");
      });
    } else {
      this.showInvalid(
        "Uploaded Excel Sheet is Invalid. Please put the right one."
      );
    }
  }

  exportUserList() {
    let data = [];
    console.log(this.UserList)
    this.UserList.forEach(function (item, i) {
      // delete item['WorkGroupOrProperty'];
      delete item["PasswordSalt"];
      delete item["RealPassword"];
      delete item["UserID"];
      delete item["LastModifyDate"];
      // delete item["LastActivatedDate"];
      // delete item["LastDeActivatedDate"];
      delete item["IsLoggedIn"];
      delete item["PropertyID"];
      delete item["Photograph"];
      delete item["CountryID"];
      delete item["City"];
      delete item["UserTransferStatus"];
      delete item["Message"];
      delete item["StateID"];
      // delete item['Status'];

      data.push(item);
    });

    // this.PatrolService.exportAsExcelFile(this.patrolzonelist, this.PatrolExcelFormt);
    this.user.exportAsExcelFile(data);
  }

  // toastr warning/success message
  showInvalid(msg) {
    this.tostre.warning(msg, "", {
      positionClass: "toast-top-right",
    });
  }

  showValid(validMsg) {
    this.tostre.success(validMsg, "", {
      positionClass: "toast-top-right",
    });
  }
}
