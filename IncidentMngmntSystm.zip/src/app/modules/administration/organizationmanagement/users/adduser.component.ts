import { Component, OnInit, Inject, Input, ViewChild } from "@angular/core";
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from "@angular/material/dialog";
import { MatSlideToggleModule } from "@angular/material/slide-toggle";
import { userService } from "./user.service";
import {
  FormBuilder,
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import Swal from "sweetalert2";
import { promise } from "protractor";
import { resolve } from "dns";
import { environment } from "../../../../../environments/environment";
import { Observable } from "rxjs";
import { startWith, map } from "rxjs/operators";
import { ToastrService } from "ngx-toastr";
import { StorageService } from "../../../../services/storage.service";
import { ModelMasterAdminComponent } from "./model-master-admin/model-master-admin.component";
import { exit } from "process";
import { DataSharingService } from "../dataSharing.service";
import { CompanyService } from "../companies/companies.service";
@Component({
  selector: "app-user-dialog",
  templateUrl: "./user-modal.component.html",
  styleUrls: ["./users.component.scss"],
  providers: [userService],
})
export class UserModalComponent implements OnInit {
  emailcheck: string;
  usercheck: string;
  imgurl: any;
  checkedOR: boolean = false;
  checkedORW: boolean = true;
  chepn = undefined;
  chewr = undefined;
  pdis: boolean;
  wris: boolean;
  pnisDisabled = false;
  wrisDisabled = false;
  selecetdFile = null;
  imageName: string;
  imageExtention: string;
  imageUrl: string | ArrayBuffer;
  imagePreview: string;
  updatavalue: Array<any>;
  submitted = false;
  UID: number;
  usersave: FormGroup;
  UserProfile: Array<any>;
  Workgroup: Array<any>;
  CompanyNames: Observable<any>;
  companynameCheck: any;
  CompanyNamesList: any;
  PropertyName: Array<any>;
  PositionTitle: Array<any>;
  TimeZoneList: Array<any>;
  LocalList: Array<any>;
  Daylightvalue: any;
  CompanyNameValue: any;
  ProfileValue: any;
  WorkGroupvalue: any;
  Propertyvalue: any;
  TimeZonevalue: any;
  Positionvalue: any;
  IsRespondingOfficer: boolean;
  IsPrimaryContact: boolean;
  companyDetail: any;
  ContryList: Array<any>;
  StateList: Array<any>;
  CityList: any;
  sc = 0;
  CountryId: any;
  StateId: any;
  restb = false;
  cencelb = false;
  showpass: any;
  Wbox: boolean = true;
  btn: string = "Add";
  btnCr = false;
  Salutations = [
    { Name: "Mr." },
    { Name: "Miss." },
    { Name: "Mrs." },
    { Name: "Ms." },
  ];
  Genders = [{ Name: "Male" }, { Name: "Female" }, { Name: "Others" }];

  Daylights = [
    { Name: "Yes", value: true },
    { Name: "No", value: false },
  ];

  Disable = true;
  color = "red";
  checked = true;
  background: "#060303";
  pageName = "Add User";

  //
  disableForMaster: any = false;
  wrkgrpBtn: any = 0;
  propertyBtn: any = 0;
  photoUploaded: any = false;
  specialPermission: any = [];

  @Input()
  disabled: boolean;
  flag: boolean = false;
  UserID: any = "";

  _phoneNumber:any = /^[0-9]{3}-[0-9]{3}-[0-9]{4}$/;

  constructor(
    @Inject(MAT_DIALOG_DATA) public duid: any,
    public tostre: ToastrService,
    public dataShare :DataSharingService,
    public Company: CompanyService,
    private route: Router,
    public dialogRef: MatDialogRef<UserModalComponent>,
    private fb: FormBuilder,
    private user: userService,
    private actroute: ActivatedRoute,
    private storage: StorageService,
    public dialog: MatDialog
  ) {
    this.usersave = this.fb.group({
      UserID: [this.UID],
      IsRespondingOfficer: [""],
      IsPrimaryContact: [""],
      Salutation: [""],
      FirstName: ["", Validators.required],
      LastName: ["", Validators.required],
      NINumber: [""],
      MiddleName: [""],
      PhoneNumber: [""],
      ZipCode: [""],
      Address: [""],
      Country: [""],
      City: [""],
      State: [""],
      Email: [null],
      Gender: [""],
      Daylight: [""],
      Photograph: [""],
      EmployeeID: [""],
      UnitID: ["", Validators.required],
      CompanyName: ["", Validators.required],
      ProfileName: ["", Validators.required],
      PositionTitle: ["", Validators.required],
      WorkGroupName: [""],
      PropertyName: [""],
      TimeZoneName: [""],
      Locale: [""],
      UserLogin: [
        "",
        [
          Validators.required,
          Validators.minLength(3),
          Validators.maxLength(50),
        ],
      ],
      Password: ["", [Validators.required, Validators.minLength(8)]],
    });

    this.companyDetail = JSON.parse(this.storage.getData("CompanyDetails"));
    if (this.companyDetail) {
      this.CompanyNameValue = this.companyDetail.CompanyID;
      this.companynameCheck = this.companyDetail.CompanyName;
    }
    if (this.CompanyNameValue) {
      this.GetUserProfileByCompanyId(this.CompanyNameValue);
      this.GetpositionTitleByCompanyId(this.CompanyNameValue);
      this.GetWorkgroupbyCompanyid(this.CompanyNameValue);
      this.getCompanyNameValue(this.CompanyNameValue);
      this.usersave.controls["CompanyName"].setValue(this.companynameCheck);
    } else {
      this.GetUserProfileByCompanyId(this.CompanyNameValue);
      this.GetpositionTitleByCompanyId(this.CompanyNameValue);
      this.GetWorkgroupbyCompanyid(this.CompanyNameValue);
      this.getCompanyNameValue(this.CompanyNameValue);
      this.usersave.controls["CompanyName"].setValue(this.companynameCheck);
    }
    this.imgurl = "";
    // this.GetWorkgroup();

    // this.GetUserProfile();

    this.UID = this.actroute.snapshot.params["UserID"];
    this.UserID = this.actroute.snapshot.params["UserID"];

    if (this.UID) {
      this.pageName = "Edit User";
      this.storage.setData("edituserid", this.UID.toString());
      this.btn = "Update";
      this.btnCr = true;
      this.restb = false;
      this.cencelb = true;
      this.Wbox = false;
      this.updateUser();
    } else {
      this.btnCr = false;
      this.cencelb = false;
      this.restb = true;
      this.flag = true;
      // this.chewr.checked=true;
      this.wris = undefined;
      this.pdis = true;
      this.checkedORW = true;
      this.Wbox = true;
    }
    this.GetCompany();
    this.GetProperty();
    // this.GetpositionTitle();
    this.GetTimeZone();
    this.GetLocale();
    this.GetCountry();
  }

  ngOnInit() {
    this.usersave.get("EmployeeID").disable();
  }

  AlphaNumeric(keyCode) {
    var iKeyCode = keyCode.which ? keyCode.which : keyCode.keyCode;
    if (
      (iKeyCode >= 48 && iKeyCode <= 57) ||
      (iKeyCode >= 97 && iKeyCode <= 122) ||
      (iKeyCode >= 65 && iKeyCode <= 90)
    )
      return true;

    return false;
  }

  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  GetDaylights(d) {
    this.Daylightvalue = d;
  }

  GetUserProfileByCompanyId(d) {
    if (this.usersave) {
      this.usersave.controls["ProfileName"].setValue("");
    } else {
    }
    this.ProfileValue = null;
    const pbody = {
      CompanyId: parseInt(d),
    };

    this.user.GetUserProfile(pbody).subscribe((res) => {
      this.UserProfile = res.UserProfileByCompanyId;
      this.UserProfile.sort((x, y) =>
        x.ProfileName !== y.ProfileName
          ? x.ProfileName < y.ProfileName
            ? -1
            : 1
          : 0
      );
    });
  }
  GetWorkgroupbyCompanyid(d) {
    this.usersave.controls["WorkGroupName"].setValue("");
    this.WorkGroupvalue = "";
    // this.WorkGroupNameValue='';
    const pbody = {
      CompanyID: parseInt(d),
    };
    this.user.GetWorkgroup(pbody).subscribe((res) => {
      this.Workgroup = res.Workgroup;
    });
  }
  GetCompany() {
    // this.user.GetCompany({ IsCompanyORSubdivision: 0 }).subscribe((res) => {
    //   this.CompanyNamesList = res.ComapnyList;
    // });
    this.user
      .GetCompanyByUser({ UserId: this.storage.getData("UserID") })
      .subscribe((elem: any) => {
        this.CompanyNamesList = elem.companyList;
      });
  }

  private _filter(value: any): any[] {
    const filterValue = this._normalizeValue(value);
    return this.CompanyNamesList.filter((street) =>
      this._normalizeValue(street).includes(filterValue)
    );
  }

  private _normalizeValue(value: any): any {
    return value.toLowerCase().replace(/\s/g, "");
  }

  GetProperty(obj?: any, event?: any) {
    if (event) {
      if (!event.isUserInput) {
        return;
      }
    }

    if (obj) {
      this.CompanyNameValue = obj.CompanyID;
    }
    this.usersave.patchValue({ PropertyName: "" });
    let data = {
      CompanyID: +this.CompanyNameValue,
    };
    this.user.GetpropertyByCompanyID(data).subscribe((res) => {
      this.PropertyName = res.getPropertyResponse;
    });
  }

  GetpositionTitleByCompanyId(d) {
    if (this.usersave) {
      this.usersave.controls["PositionTitle"].setValue("");
    } else {
    }
    this.Positionvalue = null;
    const pbody = {
      CompanyId: parseInt(d),
    };
    this.user.GetpositionTitle(pbody).subscribe((res) => {
      this.PositionTitle = res.GetpositionTitle;
    });
  }

  GetTimeZone() {
    this.user.GetTimeZone().subscribe((res) => {
      this.TimeZoneList = res.GetTimeZone;
    });
  }

  GetLocale() {
    this.user.GetLocale().subscribe((res) => {
      this.LocalList = res.GetLocale;
    });
  }
  /* To get country list */
  GetCountry() {
    this.user.GetCountry().subscribe((res) => {
      this.ContryList = res.getCountry;      
      res.getCountry.forEach((element) => {
        if (element.IsSelected == 1) {
          this.usersave.patchValue({ Country: element.CountryName });
          this.CountryId = element.CountryID;
          this.GetState(element.CountryID, false);
          // this.GetCity(element.CountryID, 0);
          exit;
        }
      });
    });
  }

  checkEmpty(ref) {
    if (ref.value == "") {
      this.usersave.patchValue({ State: "", City: "" });
      this.StateId = 0;
    }
  }
  /*to get state by country id */
  GetState(cd, bool: any = true) {
    // debugger;
    if (bool) {
      this.usersave.patchValue({ State: "", City: "" });
      this.StateId = 0;
    }
    // this.usersave.patchValue({ State: "", City: "" });

    this.CountryId = parseInt(cd);
    const pbody = {
      countryId: parseInt(cd),
    };
    this.user.GetState(pbody).subscribe((res) => {
      this.StateList = res.getState;
      //  this.CityList = [];
    });
  }

  /* get State id  */
  GetStateid(d, ref) {
    this.StateId = parseInt(d);

    ref.blur();
  }
  /* get city   */
  GetCity(atr, stateID) {
    this.usersave.patchValue({ City: "" });
    if (stateID) {
      const body = {
        countryId: this.CountryId,
        stateId: stateID,
      };
      this.user.GetCityListforAddUser(body).subscribe((res: any) => {
        this.CityList = res.getCity;
      });
    }
  }

  CheckSocialSecurityNumber(d) {
    this.user.CheckSocialSecurityNumber(d).subscribe((res) => {
      if (res.SocialSecurityNumber.returnValue == 0) {
        // "NI number is avalable ";
      } else {
        Swal.fire({
          text: "NI number is not avalable",
        }).then((result) => {
          this.usersave.controls["NINumber"].setValue("");
        });
      }
    });
  }

  updateUser() {
    const pbody = {
      UserID: this.UID,
    };
    this.user.GetUserListForUpdate(pbody).subscribe((res: any) => {
      if (res.GetUserListForUpdate.length != 0) {
        this.updatavalue = res.GetUserListForUpdate;

        this.usersave.controls["Salutation"].setValue(
          res.GetUserListForUpdate[0].Salutation
        );
        this.usersave.controls["FirstName"].setValue(
          res.GetUserListForUpdate[0].FirstName
        );
        this.usersave.controls["LastName"].setValue(
          res.GetUserListForUpdate[0].LastName
        );
        this.usersave.controls["EmployeeID"].setValue(
          res.GetUserListForUpdate[0].EmployeeCode
        );
        this.usersave.controls["MiddleName"].setValue(
          res.GetUserListForUpdate[0].MiddleName
        );
        this.usersave.controls["PhoneNumber"].setValue(
          res.GetUserListForUpdate[0].PhoneNumber
        );
        this.usersave.controls["ZipCode"].setValue(
          res.GetUserListForUpdate[0].UserZipCode
        );
        this.usersave.controls["Address"].setValue(
          res.GetUserListForUpdate[0].Address
        );
        this.usersave.controls["City"].setValue(
          res.GetUserListForUpdate[0].CityName
        );

        this.usersave.controls["Email"].setValue(
          res.GetUserListForUpdate[0].Email === ""
            ? null
            : res.GetUserListForUpdate[0].Email
        );
        this.usersave.controls["Gender"].setValue(
          res.GetUserListForUpdate[0].Gender.trim()
        );
        if (res.GetUserListForUpdate[0].IsPrimaryContact) {
          this.IsPrimaryContact = true;
        } else {
          this.IsPrimaryContact = false;
        }
        if (res.GetUserListForUpdate[0].IsRespondingOfficer) {
          this.IsRespondingOfficer = true;
        } else {
          this.IsRespondingOfficer = false;
        }

        if (res.GetUserListForUpdate[0].IsDST == true) {
          this.usersave.controls["Daylight"].setValue("Yes");
          this.Daylightvalue = true;
        } else {
          this.usersave.controls["Daylight"].setValue("No");
          this.Daylightvalue = false;
        }
        if (this.updatavalue[0].PhotoGraph) {
          this.selecetdFile = res.PhotoGraph;
          this.selecetdFile =
            environment.imagePath + this.updatavalue[0].PhotoGraph;
        } else {
          this.selecetdFile = "./assets/images/userBg.png";
        }

        this.usersave.controls["UnitID"].setValue(
          res.GetUserListForUpdate[0].UnitNumber
        );
        // this.usersave.patchValue({Country: res.GetUserListForUpdate[0].CountryName})
        // this.usersave.controls["Country"].setValue(
        //   res.GetUserListForUpdate[0].CountryName
        // );
        // if (
        //   res.GetUserListForUpdate[0].CountryID != "" ||
        //   res.GetUserListForUpdate[0].CountryID != null
        // ) {
        //   this.CountryId = res.GetUserListForUpdate[0].CountryID;
        // }
        // setTimeout(() => {
        this.usersave.controls["State"].setValue(
          res.GetUserListForUpdate[0].StateName
        );
        // }, 2000);
        if (
          res.GetUserListForUpdate[0].StateID != "" ||
          res.GetUserListForUpdate[0].StateID != null
        ) {
          this.StateId = res.GetUserListForUpdate[0].StateID;
        }

        this.usersave.controls["CompanyName"].setValue(
          res.GetUserListForUpdate[0].CompanyName
        );
        this.CompanyNameValue = res.GetUserListForUpdate[0].CompanyID;

        if (res.GetUserListForUpdate[0].CompanyID.length != 0) {
          this.GetpositionTitleByCompanyId(
            res.GetUserListForUpdate[0].CompanyID
          );
          this.GetWorkgroupbyCompanyid(res.GetUserListForUpdate[0].CompanyID);
          this.GetUserProfileByCompanyId(res.GetUserListForUpdate[0].CompanyID);
        }
        this.usersave.controls["PositionTitle"].setValue(
          res.GetUserListForUpdate[0].PositionTitle
        );
        this.usersave.controls["State"].setValue(
          res.GetUserListForUpdate[0].StateName
        );
        this.usersave.controls["City"].setValue(
          res.GetUserListForUpdate[0].CityName
        );
        this.Positionvalue = res.GetUserListForUpdate[0].Title;
        if (res.GetUserListForUpdate[0].WorkGroupName) {
          this.wris = undefined;
          this.pdis = true;
          this.checkedORW = true;
        } else {
          this.pdis = undefined;
          this.wris = true;
          this.checkedOR = true;
        }
        this.usersave.controls["WorkGroupName"].setValue(
          res.GetUserListForUpdate[0].WorkGroupName
        );
        this.WorkGroupvalue = res.GetUserListForUpdate[0].WorkGroupID;
        if (res.GetUserListForUpdate[0].PropertyName) {
          this.pdis = undefined;
          this.wris = true;
          this.checkedOR = true;
        } else {
          this.wris = undefined;
          this.pdis = true;
          this.checkedORW = true;
        }
        this.usersave.controls["PropertyName"].setValue(
          res.GetUserListForUpdate[0].PropertyName
        );
        this.Propertyvalue = res.GetUserListForUpdate[0].PropertyID;

        this.usersave.controls["ProfileName"].setValue(
          res.GetUserListForUpdate[0].ProfileName
        );
        this.ProfileValue = res.GetUserListForUpdate[0].ProfileID;
        this.usersave.controls["TimeZoneName"].setValue(
          res.GetUserListForUpdate[0].TimeZoneName
        );
        this.TimeZonevalue = res.GetUserListForUpdate[0].TimeZone;
        this.usersave.controls["Locale"].setValue(
          res.GetUserListForUpdate[0].Locale
        );
        this.usersave.controls["UserLogin"].setValue(
          res.GetUserListForUpdate[0].UserLogin
        );
        this.usersave.controls["Password"].setValue(
          res.GetUserListForUpdate[0].Password
        );
        if(res.GetUserListForUpdate[0].IsSSOUser){
          this.isSsoUser = true;
        }
          
        //);
        
        this.flag = true;

        if (res.GetUserListForUpdate[0].ProfileID == 1) {
          this.disableForMaster = true;
          this.pdis = true;
          this.wris = true;
          this.pnisDisabled = true;
          this.wrisDisabled = true;
          this.disableForMaster = true;
          // this.usersave.controls["WorkGroupName"].setValue("");
          // this.usersave.controls["PropertyName"].setValue("");
          this.usersave.controls["WorkGroupName"].reset();
          this.usersave.controls["PropertyName"].reset();
          this.checkedORW = false;
          this.checkedOR = false;
        }

        /** first time city */

        if (
          res.GetUserListForUpdate[0].CountryID &&
          res.GetUserListForUpdate[0].StateID
        ) {
          const body = {
            countryId: res.GetUserListForUpdate[0].CountryID,
            stateId: res.GetUserListForUpdate[0].StateID,
          };
          this.user.GetCityListforAddUser(body).subscribe((res: any) => {
            this.CityList = res.getCity;
          });
        }
      }
    });
  }

  primaryOfficer(d) {
    if (d.checked) {
      this.IsPrimaryContact = true;
    } else {
      this.IsPrimaryContact = false;
    }
  }

  respondingOfficer(d) {
    if (d.checked) {
      this.IsRespondingOfficer = true;
    } else {
      this.IsRespondingOfficer = false;
    }
  }
  isSsoUser:boolean = false;
  SsoUser(d) {
    if (d.checked) {
      this.isSsoUser = true;
      this.usersave.controls['Email'].setValidators(Validators.required);
      this.usersave.controls['Email'].updateValueAndValidity();
    } else {
      this.isSsoUser = false;
      this.usersave.controls['Email'].clearValidators();
      this.usersave.controls['Email'].updateValueAndValidity();
    }
  }
  saveuser(d) {
    if (this.CompanyNameValue == null) {
      this.CompanyNameValue = d.CompanyName;
    }
    if (this.Positionvalue == null) {
      this.Positionvalue = d.PositionTitle;
    }
    if (this.ProfileValue == null) {
      this.ProfileValue = d.ProfileName;
    }
    if (this.WorkGroupvalue == null) {
      this.WorkGroupvalue = d.WorkGroupName;
    }
    if (this.Propertyvalue == null) {
      this.Propertyvalue = d.PropertyName;
    }
    if (this.TimeZonevalue == null) {
      this.TimeZonevalue = d.TimeZoneName;
    }

    if (this.UID) {
    } else {
      this.UID = 0;
    }


    if(d.PhoneNumber != '' && this._phoneNumber.test(d.PhoneNumber) == false){
      this.tostre.error("Please Enter a valid phone number.");
      return false;
    }
    
    this.submitted = true;
    // if (this.usersave.value.ProfileName == "Master Admin") {
    if (this.ProfileValue == 1) {
      this.WorkGroupvalue = 0;
      this.Propertyvalue = 0;
    }

    if (this.usersave.valid) {
      if (this.ProfileValue != 1) {
        if (!d.WorkGroupName && !d.PropertyName) {
          /* Swal.fire({
            text: "Please fill all required value",
          }); */
          // this.tostre.error("Please fill the required field.", "", {
          //   positionClass: "toast-top-right",
          // });
          return false;
        }
      }

      if (
        this.ProfileValue != "1" &&
        (this.WorkGroupvalue == null ||
          this.WorkGroupvalue == "" ||
          this.WorkGroupvalue[0] == "0") &&
        (this.Propertyvalue == null ||
          this.Propertyvalue == "" ||
          this.Propertyvalue[0] == "0")
      ) {
        /* Swal.fire({
          text: "Please select property or workgroup",
        }).then((result) => {}); */
        this.tostre.error("Please select property or workgroup.", "", {
          positionClass: "toast-top-right",
        });
        return;
      } else {
        const pbody = {
          UserID: this.UID,
          IsPrimaryContact: this.IsPrimaryContact,
          IsRespondingOfficer: this.IsRespondingOfficer,
          Salutation: d.Salutation,
          EmployeeCode: d.EmployeeID,
          FirstName: d.FirstName,
          LastName: d.LastName,
          MiddleName: d.MiddleName,
          PhoneNumber: d.PhoneNumber,
          ZipCode: d.ZipCode,
          Address: d.Address,
          Country: parseInt(this.CountryId),
          City: d.City,
          State: parseInt(this.StateId),
          // Email: d.Email === "" ? null : d.Email,
          Email: d.Email,
          Gender: d.Gender.trim(),
          IsDST: this.Daylightvalue,
          Photograph: this.selecetdFile,
          UnitID: d.UnitID,
          CompanyID: parseInt(this.CompanyNameValue),
          ProfileID: parseInt(this.ProfileValue),
          PositionTitle: parseInt(this.Positionvalue),
          WorkGroupID: parseInt(this.WorkGroupvalue),
          PropertyId: parseInt(this.Propertyvalue),
          TimeZone: parseInt(this.TimeZonevalue),
          Locale: d.Locale,
          UserLogin: d.UserLogin,
          Password: d.Password,
          IsSSOUser: this.isSsoUser, 
          fileName: this.imageName,
        };
        
        if (this.photoUploaded) {
          pbody.Photograph = this.selecetdFile;
        } else {
          pbody.Photograph = null;
        }
        //
        this.user.updateuser(pbody).subscribe((res) => {     
          console.log(res)     
          if (this.UserID == undefined || this.UserID == "undefined") {
            let param = {
              UserID: res[0].ReturnMessage,
              PermissionIds: this.specialPermission,
              ApplyOn: "OM",
            };
            this.user.UpdateSpacialPermission(param).subscribe((resp) => {              
              // const companySearchParam = {
              //   countryId: 0,
              //   CompanyID: 0,
              //   CompanyTypeID: 0,
              //   StateId: 0,
              //   Status: 1,
              //   IsActive: null,
              //   IsArchive: 0,
              //   Zip: null,
              //   Address: null,
              //   ShortFilter: null,
              // };
              // this.Company.getCompanyList(companySearchParam).subscribe((x: any) => {
              //   this.dataShare.changeMessage(x);
              //   this.dataShare.changeMessageObj(x);
              // })
            });
          }
          if (res[0].ReturnKey == "UserId") {
            /* update user special permission */
            this.storage.setData("edituserid", res[0].ReturnMessage.toString());
            if (
              this.ProfileValue == 1 &&
              this.UID == 0 &&
              this.specialPermission.length
            ) {
              let param = {
                UserID: res[0].ReturnMessage,
                PermissionIds: this.specialPermission,
                ApplyOn: "OM",
              };
              // this.user.UpdateSpacialPermission(param).subscribe((resp) => {              
              //   const companySearchParam = {
              //     countryId: 0,
              //     CompanyID: 0,
              //     CompanyTypeID: 0,
              //     StateId: 0,
              //     Status: 1,
              //     IsActive: null,
              //     IsArchive: 0,
              //     Zip: null,
              //     Address: null,
              //     ShortFilter: null,
              //   };
              //   this.Company.getCompanyList(companySearchParam).subscribe((x: any) => {
              //     this.dataShare.changeMessage(x);
              //     this.dataShare.changeMessageObj(x);
              //   })
              // });
            }
          }
          /**
           * update user with registry
           */
          setTimeout(() => {
            let reg = {
              UserID: null,
              PropertyID: null,
              WorkgroupID: null,
              UpdatedFrom: null,
            };
            if (!pbody.PropertyId && !pbody.WorkGroupID) {
              reg.UserID = pbody.UserID;
            }
            if (pbody.PropertyId) {
              reg.UserID = pbody.UserID;
              reg.PropertyID = pbody.PropertyId;
              reg.WorkgroupID = null;
              reg.UpdatedFrom = "Property";
            }
            if (pbody.WorkGroupID) {
              reg.UserID = pbody.UserID;
              reg.PropertyID = null;
              reg.WorkgroupID = pbody.WorkGroupID;
              reg.UpdatedFrom = "Workgroup";
            }
            this.user.UpdateUserPropertyRegistry(reg).subscribe((elem) => {
              
            });
            /**
             *
             */

            if (
              res[0].ReturnMessage != "EmployeeCodeExists" &&
              res[0].ReturnMessage != "EmailExists" &&
              res[0].ReturnMessage != "LoginExists") {
              if (this.UID == 0) {
                if (this.sc == 1) {
                  this.sc = 2;
                  this.sendCredentials(pbody);
                }
                this.tostre.success(
                  "The Record has been saved successfully.",
                  "",
                  {
                    positionClass: "toast-top-right",
                  }
                );
                // Swal.fire({
                //   text: "User has been saved",
                // }).then((result) => {
                var myurl = `/products/administration/organizationmanagement/users`;
                // this.route.navigateByUrl(myurl);
                // });
                this.submitted = false;
                this.reset();
                this.UID = 0;
                return false;
              } else {
                this.tostre.success(
                  "The Record has been saved successfully.",
                  "",
                  {
                    positionClass: "toast-top-right",
                  }
                );
                // Swal.fire({
                //   text: "User has been updated",
                // }).then((result) => {
                var myurl = `/products/administration/organizationmanagement/users`;
                this.route.navigateByUrl(myurl);
                // });
                this.submitted = false;
                this.reset();
                this.UID = 0;
                // this.dialogRef.close();
                return false;
              }
            } else {
              let msg = res[0].ReturnMessage;
              /* Swal.fire({
              text: msg,
            }).then((result) => {}); */
              if (msg == "EmployeeCodeExists") {
                msg = "UserID exists";
              }
              if (msg === "EmailExists") {
                msg = "Email exists";
              }
              if (msg === "LoginExists") {
                msg = "Login exists";
              }
              this.tostre.error(msg, "", { positionClass: "toast-top-right" });
              return false;
            }
          }, 500);
        });
      }
    } else {
      /*  Swal.fire({
        text: "Please fill all required value",
      }).then((result) => {}); */
      this.tostre.error("Please fill all required field.", "", {
        positionClass: "toast-top-right",
      });
      return;
    }
  }

  onFileUpload(event) {
    const file = event.target.files[0];
    // this.selecetdFile =<File> event.target.files[0];
    this.imageName = (event.target as HTMLInputElement).files[0].name;
    (this.imageName = this.imageName.split(".")[0]),
      (this.imageExtention = event.target.files[0].name
        .split(".")[1]
        .toLowerCase());
    if (this.imageExtention == "jpg" || this.imageExtention == "png") {
      this.convertIntoBase64(event.target.files[0]).then((res) => {
        this.selecetdFile = res;
        this.photoUploaded = true;
      });
    } else {
      this.imageName = null;
      this.photoUploaded = false;
      Swal.fire({
        text: "Please Upload only jpeg,jpg , png  format ",
      }).then((result) => {
        this.usersave.controls["Photograph"].reset();
      });
    }
  }

  convertIntoBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result);
      reader.onerror = (error) => reject(error);
    });
  }

  workgroupRadio(evt) {
    this.chewr = evt.source;
    if (evt.source.checked) {
      this.Propertyvalue = null;
      this.usersave.controls["PropertyName"].setValue("");
      this.wris = undefined;
      this.pdis = true;
    } else {
      this.usersave.controls["WorkGroupName"].setValue("");
      this.WorkGroupvalue = null;
    }
  }
  propertyNameRadio(event) {
    // this.chepn=event.source;
    if (event.source.checked) {
      this.usersave.controls["WorkGroupName"].setValue("");
      this.WorkGroupvalue = null;
      this.pdis = undefined;
      this.wris = true;
    } else {
      this.usersave.controls["PropertyName"].setValue("");
      this.Propertyvalue = null;
    }
  }

  cancel() {
    var myurl = `/products/administration/organizationmanagement/users`;
    this.route.navigateByUrl(myurl);
  }
  changePropertyName() {
    this.wrisDisabled = false;
    // this.disableForMaster = true;
    this.usersave.controls["WorkGroupName"].setValue("");
  }

  changeWorkGroupName() {
    this.pnisDisabled = false;
    //   this.disableForMaster = true;
    this.usersave.controls["PropertyName"].setValue("");
  }

  sendCredentials(d) {
    if (this.UID > 0 || this.sc == 2) {
      this.sc = 0;
      this.user.sendCredentials(d).subscribe((res) => {
        if (res.statusCode == 200) {
          this.tostre.success("Credentials has been sent ", "", {
            positionClass: "toast-bottom-right",
          });
        } else {
          this.tostre.error("There is some error ", "", {
            positionClass: "toast-bottom-right",
          });
        }
      });
    } else {
      this.sc = 1;
      this.saveuser(d);
      //  await   this.user.sendCredentials(d).subscribe(res=>{
      //       if(res.statusCode==200){
      //         this.tostre.success('Credentials has been sent ', '', {
      //           positionClass: 'toast-bottom-right'
      //         });

      //       }else{
      //         this.tostre.warning('There is some error ', '', {
      //           positionClass: 'toast-bottom-right'
      //         });
      //       }

      //     });
    }
  }

  getCompanyNameValue(d) {
    this.CompanyNameValue = d;
  }
  GetProfileValue(d) {
    this.ProfileValue = d;
  }

  GetPositionvalue(d) {
    this.Positionvalue = d;
  }
  GetLocal(d) {}
  GetWorkGroupvalue(d) {
    this.WorkGroupvalue = d;
  }
  GetPropertyvalue(d) {
    this.Propertyvalue = d;
  }
  GetTimeZonevalue(d) {
    this.TimeZonevalue = d;
  }

  reset() {
    this.submitted = false;
    this.usersave.reset({
      UserID: "",
      EmployeeCode: "",
      FirstName: "",
      LastName: "",
      PhoneNumber: "",
      MiddleName: "",
      Email: "",
      Gender: "",
      IsDST: "",
      Photograph: "",
      UnitID: "",
      UserLogin: "",
      Password: "",
    });
    this.usersave.controls["WorkGroupName"].setValue("");
    this.usersave.controls["CompanyName"].setValue("");
    this.usersave.controls["PositionTitle"].setValue("");
    this.usersave.controls["PropertyName"].setValue("");
    this.usersave.controls["TimeZoneName"].setValue("");
    this.usersave.controls["Locale"].setValue("");
    this.usersave.controls["ProfileName"].setValue("");
    this.usercheck = "";
  }

  uservalid(keyCode) {
    var iKeyCode = keyCode.which ? keyCode.which : keyCode.keyCode;
    // if (
    //   iKeyCode == 45 ||
    //   iKeyCode == 46 ||
    //   iKeyCode == 95 ||
    //   (iKeyCode >= 48 && iKeyCode <= 57) ||
    //   (iKeyCode >= 97 && iKeyCode <= 122) ||
    //   (iKeyCode >= 65 && iKeyCode <= 90)
    // )
    //   return true;
    // return false;
  }
  // update user login name
  checkUser(d) {
    if (this.flag) {
      if (d.trim() == "") {
        this.usercheck = ".....please enter valid User Login  ";
        this.usersave.controls["UserLogin"].setValue("");
      } else {
        const pbody = {
          LoginID: d,
          UserID: this.UID ? this.UID : 0,
        };
        
        this.user.checkUser(pbody).subscribe((res) => {
          if (res.UserAvailability.returnValue == 0) {
            this.usercheck = ".....User Login is available ";
          } else {
            this.usersave.controls["UserLogin"].setValue("");

            this.usercheck = ".....User Login is not available ";
          }
        });
      }
    }
  }

  CheckEmailAvailablety(d) {
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (d.match(mailformat)) {
      const pbody = {
        UserID: 0,
        EmailID: d,
      };
      this.user.CheckEmailAvailablety(pbody).subscribe((res) => {
        if (res.checkEmailAvailablety.returnValue == 0) {
          this.emailcheck = "....Email is available ";
        } else {
          this.usersave.controls["Email"].setValue("");
          this.emailcheck = ".....Email is not available ";
        }
      });
    } else {
      this.emailcheck = ".....Please enter valid Email  ";
    }
  }

  password() {
    this.showpass = !this.showpass;
  }
  checkOr = new FormControl(null);
  profileSelect(data, ProfileID, event?: any) {
    if (!event.isUserInput) {
      return;
    }

    if (ProfileID == "1") {
      this.pdis = true;
      this.wris = true;
      this.pnisDisabled = true;
      this.wrisDisabled = true;
      this.disableForMaster = true;
      // this.usersave.controls["WorkGroupName"].setValue("");
      // this.usersave.controls["PropertyName"].setValue("");
      // .. below line is commented because these should not blank on change profile
      /* this.usersave.controls["WorkGroupName"].reset();
      this.usersave.controls["PropertyName"].reset(); 
      this.checkedORW = false;
      this.checkedOR = false;*/

      this.openDialogMasterAdmin();
    } else {
      this.disableForMaster = false;
      this.pnisDisabled = false;
      this.wrisDisabled = false;
      this.pdis = false;
      this.wris = false;
      // .. below line is commented because these should not blank on change profile
      /*this.checkedORW = false;
      this.checkedOR = false;      
      this.usersave.controls["WorkGroupName"].reset();
      this.usersave.controls["PropertyName"].reset(); */
    }
    // this.checkOr.reset();
  }

  openDialogMasterAdmin() {
    this.specialPermission = [];

    const dialogRef = this.dialog.open(ModelMasterAdminComponent, {
      width: "36%",
      maxWidth: "100vw",
      data: { UserID: this.UID },
      disableClose: true,
    });

    dialogRef.afterClosed().subscribe((result) => {
      this.specialPermission = result;
    });
  }

  onkeyUpSelection(d) {
    if ("WorkGroups" == d) {
      this.WorkGroupvalue = "";
    } else if ("Propert" == d) {
      this.Propertyvalue = "";
    } else {
    }
  }

  openFile(event, elem, type) {
    var input = event.target;
    if (
      input.files[0].type == "image/jpeg" ||
      input.files[0].type == "image/jpg" ||
      input.files[0].type == "image/png"
    ) {
      // this.file2 = event && event.target.files.item(0);

      var reader = new FileReader();
      reader.onload = function () {
        var dataURL = reader.result;
        elem.src = dataURL;
      };
      reader.readAsDataURL(input.files[0]);
    } else {
      Swal.fire({
        text: "Plese select jpg or png image only",
      });
      event.target.value = "";
    }
  }

  telephoneNumber: string = "";
  phoneNumber(event: any) {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    let filterValue = (event.target as HTMLInputElement).value;
    this.telephoneNumber = filterValue;
    if (this.telephoneNumber.length == 3 || this.telephoneNumber.length == 7) {
      this.telephoneNumber = this.telephoneNumber + "-";
    }
  }

  blurFun(ref) {
    ref.blur();
  }

  checkErrors() {
    // console.log(this.usersave.controls.Email.errors);
  }
}
