import { Component, OnInit, ViewChild } from "@angular/core";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { ActivatedRoute } from "@angular/router";
import { UserPermissionService } from "src/app/services/user-permission.service";
import { AddCompanyService } from "../addcompanies/addCompany.service";
import { DataSharingService } from "../dataSharing.service";

export interface keycontact {
  keycontactname: string;
  keycontactuserid: string;
  keycontactposition: string;
  keycontactcompany: string;
  keycontactsubdiv: string;
  keycontacttype: string;
  keycontactconc: string;
  telephonenum: number;
  keycontactaction: string;
}

const eleDataallperson: keycontact[] = [
  {
    keycontactname: "name1",
    keycontactuserid: "",
    keycontactposition: "",
    keycontactcompany: "",
    keycontactsubdiv: "",
    keycontacttype: "",
    keycontactconc: "",
    telephonenum: 53543643643,
    keycontactaction: "",
  },
];
@Component({
  selector: "app-allpersonlist",
  templateUrl: "./allpersonlist.component.html",
  styleUrls: ["./allpersonlist.component.scss"],
})
export class AllpersonlistComponent implements OnInit {
  constructor(
    private route: ActivatedRoute,
    private AddCompanyService: AddCompanyService,
    private DataSharing: DataSharingService,
    public UserPermission: UserPermissionService
  ) {}

  displayedColumnsallperson: string[] = [
    "PersonsName",
    "UserID",
    "PositionTitle",
    "UserProfile",
    "CompanyName",
    "WorkgroupOrProperty",
    "EmailAddress",
    "TelephoneNumber",
    "action",
  ];
  dataSourceallperson = new MatTableDataSource();

  @ViewChild(MatSort, { static: true }) sort: MatSort;

  companyID: any;
  allConatacts: any = [];

  ngOnInit() {
    let cid = this.route.snapshot.paramMap.get("id");
    if (cid) {
      this.companyID = atob(cid);
      this.getAllContacts(this.companyID);
    }
    // console.log("IDS = ", companyID)
    this.dataSourceallperson.sort = this.sort;
  }

  getAllContacts(companyID: any) {
    this.AddCompanyService.GetCompanyAllPerson(companyID).subscribe(
      (response) => {
        let result = response;
        this.allConatacts = result.GetCompanyAllPerson;
        // console.log("All - ", this.allConatacts.length)
        // this.dataSourceallperson = result.GetCompanyAllPerson

        this.DataSharing.changeAllKeyPersionMessage({
          allPerson: result.GetCompanyAllPerson,
        });

        this.DataSharing.allKeyPersionStream.subscribe((x: any) => {
          this.dataSourceallperson = new MatTableDataSource(x.allPerson);
        });
      }
    );
  }

  updateAssignPerson(event, data: any) {
    event.preventDefault();
    // console.log(data)
    if (!data.IsAssigned) {
      let finalData = {
        CompanyContactID: 0,
        CompanyID: +this.companyID, //data.CompanyID,
        UserID: +data.ID,
        IsAssigned: 1,
      };
      this.AddCompanyService.UpdateCompanyContact(finalData).subscribe(
        (response) => {
          // console.log(response)
          this.getAllContacts(this.companyID);
          this.AddCompanyService.GetCompanyContact(this.companyID).subscribe(
            (response) => {
              this.DataSharing.changeKeyContactMessage({
                keyPerson: response.GetCompanyContact,
              });
            }
          );
        }
      );
    }
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSourceallperson.filter = filterValue.trim().toLowerCase();
  }
}
