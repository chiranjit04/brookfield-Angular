import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllpersonlistComponent } from './allpersonlist.component';

describe('AllpersonlistComponent', () => {
  let component: AllpersonlistComponent;
  let fixture: ComponentFixture<AllpersonlistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllpersonlistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllpersonlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
