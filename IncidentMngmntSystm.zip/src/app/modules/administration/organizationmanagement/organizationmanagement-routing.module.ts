import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { OrganizationmanagementComponent } from './organizationmanagement.component';
import { CompaniesComponent } from './companies/companies.component';
import { PermissionsComponent } from './permissions/permissions.component';
import { ProfilesComponent } from './profiles/profiles.component';
import { WorkgroupsComponent } from './workgroups/workgroups.component';
import { UsersComponent } from './users/users.component';

import { UserModalComponent } from './users/adduser.component';
import { AddcompaniesComponent } from './addcompanies/addcompanies.component';
import { AddprofileComponent } from './profiles/addprofile/addprofile.component';
import { JobtitlesComponent } from './jobtitles/jobtitles.component';
import { AddjobtitleComponent } from './jobtitles/addjobtitle/addjobtitle.component';
import { AuthGuard } from "./../../../guard/auth.guard";

const routes: Routes = [
  // { path: '',canActivate: [ AuthGuard ], component: CompaniesComponent, pathMatch: 'full' },
  { path: '',canActivate: [ AuthGuard ], redirectTo: 'companies', pathMatch: 'full' },
  { path: 'companies',canActivate: [ AuthGuard ], component: CompaniesComponent },
  { path: 'companies/addcompanies',canActivate: [ AuthGuard ], component: AddcompaniesComponent },
  { path: 'companies/editcompanies/:id',canActivate: [ AuthGuard ], component: AddcompaniesComponent },
  { path: 'permission',canActivate: [ AuthGuard ], component: PermissionsComponent },
  { path: 'profile',canActivate: [ AuthGuard ], component: ProfilesComponent },
  { path: 'profile/addprofile',canActivate: [ AuthGuard ], component: AddprofileComponent },
  { path: 'profile/editprofile/:id',canActivate: [ AuthGuard ], component: AddprofileComponent },
  { path: 'workgroups',canActivate: [ AuthGuard ], component: WorkgroupsComponent },

  { path: 'users',canActivate: [ AuthGuard ], component: UsersComponent },
  { path: 'users/addusers',canActivate: [ AuthGuard ], component: UserModalComponent },
  { path: 'users/addusers/:UserID',canActivate: [ AuthGuard ], component: UserModalComponent },

  { path: 'addprofile',canActivate: [ AuthGuard ], component: AddprofileComponent },
  { path: 'addprofile/:id',canActivate: [ AuthGuard ], component: AddprofileComponent },
  { path: 'jobtitles',canActivate: [ AuthGuard ], component: JobtitlesComponent },
  { path: 'jobtitles/updated',canActivate: [ AuthGuard ], component: JobtitlesComponent },
  { path: 'jobtitles/updated/addjobtitle',canActivate: [ AuthGuard ], component: AddjobtitleComponent },
  { path: 'jobtitles/addjobtitle',canActivate: [ AuthGuard ], component: AddjobtitleComponent },
  { path: 'jobtitles/editjobtitle/:id',canActivate: [ AuthGuard ], component: AddjobtitleComponent },
  { path: 'companies/addsubdivision/:cid',canActivate: [ AuthGuard ], component: AddcompaniesComponent },
  { path: '**',canActivate: [ AuthGuard ], component: CompaniesComponent, pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class OrganizationmanagementRoutingModule {}
