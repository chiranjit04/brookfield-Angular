import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { environment } from "../../../../../environments/environment";
import { Observable } from "rxjs";
import { retry } from "rxjs/operators";
@Injectable({
  providedIn: "root",
})
export class AddCompanyService {
  _LocalUrl: string;
  constructor(private http: HttpClient) {
    this._LocalUrl = environment.origin;
    // this._LocalUrl = 'http://localhost:1601/';
  }
  getCountry(): Observable<any> {
    return this.http.get<any>(this._LocalUrl + "api/getCountry");
  }
  getState(param: any): Observable<any> {
    return this.http.post<any>(this._LocalUrl + "api/getState", param);
  }
  getCity(param: any): Observable<any> {
    return this.http.post<any>(this._LocalUrl + "api/getCity", param);
  }
  getCompanyBYId(param: any): Observable<any> {
    return this.http.post<any>(this._LocalUrl + "api/GetCompanyById", param);
  }

  updateCompany(param: any): Observable<any> {
    return this.http.post<any>(this._LocalUrl + "api/UpdateCompany", param);
  }
  getCompanyType() {
    return this.http.get<any>(this._LocalUrl + "api/GetCompanyType");
  }

  GenerateCompanyIDNumber() {
    return this.http.get<any>(this._LocalUrl + "api/GetCompanyIndentNumber");
  }

  VerifyCompanyIDNumber(data: any) {
    return this.http.post<any>(
      this._LocalUrl + "api/VerifyCompanyIDNumber",
      data
    );
  }

  GetCompanyAllPerson(CompanyID: any) {
    let data = {
      CompanyID: +CompanyID,
    };
    return this.http.post<any>(
      this._LocalUrl + "api/GetCompanyAllPerson",
      data
    );
  }

  GetCompanyContact(CompanyID: any) {
    let data = {
      CompanyID: +CompanyID,
    };
    return this.http.post<any>(this._LocalUrl + "api/GetCompanyContact", data);
  }

  UpdateCompanyContact(data: any) {
    return this.http.post<any>(
      this._LocalUrl + "api/UpdateCompanyContact",
      data
    );
  }
}
