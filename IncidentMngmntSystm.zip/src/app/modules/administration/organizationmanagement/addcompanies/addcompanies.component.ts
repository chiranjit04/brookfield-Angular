import { Component, OnInit, ɵConsole, Renderer2 } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
import { AddCompanyService } from "./addCompany.service";
import { StorageService } from "../../../../services/storage.service";
import {
  FormGroup,
  FormBuilder,
  FormControl,
  Validators,
  FormArray,
} from "@angular/forms";
import { startWith, map } from "rxjs/operators";
import { ToastrService } from "ngx-toastr";
//import { KeycontactlistComponent } from '../keycontactlist/keycontactlist.component'
import Swal from "sweetalert2";
import { environment } from "../../../../../environments/environment";
import { UserPermissionService } from "src/app/services/user-permission.service";

@Component({
  selector: "app-addcompanies",
  templateUrl: "./addcompanies.component.html",
  styleUrls: ["./addcompanies.component.scss"],
})
export class AddcompaniesComponent implements OnInit {
  _companyName: any;
  _companyIdent: any;
  _subdivision: any;
  _isActive: any = true;
  _isArchieve: any;
  _subdivisionID: any;
  EditCompany: string = "Edit Company Subdivision";

  companyFormGroup: FormGroup;
  _websiteControl: any;
  listArray = {
    countryList: [],
    stateList: [],
    cityList: [],
    typeList: [],
  };
  filterObj = {
    countryFilter: null,
    stateFilter: null,
    cityFilter: null,
    typeFilter: null,
  };

  companyIdNumber: any = "";
  IdentyNumber = 0;
  editCompany: any = false;
  CurrentCompanyID: any = 0;

  private file2: File = null;
  currentURL: any = null;
  compnayORsubdivision: any = "Add Company";

  myreg = /^(?:(?:(?:https?|ftp):)?\/\/)(?:\S+(?::\S*)?@)?(?:(?!(?:10|127)(?:\.\d{1,3}){3})(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)(?:\.(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)*(?:\.(?:[a-z\u00a1-\uffff]{2,})))(?::\d{2,5})?(?:[/?#]\S*)?$/i;

  authToken = null;
  userData = null;
  UserID = null;
  CountryID: any;

  constructor(
    private addCompany: AddCompanyService,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private alertMsg: ToastrService,
    private router: Router,
    private renderer: Renderer2,
    private storage: StorageService,
    public UserPermission: UserPermissionService
  ) {
    //... Read User Data ...
    this.authToken = this.storage.getData("token");
    this.userData = JSON.parse(this.storage.getData("UserData"));
    let companyDetails: any = this.storage.getData("CompanyDetails");
    this.UserID = this.userData[0].UserID;
    if (this.authToken == null) {
      this.router.navigate(["/login"]);
    }
    this.currentURL = location.pathname.split("/");

    if (this.currentURL[5] == "addcompanies") {
      this._companyName = "Add Company";
      return;
    }

    if (this.currentURL[5] == "addsubdivision") {
      this.compnayORsubdivision = "Add Company Subdivision";
      this._companyName = this.compnayORsubdivision;
    } else if (this.currentURL[5] != "addsubdivision") {
      this.compnayORsubdivision = "Add Company Subdivision";
      if (!companyDetails) {
        return;
      } else {
        companyDetails = JSON.parse(companyDetails);
      }
      if (companyDetails.ParentID == 0) {
        this._companyName = companyDetails.CompanyName;
        this._companyIdent = companyDetails.CompanyIndentNumber;
      } else {
        this.EditCompany = "Add Company Subdivision";
        this._companyName = companyDetails.CompanyName;
        this._companyIdent = companyDetails.CompanyIndentNumber;
        this.addCompany
          .getCompanyBYId({ companyID: companyDetails.RootCompanyID })
          .subscribe((x) => {
            this._subdivision = x.CompanyById[0].CompanyName;
            this._subdivisionID = x.CompanyById[0].CompanyIndentNumber;
          });
      }
    } else {
      this._companyName = "Add Company";
    }
  }

  ngOnInit() {
    let companyID = this.route.snapshot.paramMap.get("id");
    if (companyID != undefined) {
      this.setCompanyDetailsByID(atob(companyID));
      this.editCompany = atob(companyID);
      this.compnayORsubdivision = "Edit Company";
      this.CurrentCompanyID = atob(companyID);
    }
    this.getCountry();

    this.getCompanyType();

    this.companyFormGroup = this.formBuilder.group({
      companyID: [""],
      companyName: ["", [Validators.required]],
      companyTypeID: [""],
      companyTypeName: [""],
      parentID: [""],
      subdivisionName: [""],
      companyIdent: ["", [Validators.required]],
      companyDesc: ["", [Validators.required]],
      companyStatus: [""],
      isActive: [],
      isArchieve: [0],
      companyAddress: [""],
      countryID: [""],
      countryName: [""], //["United States of America"],
      stateID: [""],
      stateName: [""],
      cityID: [null],
      cityName: [""],
      zipCode: [""],
      companyPhone: ["", Validators.minLength(12)],
      companyEmail: ["", Validators.email],
      companyImageName: [""],
      website: this.formBuilder.array([this.createWebsiteRows()]),
      userID: [this.UserID],
      companyOldPhoto: [""],
    });
  }

  submitted = false;
  get companyFormGroupF() {
    return this.companyFormGroup.controls;
  }

  createWebsiteRows(): FormGroup {
    return this.formBuilder.group({
      // url: ['']
      url: ["", Validators.pattern(this.myreg)],
    });
  }

  addWebsiteRows() {
    this._websiteControl = this.companyFormGroup.get("website");
    this._websiteControl.push(this.createWebsiteRows());
  }

  /** */
  setCompanyDetailsByID(companyID: any) {
    // console.log(companyID);
    this.addCompany.getCompanyBYId({ companyID: companyID }).subscribe((x) => {
      let response = x.CompanyById[0];
      // console.log("111 - ", response);
      this._companyName = response.CompanyName;
      this._companyIdent = response.CompanyIndentNumber;
      this._subdivision = response.Subdivision;
      this._isActive = response.IsActive ? true : false;
      this._isArchieve = response.IsArchieve;
      this._subdivisionID = response.SubdivisionIndentNumber;

      if (response.IsActive == true) {
        this.companyFormGroup.patchValue({ isActive: 1 });
      } else if (response.IsActive === false) {
        this.companyFormGroup.patchValue({ isActive: 0 });
      } else if (response.IsArchieve === true && response.IsArchieve != null) {
        {
          this.companyFormGroup.patchValue({ isArchieve: 1 });
        }
      }
      // console.log(this._isActive);
      this.companyFormGroup.patchValue({
        companyID: response.CompanyID,
        companyName: response.CompanyName,
        companyTypeID: response.CompanyTypeId,
        companyTypeName: response.CompanyType,
        parentID: response.ParentId,
        subdivisionName: response.Subdivision,
        companyIdent: response.CompanyIndentNumber,
        companyDesc: response.CompanyDescription,
        companyAddress: response.CompanyAddress,
        countryID: response.CountryID,
        countryName: response.CountryName,
        stateID: response.StateCityID,
        stateName: response.StateName,
        cityID: null,
        cityName: response.CompanyCity,
        zipCode: response.CompanyZipCode,
        companyPhone: response.CompanyPhone,
        companyEmail: response.CompanyBusinessMail,
        companyOldPhoto: response.CompanyImagePath,
      });

      /* if (response.CompanyWebSite && response.CompanyWebSite.length != 0) {
        this._websiteControl = this.companyFormGroup.get('website');
        // console.log(this._websiteControl)
        response.CompanyWebSite.forEach((element: any) => {
          this._websiteControl.push(this.formBuilder.group({
            url: [element.url, Validators.pattern(this.myreg)]
          }));
        });
      } */

      if (response.CompanyWebSite && response.CompanyWebSite.length != 0) {
        this._websiteControl = this.companyFormGroup.get("website");
        response.CompanyWebSite.forEach((element: any, i) => {
          if (i == 0) {
            this._websiteControl.controls[0].setValue(element);
          } else {
            this._websiteControl.push(
              this.formBuilder.group({
                url: [element.url, Validators.pattern(this.myreg)],
              })
            );
          }
        });
      }

      this.setImage(response.CompanyImagePath);
    });
  }

  setImage(image: any) {
    const photoLogoRef = this.renderer.selectRootElement("#companyLogo", true);
    const url = `${environment.imagePath}`;
    if (image) {
      this.renderer.setAttribute(
        photoLogoRef,
        "src",
        `${url}companies/${image}`
      );
    }
  }

  /**
   * image reader file
   * @param file
   * @param elem
   */
  openFile(event, elem, type) {
    var input = event.target;
    // console.log(input.files[0].type);
    if (
      input.files[0].type == "image/jpeg" ||
      input.files[0].type == "image/jpg" ||
      input.files[0].type == "image/png"
    ) {
      this.file2 = event && event.target.files.item(0);

      var reader = new FileReader();
      reader.onload = function () {
        var dataURL = reader.result;
        elem.src = dataURL;
      };
      reader.readAsDataURL(input.files[0]);
    } else {
      this.alertMsg.warning("Plese select jpg or png image only");
      event.target.value = "";
    }
  }

  getCountry() {
    this.addCompany.getCountry().subscribe((x) => {
      this.listArray.countryList = x.getCountry;
      x.getCountry.forEach(element => {
        if (element.IsSelected == 1) {
          this.CountryID = element.CountryID;
          this.companyFormGroup.patchValue({countryName: element.CountryName});
          this.getState(element.CountryID);
         // this.getCity(element.CountryID, 0);
        }
      });
      this.initiate(
        "countryFilter",
        "countryName",
        "countryList",
        "CountryName"
      );
    });
  }
  getState(cntry) {
    this.CountryID = cntry;
    this.addCompany.getState({ countryId: cntry }).subscribe((x) => {
      this.listArray.stateList = x.getState;
      this.initiate("stateFilter", "stateName", "stateList", "StateName");
    });
  }
  getCity(cntry, stdID) {
    this.statecityvalue = stdID;
    this.addCompany
      .getCity({ countryId: this.CountryID, stateId: stdID })
      .subscribe((x) => {
        this.listArray.cityList = x.getCity;
        this.initiate("cityFilter", "cityName", "cityList", "CityName");
      });
  }
  removeCity(){
    this.listArray.cityList = [];
    this.initiate("cityFilter", "cityName", "cityList", "CityName");
    this.companyFormGroup.patchValue({cityName: ''})
  }
  /*convert first in capital*/
  getPropertyname(name) {
    if (name == null) {
      return null;
    } else {
      return (name = name.split("-")[0].trim());
    }
  }
 /**/ 
  getCompanyType() {
    this.addCompany.getCompanyType().subscribe((x) => {
      this.listArray.typeList = x.companyTypeList;
      this.initiate("typeFilter", "companyTypeName", "typeList", "Title");
    });
  }

  /** */
  initiate(_filterObj, _fControlName, arrName, objKeyName) {
    this.filterObj[_filterObj] = this.companyFormGroup.controls[
      _fControlName
    ].valueChanges.pipe(
      startWith(""),
      map((value) => this._filter(value, arrName, objKeyName))
    );
  }

  private _filter(value: string, arrName: any, objKeyName: any) {
    const filterValue = value.toLowerCase();
    return this.listArray[arrName].filter((name: any) =>
      name[objKeyName].toLowerCase().includes(filterValue)
    );
  }

  /**
   *
   */
  statecityvalue = 0;
  setIdentityColumn(controlName, value) {
    this.statecityvalue = value;
    if (controlName === "countryID")
      this.companyFormGroup.patchValue({
        countryID: value,
      });
    else if (controlName === "companyTypeID")
      this.companyFormGroup.patchValue({
        companyTypeID: value,
      });
    else if (controlName === "stateID")
      this.companyFormGroup.patchValue({
        stateID: value,
      });
    else if (controlName === "cityID")
      this.companyFormGroup.patchValue({
        cityID: value,
      });
  }

  saveForm() {
    this.submitted = true;
    if (this.companyFormGroup.invalid) {
      return;
    }

    let currentObj = this.companyFormGroup.value;
    if(currentObj.companyName != "" && currentObj.companyName != undefined){
    currentObj.companyName = this.getPropertyname(currentObj.companyName.charAt(0).toUpperCase() + currentObj.companyName.slice(1)) || ""
    }
    if (currentObj.companyStatus != "") {
      if (currentObj.companyStatus == "Active") {
        // this.companyFormGroup.patchValue({ isActive: 1 });
        currentObj.isActive = 1;
        currentObj.isArchieve = 0;
      } else if (currentObj.companyStatus == "InActive") {
        // this.companyFormGroup.patchValue({ isActive: 0 });
        currentObj.isActive = 0;
        currentObj.isArchieve = 0;
      } else if (
        currentObj.companyStatus == "Archived" &&
        currentObj.companyStatus != ""
      ) {
        // this.companyFormGroup.patchValue({ isArchieve: 1 });
        currentObj.isArchieve = 1;
      }
    } else {
      currentObj.isActive = this._isActive ? 1 : 0;
    }

    currentObj.userID = this.UserID;

    if (currentObj.parentID == null) {
      currentObj.parentID = 0;
    }

    if (currentObj.parentID) {
      currentObj.parentID = currentObj.parentID[0];
    }

    let cid = this.route.snapshot.paramMap.get("cid");
    if (cid) {
      currentObj.parentID = atob(cid);
    }

    let websiteArray = currentObj["website"];

    let payload = new FormData();

    if (this.file2 != null) {
      // console.log(this.file2)
      payload.append(
        "_companyPhoto",
        this.file2,
        Date.now() + 1 + this.file2.name
      );
    }
    Object.keys(currentObj).forEach((key: string) => {
      payload.append(key, currentObj[key]);
    });
    payload.delete("website");

    /* let website = websiteArray.map(function (elem: { url: any; }) {
      if (elem.url != ""){        
        return elem.url;
      }
    }).join("|"); */

    let website = "";
    for (let i = 0; i < websiteArray.length; i++) {
      if (websiteArray[i].url != "") {
        website = website + "|" + websiteArray[i].url;
      }
    }
    payload.append("website", website);

    // console.log("RAM = ", currentObj); return false;

    // if(this.editCompany){
    //   this.addCompany.updateCompany(payload).subscribe(x => {
    //     if (x.statusCode === 200) {
    //       this.alertMsg.success("Company details saved successfully.")
    //       this.router.navigate(["/products/administration/organizationmanagement/companies"]);
    //     }
    //   });
    // }else{
    let element: HTMLElement = document.getElementById(
      "companyIdent"
    ) as HTMLElement;
    let number = currentObj.companyIdent;
    if (number != "" && number.length == 4) {
      let data = {
        CompanyID: +this.CurrentCompanyID,
        CompanyIdentyNumber: +number,
      };
      this.addCompany.VerifyCompanyIDNumber(data).subscribe((response) => {
        // console.log("CompanyIdentyNumber = ", response)
        let result = response.VerifyCompanyIDNumber[0];
        if (result.ReturnMessage == "Already Exists.") {
          this.IdentyNumber = 1;
          // let element: HTMLElement = document.getElementById("companyIdent") as HTMLElement;
          element.classList.add("is-invalid");
        } else {
          this.IdentyNumber = 2;
          element.classList.remove("is-invalid");
          this.addCompany.updateCompany(payload).subscribe((x) => {
            let result = x.updateCompany[0];
            if (
              result &&
              result.ReturnMessage ==
                currentObj.companyName + " already exists."
            ) {
              this.alertMsg.warning(result.ReturnMessage);
              // Swal.fire({ html: result.ReturnMessage });
            } else if (x.statusCode === 200) {
              this.alertMsg.success("The Record has been saved successfully.");
              // Swal.fire({ html: "Company details saved successfully." });
              this.submitted = false;
              this.companyFormGroup.reset();
              const photoLogoRef = this.renderer.selectRootElement(
                "#companyLogo",
                true
              );
              this.renderer.setAttribute(
                photoLogoRef,
                "src",
                `./assets/images/imagenaBg.png`
              );

              if (this.editCompany) {
                this.router.navigate([
                  "/products/administration/organizationmanagement/companies",
                  { act: "updated" },
                ]);
              } else {
                this.storage.setData("companyAdded", "1");
              }
            }
          });
        }
      });
    } else {
      let element: HTMLElement = document.getElementById(
        "companyIdent"
      ) as HTMLElement;
      element.classList.add("is-invalid");
    }
    //}
  }

  GenerateCompanyIDNumber() {
    this.addCompany.GenerateCompanyIDNumber().subscribe((response) => {
      // console.log(response)
      this.companyFormGroup.controls["companyIdent"].setValue(
        response.GetCompanyIndentNumber[0].PropertyIdentyNumber
      );
      this.companyIdNumber =
        response.GetCompanyIndentNumber[0].PropertyIdentyNumber;
    });
  }

  VerifyCompanyIDNumber(number: any) {
    let element: HTMLElement = document.getElementById(
      "companyIdent"
    ) as HTMLElement;
    if (number != "" && number.length == 4) {
      let data = {
        CompanyID: +this.CurrentCompanyID,
        CompanyIdentyNumber: +number,
      };

      this.addCompany.VerifyCompanyIDNumber(data).subscribe((response) => {
        // console.log("CompanyIdentyNumber = ", response)
        let result = response.VerifyCompanyIDNumber[0];
        if (result.ReturnMessage == "Already Exists.") {
          this.IdentyNumber = 1;
          // let element: HTMLElement = document.getElementById("companyIdent") as HTMLElement;
          element.classList.add("is-invalid");
        } else {
          this.IdentyNumber = 2;
          element.classList.remove("is-invalid");
        }
      });
    } else {
      // let element: HTMLElement = document.getElementById("companyIdent") as HTMLElement;
      element.classList.add("is-invalid");
    }
  }

  onSearchChange(n) {
    this.IdentyNumber = 0;
    let element: HTMLElement = document.getElementById(
      "companyIdent"
    ) as HTMLElement;
    element.classList.remove("is-invalid");
  }

  numberOnly(event: any): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
  telephoneNumber: string = "";
  phoneNumber(event: any) {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    let filterValue = (event.target as HTMLInputElement).value;
    this.telephoneNumber = filterValue;
    if (this.telephoneNumber.length == 3 || this.telephoneNumber.length == 7) {
      this.telephoneNumber = this.telephoneNumber + "-";
    }
  }

  removeUrl(event, index, data) {
    event.preventDefault();
    // console.log(data)
    // let element: HTMLElement = document.getElementById('urlinput-'+index) as HTMLElement
    // element.remove()
    this._websiteControl.removeAt(index);
  }

  viewWebsite(index: any, data: any) {
    if (data.value.url != "") {
      window.open(data.value.url, "_blank");
    }
  }

  checkUrl(event, index) {
    let url = event.target.value;
    if (url.match(this.myreg)) {
      event.target.classList.remove("is-invalid");
    } else {
      event.target.classList.add("is-invalid");
    }
  }
}
