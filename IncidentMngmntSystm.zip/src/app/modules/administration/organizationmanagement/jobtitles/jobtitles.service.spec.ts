import { TestBed } from '@angular/core/testing';

import { JobtitlesService } from './jobtitles.service';

describe('JobtitlesService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: JobtitlesService = TestBed.get(JobtitlesService);
    expect(service).toBeTruthy();
  });
});
