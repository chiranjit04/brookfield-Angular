import { Component, Input, ViewChild, OnInit } from "@angular/core";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { JobtitlesService } from "./jobtitles.service";
import { FormControl } from "@angular/forms";
import { Observable } from "rxjs";
import { startWith, map } from "rxjs/operators";
import { FormGroup, FormBuilder, FormArray, Validators } from "@angular/forms";
import { ToastrService } from "ngx-toastr";
import { Router, ActivatedRoute } from "@angular/router";
import Swal from "sweetalert2";
import * as XLSX from "xlsx";
import { LoginComponent } from "src/app/modules/auth/login/login.component";
import { UserPermissionService } from "src/app/services/user-permission.service";
import { StorageService } from "../../../../services/storage.service";
import { ServiceService } from "./../../service/service.service";
import { MatDialog } from "@angular/material";
import { environment } from 'src/environments/environment';

@Component({
  selector: "app-jobtitles",
  templateUrl: "./jobtitles.component.html",
  styleUrls: ["./jobtitles.component.scss"],
  providers: [LoginComponent],
})
export class JobtitlesComponent implements OnInit {
  allowWhiteListButton = environment.AllowWhiteListButton;
  allowUsersID = environment.AllowUsersID;
  allowAddIPButton:boolean = false;
  companylist: any;
  streets: any[] = [];
  filteredStreets: any;
  companyControl: any = new FormControl();
  CompanyID: any = false;
  CompanyIDs: any;
  companyChangeID: any;

  CompanyDetails = null;
  companyId = new FormControl();
  IsActive: Boolean;

  toggle: boolean = false;
  matControl = false;
  selectedCompany: any = "";
  CompName: any;
  CompNewID: any;
  selectedJobTitleID: any = false;
  checkArray: any = [];
  addEditForm: FormGroup;
  uploadfileList = false;
  onscreenList = true;
  displayedColumnsOne: any = [
    "CompanyName",
    "JobTitleName",
    "JobTitleDescription",
    "JobTitleStatus",
    "Status",
    "Message",
  ];
  displayedColumns: any = [
    "CompanyName",
    "CompanySubDivision",
    "ParentName",
    "JobTitleName",
    "JobTitleDescription",
    "CreatedBy",
    "CreatedDate",
    "action",
  ];
  CompanyName: any;
  CompanyNames: any;
  fileUploaded: File;
  storeData: any;
  worksheet: any;
  loginUserid: any;
  jsonData: any;
  SubCompanyHeader = "";
  CompanyNameHeader = "";
  dataSource = new MatTableDataSource();
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  jobTitleLIst: any;
  userId: string;


  applyFilter(event: any, ref?) {
    if (ref) {
      if ((event as HTMLInputElement).value) {
        (event as HTMLInputElement).value = "";
      }
    } else {
      if ((event as HTMLInputElement).value) {
        (event as HTMLInputElement).value = "";
        const filterValue = (event as HTMLInputElement).value;
        this.dataSource.filter = filterValue.trim().toLowerCase();
      } else {
        const filterValue = (event.target as HTMLInputElement).value;
        this.dataSource.filter = filterValue.trim().toLowerCase();
      }
    }
  }

  constructor(
    private jobtitlesservice: JobtitlesService,
    public tostre: ToastrService,
    private locg: LoginComponent,
    private route: Router,
    private routerActive: ActivatedRoute,
    public UserPermission: UserPermissionService,
    private storage: StorageService,
    private adminService:ServiceService,
    public dialog: MatDialog,
  ) {
    this.locg.currentUser.subscribe((res) => {
      // console.log(res, "res..................");
      this.loginUserid = res[0].UserID;
      // console.log(this.loginUserid, " this.loginUserid..................");
    });

    this.CompanyDetails = JSON.parse(this.storage.getData("CompanyDetails"));

    if (this.CompanyDetails) {
      this.CompanyID = parseInt(this.CompanyDetails.CompanyID);
      this.CompanyName = this.CompanyDetails.CompanyName;
      this.IsActive = this.CompanyDetails.IsActive;
      this.CompanyNameHeader =
        this.CompanyDetails.CompanyName +
        " - " +
        this.CompanyDetails.CompanyIndentNumber;
      if (this.CompanyDetails.ParentName) {
        // this.SubCompanyHeader =
        //   'This is a Company Subdivision of Company : ' +
        //   this.CompanyDetails.ParentName +
        //   ' - ' +
        //   this.CompanyDetails.ParentIdentNumber;
        if (
          this.CompanyDetails.ParentName ===
          this.CompanyDetails.ParentCompanyName
        ) {
          this.SubCompanyHeader =
            "This is a Company Subdivision of Company: " +
            this.CompanyDetails.ParentCompanyName +
            " - " +
            this.CompanyDetails.ParentCompanyIndentNumber;
        } else {
          /**
           * if not same
           */
          this.SubCompanyHeader =
            "This is a Subdivision of Company Subdivision: " +
            this.CompanyDetails.ParentCompanyName +
            " - " +
            this.CompanyDetails.ParentCompanyIndentNumber;
        }
      }
    }
    // console.log("Hiting Job Title on every click");
    // routerActive.params.subscribe((x) => {
    //   if (x.hasOwnProperty("id") === true) {
    //     console.log("yes");
    //   } else {
    //     console.log("no");
    //     // this.CompanyID
    //   }
    // });

    this.isCompanySelected();
  }

  isCompanySelected() {
    if (!this.CompanyID) {
      // Swal.fire({ text: "Please first select a Company." });
      this.tostre.error("Please first select a Company.", "", {
        positionClass: "toast-top-right",
      });
      this.route.navigate([
        "products/administration/organizationmanagement/companies",
      ]);
    }
    if (this.CompanyID && !this.CompanyDetails.IsActive) {
      // Swal.fire({
      //   text: "Selected company is inactive. Please select an active company",
      // });
      this.showInvalid(
        "Selected company is inactive. Please select an active company"
      );
      this.route.navigate([
        "products/administration/organizationmanagement/companies",
      ]);
    }
    if (this.CompanyID && this.CompanyDetails.IsArchive) {
      Swal.fire({
        text: "Selected company is archived. Please select an active company",
      });
      this.route.navigate([
        "products/administration/organizationmanagement/companies",
      ]);
    }
  }

  checkCompany() {
    if (this.CompanyID) {
      return true;
    } else {
      Swal.fire({
        text: "Please first select a Company.",
      }).then((result) => {
        this.route.navigate([
          "products/administration/organizationmanagement/companies",
        ]);
      });
      return false;
    }
  }

  ngOnInit() {
    this.userId = this.storage.getUserID();
    if(this.allowWhiteListButton){
        if(this.allowUsersID.length >0){
          this.allowUsersID.forEach(element => {
            if(this.userId == element){
              this.allowAddIPButton = true;
            }
          });
        }
    }
    this.storage.removeData("justCreated");
    if (this.checkCompany()) {
      this.companyDetail();
      this.jobtitlesservice.currentMessage.subscribe((data) => {
        // console.log("let us see what is coming", data);
        if (data == "default message") {
          this.CompanyIDs = this.CompanyID;
          // console.log("TestOne", this.CompanyIDs);
        } else {
          const flag = location.href.split("/").lastIndexOf("updated");
          if (flag > 0) {
            this.CompanyIDs = data;
            this.CompanyID = data;
            // console.log("TestOne ONE", this.CompanyIDs);
          } else {
            this.CompanyIDs = this.CompanyID;
          }
        }
      });

      this.jobtitlesservice.currentMessageName.subscribe((data) => {
        // console.log("let us see what is coming in name", data);
        if (data == "default message") {
          // console.log("TestTwo");
          this.CompanyName = this.CompanyName;
        } else {
          const flag = location.href.split("/").lastIndexOf("updated");
          // console.log("TestTwo TWO");
          if (flag > 0) {
            this.CompanyNameHeader = data;
            this.CompanyName = data;
            // console.log("TestOne ONE", this.CompanyIDs);
          } else {
            this.CompanyName = this.CompanyName;
          }
        }
        // this.CompanyName = data;
        this.companyControl.value = this.CompanyName;
        // this.CompanyName = this.CompanyName;
      });

      this.jobtitlesservice.currentmessageJobId.subscribe((data: any) => {
        this.selectedJobTitleID = data;
      });
      this.GetJobTitleLists(this.CompanyIDs);
      // this.companyControl.value = this.CompanyName;
    }
  }

  private _normalizeValue(value: string): string {
    return value.toLowerCase().replace(/\s/g, "");
  }

  companyDetail() {
    const obj = {
      CompanyID: 0,
      CompanyTypeID: 0,
      StateId: 0,
      Status: 1,
      IsActive: null,
      IsArchive: 0,
      Zip: null,
      Address: null,
      ShortFilter: null,
    };
    this.jobtitlesservice.companysearchlist(obj).subscribe((res) => {
      this.companylist = res.companySearchList;
      if (this.storage.getData("CompanyDetails")) {
        const selectedComp = JSON.parse(this.storage.getData("CompanyDetails"));
        let a = "";
        if (
          this.companylist.some((data) =>
            data.CompanyID === selectedComp.CompanyID
              ? (a = data.CompanyID)
              : ""
          )
        ) {
        } else {
          // Swal.fire({
          //   text: "Selected company is InActive.",
          // }).then((result) => {
          this.showInvalid("Selected company is InActive.");
          this.route.navigate([
            "products/administration/organizationmanagement/companies",
          ]);
          // });
          return false;
        }
      }
      for (let i = 0; i < this.companylist.length; i++) {
        const arr = this.companylist[i].CompanyName;
        this.streets.push({
          companyID: this.companylist[i].CompanyID,
          companyName: this.companylist[i].CompanyName,
          ParentIdentNumber: this.companylist[i].ParentIdentNumber,
          ParentName: this.companylist[i].ParentName,
          CompanyIndentNumber: this.companylist[i].CompanyIndentNumber,
        });
      }
      this.streets.sort((a, b) =>
        a.companyName !== b.companyName
          ? a.companyName < b.companyName
            ? -1
            : 1
          : 0
      );
      this.filteredStreets = this.companyControl.valueChanges.pipe(
        startWith(""),
        map((val: any) => (val.length >= 0 ? this._filter(val) : []))
      );
    });
  }

  _filter(val: any): any[] {
    return this.streets
      .map((x) => x)
      .filter((option) =>
        option.companyName.toLowerCase().includes(val.toLowerCase())
      );
  }

  check(compName, event) {
    this.selectedCompany = compName;
    let id = "";
    if (!event.isUserInput) {
      return;
    }
    if (
      this.companylist.some((data) =>
        data.CompanyName === compName ? (id = data.CompanyID) : ""
      )
    ) {
      this.addEditForm.patchValue({
        CompanyID: parseInt(id),
      });
      this.matControl = false;
      // console.log(this.addEditForm.value);
    }
  }

  checkOne(test) {
    this.filteredStreets = this.companyControl.valueChanges.pipe(
      startWith(""),
      map((val: any) => (val.length >= 0 ? this._filter(val) : []))
    );
    test.blur();
  }

  disableSpecialChar(event) {
    let k;
    k = event.charCode;
    return (
      (k > 64 && k < 91) ||
      (k > 96 && k < 123) ||
      k == 8 ||
      k == 32 ||
      (k >= 48 && k <= 57)
    );
  }

  GetJobTitleLists(CompanyID: any) {
    // const param = {
    //   CompanyID: CompanyID,
    // };
    this.jobtitlesservice.GetJobTitleList(CompanyID).subscribe((data) => {
      this.jobTitleLIst = data.getJobTitleList;
      this.uploadfileList = false;
      this.onscreenList = true;
      if (history.state.data) {
        this.selectedJobTitleID = +history.state.data;
        let j = 0;
        let ind = null;
        data.getJobTitleList.forEach((element) => {
          if (element.JobTitleID == +history.state.data) {
            ind = j;
          }
          j++;
        });
        data.getJobTitleList.splice(
          0,
          0,
          data.getJobTitleList.splice(ind, 1)[0]
        );
      }
      this.dataSource = new MatTableDataSource(data.getJobTitleList);
      this.dataSource.sort = this.sort;
      this.sort.disableClear = true;
      this.CompName = data.getJobTitleList[0].CompanyName;
      this.CompNewID = +data.getJobTitleList[0].CompanyID;
      // console.log("New List details", data.getJobTitleList);
      // if (this.CompNewID != this.CompanyID) {
      //   console.log("Is this hitting here");
      //   this.jobtitlesservice.changeName(this.CompName);
      //   this.jobtitlesservice.changeMessage(this.CompNewID);
      // }
    });
  }

  ChangeProfileStatus(data: any) {
    // console.log(data);
    const msg = data.IsActive ? "deactivate" : "activate";
    // Swal.fire({
    //   text: "Are you sure you want to " + msg + " this?",
    //   showCancelButton: true,
    //   width: "30%",
    //   confirmButtonColor: "#3085d6",
    //   cancelButtonColor: "#d33",
    //   confirmButtonText: "Yes",
    // }).then((result) => {
    //   if (result.value) {
    //     const JobTitle = { JobTitleID: parseInt(data.JobTitleID) };
    //     this.jobtitlesservice
    //       .ChangeJobTitleStatus(JobTitle)
    //       .subscribe((res) => {
    //         if (res.statusCode === 200) {
    //           this.GetJobTitleLists(this.CompanyID);
    //         }
    //       });
    //   }
    // });
    const JobTitle = { JobTitleID: parseInt(data.JobTitleID) };
        this.jobtitlesservice
          .ChangeJobTitleStatus(JobTitle)
          .subscribe((res) => {
            if (res.statusCode === 200) {
              this.tostre.success(this.adminService.statusMsg);
              this.GetJobTitleLists(this.CompanyID);
            }
          });
  }

  editJobTitle(OBJ, JobTitleID, CoID) {
    this.route.navigate([
      "/products/administration/organizationmanagement/jobtitles/editjobtitle/" +
        JobTitleID,
    ]);
  }

  DeleteJobTitle(JobId) {
    Swal.fire({
      // text: "Are you sure you want to delete this Job title?",
      text: this.adminService.deleteMsg,
      showCancelButton: true,
      width: "30%",
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      cancelButtonText: "No",
      confirmButtonText: "Yes",
    }).then((result) => {
      if (result.value) {
        this.jobtitlesservice.deleteJobTitle(JobId).subscribe((res) => {
          if (res.statusCode === 200) {
            //this.showValid(res.message);
            // Swal.fire({ html: res.message });
            // this.showValid("Deleted Successfully");
            this.jobtitlesservice.currentMessage.subscribe((data) => {
              if (data == "default message") {
                this.CompanyID = this.CompanyID;
              } else {
                this.CompanyID = data;
              }
            });
            this.GetJobTitleLists(this.CompanyID);
          }
        });
      }
    });
  }

  showInvalid(msg) {
    this.tostre.warning(msg, "", {
      positionClass: "toast-top-right",
    });
  }
  showValid(validMsg) {
    this.tostre.success(validMsg, "", {
      positionClass: "toast-top-right",
    });
  }
  @ViewChild("test", { static: false }) b;
  changeCompany(companyID, companyName, event, companyObj) {
    if (!event.isUserInput) return;
    // this.GetJobTitleLists(this.CompanyID);
    if (companyID != "") {
      this.CompanyID = +companyID;
      this.CompanyName = companyName;
      this.CompanyNameHeader =
        companyName + " - " + companyObj.CompanyIndentNumber;
      if (companyObj.ParentName) {
        this.SubCompanyHeader =
          "This is a Company Subdivision of Company : " +
          companyObj.ParentName +
          " - " +
          companyObj.ParentIdentNumber;
      } else {
        this.SubCompanyHeader = "";
      }
      this.jobtitlesservice.changeName(this.CompanyName);
      this.jobtitlesservice.changeMessage(this.CompanyID);
      this.GetJobTitleLists(this.CompanyID);
    }
  }

  highlightJobTitle(data: any) {
    if (this.selectedJobTitleID == data.JobTitleID) {
      this.selectedJobTitleID = !this.selectedJobTitleID;
    } else {
      this.selectedJobTitleID = data.JobTitleID;
    }
  }

  uploadedFile(event) {
    this.fileUploaded = event.target.files[0];

    this.readExcel();
  }

  readExcel() {
    const readFile = new FileReader();

    readFile.onload = (e) => {
      this.storeData = readFile.result;

      var data = new Uint8Array(this.storeData);

      var arr = new Array();

      for (var i = 0; i != data.length; ++i)
        arr[i] = String.fromCharCode(data[i]);
      var bstr = arr.join("");

      var workbook = XLSX.read(bstr, { type: "binary" });

      var first_sheet_name = workbook.SheetNames[1];

      this.worksheet = workbook.Sheets[first_sheet_name];

      var range = XLSX.utils.decode_range(this.worksheet["!ref"]);
      range.s.r = 2; // <-- zero-indexed, so setting to 1 will skip row 0
      this.worksheet["!ref"] = XLSX.utils.encode_range(range);

      this.readAsJson(this.loginUserid);
    };
    readFile.readAsArrayBuffer(this.fileUploaded);
  }

  readAsJson(loginUserid) {
    this.jsonData = XLSX.utils.sheet_to_json(this.worksheet, { raw: false });

    //this.jsonData = JSON.stringify(this.jsonData);

    const arrofobj = (this.jobTitleLIst = this.jsonData);
    const result = arrofobj.map((el) => {
      const o = Object.assign({}, el);
      o.CompanyName = o["Company Name"];
      o.JobTitle = o["Job Title"];
      o.JobTitleDescription = o["Job Title Description"];
      o.JobTitleStatus = o["Status"];
      o.UserID = loginUserid;
      o.Status = "";
      o.Message = "";
      o.RecNo = "1";
      return o;
    });

    const length = Object.keys(result).length;
    this.JobtitleImport(result);
  }

  JobtitleImport(obj) {
    // console.log("delivcered data", obj);
    // console.log(
    //   "delivcered data",
    //   Object.keys(obj[0]).includes("JobTitleDescription")
    // );
    let matchKey = Object.keys(obj[0]);
    if (
      matchKey.includes("JobTitleDescription") &&
      matchKey.includes("JobTitle Name")
    ) {
      const data = [];
      obj.forEach((item) => {
        const newObj = {
          RecNo: item.RecNo,
          CompanyName: item["Company Name"],
          JobTitle: item["JobTitle Name"],
          JobTitleDescription: item["JobTitle Description"],
          JobTitleStatus: item["JobTitle Status"],
          UserID: +item.UserID,
          Status: "",
          Message: "",
        };
        data.push(newObj);
      });
      // console.log(data);
      this.jobtitlesservice.importJobtitle(data).subscribe(
        (res: any) => {
          // console.log("dreametr", res);
          if (res.statusCode == 200) {
            this.uploadfileList = true;
            this.onscreenList = false;
            this.dataSource = new MatTableDataSource(
              res.jobtitleimport.recordset
            );
            this.showValid("Processed successfully. Please check the table.");
          }
        },
        (error) => {
          // console.log("not valid pdf");
          if (error.status == 500) {
            Swal.fire({
              text: "Import Failed",
            });
            // console.log("not valid pdf");
          }
        }
      );
    } else {
      this.showInvalid(
        "Uploaded Excel Sheet is Invalid. Please put the right one."
      );
    }
  }

  exportJobList() {
    const data = JSON.parse(JSON.stringify(this.jobTitleLIst));
    const tempData = [];
    data.forEach((item) => {
      delete item.JobTitleID;
      delete item.CompanyID;
      delete item.CompanySubDivision;
      delete item.CreatedDate;
      delete item.CreatedBy;
      delete item.ParentName;

      if (item.IsActive == true) {
        item.IsActive = "Active";
      } else {
        item.IsActive = "Inactive";
      }

      tempData.push({
        "Company Name": item["Company Name"] || item.CompanyName,
        "JobTitle Name": item["JobTitle Name"] || item.JobTitleName,
        "JobTitle Description":
          item["JobTitle Description"] || item.JobTitleDescription,
        "JobTitle Status":
          item["JobTitle Status"] || item.IsActive ? "Active" : "Inactive",
      });
    });

    // console.log("temp data", tempData);
    this.jobtitlesservice.exportAsExcelFile(tempData);
  }

  // openIpaddress() {
  //   const dialogRef = this.dialog.open(IpaddressComponent, {
  //     disableClose: true,
  //       width: "40%",
  //       maxWidth: "100vw",
  //   });

  // }

}
