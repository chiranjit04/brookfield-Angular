import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { environment } from "../../../../../environments/environment";
// import * as logoFile from "../../propertymanagement/patrolzonemanagement/brookfieldlogo1.js";
import  * as logoFile from "src/assets/images/logo/brookfieldlogo";
import { Observable, BehaviorSubject } from "rxjs";
import { Workbook } from "exceljs";
import * as fs from "file-saver";
import * as XLSX from "xlsx";
import { map } from "rxjs/internal/operators/map";

@Injectable({
  providedIn: "root",
})
export class JobtitlesService {
  url: any;
  observable: Observable<any>;

  private messageSource = new BehaviorSubject("default message");
  currentMessage = this.messageSource.asObservable();

  private messageName = new BehaviorSubject("default message");
  currentMessageName = this.messageName.asObservable();

  private messageJobId = new BehaviorSubject("default message");
  currentmessageJobId = this.messageJobId.asObservable();

  constructor(private http: HttpClient) {
    this.url = environment.origin + "api/";
    // this.url = 'http://192.168.0.162:1601/api/';
    // http://198.12.156.249:2004/api/GetJobTitleByJobTitleID
  }
  // Job Title List
  GetJobTitleList(param) {
    try {
      const data = {
        CompanyID: param,
      };
      this.observable = this.http.post(this.url + "GetJobTitleList", data);
      return this.observable;
    } catch (error) {
      throw error;
    }
  }
  addUpdateJobTitle(param) {
    this.observable = this.http.post(this.url + "UpdateJobTitle", param);
    return this.observable;
  }
  GetCompanySubdivision() {
    this.observable = this.http.get(this.url + "GetCompanySubdivision");
  }
  ChangeJobTitleStatus(Jobtitle) {
    this.observable = this.http.post(
      this.url + "ChangeJobTitleStatus",
      Jobtitle
    );
    return this.observable;
  }

  deleteJobTitle(JobtitleId) {
    const options = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
      }),
      body: {
        JobTitleID: parseInt(JobtitleId),
      },
    };
    this.observable = this.http.delete(this.url + "DeleteJobTitle", options);
    return this.observable;
  }

  getJobById(JobtitleId) {
    this.observable = this.http.post(
      this.url + "GetJobTitleByJobTitleID",
      JobtitleId
    );
    return this.observable;
  }

  companysearchlist(param) {
    // companySearchList
    this.observable = this.http
      .post(this.url + "CompanySearchListOM", param)
      .pipe(
        map((elem: any) => {
          return {
            companySearchList: elem.companySearchListOM,
          };
        })
      );
    return this.observable;
  }

  /*add or edit ip apis*/
  updateMachineInfo(param){
   return this.http.post(
      this.url + "jobTitle/UpdateMachineInfo",
      param
    );
  }
  getMachineInformation(param){
    return this.http.post(
       this.url + "jobTitle/GetMachineInformation",
       param
     );
  }
  getMachineInfoList(param){
    return this.http.post(
       this.url + "jobTitle/GetMachineInfoList",
       param
     );
  } 
  getPropertyList(userId) {
    return this.http.get(`${this.url}getProperty/${userId}`);
  }

  /*====================*/

  changeMessage(message: any) {
    this.messageSource.next(message);
  }

  changeName(message: any) {
    this.messageName.next(message);
  }

  changeId(message: any) {
    this.messageJobId.next(message);
  }

  importJobtitle(param) {
    this.observable = this.http.post(this.url + "jobTitleImport", param);
    return this.observable;
  }

  async exportAsExcelFile(json: any[]) {
    console.log("nice json", json);
    const title = "JobTitle Exported Data";
    const header = [
      "Company Name",
      "JobTitle Name",
      "JobTitle Description",
      "JobTitle Status",
    ];

    // Create workbook and worksheet
    const workbook = new Workbook();
    const worksheetOne = workbook.addWorksheet("Instructions");
    const worksheet = workbook.addWorksheet("JobTitle Data");
    const worksheetTwo = workbook.addWorksheet("System Pick Values");

    let objectList = [];
    objectList = json.map((ob) => Object.values(ob));

    console.log(":combat", objectList);

    // Add the Header Image
    worksheet.mergeCells("A1:B1");
    const imageRow = worksheet.getRow(1);
    imageRow.height = 80;

    // Add Image
    const logo = workbook.addImage({
      base64: logoFile.logoBase64,
      extension: "png",
    });

    worksheet.addImage(logo, {
      tl: { col: 0.5, row: 0.5 },
      ext: { width: 350, height: 85 },
    });

    const titleRow = worksheet.addRow([title]);
    titleRow.font = { name: "Calibri", family: 4, size: 16, bold: true };
    worksheet.getRow(2).height = 30;
    worksheet.mergeCells("A2:C2");
    // Add Header Row
    const headerRow = worksheet.addRow(header);

    // Set a specific row height
    headerRow.height = 42.5;

    headerRow.font = { name: "Calibri", family: 4, size: 11, bold: true };
    headerRow.alignment = {
      vertical: "middle",
      horizontal: "center",
    };

    // Cell Style : Fill and Border
    headerRow.eachCell((cell, number) => {
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "0xEAF1DD" },
        bgColor: { argb: "FF0000FF" },
      };
      cell.border = {
        top: { style: "thin" },
        left: { style: "thin" },
        bottom: { style: "thin" },
        right: { style: "thin" },
      };
    });
    // worksheet.addRows(data);

    // Add Data and Conditional Formatting
    objectList.forEach((d) => {
      const row = worksheet.addRow(d);
      row.alignment = { horizontal: "center", wrapText: true };
      const qty = row.getCell(4);
    });

    worksheet.getColumn(1).width = 30;
    worksheet.getColumn(2).width = 30;
    worksheet.getColumn(3).width = 30;
    worksheet.getColumn(4).width = 30;
    worksheet.getColumn(5).width = 30;

    worksheet.addRow([]);

    worksheetOne.getColumn(3).width = 13;
    worksheetOne.getColumn(4).width = 13;

    // Add the Header Image
    worksheetOne.mergeCells("D1:H6");
    // Add Image
    const logoOne = workbook.addImage({
      base64: logoFile.logoBase64,
      extension: "png",
    });

    worksheetOne.addImage(logoOne, "D1:H6");
    worksheetOne.addRow([]);
    worksheetOne.getCell("C7").value =
      "Brookfield Properties Job Titles Spreadsheet";
    worksheetOne.getCell("C7").font = {
      name: "Calibri",
      family: 4,
      size: 16,
      underline: true,
      bold: true,
    };
    worksheetOne.getRow(7).height = 25;
    worksheetOne.addRow([]);
    worksheetOne.addRow([]);

    worksheetOne.getCell("B10").value =
      "Please list the Brookfield Properties, these Properties are customized to represent that company’s organizational structure and related positions of oversight.";
    worksheetOne.getCell("B10").alignment = {
      vertical: "top",
      horizontal: "left",
      wrapText: true,
    };

    worksheetOne.mergeCells("B10", "K13");

    worksheetOne.getCell("B10").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "C9DEC9" },
      bgColor: { argb: "FF0000FF" },
    };

    worksheetOne.getCell("B15").value =
      "Set of Instructions for the Spreadsheet:";
    worksheetOne.getCell("B15").font = {
      name: "Calibri",
      family: 4,
      size: 12,
      bold: true,
    };
    worksheetOne.addRow([]);
    worksheetOne.getCell("B17").value = "GENERAL INFO:";
    worksheetOne.getCell("B23").alignment = { horizontal: "center" };
    worksheetOne.getCell("B17").font = {
      name: "Calibri",
      family: 4,
      size: 12,
      bold: true,
    };
    worksheetOne.getCell("B18").value = "-";
    worksheetOne.getCell("B18").alignment = { horizontal: "right" };
    worksheetOne.getCell("C18").value =
      "Please fill in the required fields to upload data into MAXIMUS.";
    worksheetOne.addRow([]);
    worksheetOne.getCell("B20").value = "-";
    worksheetOne.getCell("B20").alignment = { horizontal: "right" };
    worksheetOne.getCell("C20").value =
      "Dropdown values will appear in each cell if there is a selection to be made,";
    worksheetOne.getCell("C21").value = " otherwise enter appropriate data.";
    worksheetOne.addRow([]);
    worksheetOne.getCell("B23").value = "-";
    worksheetOne.getCell("B23").alignment = { horizontal: "right" };
    worksheetOne.getCell("C23").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "C9DEC9" },
      bgColor: { argb: "FF0000FF" },
    };
    worksheetOne.getCell("C23").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheetOne.getCell("D23").value =
      "Headers in Light Green are Mandatory or Required fields.";
    worksheetOne.getCell("B24").value = "-";
    worksheetOne.getCell("B24").alignment = { horizontal: "right" };
    worksheetOne.getCell("C24").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "" },
      bgColor: { argb: "" },
    };
    worksheetOne.getCell("C24").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheetOne.getCell("D24").value =
      "Headers in White are not Required entry fields.";
    worksheetOne.addRow([]);
    worksheetOne.getCell("B26").value = "-";
    worksheetOne.getCell("B26").alignment = { horizontal: "right" };
    worksheetOne.getCell("C26").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "" },
      bgColor: { argb: "" },
    };
    worksheetOne.getCell("C26").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheetOne.getCell("D26").value =
      "Header cells that include a red triangle at top right provide";
    worksheetOne.getCell("D27").value =
      "information about the field when you mouse over the cell.";

    worksheetOne.addRow([]);

    // Worksheet for System Pick Values
    worksheetTwo.getCell("C2").value = "Active";
    worksheetTwo.getCell("C3").value = "InActive";

    // Generate Excel File with given name
    workbook.xlsx.writeBuffer().then((data: any) => {
      const blob = new Blob([data], {
        type:
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });
      fs.saveAs(blob, "JobTitleExportData.xlsx");
    });
  }
}
