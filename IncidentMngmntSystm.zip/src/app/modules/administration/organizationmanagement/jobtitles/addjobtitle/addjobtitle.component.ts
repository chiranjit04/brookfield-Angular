import {
  Component,
  OnInit,
  Injectable,
  ElementRef,
  ViewChild,
} from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { JobtitlesService } from "../jobtitles.service";
import { FormGroup, FormBuilder, FormArray, Validators } from "@angular/forms";
import { FormControl } from "@angular/forms";
import { Observable } from "rxjs";
import { startWith, map } from "rxjs/operators";
import Swal from "sweetalert2";
import { ToastrService } from "ngx-toastr";
import { StorageService } from "../../../../../services/storage.service";
@Component({
  selector: "app-addjobtitle",
  templateUrl: "./addjobtitle.component.html",
  styleUrls: ["./addjobtitle.component.scss"],
})
export class AddjobtitleComponent implements OnInit {
  // CompanyID: number;
  // JobTitleName: string;
  // JobTitleDescription: string;
  // IsActive = true;
  //// SELECT COMPANY
  companylist: any;
  streets: any[] = [];
  filteredStreets: any;
  companyControl: any = new FormControl();
  submitted = false;
  matControl = false;
  companyId = new FormControl();
  JobTitleName: any = "";
  JobTitleDescription: any = "";

  checkArray: any = [];

  toggle: boolean = false;
  tempSet: string = "";
  temp: any;
  flag: boolean = false;
  userData = null;
  currentUserID = 0;
  addCompanyName: any = "";
  highlightedID: any;
  //// SELECT COMPANY

  addEditForm: FormGroup;
  JobTitleID = this.activeRoute.snapshot.params.id;
  label = "Add job title";

  @ViewChild("job", { static: false })
  job: any;

  selectedCompany: any = "";
  CompanyDetails: any;
  CompanyID: any;
  CompanyName: any;

  constructor(
    public Fbuilder: FormBuilder,
    public tostre: ToastrService,
    private route: Router,
    public activeRoute: ActivatedRoute,
    public jobtitlesservice: JobtitlesService,
    private storage: StorageService
  ) {
    this.userData = JSON.parse(this.storage.getData("UserData"));
    this.currentUserID = this.userData[0].UserID;
    this.CompanyDetails = JSON.parse(this.storage.getData("CompanyDetails"));
    if (this.CompanyDetails) {
      this.CompanyID = parseInt(this.CompanyDetails.CompanyID);
      this.CompanyName = this.CompanyDetails.CompanyName;
    }
  }

  ngOnInit() {
    this.jobtitlesservice.currentMessage.subscribe((data) => {
      if (data == "default message") {
        this.CompanyID = this.CompanyID;
      } else {
        this.CompanyID = data;
        console.log("gotcga", data);
      }
    });
    this.jobtitlesservice.currentMessageName.subscribe((data) => {
      if (data == "default message") {
        this.CompanyName = this.CompanyName;
      } else {
        this.CompanyName = data;
        console.log("gotcga name", data);
      }
    });

    // this.jobtitlesservice.changeMessage(this.CompanyID);

    this.jobtitlesservice.GetJobTitleList(this.CompanyID).subscribe((data) => {
      this.CompanyName = (data.getJobTitleList[0] || {}).CompanyName;
      if (!this.CompanyName) {
        return;
      }
      this.companyId.patchValue(this.CompanyName);
    });

    this.jobtitlesservice.changeId(this.JobTitleID);

    this.addEditForm = this.Fbuilder.group({
      JobTitleID: +[this.JobTitleID ? this.JobTitleID : 0],
      CompanyID: +[this.CompanyID],
      JobTitleName: ["", Validators.required],
      JobTitleDescription: [""],
      UserID: +[this.currentUserID],
      IsActive: ["1"],
    });

    this.companyDetail();
    this.getJobBYId();
    console.log("AddCOmopanyNAme", this.addCompanyName);
    // this.companyId.patchValue(this.CompanyName);
    const getCompanyDet = JSON.parse(
      this.storage.getData("CompanyDetails") || "{}"
    );

    this.companyId.setValue(getCompanyDet.CompanyName);
    this.addEditForm.patchValue({
      CompanyID: parseInt(getCompanyDet.CompanyID),
    });
    console.log("let us see user ID", this.currentUserID);
  }

  private _normalizeValue(value: string): string {
    return value.toLowerCase().replace(/\s/g, "");
  }

  companyDetail() {
    const obj = {
      CompanyID: 0,
      CompanyTypeID: 0,
      StateId: 0,
      Status: 1,
      IsActive: null,
      IsArchive: 0,
      Zip: null,
      Address: null,
      ShortFilter: null,
    };
    this.jobtitlesservice.companysearchlist(obj).subscribe((res) => {
      this.companylist = res.companySearchList;
      if (this.storage.getData("CompanyDetails")) {
        const selectedComp = JSON.parse(this.storage.getData("CompanyDetails"));
      }
      for (let i = 0; i < this.companylist.length; i++) {
        const arr = this.companylist[i].CompanyName;
        this.streets.push({
          companyID: this.companylist[i].CompanyID,
          companyName: this.companylist[i].CompanyName,
        });
      }
      this.filteredStreets = this.companyId.valueChanges.pipe(
        startWith(""),
        map((val: any) => (val.length >= 0 ? this._filter(val) : []))
      );
    });
  }

  _filter(val: any): any[] {
    return this.streets
      .map((x) => x)
      .filter((option) =>
        option.companyName.toLowerCase().includes(val.toLowerCase())
      );
  }

  check(compName, event) {
    this.selectedCompany = compName;
    let id = "";
    if (!event.isUserInput) {
      return;
    }
    if (
      this.companylist.some((data) =>
        data.CompanyName === compName ? (id = data.CompanyID) : ""
      )
    ) {
      this.addEditForm.patchValue({
        CompanyID: parseInt(id),
      });
      this.matControl = false;
      // console.log(this.addEditForm.value);
    }
    this.companyDetail();
  }

  disableSpecialChar(event) {
    let k;
    k = event.charCode;
    return (
      (k > 64 && k < 91) ||
      (k > 96 && k < 123) ||
      k == 8 ||
      k == 32 ||
      (k >= 48 && k <= 57)
    );
  }

  checkingCompany(ids) {
    // console.log("aaa = ", ids.value)
    this.selectedCompany = ids.value;
    this.temp = ids;
    /* if (this.checkArray.length === 0 && this.toggle == false) {
      Swal.fire(
        "Please Select Company or Company Subdivision From The List."
      ).then((x) => {
        ids.focus();
        this.toggle = true;
      });
      return;
    } */
  }

  // checkOne() {
  //   this.checkingCompany(this.temp);
  //   console.log("alrightyyy");
  // }
  // OnCompany(event) {
  //   this.streets.find()
  // }

  addjobtitle() {
    if (this.addEditForm.invalid) {
      if (this.companyId.value === null || this.companyId.value === "") {
        this.matControl = true;
      } else {
        this.matControl = false;
      }
      const msg = "Please fill required field";
      //this.showInvalid(msg);
      this.submitted = true;
      return;
    } else {
      const company: HTMLInputElement = document.getElementById(
        "company"
      ) as HTMLInputElement;
      let selectedCompany = company.value.trim();
      let obj1 = this.companylist.find((x) => x.CompanyName == selectedCompany);
      let index = this.companylist.indexOf(obj1);

      // console.log("form detailsss", this.addEditForm.value); return false
      // if (this.addEditForm.value.CompanyID == "") {
      if (index == -1) {
        console.log("Listt", this.companylist);
        Swal.fire(
          "Please Select Company or Company Subdivision From The List."
        ).then(() => {
          // console.log("workaound");
          this.matControl = true;
          this.job.nativeElement.focus();
        });
      } else {
        this.matControl = false;
        this.addEditForm.value.UserID = +this.currentUserID;
        this.addEditForm.value.CompanyID = parseInt(
          this.addEditForm.value.CompanyID
        );
        this.jobtitlesservice
          .addUpdateJobTitle(this.addEditForm.value)
          .subscribe((res) => {
            // console.log("duplicate", res);
            if (
              res.statusCode === 200) {
              const validMsg = res.message = 'The Record has been saved successfully.';
              this.showValid(validMsg);
              setTimeout(() => {
                this.route.navigate(
                  [
                    "/products/administration/organizationmanagement/jobtitles/updated",
                  ],
                  { state: { data: res.updateJobTitle[0].ReturnMessage } }
                );
              }, 1000);
              // Swal.fire({ html: validMsg }).then(() => {
              //   this.route.navigate([
              //     '/products/administration/organizationmanagement/jobtitles/updated',
              //   ]);
              // });
            } else if (
              res.statusCode === 200 &&
              res.message === "Already Exists"
            ) {
              const validMsg = "Record Already Exists.";
              this.showAlreadyExist(validMsg);
              // Swal.fire({ html: validMsg });
            } else {
              this.showValid('The Record has been saved successfully.');
              setTimeout(() => {
                this.route.navigate([
                  "/products/administration/organizationmanagement/jobtitles/updated",
                ]);
              }, 1000);
              // Swal.fire({ html: res.message }).then(() => {
              //   this.route.navigate([
              //     '/products/administration/organizationmanagement/jobtitles/updated',
              //   ]);
              // });
            }
          });
      }
      // this.addEditForm.value.Rank = parseInt(this.addEditForm.value.Rank);
    }
    // this.jobtitlesservice.addUpdateJobTitle(this.addEditForm.value).subscribe(res => {
    //   console.log(res);
    //   if (res.statusCode === 200) {
    //     const validMsg = res.message;
    //     this.showValid(validMsg);
    //   } else {
    //     this.showInvalid(res.message);
    //   }
    // });
  }

  get controlMat() {
    return this.companyId;
  }
  get jobtitle() {
    return this.addEditForm.controls;
  }

  getJobBYId() {
    if (this.JobTitleID) {
      console.log("Job title ID", this.JobTitleID);
      this.highlightedID = this.JobTitleID;
      this.label = "Edit Job Title";

      const jobTitleId = { JobTitleID: parseInt(this.JobTitleID) };
      this.jobtitlesservice.getJobById(jobTitleId).subscribe((res) => {
        // console.log("what is this", res.getJobTitleByJobTitleID);

        const object = res.getJobTitleByJobTitleID[0];
        console.log("what is thuis", object);
        // console.log("same or not", object);

        this.jobtitlesservice.changeMessage(+object.CompanyID);
        this.jobtitlesservice.changeName(object.CompanyName);

        const company: HTMLInputElement = document.getElementById(
          "company"
        ) as HTMLInputElement;

        company.value = object.CompanyName;
        this.addCompanyName = object.CompanyName;
        this.addEditForm.patchValue({
          CompanyName: object.CompanyName,
          CompanyID: +object.CompanyID,
          JobTitleName: object.JobTitleName,
          JobTitleDescription: object.JobTitleDescription,
        });
      });
    }
  }

  numberOnly(event: any): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  // toastr warning/success message
  showInvalid(msg) {
    this.tostre.warning(msg, "", {
      positionClass: "toast-top-right",
    });
  }

  showValid(validMsg) {
    this.tostre.success(validMsg, "", {
      positionClass: "toast-top-right",
    });
  }
  showAlreadyExist(validMsg) {
    this.tostre.warning(validMsg, "", {
      positionClass: "toast-top-right",
    });
  }

  Jobblur(ref) {
    ref.blur();
  }
}
