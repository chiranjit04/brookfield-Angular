import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KeycontactlistComponent } from './keycontactlist.component';

describe('KeycontactlistComponent', () => {
  let component: KeycontactlistComponent;
  let fixture: ComponentFixture<KeycontactlistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KeycontactlistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KeycontactlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
