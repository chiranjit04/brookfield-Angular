import { Component, OnInit, ViewChild } from "@angular/core";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { ActivatedRoute } from "@angular/router";
import { AddCompanyService } from "../addcompanies/addCompany.service";
import { DataSharingService } from "../dataSharing.service";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { UserPermissionService } from "src/app/services/user-permission.service";

export interface keycontact {
  keycontactname: string;
  keycontactuserid: string;
  keycontactposition: string;
  keycontactcompany: string;
  keycontactsubdiv: string;
  keycontacttype: string;
  keycontactconc: string;
  telephonenum: number;
  keycontactaction: string;
}

const eleDataallperson: keycontact[] = [
  {
    keycontactname: "name1",
    keycontactuserid: "",
    keycontactposition: "",
    keycontactcompany: "",
    keycontactsubdiv: "",
    keycontacttype: "",
    keycontactconc: "",
    telephonenum: 23543553,
    keycontactaction: "",
  },
];

@Component({
  selector: "app-keycontactlist",
  templateUrl: "./keycontactlist.component.html",
  styleUrls: ["./keycontactlist.component.scss"],
})
export class KeycontactlistComponent implements OnInit {
  registerForm: FormGroup;
  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private AddCompanyService: AddCompanyService,
    private DataSharing: DataSharingService,
    public UserPermission: UserPermissionService
  ) {}

  displayedColumnsallperson: string[] = [
    "PersonsName",
    "UserID",
    "PositionTitle",
    "UserProfile",
    "CompanyName",
    "WorkgroupOrProperty",
    "EmailAddress",
    "TelephoneNumber",
    "action",
  ];
  dataSourceallperson = new MatTableDataSource();

  @ViewChild(MatSort, { static: true }) sort: MatSort;

  companyID: any;
  keycontacts: any = [];

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      tablesearch: [""],
    });
    let cid = this.route.snapshot.paramMap.get("id");
    if (cid) {
      this.companyID = atob(cid);
      this.getKeyContacts(this.companyID);
    }
    // console.log("IDS = ", this.companyID)
    this.dataSourceallperson.sort = this.sort;
  }

  getKeyContacts(companyID: any) {
    this.AddCompanyService.GetCompanyContact(companyID).subscribe(
      (response) => {
        let result = response;
        this.keycontacts = result.GetCompanyContact;
        // console.log("Key - ", this.keycontacts.length)
        // this.dataSourceallperson = result.GetCompanyContact
        this.DataSharing.changeKeyContactMessage({
          keyPerson: result.GetCompanyContact,
        });
        this.DataSharing.keyContactStream.subscribe((x: any) => {
          this.dataSourceallperson = new MatTableDataSource(x.keyPerson);
        });
      }
    );
  }

  updateAssignPerson(event, data: any) {
    event.preventDefault();
    // console.log(data)
    let finalData = {
      CompanyContactID: +data.CompanyContactID,
      CompanyID: +this.companyID, //data.CompanyID,
      UserID: +data.ID,
      IsAssigned: 0,
    };
    this.AddCompanyService.UpdateCompanyContact(finalData).subscribe(
      (response) => {
        // console.log(response)
        this.getKeyContacts(this.companyID);
        this.AddCompanyService.GetCompanyAllPerson(this.companyID).subscribe(
          (response) => {
            this.DataSharing.changeAllKeyPersionMessage({
              allPerson: response.GetCompanyAllPerson,
            });
          }
        );
      }
    );
  }
  showcross: boolean;
  applyFilter(event: Event) {
    this.showcross = true;
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSourceallperson.filter = filterValue.trim().toLowerCase();
  }
  dataload() {
    this.registerForm.patchValue({
      tablesearch: "",
    });
    this.getKeyContacts(this.companyID);
  }
}
