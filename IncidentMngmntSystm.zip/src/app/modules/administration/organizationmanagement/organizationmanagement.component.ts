import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-organizationmanagement',
  templateUrl: './organizationmanagement.component.html',
  styleUrls: ['./organizationmanagement.component.scss']
})
export class OrganizationmanagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
