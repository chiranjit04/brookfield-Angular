import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";

@Injectable({
  providedIn: "root",
})
export class DataSharingService {
  private messageSource = new BehaviorSubject("default message");
  private messageObj = new BehaviorSubject("default message");
  private companytableSource = new BehaviorSubject("default Message");
  private booleanSource = new BehaviorSubject("default message");

  private allKeyPersionList = new BehaviorSubject("default Subject");
  private keyContactList = new BehaviorSubject("keyContact");

  private createWorkGroup = new BehaviorSubject("default");
  private assignPropertyWorkGroup = new BehaviorSubject("default");
  private managePropertyWorkGroup = new BehaviorSubject("default");
  private importCompSource = new BehaviorSubject("company Defaut");

  companyCurrentMessage = this.companytableSource.asObservable();
  currentMessage = this.messageSource.asObservable();
  currentObj = this.messageObj.asObservable();
  currentBoolean: any = this.booleanSource.asObservable();

  allKeyPersionStream = this.allKeyPersionList.asObservable();
  keyContactStream = this.keyContactList.asObservable();

  createWorkGroupStream = this.createWorkGroup.asObservable();
  assignPropertyWorkGroupStream = this.assignPropertyWorkGroup.asObservable();
  managePropertyWorkGroupStream = this.managePropertyWorkGroup.asObservable();
  importCompanyStream = this.importCompSource.asObservable();
  constructor() {}

  changeMessage(message: string) {
    this.messageSource.next(message);
    console.log(message)
  }
  changeMessageObj(message: string) {
    this.messageObj.next(message);
  }
  changeCompanyMessage(message: any) {
    this.companytableSource.next(message);
  }
  changeBoolean(message: any) {
    this.booleanSource.next(message);
  }

  changeAllKeyPersionMessage(message: any) {
    this.allKeyPersionList.next(message);
  }
  changeKeyContactMessage(message: any) {
    this.keyContactList.next(message);
  }

  changeCreateWorkGroup(data: any) {
    this.createWorkGroup.next(data);
  }
  changeAssignPropertyWorkGroup(data: any) {
    this.assignPropertyWorkGroup.next(data);
  }
  changeManagePropertyWorkGroup(data: any) {
    this.managePropertyWorkGroup.next(data);
  }

  changeCompImportMessage(data: any) {
    this.importCompSource.next(data);
  }
}
