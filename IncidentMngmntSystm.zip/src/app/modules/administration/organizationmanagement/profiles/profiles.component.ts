import { Component, OnInit, Injectable, ViewChild } from "@angular/core";
import { MatTableDataSource } from "@angular/material/table";
import { ActivatedRoute, Router } from "@angular/router";
import { ProfileServiceService } from "../profiles/profile-service.service";
import Swal from "sweetalert2";
import { ToastrService } from "ngx-toastr";
import * as XLSX from "xlsx";
import * as FileSaver from "file-saver";
import { ModelAssociatedJobComponent } from "./model-associated-job/model-associated-job.component";
import { MatDialog } from "@angular/material/dialog";
import { MatSort, MatSortable } from "@angular/material/sort";
import { Observable } from "rxjs";
import { FormControl } from "@angular/forms";
import { startWith, map } from "rxjs/operators";
import { UserPermissionService } from "../../../../services/user-permission.service";
import { StorageService } from "../../../../services/storage.service";
import { ServiceService } from "./../../service/service.service";
import { SearchKeyPipe } from "src/app/modules/dashboard/search-key.pipe";

export interface PeriodicElement {
  companysubdivision: string;
  company: string;
  profilename: string;
  profiledescription: string;
  createdby: string;
  createddate: string;
  profilerank: string;
  action: string;
}

const ELEMENT_DATA: PeriodicElement[] = [];
@Component({
  selector: "app-profiles",
  templateUrl: "./profiles.component.html",
  styleUrls: ["./profiles.component.scss"],
})
export class ProfilesComponent implements OnInit {
  companylist: any;
  streets: any[] = [];
  filteredStreets: any;
  companyControl: any = new FormControl();
  searchControl: any = new FormControl();
  SubCompanyHeader = "";
  CompanyNameHeader = "";
  constructor(
    public tostre: ToastrService,
    private route: Router,
    public profileService: ProfileServiceService,
    public dialog: MatDialog,
    public UserPermission: UserPermissionService,
    private storage: StorageService,
    private adminService:ServiceService
  ) {
    /* Read user data from storage */
    this.authToken = this.storage.getData("token");
    if (this.authToken == null) {
      this.route.navigate(["/login"]);
      return;
    }
    this.userData = JSON.parse(this.storage.getData("UserData"));
    this.currentUserID = this.userData[0].UserID;

    /* check module permission of the user */
    if (this.UserPermission.checkPermission("access_profiles") == false) {
      this.route.navigate(["/products/list"]);
      this.tostre.warning(
        "You don't have permission to access this module.",
        "",
        {
          positionClass: "toast-top-right",
        }
      );
      return;
    }

    this.CompanyDetails = JSON.parse(this.storage.getData("CompanyDetails"));
    if (this.CompanyDetails) {
      this.CompanyID = this.CompanyDetails.CompanyID;
      this.CompanyName = this.CompanyDetails.CompanyName;
      this.selectedProfileID = this.CompanyDetails.ProfileID;
      this.storage.setData("CompanyID", this.CompanyDetails.CompanyID);
      this.CompanyNameHeader =
        this.CompanyDetails.CompanyName +
        " - " +
        this.CompanyDetails.CompanyIndentNumber;
      if (this.CompanyDetails.ParentName) {
        // this.SubCompanyHeader =
        //   "This is a Company Subdivision of Company : " +
        //   this.CompanyDetails.ParentName +
        //   " - " +
        //   this.CompanyDetails.ParentIdentNumber;
        if (
          this.CompanyDetails.ParentName ===
          this.CompanyDetails.ParentCompanyName
        ) {
          this.SubCompanyHeader =
            "This is a Company Subdivision of Company: " +
            this.CompanyDetails.ParentCompanyName +
            " - " +
            this.CompanyDetails.ParentCompanyIndentNumber;
        } else {
          /**
           * if not same
           */
          this.SubCompanyHeader =
            "This is a Subdivision of Company Subdivision: " +
            this.CompanyDetails.ParentCompanyName +
            " - " +
            this.CompanyDetails.ParentCompanyIndentNumber;
        }
      }
    }

    if (this.CompanyID == 0) {
      this.tostre.error("Please first select a Company.", "", {
        positionClass: "toast-top-right",
      });
      this.route.navigate([
        "products/administration/organizationmanagement/companies",
      ]);
    }
    if (this.CompanyID && !this.CompanyDetails.IsActive) {
      // Swal.fire({
      //   text: "Selected company is inactive. Please select an active company",
      // });
      this.showInvalid(
        "Selected company is inactive. Please select an active company"
      );
      this.route.navigate([
        "products/administration/organizationmanagement/companies",
      ]);
    }
    if (this.CompanyID && this.CompanyDetails.IsArchive) {
      Swal.fire({
        text: "Selected company is archived. Please select an active company",
      });
      this.route.navigate([
        "products/administration/organizationmanagement/companies",
      ]);
    }
  }
  selectedProfileID: any = false;
  CompanyDetails = null;
  CompanyID = 0;
  CompanyName = "";
  isChanged = false;

  authToken = null;
  userData = null;
  currentUserID = false;

  uploadfileList: boolean = false;
  onscreenList = true;
  profileImportData: any;

  /** Upload Excel start  */

  title = "read-excel-in-angular8";
  storeData: any;
  jsonData: any;
  fileUploaded: File;
  worksheet: any;
  htmlData: any;

  profilelist: any;

  displayedColumnsOne: string[] = [
    "companyname",
    "profilename",
    "profiledescription",
    "Rank",
    "profilestatus",
    "status",
    "message",
  ];
  // dataSourceOne = this.profileImportData;
  dataSourceOne = new MatTableDataSource();

  displayedColumns: string[] = [
    "CompanyName",
    "CompanySubDivision",
    "ParentName",
    "ProfileName",
    "ProfileDescription",
    "CreatedBy",
    "CreatedDate",
    "ProfileRank",
    "IsAssociateJobTitle",
    "action",
  ];
  // dataSource = new MatTableDataSource(ELEMENT_DATA);
  // profileDataSource = new MatTableDataSource(this.profilelist);
  profileDataSource = new MatTableDataSource();
  @ViewChild(MatSort, null) sort: MatSort;

  ApiData: any;

  ngOnInit() {
    if (this.checkCompany()) {
      this.companyDetail();
      this.profileDataSource.sort = this.sort;
      
      if (this.storage.getData("profileCompany")) {
        let profileCompany = JSON.parse(this.storage.getData("profileCompany"));
        this.companyControl.value = profileCompany.CompanyName;
        this.CompanyName = profileCompany.CompanyName;
        this.getProfileLIsts(profileCompany.CompanyID, this.currentUserID);
        this.storage.removeData("profileCompany");
      } else {
        this.getProfileLIsts(this.CompanyID, this.currentUserID);
        this.companyControl.setValue(this.CompanyName);
      }
    }
  }

  /* Upload file */
  openFileBrowser(event: any) {
    event.preventDefault();
    let element: HTMLElement = document.getElementById("file") as HTMLElement;
    element.click();
  }

  viewjobtitile(element) {
    //console.log(element)
    const dialogRef = this.dialog.open(ModelAssociatedJobComponent, {
      width: "400px",
      panelClass: "my-dialog-container-class2",
      data: { ProfileID: element.ProfileID },
    });
    dialogRef.afterClosed().subscribe((result) => {});
  }

  getCustomCss(element){
    if (element.IsAssociateJobTitle == '0' ||
    element.IsAssociateJobTitle == '1') {
      return 'conditionalBlock';
    }
  }

  uploadedFile(event) {
    this.fileUploaded = event.target.files[0];
    this.readExcel();
  }
  readExcel() {
    let readFile = new FileReader();

    readFile.onload = (e) => {
      this.storeData = readFile.result;

      var data = new Uint8Array(this.storeData);

      var arr = new Array();

      for (var i = 0; i != data.length; ++i)
        arr[i] = String.fromCharCode(data[i]);

      var bstr = arr.join("");

      var workbook = XLSX.read(bstr, { type: "binary" });

      var first_sheet_name = workbook.SheetNames[1];

      this.worksheet = workbook.Sheets[first_sheet_name];

      var range = XLSX.utils.decode_range(this.worksheet["!ref"]);
      range.s.r = 2; // <-- zero-indexed, so setting to 1 will skip row 0
      this.worksheet["!ref"] = XLSX.utils.encode_range(range);

      this.readAsJson(this.currentUserID);
    };

    readFile.readAsArrayBuffer(this.fileUploaded);
  }

  // Upload Excel End

  /** Read As Json */

  readAsJson(currentUserID) {
    this.jsonData = XLSX.utils.sheet_to_json(this.worksheet, { raw: false });

    //this.jsonData = JSON.stringify(this.jsonData);

    var arrofobj = (this.profilelist = this.jsonData);
    // this.patrolZoneImportList = this.jsonData
    console.log(arrofobj)

    var result = arrofobj.map(function (el) {
      var o = Object.assign({}, el);
      o.UserID = +currentUserID;
      o.Status = "";
      o.Message = "";
      o.RecNo = "";
      return o;
    });
    let length = Object.keys(result).length;

    this.profileImport(result);
    // this.getPropertyPatrolZoneList(this.PropertyID, 0);
  }
  newObjArr = [];
  profileImport(obj) {
    console.log("obj====final hit to service --->>>>", obj);
    console.log("obj is here", obj);
    let matchProfile =
      Object.keys(obj[0]).includes("Profile Name") &&
      Object.keys(obj[0]).includes("Rank");
    console.log("test", matchProfile);

    if (matchProfile) {
      this.uploadfileList = true;
      this.onscreenList = false;
      if (obj.length == 0) {
        Swal.fire({
          text: "No Data Found ",
        });
        return;
      }

      for (var i = 0; i < obj.length; i++) {
        let newObj = {
          RecNo: obj[i].RecNo,
          CompanyName: obj[i]["Company Name"],
          ProfileName: obj[i]["Profile Name"],
          ProfileDescription: obj[i]["Profile Description"],
          Rank: obj[i].Rank,
          ProfileStatus: obj[i]["Profile Status"],
          UserID: +obj[i].UserID,
          Status: "",
          Message: "",
        };
        this.newObjArr.push(newObj);
      }
      let passingArray = this.newObjArr;
      console.log(passingArray);
      let result: any;
      this.profileService.ProfileImport(passingArray).subscribe(
        (res) => {
          result = res;
          if (result.statusCode == 200) {
            // Swal.fire({
            //   text: 'Profile Imported Successfully',
            // });
            this.profileImportData = result.profileImport.recordsets[0];
            this.dataSourceOne = new MatTableDataSource(this.profileImportData);
            
            this.showValid("Processed successfully. Please check the table.");
          }
          // this.profileImportData = result.profileImport.recordsets[0]
          // this.dataSourceOne = new MatTableDataSource(this.profileImportData)
        },
        (error) => {
          if (error.status == 500) {
            Swal.fire({
              text: "Import Failed",
            });
          }
        }
      );
    } else {
      this.showInvalid(
        "Uploaded Excel Sheet is Invalid. Please put the right one."
      );
    }
  }

  exportProfileList() {
    let data = JSON.parse(JSON.stringify(this.profilelist));
    console.log(this.profilelist);
    let tempData = [];
    data.forEach(function (item, i) {
      delete item.ProfileID;
      delete item.CompanyID;
      delete item.CompanySubDivision;
      delete item.CreatedDate;
      delete item.CreatedBy;
      delete item.RecordTimeStamp;
      delete item.IsAssociateJobTitle;
      delete item.ParentName;
      if (item.IsActive == 1) {
        item.IsActive = "Active";
      } else {
        item.IsActive = "Inactive";
      }
      tempData.push(item);
    });
    console.log(tempData);
    this.profileService.exportAsExcelFile(tempData);
  }

  applyFilter(event: any) {
    // console.log("new reference", event.target.value);
    // if (ref) {
    //   if ((event as HTMLInputElement).value) {
    //     (event as HTMLInputElement).value = "";
    //     this.CompanyNameHeader = "";
    //   }
    // } else {
    if ((event as HTMLInputElement).value) {
      (event as HTMLInputElement).value = "";
      const filterValue = (event as HTMLInputElement).value;
      this.profileDataSource.filter = filterValue.trim().toLowerCase();
    } else {
      const filterValue: any = (event.target as HTMLInputElement).value;
      console.log("Three", filterValue);
      this.profileDataSource.filter = filterValue.trim().toLowerCase();
    }
    // }
  }

  clearCompanyField() {
    this.companyControl.setValue("");
    this.searchControl.setValue("");
    this.CompanyNameHeader = "";
    this.SubCompanyHeader = "";
    this.profilelist = [];
    this.profileDataSource = new MatTableDataSource(this.profilelist);
  }

  clearSearchField() {
    this.searchControl.setValue("");
    this.profileDataSource = new MatTableDataSource(this.profilelist);
  }

  checkOne(test) {
    console.log(test.value);
    this.filteredStreets = this.companyControl.valueChanges.pipe(
      startWith(""),
      map((val: any) => (val.length >= 0 ? this._filter(val) : []))
    );
    test.blur();
  }

  getProfileLIsts(CompanyID, UserID) {
    const obj = {
      CompanyID: +CompanyID,
      UserID: +UserID,
    };
    let result: any;
    this.profileService.getProfileList(obj).subscribe((res) => {
      result = res;
      //   if (this.storage.getData('justCreated')) {
      //     const justCreatedID = JSON.parse(this.storage.getData('justCreated'));
      //     this.selectedProfileID = justCreatedID;
      //   }
      if (history.state.data) {
        this.selectedProfileID = +history.state.data;
        let j = 0;
        let ind = null;
        result.getProfileList.forEach((element) => {
          if (element.ProfileID == +history.state.data) {
            ind = j;
          }
          j++;
        });
        result.getProfileList.splice(
          0,
          0,
          result.getProfileList.splice(ind, 1)[0]
        );
      }
      this.profilelist = result.getProfileList;
      // this.profilelist.forEach((data) => {
      //   return (data.ProfileRank = "0" + data.ProfileRank);
      // });
      let profileRank = result.getProfileList.map(
        (data) => "0" + data.ProfileRank
      );

      console.log("rankins", profileRank, this.profilelist);
      // this.profilelist.sort((a: any, b: any) => b.CreatedDate - a.CreatedDate );
      this.profileDataSource = new MatTableDataSource(this.profilelist);
      this.profileDataSource.sort = this.sort;
      this.sort.disableClear = true;

    });
  }

  checkCompany() {
    if (this.CompanyID && this.CompanyDetails.IsActive) {
      return true;
    } else if (this.CompanyDetails.IsActive == false) {
      // Swal.fire({
      //   text: "Selected company is inactive.",
      // }).then((result) => {
      this.showInvalid("Selected company is inactive.");
      this.route.navigate([
        "products/administration/organizationmanagement/companies",
      ]);
      // });
      return false;
    } else {
      Swal.fire({
        text: "Please first select a Company.",
      }).then((result) => {
        this.route.navigate([
          "products/administration/organizationmanagement/companies",
        ]);
      });
      return false;
    }
  }

  editProfile(OBJ, PROid, CoID) {
    // this.setProfileToLocalStorage(OBJ);
    this.storage.setData("CompanyForProfile", JSON.stringify(OBJ));
    // this.route.navigate(['/products/administration/organizationmanagement/editprofile', PROid]);
    this.storage.setData(
      "profileCompany",
      JSON.stringify({
        CompanyID: CoID,
        CompanyName: this.companyControl.value,
      })
    );
    this.route.navigate([
      "/products/administration/organizationmanagement/profile/editprofile/" +
        PROid,
    ]);
  }

  setProfileToLocalStorage(data: any) {
    console.log("data", data);
    this.storage.setData("CompanyDetails", JSON.stringify(data));
    this.selectedProfileID = data.ProfileID;
    // console.log("this.CompanyID", this.CompanyID)
    // this.getProfileLIsts(this.CompanyID, this.currentUserID)
  }

  onSelectProfileRow(value: any) {
    if (this.selectedProfileID == value) {
      this.selectedProfileID = !this.selectedProfileID;
    } else {
      this.selectedProfileID = value;
    }
  }

  changeProfileStatus(IsActive, ProfileID) {
    //console.log(data)
    // let msg = IsActive ? "deactivate" : "activate";
    // Swal.fire({
    //   text: "Are you sure you want to " + msg + " this?",
    //   showCancelButton: true,
    //   width: "30%",
    //   confirmButtonColor: "#3085d6",
    //   cancelButtonColor: "#d33",
    //   confirmButtonText: "Yes",
    // }).then((result) => {
    //   if (result.value) {
    //     const Profile = { ProfileID: parseInt(ProfileID) };
    //     this.profileService.changeProfilestatus(Profile).subscribe((res) => {
    //       if (res.statusCode === 200) {
    //         this.getProfileLIsts(this.CompanyID, this.currentUserID);
    //       }
    //     });
    //   }
    // });
    const Profile = { ProfileID: parseInt(ProfileID) };
    this.profileService.changeProfilestatus(Profile).subscribe((res) => {
      if (res.statusCode === 200) {
        this.tostre.success(this.adminService.statusMsg);
        this.getProfileLIsts(this.CompanyID, this.currentUserID);
      }
    });

    // const Profile = { ProfileID: parseInt(ProfileID) };
    // this.profileService.changeProfilestatus(Profile).subscribe(res => {
    //   if (res.statusCode === 200) {
    //     this.getProfileLIsts(this.CompanyID, this.currentUserID);
    //   }
    // });
  }

  companyDetail() {
    const obj = {
      CompanyID: 0,
      CompanyTypeID: 0,
      StateId: 0,
      Status: 1,
      IsActive: null,
      IsArchive: 0,
      Zip: null,
      Address: null,
      ShortFilter: null,
    };

    this.profileService.companysearchlist(obj).subscribe((res) => {
      this.companylist = res.companySearchList;
      if (this.storage.getData("CompanyDetails")) {
        const selectedComp = JSON.parse(this.storage.getData("CompanyDetails"));
      }
      for (let i = 0; i < this.companylist.length; i++) {
        const arr = this.companylist[i].CompanyName;
        this.streets.push({
          companyID: this.companylist[i].CompanyID,
          companyName: this.companylist[i].CompanyName,
          ParentIdentNumber: this.companylist[i].ParentIdentNumber,
          ParentName: this.companylist[i].ParentName,
          CompanyIndentNumber: this.companylist[i].CompanyIndentNumber,
        });
      }
      this.streets.sort((a, b) =>
        a.companyName !== b.companyName
          ? a.companyName < b.companyName
            ? -1
            : 1
          : 0
      );
      this.filteredStreets = this.companyControl.valueChanges.pipe(
        startWith(""),
        map((val: any) => (val.length >= 0 ? this._filter(val) : []))
      );
      console.log(this.filteredStreets);
    });
  }

  _filter(val: any): any[] {
    return this.streets
      .map((x) => x)
      .filter((option) =>
        option.companyName.toLowerCase().includes(val.toLowerCase())
      );
  }

  DeleteProfile(ProID) {
    Swal.fire({
      // text: "Are you sure you want to delete profile?",
      text: this.adminService.deleteMsg,
      showCancelButton: true,
      width: "30%",
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes",
      cancelButtonText: "No",
    }).then((result) => {
      if (result.value) {
        this.profileService.DeleteProfiles(ProID).subscribe((res) => {
          if (res.statusCode === 200) {
            const msg = "Profile Deleted";
            // Swal.fire({html: msg, });
            if (this.storage.getData("CompanyForProfile")) {
              let profileCompany = JSON.parse(
                this.storage.getData("CompanyForProfile")
              );
              let cid = profileCompany.CompanyID;
              this.getProfileLIsts(cid, this.currentUserID);
              this.storage.removeData("CompanyForProfile");
            } else {
              this.getProfileLIsts(this.CompanyID, this.currentUserID);
            }
            // this.showValid(msg);
          } else {
            const msg = "Something went wrong";
            Swal.fire({
              html: msg,
            });
            //this.showInvalid(msg);
          }
        });
      }
    });
  }

  // toastr warning/success message
  showInvalid(msg) {
    this.tostre.warning(msg, "", {
      positionClass: "toast-top-right",
    });
  }
  showValid(validMsg) {
    this.tostre.success(validMsg, "", {
      positionClass: "toast-top-right",
    });
  }
  gotopatrollist() {
    window.location.reload();
    //this.router.navigate(['products/administration/propertymanagement']);
  }
  exportImportData(): void {
    let data = JSON.parse(JSON.stringify(this.profilelist));
    let tempData = [];
    data.forEach(function (item, i) {
      delete item.RecNo;
      delete item.UserID;
      delete item.Status;
      delete item.Message;
      tempData.push(item);
    });
    this.profileService.exportAsExcelFile(tempData);
  }
  changeCompany(companyID, companyName, event, companyObj) {
    // // if (!event.isUserInput) return;
    // if (companyID != "") {
    //   this.isChanged = true;
    //   this.CompanyID = companyID;
    //   this.CompanyName = companyName;
    //   this.storage.setData("profileCompany", JSON.stringify({ "CompanyID": companyID, "CompanyName": companyName }))
    //   this.storage.setData("CompanyForProfile", JSON.stringify({ "CompanyID": companyID, "CompanyName": companyName }))
    //   this.CompanyNameHeader = companyName + " - " + companyObj.CompanyIndentNumber;
    //   if (companyObj.ParentName) {
    //     this.SubCompanyHeader = "This is a Company Subdivision of Company : " + companyObj.ParentName + " - " + companyObj.ParentIdentNumber;
    //   }
    //   else {
    //     this.SubCompanyHeader = "";
    //   }
    //   this.getProfileLIsts(companyID, this.currentUserID);
    // }
    // else {
    //   this.profileDataSource = new MatTableDataSource(this.profilelist);
    // }
    if (!event.isUserInput) return;
    // this.GetJobTitleLists(this.CompanyID);
    if (companyID != "") {
      this.CompanyID = +companyID;
      this.CompanyName = companyName;
      this.storage.setData(
        "profileCompany",
        JSON.stringify({ CompanyID: companyID, CompanyName: companyName })
      );
      this.storage.setData(
        "CompanyForProfile",
        JSON.stringify({ CompanyID: companyID, CompanyName: companyName })
      );
      this.CompanyNameHeader =
        companyName + " - " + companyObj.CompanyIndentNumber;
      if (companyObj.ParentName) {
        this.SubCompanyHeader =
          "This is a Company Subdivision of Company : " +
          companyObj.ParentName +
          " - " +
          companyObj.ParentIdentNumber;
      } else {
        this.SubCompanyHeader = "";
      }
      this.getProfileLIsts(companyID, this.currentUserID);
    } else {
      this.profileDataSource = new MatTableDataSource(this.profilelist);
    }
  }
}
