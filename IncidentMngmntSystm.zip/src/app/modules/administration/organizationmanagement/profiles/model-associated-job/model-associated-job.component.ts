import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material';
import { ProfileServiceService } from '../profile-service.service';

@Component({
  selector: 'app-model-associated-job',
  templateUrl: './model-associated-job.component.html',
  styleUrls: ['./model-associated-job.component.scss']
})
export class ModelAssociatedJobComponent implements OnInit {
  associateJobList: any;
  ProfileID: any;
  constructor(private ProfileServiceService: ProfileServiceService, @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit() {

    this.ProfileID = this.data.ProfileID;
    this.getJobProfile(this.ProfileID);
  }

  getJobProfile(ProfileID) {

    const obj = {
      ProfileId: +ProfileID
    }
    let result: any
    this.ProfileServiceService.GetJobProfile(obj).subscribe(res => {

      result = res
      this.associateJobList = result.getJobProfile
    })
  }

}
