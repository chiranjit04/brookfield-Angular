import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModelAssociatedJobComponent } from './model-associated-job.component';

describe('ModelAssociatedJobComponent', () => {
  let component: ModelAssociatedJobComponent;
  let fixture: ComponentFixture<ModelAssociatedJobComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModelAssociatedJobComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModelAssociatedJobComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
