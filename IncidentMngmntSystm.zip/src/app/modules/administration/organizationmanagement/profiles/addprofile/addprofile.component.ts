import { Component, ElementRef, OnInit, ViewChild } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { ProfileServiceService } from "../../profiles/profile-service.service";
import {
  FormGroup,
  FormBuilder,
  FormArray,
  Validators,
  FormControl,
} from "@angular/forms";
import Swal from "sweetalert2";
import { ToastrService } from "ngx-toastr";
import { startWith, map } from "rxjs/operators";
import { Observable, from, EMPTY } from "rxjs";
import { JobtitlesService } from "../../jobtitles/jobtitles.service";
import { Validation } from "src/app/shared/common-validation";
import { StorageService } from "../../../../../services/storage.service";
@Component({
  selector: "app-addprofile",
  providers: [Validation, ProfileServiceService],
  templateUrl: "./addprofile.component.html",
  styleUrls: ["./addprofile.component.scss"],
})
export class AddprofileComponent implements OnInit {
  @ViewChild("companyP", { static: false, read: ElementRef })
  defaultCompShow: ElementRef;

  CompanyDetails = null;
  CompanyID = 0;
  CompanyName = "";
  companylist: any;
  streets: any[] = [];
  filteredStreets: any;

  authToken = null;
  userData = null;
  currentUserID = false;

  submitted = false;
  matControl = false;
  control: any = new FormControl();

  addEditForm: FormGroup;
  profileId = this.activeRoute.snapshot.params.id;
  label = "Add profile";
  profileOpLabel = "Add Profile";
  constructor(
    public Fbuilder: FormBuilder,
    public tostre: ToastrService,
    private route: Router,
    public activeRoute: ActivatedRoute,
    public profileService: ProfileServiceService,
    public forCompanyList: JobtitlesService,
    public customValiadator: Validation,
    private storage: StorageService
  ) {
    this.CompanyDetails = JSON.parse(this.storage.getData("CompanyForProfile"));

    console.log(this.CompanyDetails);
    if (this.CompanyDetails) {
      this.CompanyID = this.CompanyDetails.CompanyID;
      this.CompanyName = this.CompanyDetails.CompanyName;
      this.storage.setData("CompanyID", this.CompanyDetails.CompanyID);
    }
    this.authToken = this.storage.getData("token");
    this.userData = JSON.parse(this.storage.getData("UserData"));
    this.currentUserID = this.userData[0].UserID;
  }
  ngOnInit() {
    this.storage.removeData("justCreated");
    this.companyDetail();
    this.addEditForm = this.Fbuilder.group({
      ProfileID: [this.profileId ? this.profileId : 0],
      CompanyID: [this.CompanyID],
      ProfileName: ["", Validators.required],
      ProfileDescription: [""],
      Rank: ["", Validators.required],
      UserID: +this.currentUserID,
    });
    this.profileById();
    if (this.activeRoute.snapshot.params.id == undefined) {
      this.control.value = this.CompanyName;
    } else {
      this.profileOpLabel = "Edit";
    }
    if (this.storage.getData("profileCompany")) {
      let profileCompany = JSON.parse(this.storage.getData("profileCompany"));
      this.control.value = profileCompany.CompanyName;
      this.addEditForm.patchValue({ CompanyID: profileCompany.CompanyID });
      //this.storage.removeData("profileCompany");
    }
  }
  getCompanyDetail(compName, event) {
    let id = "";
    if (!event.isUserInput) {
      return;
    }
    if (
      this.companylist.some((data) =>
        data.CompanyName === compName ? (id = data.CompanyID) : ""
      )
    ) {
      this.addEditForm.patchValue({
        CompanyID: parseInt(id),
      });
      this.matControl = false;
    }
    this.companyDetail();
  }

  companyDetail() {
    this.profileService.GetCompanySubdivision().subscribe((res) => {
      this.companylist = res.companySearchList;
      if (this.storage.getData("CompanyForProfile")) {
        const selectedComp = JSON.parse(
          this.storage.getData("CompanyForProfile")
        );
      }
      for (let i = 0; i < this.companylist.length; i++) {
        const arr = this.companylist[i].CompanyName;
        this.streets.push({
          companyID: this.companylist[i].CompanyID,
          companyName: this.companylist[i].CompanyName,
        });
      }
      let comp: any = this.storage.getData("CompanyDetails");
      this.filteredStreets = this.control.valueChanges.pipe(
        startWith(""),
        map((val: any) => (val.length >= 0 ? this._filter(val) : []))
      );
      if (!comp) {
        return;
      }

      // let companyDetails = this.companylist.find((data) =>
      //   data.CompanyName === comp.CompanyName ? (id = data.CompanyID) : ""
      // )

      comp = JSON.parse(comp);
      this.control.setValue(comp.CompanyName);
      this.addEditForm.patchValue({ CompanyID: comp.CompanyID });
      // this.getCompanyDetail(comp.CompanyName, { isUserInput: true });
    });
  }

  _filter(val: any): any[] {
    return this.streets
      .map((x) => x)
      .filter((option) =>
        option.companyName.toLowerCase().includes(val.toLowerCase())
      );
  }

  get profileVal() {
    return this.addEditForm.controls;
  }

  addProfile() {
    if (this.addEditForm.invalid) {
      if (this.control.value === null || this.control.value === "") {
        this.matControl = true;
      } else {
        this.matControl = false;
      }
      // this.tostre.success("Please fill required field.");
      this.submitted = true;
      return;
    } else {
      console.log(this.companylist);
      if (
        this.companylist.some(
          (data) => data.CompanyName === this.control.value.trim()
        )
      ) {
        console.log("this.addEditForm.value", this.addEditForm.value);
        this.addEditForm.value.Rank = parseInt(this.addEditForm.value.Rank);
        this.addEditForm.value.CompanyID = parseInt(
          this.addEditForm.value.CompanyID
        );

        this.profileService
          .addProfile(this.addEditForm.value)
          .subscribe((res) => {
            console.log(res);
            // && res.message === 'Already Exists'
            if (res.statusCode === 200) {
              const validMsg = res.message;
              // this.tostre.success(validMsg);
              if (res.message === "Already Exists") {
                this.tostre.error(validMsg);
              } else {
                this.tostre.success('The Record has been saved successfully.');
                // this.storage.setData('justCreated', JSON.stringify(res.updateProfile[0].ReturnMessage));
                this.route.navigate(
                  ["/products/administration/organizationmanagement/profile"],
                  { state: { data: res.updateProfile[0].ReturnMessage } }
                );
              }
            } else {
              this.tostre.warning(res.message);
            }
          });
      } else {
        // this.tostre.warning(
        //   "Please Select Company or Company Subdivision From The List."
        // );
        // console.log("workaound");
        this.submitted = true;
        this.matControl = true;
      }
    }
    // this.route.navigate(['/products/administration/organizationmanagement/profile']);
  }

  profileById() {
    if (this.profileId) {
      this.label = "Edit";
      const ProId = { ProfileID: parseInt(this.profileId) };
      this.profileService.GetProfileById(ProId).subscribe((res) => {
        if (res.statusCode === 200) {
          const object = res.getProfileByProfileID[0];
          const company: HTMLInputElement = document.getElementById(
            "company"
          ) as HTMLInputElement;
          // company.value = object.CompanyName;
          this.addEditForm.patchValue({
            CompanyID: object.CompanyID,
            ProfileName: object.ProfileName,
            ProfileDescription: object.ProfileDescription,
            Rank: object.Rank,
          });
          this.control.patchValue(object.CompanyName);
        }
      });
    }
  }

  numberOnly(event: any): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  // toastr warning/success message
  showInvalid(msg) {
    this.tostre.error(msg, "", {
      positionClass: "toast-top-right",
    });
  }

  showValid(validMsg) {
    debugger;
    this.tostre.success(validMsg, "", {
      positionClass: "toast-top-right",
    });
  }

  onCompanyBlur(ref) {
    ref.blur();
  }
}
