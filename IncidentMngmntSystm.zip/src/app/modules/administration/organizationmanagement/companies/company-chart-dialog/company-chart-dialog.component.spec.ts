import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompanyChartDialogComponent } from './company-chart-dialog.component';

describe('CompanyChartDialogComponent', () => {
  let component: CompanyChartDialogComponent;
  let fixture: ComponentFixture<CompanyChartDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompanyChartDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompanyChartDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
