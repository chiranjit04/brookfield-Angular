import {
  Component,
  OnInit,
  Inject,
  Renderer2,
  ElementRef,
  ViewChild,
  AfterViewInit,
} from "@angular/core";
import { CompanyService } from "../companies.service";
import { PropertyDetailService } from "../../../propertymanagement/propertydetail/propertyDetail.service";
import html2canvas from "html2canvas";
import { StorageService } from "../../../../../services/storage.service";
import * as pdfMake from "pdfmake";
import pdfFonts from "pdfmake/build/vfs_fonts";
pdfMake.vfs = pdfFonts.pdfMake.vfs;

declare var google: any;

import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from "@angular/material/dialog";
@Component({
  selector: "app-company-chart-dialog",
  templateUrl: "./company-chart-dialog.component.html",
  styleUrls: ["./company-chart-dialog.component.scss"],
})
export class CompanyChartDialogComponent implements OnInit, AfterViewInit {
  defaultImageUrl: string =
    location.origin + "/assets/images/icons/company.png";
  defaultScale: any = 1.0;
  relationList: any;
  zoomIn: number = 1.0;

  @ViewChild("clicked", { static: false }) clicked;

  constructor(
    private companyService: CompanyService,
    public companyDialogRef: MatDialogRef<CompanyChartDialogComponent>,
    private renderer: Renderer2,
    private companyChartOper: PropertyDetailService,
    private storage: StorageService
  ) {}

  ngOnInit() {}
  initiate(company) {
    this.companyService
      .getCompanyChart({
        CompanyId: +company.CompanyID,
      })
      .subscribe(async (companyRelationList) => {
        let relData = await this.modifyData(
          companyRelationList.UpdateCompanyContact[0]
        );
        google.charts.load("visualization", "1", { packages: ["orgchart"] });
        google.charts.setOnLoadCallback(this.drawChart);
      });
  }

  async modifyData(listCompany) {
    let dataSource = [];

    listCompany.forEach((elem, index) => {
      dataSource.push([
        {
          v: elem.CompanyId.toString(),
          // f: `
          // 	 <div class='row'  style='width:200px'>
          //       	<span class='text-center mt-1'>${elem.CompanyName}</span>
          //       </div>
          //    <div>

          // `,
          f: `
          <div
              class="google-visualization-orgchart-node"
              style="display: inline-block; padding: 3px; margin: 5px;background: transparent; border: none"
            >
              ${elem.CompanyName}
            </div>
          `,
        },
        index === 0 ? "" : elem.CompanyParentId.toString(),
        "",
      ]);
    });
    this.relationList = dataSource;
    return;
  }
  /**
 * 
 * @param elem 
 * 	<!--	<div class='col-3'>
                		<!-- <img class='img-thumbnail' src='${this.defaultImageUrl}' height=50 width=50 alt='image/jpg'> -->
                </div>
                <div class='col-9'> -->
 * @param index 
 */
  // getParentId(elem, index) {
  //   if (index === 0) {
  //     return "";
  //   } else {
  //     //   elem.CompanyParentId === null ||
  //     // elem.CompanyParentId === 0 ||
  //     // elem.CompanyParentId === undefined
  //     //   ? ""
  //     return elem.CompanyParentId.toString();
  //     // ""
  //   }
  // }
  drawChart = () => {
    // tslint:disable-next-line
    var data = new google.visualization.DataTable();
    data.addColumn("string", "Name");
    data.addColumn("string", "Manager");
    data.addColumn("string", "ToolTip");

    // For each orgchart box, provide the name, manager, and tooltip to show.

    data.addRows(this.relationList);

    // Create the chart.
    var chart = new google.visualization.OrgChart(
      document.querySelector("#myDiagramDiv")
    );
    // Draw the chart, setting the allowHtml option to true for the tooltips.
    chart.draw(data, {
      allowHtml: true,
      nodeClass: "default-leaf",
      selectedNodeClass: "selected-leaf",
    });
    let id: any = document.querySelector("#myDiagramDiv");
    let tableElem = id.children[0];
    let calculatedWidth: any = id.children[0].offsetWidth;

    // if (calculatedWidth <= 900) return;

    // let diffValue = (calculatedWidth - 900) / 2;

    // id.scrollTo(diffValue, 0);
    if (this.getLength(this.relationList) === 1) {
      id.scrollTo(calculatedWidth, 0);

      let diffRelative = calculatedWidth / 875;

      let scaleDiff = 1 / 0.5;
      this.defaultScale = scaleDiff;

      this.zoomIn = scaleDiff;
      tableElem.style.transform = `scale(${+scaleDiff})`;
    } else {
      id.scrollTo(calculatedWidth, 0);

      let diffRelative = calculatedWidth / 875;

      let scaleDiff = 1 / diffRelative;
      this.defaultScale = scaleDiff;

      this.zoomIn = scaleDiff;
      // tableElem.style.transform = `scale(${+scaleDiff})`;
    }
    // let j = 0;
    // let time = setInterval(() => {
    let f = document.getElementById("myDiagramDiv");
    f.scrollIntoView();
    // if (j === 2000) {
    // clearInterval(time);
    // }
    // console.log(f);
    //   j++;
    // }, 0);
  };
  getLength(arr) {
    let arrFilter = arr.filter((accu) => {
      if (accu) {
        return accu;
      }
    });

    return (arrFilter || []).length;
  }

  ngAfterViewInit() {
    let company = JSON.parse(this.storage.getData("CompanyDetails"));
    this.initiate(company);
  }
  exportAsPdf() {
    let id: any = document.getElementById("myDiagramDiv");
    let tableElem = id.children[0];
    // tableElem.style.transform = `scale(${this.defaultScale})`;

    let calculatedHeight = id.children[0].offsetHeight;
    let calculatedWidth = id.children[0].offsetWidth + 15;
    console.log(calculatedWidth, calculatedHeight);

    // if (calculatedWidth <= 1000) {
    //   let minusValue = 1000 - calculatedWidth;

    //   calculatedWidth = calculatedWidth + minusValue;
    // }
    console.log(calculatedHeight, calculatedWidth);
    html2canvas(id, { width: calculatedWidth, height: calculatedHeight }).then(
      async (x: any) => {
        let canObj = document.getElementById("page");
        canObj.appendChild(x);
        let can = document.querySelector("canvas");

        let dataUrl = can.toDataURL();
        // let logoData = await this.toDataUrlBase64(
        //   location.origin + "/assets/images/icons/company.png"
        // );
        let logoData = await this.companyChartOper.toDataUrlBase64(
          location.origin + "/assets/images/icons/company.png"
        );
        let companyName = "No Comapany Name";
        let CompanyDetails = this.storage.getData("CompanyDetails");
        if (CompanyDetails !== null || CompanyDetails !== undefined) {
          companyName = JSON.parse(CompanyDetails).CompanyName;
        }
        // playground requires you to assign document definition to a variable called dd

        var dd = {
          info: {
            title: `${companyName}`,
            author: `${companyName}`,
            subject: "All Detail of Property and work group and Company",
            keywords: "property management",
            creationDate: `${new Date()}`,
          },
          pageSize: {
            width: 780,
            height: calculatedHeight + 500,
          },
          content: [
            {
              layout: "noBorders",
              table: {
                widths: [80, "*"],
                body: [
                  [
                    {
                      image: logoData,
                      width: 60,
                      height: 60,
                    },
                    {
                      text: "\nCompany",
                      style: "headers",
                    },
                  ],
                ],
              },
            },
            {
              text: `\nCompany Name: ${companyName}\n\n`,
              style: "title",
            },

            {
              layout: "noBorders",
              table: {
                body: [
                  [
                    {
                      image: dataUrl,
                      width: 600,
                    },
                  ],
                ],
              },
            },
          ],
          styles: {
            headers: {
              fontSize: 15,
            },
            title: {
              fontSize: 13,
            },
          },
        };

        pdfMake
          .createPdf(dd)
          .download(
            this.companyChartOper.generateFileName(companyName, ".pdf")
          );
      }
    );
  }
  ZoomIn() {
    this.zoomIn = this.zoomIn + 0.1;

    let id: any = document.getElementById("myDiagramDiv");

    let tableElem = id.children[0];

    tableElem.style.transform = `scale(${this.zoomIn})`;
  }
  ZoomOut() {
    this.zoomIn = this.zoomIn - 0.1;
    let id: any = document.getElementById("myDiagramDiv");

    let tableElem = id.children[0];

    tableElem.style.transform = `scale(${this.zoomIn})`;
  }
  fitToDisplay() {
    this.zoomIn = this.defaultScale;
    let id: any = document.getElementById("myDiagramDiv");

    let tableElem = id.children[0];

    tableElem.style.transform = `scale(${this.defaultScale})`;
  }
  closeDialog() {
    this.companyDialogRef.close();
  }
}
