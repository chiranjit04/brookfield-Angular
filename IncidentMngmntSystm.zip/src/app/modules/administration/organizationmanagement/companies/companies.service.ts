import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { environment } from "../../../../../environments/environment";
import { Observable } from "rxjs";
import { map } from "rxjs/internal/operators/map";
@Injectable({
  providedIn: "root",
})
export class CompanyService {
  url: any;
  observable: Observable<any>;
  constructor(private http: HttpClient) {
    this.url = environment.origin + "api/";
    // this.url = 'http://localhost:1601/api/';
  }

  getCountry(): Observable<any> {
    return this.http.get<any>(this.url + "getCountry");
  }

  // Get Goe Table
  getCompanyList(param: any) {
    try {
      // old api -> companySearchList
      return this.http.post<any>(`${this.url}CompanySearchListOM`, param).pipe(
        map((elem) => {
          return {
            companySearchList: elem.companySearchListOM,
          };
        })
      );
    } catch (error) {
      throw error;
    }
  }

  changeCompanyStatus(param) {
    try {
      return this.http.post<any>(`${this.url}ChangeCompanyStatus`, param);
    } catch (error) {
      throw error;
    }
  }
  getState(param: any) {
    return this.http.post<any>(`${this.url}getState`, param);
  }
  getCompanyByUser(param: any): Observable<any> {
    // GetCompanyByUser;
    return this.http.post<any>(`${this.url}GetCompanyByUserOM`, param);
    // .pipe(
    // map((elem) => {
    //   return {
    //     companyList: elem.GetCompanyByUserOM,
    //   };
    // })
    // );
  }

  getCompanyType() {
    try {
      return this.http.get<any>(`${this.url}GetCompanyType`);
    } catch (error) {
      throw error;
    }
  }

  UpdateCompanyArchive(CompanyID: any): Observable<any> {
    let data = {
      CompanyID: +CompanyID,
    };
    return this.http.post<any>(`${this.url}UpdateCompanyArchive`, data);
  }
  getCompanyChart(data: any): Observable<any> {
    return this.http.post<any>(this.url + "getCompanyChart", data);
  }

  DeleteCompany(CompanyID: number) {
    const options = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
      }),
      body: {
        CompanyID: +CompanyID,
      },
    };
    return this.http.delete(`${this.url}DeleteCompany`, options);
  }
  companyImport(data: any): Observable<any> {
    return this.http.post<any>(this.url + "companyImport", data);
  }

  getCompanyZipcodeList(): Observable<any> {
    return this.http.get<any>(this.url + "CompanyZipcodeList");
  }
}
