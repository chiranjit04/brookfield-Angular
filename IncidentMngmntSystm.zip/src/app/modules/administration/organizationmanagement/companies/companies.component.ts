import {
  Component,
  OnInit,
  ViewChild,
  Renderer,
  Renderer2,
  ElementRef,
} from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import { MatAutocompleteTrigger } from "@angular/material";
import { CompanyService } from "../companies/companies.service";
import { FormControl } from "@angular/forms";
import { startWith, map, concatAll } from "rxjs/operators";
import { DataSharingService } from "../dataSharing.service";
import { Router, ActivatedRoute } from "@angular/router";
import * as ExcelJS from "exceljs";
import Swal from "sweetalert2";
import { ToastrService } from "ngx-toastr";
import { CompanyExportToPdfService } from "../companylisttable/companyExportToPdf.service";
import { CompanyChartDialogComponent } from "./company-chart-dialog/company-chart-dialog.component";
import { UserPermissionService } from "../../../../services/user-permission.service";
import { StorageService } from "../../../../services/storage.service";

@Component({
  selector: "app-companies",
  templateUrl: "./companies.component.html",
  styleUrls: ["./companies.component.scss"],
})
export class CompaniesComponent implements OnInit {
  selectedIndex = -1;
  downloadToExcel: Array<any> = [];
  @ViewChild("fileInput", { static: false }) importFile;
  alphabets = [];
  addresssearch = "";
  CompanyDetails: any;
  SystemPickValues: any = [];
  formControlobj = {
    filterByCountry: new FormControl(),
    filterByCompanySearch: new FormControl(),
    filterByTypeSearch: new FormControl(),
    filterByStateSearch: new FormControl(),
    filterByIsActive: new FormControl(),
    filterByIsArchived: new FormControl(),
    filterByZipcodeSearch: new FormControl(),
    filterByAddressSearch: new FormControl(),
  };

  filtered = {
    filterByCompanyFiltered: null,
    filterByTypeFiltered: null,
    filterByStateFiltered: null,
    filterCountry: null,
    filterByIsActiveFiltered: null,
    filterByIsArchiveFiltered: null,
    filterByZipcodeFiltered: null,
  };

  comstatus = [
    { id: 0, name: "All" },
    { id: 1, name: "Active" },
    { id: 2, name: "InActive" },
    { id: 3, name: "Archived" },
  ];

  obj = {
    CountryList: [],
    CompanyList: [],
    CompanyType: [],
    StateList: [],
    CompStatusList: [],
    isArchiveList: [],
    isActiveList: [],
    ZipCodeList: [],
  };

  companySearchParam = {
    countryId: 0,
    CompanyID: 0,
    CompanyTypeID: 0,
    StateId: 0,
    Status: 1,
    IsActive: null,
    IsArchive: 0,
    Zip: null,
    Address: null,
    ShortFilter: null,
  };

  default = {
    countryId: 0,
    CompanyID: 0,
    CompanyTypeID: 0,
    StateId: 0,
    Status: null,
    IsActive: null,
    IsArchive: 0,
    Zip: null,
    Address: null,
    ShortFilter: null,
  };

  isDataFound = false;
  isCompanySubDivision: boolean = false;
  act: any = false;

  authToken = null;
  userData = null;
  UserID = null;
  inteliTypeFilters: Array<any> = [
    "filterByCompanySearch",
    "filterByTypeSearch",
    "filterByZipcodeSearch",
  ];

  constructor(
    public Company: CompanyService,
    public companyChartDialog: MatDialog,
    private dataShare: DataSharingService,
    private route: Router,
    private renderer: Renderer2,
    private router: ActivatedRoute,
    private exportToExcel: CompanyExportToPdfService,
    private tostre: ToastrService,
    public UserPermission: UserPermissionService,
    private storage: StorageService
  ) {
    //... Read User Data ...
    this.authToken = this.storage.getData("token");
    if (this.authToken == null) {
      this.route.navigate(["/login"]);
    }
    this.userData = JSON.parse(this.storage.getData("UserData"));
    this.UserID = this.userData[0].UserID;

    /* check module permission of the user */
    if (
      this.UserPermission.checkPermission("access_companies_management") ==
      false
    ) {
      this.route.navigate(["/products/list"]);
      this.tostre.warning(
        "You don't have permission to access this module.",
        "",
        {
          positionClass: "toast-top-right",
        }
      );
    }
  } 

  toggleStatus: FormControl = new FormControl("Active");

  @ViewChild("autoTrigger", { read: MatAutocompleteTrigger, static: false })
  autoTrigger: MatAutocompleteTrigger;

  @ViewChild(MatAutocompleteTrigger, { static: false })
  autocomplete: MatAutocompleteTrigger;

  ngOnInit() {
    this.storage.removeData("justCreated");
    this.act = this.router.snapshot.paramMap.get("act");
    // console.log(this.act);
    if (this.act == "updated") {
      this.getCompanySearchList(this.companySearchParam);
    }
    if (this.storage.getData("companyAdded") == "1") {
      this.getCompanySearchList(this.companySearchParam);
      this.storage.removeData("companyAdded");
    }
    this.getCompanyType();
    this.getCompanySubDivision();
    this.getCompanySearchList(this.companySearchParam);
    this.getCountry();
    this.alphabets = this.generateAlphabate();
    this.getCompanyZipCodeList();
    // this.getComsSatus();
    this.getIsActiveFilterOption();
    this.getIsArchiveFilterOption();
    this.CompanyDetails = JSON.parse(this.storage.getData("CompanyDetails"));
    if (this.CompanyDetails) {
      this.isCompanySubDivision = true;
    }
  }

  generateAlphabate(): Array<string> {
    return "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("");
  }

  getState(atr) {
    this.Company.getState({ countryId: atr }).subscribe((x) => {
      this.obj.StateList = x.getState;
      this.initiate(
        "filterByStateFiltered",
        "StateList",
        "StateName",
        "filterByStateSearch"
      );
    });
  }

  getCountry() {
    this.Company.getCountry().subscribe((x) => {
      this.obj.CountryList = x.getCountry;
      x.getCountry.forEach((element) => {
        if (element.IsSelected == 1) {
          this.companySearchParam.countryId = element.CountryID;
          this.default.countryId = element.CountryID;
          this.formControlobj.filterByCountry.setValue(element.CountryName);
          this.getState(element.CountryID);
        }
      });

      this.initiate(
        "filterCountry",
        "CountryList",
        "CountryName",
        "filterByCountry"
      );
    });
  }

  /**
   *
   * @param keyNameFilter of - filtered - after lost
   * @param listFromServer  of - from array of object list the from server -
   * @param keyNameObj of - array of keyname that we want to take -
   * @param formControlKeyName of - from control that has value changes obtain -
   */
  initiate(keyNameFilter, listFromServer, keyNameObj, formControlKeyName) {
    this.filtered[keyNameFilter] = this.formControlobj[
      formControlKeyName
    ].valueChanges.pipe(
      startWith(""),
      //map((value: any) => this._filter(value, listFromServer, keyNameObj))
      map((value) => {
        let list = [];
        if (this.inteliTypeFilters.includes(formControlKeyName)) {
          list =
            String(value).length >= 0
              ? this._filter(value, listFromServer, keyNameObj)
              : [];
          if (list.length == 1 && list[0][keyNameObj] == value) {
            list = [];
          }
        } else {
          list = this._filter(value, listFromServer, keyNameObj);
        }

        return list;
      })
    );
  }

  private _filter(value: any, keyName: string, filterName: string): string[] {
    const filterValue = value.toLowerCase();
    return this.obj[keyName].filter((option) =>
      option[filterName].toLowerCase().includes(filterValue)
    );
  }

  getCompanySubDivision() {
    this.Company.getCompanyByUser({ UserId: this.UserID }).subscribe((x) => {
      // console.log(x);
      if (x.status === "success") {
        this.obj.CompanyList = x.companyList;
        // console.log(this.obj.CompanyList);
        this.initiate(
          "filterByCompanyFiltered",
          "CompanyList",
          "CompanyName",
          "filterByCompanySearch"
        );
      }
    });
  }

  getCompanyType() {
    this.Company.getCompanyType().subscribe((x) => {
      if (x.status === "success") {
        // console.log(x.companyTypeList);
        this.obj.CompanyType = x.companyTypeList;
        this.initiate(
          "filterByTypeFiltered",
          "CompanyType",
          "Title",
          "filterByTypeSearch"
        );
      }
    });
  }
  /** set type  B input for  getCompanyType */
  setTypeBInput() {
    this.autocomplete.openPanel;
  }

  getIsActiveFilterOption() {
    let array = [
      { value: 1, name: "Active" },
      { value: 0, name: "Inactive" },
    ];
    this.obj.isActiveList = array;

    this.initiate(
      "filterByIsActiveFiltered",
      "isActiveList",
      "name",
      "filterByIsActive"
    );
  }
  getIsArchiveFilterOption() {
    let array = [
      { value: 1, name: "Yes" },
      { value: 0, name: "No" },
    ];
    this.obj.isArchiveList = array;

    this.initiate(
      "filterByIsArchiveFiltered",
      "isArchiveList",
      "name",
      "filterByIsArchived"
    );
  }

  getCompanyZipCodeList() {
    this.Company.getCompanyZipcodeList().subscribe((x) => {
      this.obj.ZipCodeList = x.CompanyZipcodeList;
      this.initiate(
        "filterByZipcodeFiltered",
        "ZipCodeList",
        "CompanyZipCode",
        "filterByZipcodeSearch"
      );
      // console.log(this.filtered.filterByZipcodeFiltered);
    });
  }

  /*  getComsSatus() {
    let comstatus = [
      //{ id: 0, name: "All" },
      { id: 1, name: "Active" },
      { id: 0, name: "InActive" },
      //{ id: 3, name: "Archived" },
    ];
    this.obj.CompStatusList = comstatus;
    this.initiate(
      "filterByStatusFiltered",
      "CompStatusList",
      "name",
      "filterByStatus"
    );
  } */

  /**
   * selection functinality
   */
  setSelections(key, optKey, opt, evt) {
    if (!evt.isUserInput) return;
    this.companySearchParam[key] =
      key == "CompanyName"
        ? opt.CompanyName.split("-")[0].trim()
        : +opt[optKey];
    this.companySearchParam.ShortFilter = null;
    // console.log(opt[optKey]);
    this.getCompanySearchList(this.companySearchParam);
  }
  onkeyUpSelection(str) {
    if (
      str == "Zip" ||
      str == "Address" ||
      str == "IsActive" ||
      str == "Status"
    ) {
      this.companySearchParam[str] = null;
    } else {
      this.companySearchParam[str] = 0;
    }
    this.companySearchParam.ShortFilter = null;
    this.getCompanySearchList(this.companySearchParam);
  }

  onActiveInActiveSearch(str, event) {
    if (str == "Active") {
      // this.companySearchParam["IsActive"] = 1;
      this.companySearchParam["Status"] = 1;
      this.companySearchParam["IsArchive"] = 0;
    } else if (str == "InActive") {
      // this.companySearchParam["IsActive"] = 0;
      this.companySearchParam["Status"] = 0;
      this.companySearchParam["IsArchive"] = 0;
    } else if (str == "Archived") {
      // this.companySearchParam["IsActive"] = null;
      this.companySearchParam["Status"] = null;
      this.companySearchParam["IsArchive"] = 1;
    } else {
      // this.companySearchParam["IsActive"] = null;
      this.companySearchParam["Status"] = null;
      this.companySearchParam["IsArchive"] = 0;
    }
    // console.log(this.companySearchParam);
    this.companySearchParam.ShortFilter = null;
    this.getCompanySearchList(this.companySearchParam);
  }

  customSearch(type, elem) {
    if (
      type == "IsArchive" ||
      type == "IsActive" ||
      type == "Status" ||
      type == "Zip" ||
      type == "Address"
    ) {
      if (elem.value == undefined || elem.value == "") {
        elem.value = null;
      } else {
        this.companySearchParam[type] = elem.value;
      }
    } else {
      this.companySearchParam[type] = elem.value;
    }
    // console.log(this.companySearchParam);
    this.getCompanySearchList(this.companySearchParam);
  }

  adsearch() {
    this.addresssearch = "";
  }
  // selectedIndex:any =null;
  alphabatSearch(rule, obj) {
    // console.log(rule);
    //this.storage.removeData("CompanyDetails");
    if (rule == "all") {
      obj = this.default;

      obj.ShortFilter = null;
    } else {
      obj = this.default;
      obj.ShortFilter = rule;
    }
    /* add css class on active*/
    //this.selectedIndex = index;
    // if(rule != "all"){
    //   for(let i=0;i<this.alphabets.length ; i++){
    //       this.alphabets[i].active = false;
    //   }
    //   rule.active = !rule.active;
    // }
    /**/
    // Clear status search filter ..
    let shadesEl = document.querySelectorAll(".mat-button-toggle-checked");
    for (let i = 1; i < shadesEl.length; i++) {
      shadesEl[i].classList.remove("mat-button-toggle-checked");
    }
    // console.log(this.companySearchParam.Status);
    if (this.companySearchParam.Status != 1) {
      let element: HTMLElement = document.getElementById(
        "active_status-button"
      ) as HTMLElement;
      element.click();
    }
    obj.Status = 1;

    //this.companySearchParam["Status"] = 1;
    //this.companySearchParam["IsArchive"] = 0;

    this.getCompanySearchList(obj);
  }

  getCompanySearchList(obj: any) {
    // console.log("company = ", obj)
    this.Company.getCompanyList(obj).subscribe((x: any) => {
      this.downloadToExcel = x.companySearchList;
      this.dataShare.changeMessage(x);
      this.dataShare.changeMessageObj(obj);
      if (this.downloadToExcel.length == 0) {
        this.isDataFound = true;
      } else {
        this.isDataFound = false;
      }
    });
  }

  calledToExcel() {
    // this.jsonToExcel.exportToExecl(
    //   this.downloadToExcel,
    //   this.jsonToExcel.generateFileName()
    // );
    if (this.downloadToExcel.length === 0) {
      // download format also
      this.exportToExcel.downloadSheetWithError([], [], false);
      return;
    }
    if (this.downloadToExcel[0].hasOwnProperty("Status") === true) {
      this.exportToExcel.downloadSheetWithError(
        this.downloadToExcel,
        this.SystemPickValues,
        false
      );
    } else {
      this.exportToExcel.downloadSheetWithError(this.downloadToExcel, [], true);
    }
  }
  /**
   *
   * @param event Validate so time can input only number
   */
  numberOnly(event: any): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  addSubDivision(event: any) {
    event.preventDefault();
    let selectedCompanyID: any = false;
    let CompanyDetails = JSON.parse(this.storage.getData("CompanyDetails"));
    if (CompanyDetails) {
      selectedCompanyID = CompanyDetails.CompanyID;
    }

    if (selectedCompanyID) {
      this.route.navigate([
        "/products/administration/organizationmanagement/companies/addsubdivision/" +
          btoa(selectedCompanyID),
      ]);
    } else {
      Swal.fire({
        text: " Please first select a company to add a company sub division.",
      });
    }
  }
  clearDom() {}
  generateTree() {}
  companyList: any = null;
  openDialogChart() {
    // console.log("helll");
    const dialogCompanyRef = this.companyChartDialog.open(
      CompanyChartDialogComponent,
      {
        width: "900px",
        height: "700px",
      }
    );
    dialogCompanyRef.afterClosed().subscribe((x) => {
      // console.log("hello");
    });
  }
  receiveListCompany(event) {
    // console.log(event);
    if (
      event.CompanySubdivision !== null ||
      event.CompanySubdivision !== undefined
    ) {
      this.isCompanySubDivision = true;
      this.companyList = event;
    } else {
      this.companyList = null;
    }
  }

  toggleChange(event) {
    let toggle = event.source;
    if (toggle) {
      let group = toggle.buttonToggleGroup;
      if (event.value.some((item) => item == toggle.value)) {
        group.value = [toggle.value];
        // console.log(group.value[0])
        let status = group.value[0];

        this.onActiveInActiveSearch(status, "");
      }
    } else {
      //console.log(toggle)
      this.onActiveInActiveSearch(null, "");
    }
  }

  importToExcel() {
    this.SystemPickValues = [];
    if (this.importFile.nativeElement.files[0] === undefined) return;

    /** validate xlsx file */
    if (
      this.importFile.nativeElement.files[0].type !==
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" &&
      this.importFile.nativeElement.files[0].name
        .split(".")
        .lastIndexOf("xlsx") < 0
    ) {
      Swal.fire("This not excel file");
      return;
    }

    let wb = new ExcelJS.Workbook();
    let reader: FileReader = new FileReader();
    let propertyImportArr = [];
    reader.readAsArrayBuffer(this.importFile.nativeElement.files[0]);

    reader.onload = () => {
      let buffer: any = reader.result;
      wb.xlsx.load(buffer).then((workbook) => {
        workbook.eachSheet((sheet, id) => {
          if (sheet.name === "Upload Sheet") {
            sheet.eachRow((row, rowIndex) => {
              if (rowIndex > 3) {
                propertyImportArr.push(row.values);
              }
            });
            // console.log("cena", propertyImportArr);
            this.PropertyImportSend(propertyImportArr);
          }
          if (sheet.name === "SystemPickValues") {
            sheet.eachRow((row, rowIndex) => {
              this.SystemPickValues.push(row.values);
            });
            // console.log(this.SystemPickValues);
          }
        });
      });
    };
    reader.onerror = () => {
      Swal.fire("Error in Reading File ");
    };
    /** clearing tha value of element for override that data */
    this.importFile.nativeElement.value = "";
  }
  PropertyImportSend(arr) {
    // console.log("Match", arr[0]);
    let importedData = [];
    let userDetail = JSON.parse(this.storage.getData("UserData"))[0].UserID;
    let keys = [
      "CompanyType",
      "CompanyName",
      "ParentName",
      "IdentificationNumber",
      "CompanyDescription",
      "Address",
      "Country",
      "State",
      "City",
      "ZipCode",
      "CompanyPhone",
      "BusinessEmail",
      "CompanyWebsite",
      "CompanyStatus",
      "test",
      "Status",
      "Message",
    ];
    // console.log(userDetail);
    let demo: any = this.defaultImport();
    // console.log(Object.keys(importPrototype));
    try {
      arr.forEach((elem, i) => {
        demo["RecNo"] = i + 1;
        demo["CreatedBy"] = +userDetail;
        // console.log(demo["CreatedBy"]);
        keys.forEach((e, index) => {
          if (index == 3) {
            if (
              elem[index + 1] === undefined ||
              elem[index + 1] === undefined
            ) {
              importedData = null;
              let err = new Error();
              err.name = elem[index + 1 - 2];
              err.message = i + 4;
              throw err;
            }
          }
          demo[e] = elem[index + 1] === undefined ? "" : elem[index + 1];
        });
        demo["BusinessEmail"] =
          typeof demo["BusinessEmail"] === "object"
            ? demo["BusinessEmail"].text
            : demo["BusinessEmail"];

        demo["CompanyWebsite"] =
          typeof demo["CompanyWebsite"] === "object"
            ? demo["CompanyWebsite"].text
            : demo["CompanyWebsite"];

        importedData.push(demo);

        demo = this.defaultImport();
      });
    } catch (err) {
      Swal.fire(
        "invalid Identification Number in " +
          err.name +
          " Row number: " +
          err.message
      );
    }
    if (importedData === null) {
      return;
    }
    // console.log(importedData);
    this.Company.companyImport({ compImport: importedData }).subscribe(
      (res) => {
        let t = this.modifyStateOfList(res.compImportResData[0]);
        this.downloadToExcel = t;
        this.dataShare.changeCompImportMessage(this.downloadToExcel);
        this.showValid("Processed successfully. Please check the table.");
      }
    );
  }
  modifyStateOfList(importProperty) {
    // console.log(importProperty);
    return importProperty.map((elem, index) => {
      return {
        CompanyType: elem.CompanyType,
        CompanyName: elem.CompanyName,
        ParentName: elem.ParentName,
        CompanyIndentNumber: elem.IdentificationNumber,
        CompanyDescription: elem.CompanyDescription,
        Address: elem.Address,
        Country: elem.Country,
        StateName: elem.State,
        City: elem.City,
        ZipCode: elem.ZipCode,
        CompanyPhone: elem.CompanyPhone,
        BusinessEmail: elem.BusinessEmail,
        CompanyWebsite: elem.CompanyWebsite,
        CompanyStatus: elem.CompanyStatus,
        CompanySubdivision: "",
        CompanySubdivisionType: "",
        Status: `${elem.Status} ${elem.Message}`,
      };
    });
  }
  defaultImport() {
    return {
      CompanyType: "",
      CompanyName: "",
      ParentName: "",
      IdentificationNumber: "",
      CompanyDescription: "",
      Address: "",
      Country: "",
      State: "",
      City: "",
      ZipCode: "",
      CompanyPhone: "",
      BusinessEmail: "",
      CompanyWebsite: "",
      CompanyStatus: "",
      CreatedBy: null,
      Status: "",
      test: "",
      Message: "",
    };
  }

  resetTable(key, value) {
    // if (key == "Zip") {
    //   this.companySearchParam[key] = null;
    // } else {
    //   this.companySearchParam[key] = 0;
    // }
    // if (key == "Address") {
    //   this.companySearchParam[key] = null;
    // } else {
    //   this.companySearchParam[key] = null;
    // }

    this.companySearchParam[key] = value;
    this.companySearchParam.ShortFilter = null;

    this.getCompanySearchList(this.companySearchParam);
  }

  // toastr warning/success message
  showInvalid(msg) {
    this.tostre.warning(msg, "", {
      positionClass: "toast-top-right",
    });
  }

  showValid(validMsg) {
    this.tostre.success(validMsg, "", {
      positionClass: "toast-top-right",
    });
  }
}
