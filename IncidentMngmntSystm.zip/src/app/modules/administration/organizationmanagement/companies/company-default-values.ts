export const companyDefaultSystempicks = [
  ["", "Owner/Partner Company", "Active"],
  ["", "Management Company", "InActive"],
  ["", "Security Provider", ""],
  ["", "Sub Divisions", ""],
  ["", "company type", ""],
];
