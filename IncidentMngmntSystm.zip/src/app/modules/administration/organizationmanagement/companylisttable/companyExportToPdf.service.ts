import { Injectable } from "@angular/core";
import { AddCompanyService } from "../addcompanies/addCompany.service";
import * as pdfMake from "pdfmake";
import * as ExcelJS from "exceljs";
import { saveAs } from "file-saver";
//import { logoBase64 } from "../../propertymanagement/locationmanagement/brookfieldlogo";
import  { logoBase64 } from "src/assets/images/logo/brookfieldlogo";
import pdfFonts from "pdfmake/build/vfs_fonts";
import { environment } from "../../../../../environments/environment";
import { companyDefaultSystempicks } from "../companies/company-default-values";
//import { companyImageLogo } from "../../propertymanagement/locationmanagement/brookfieldlogo";
pdfMake.vfs = pdfFonts.pdfMake.vfs;
@Injectable({
  providedIn: "root",
})
export class CompanyExportToPdfService {
  obj: any = {
    companyDetail: null,
    keyPerson: null,
    companyLogoBase64: null,
    companyImageBase64: null,
  };
  websitesheet: string;
  constructor(private comppanyService: AddCompanyService) {}
  public generateFilename(companyName: string, extension: string): string {
    return `${
      companyName === "" || companyName === undefined || companyName === null
        ? "defaultCompanyName"
        : companyName
    }-${Date.now()}.${extension}`;
  }

  async downloadOriginalSheet(json: any) {
    let arr = [];
    // let columnsSet = ["A", "B", "C", "D", "E", "F", "G", "H", "I"];
    const wb = new ExcelJS.Workbook();
    const ws = wb.addWorksheet("Company Detail Sheet", {
      properties: { tabColor: { argb: "FF00FF00" } },
    });
    let columnsHead = [
      "Company Name",
      "Company Subdivision",
      "Parent Name",
      "Company ID",
      "Address",
      "State Name",
      "Zip Code",
      "Company Subdivision Type",
      "Status",
    ];
    columnsHead.forEach((elem, i) => {
      arr.push({ key: "col " + i, header: " " });
    });
    ws.columns = arr;
    ws.columns.forEach((column) => {
      column.width =
        column.header.length < 12 ? 12 + 15 : column.header.length + 15;
    });

    let im = wb.addImage({
      base64: logoBase64,
      extension: "png",
    });
    ws.addImage(im, "A1:B1");
    ws.getRow(1).height = 100;
    ws.getRow(2).height = 30;

    if (json.length === 0) {
    } else {
      json.forEach((element, index) => {
        ws.getRow(index + 4).values = [
          element.CompanyName,
          element.CompanySubdivision,
          element.ParentName,
          element.CompanyIndentNumber,
          element.Address,
          element.StateName,
          element.ZipCode,
          element.CompanySubdivisionType,
          element.IsActive === true ? "Active" : "InActive",
        ];
        ws.getRow(index + 4).alignment = {
          wrapText: true,
          horizontal: "justify",
        };
      });
    }
    ws.getRow(2).values = ["Company Exported Data"];
    ws.getCell("A2").font = {
      size: 22,
    };

    ws.getRow(3).values = columnsHead;

    ws.getRow(3).height = 50;
    ws.getCell("A7");
    ws.getRow(3).alignment = {
      vertical: "middle",
      horizontal: "center",
      wrapText: true,
    };
    ws.getRow(3).font = {
      bold: true,
    };
    ws.getRow(3).border = {
      top: { style: "thin", color: { argb: "#000000" } },
      left: { style: "thin", color: { argb: "#000000" } },
      bottom: { style: "thin", color: { argb: "#000000" } },
      right: { style: "thin", color: { argb: "#000000" } },
    };

    ws.getRow(3).fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "0xE2EFDA" },
    };
    // await ws.protect('the-password', {});
    const buf = await wb.xlsx.writeBuffer();
    saveAs(
      new Blob([buf]),
      this.generateFilename("companyDetailList", ".xlsx")
    );
  }
  async downloadSheetWithError(json: any, pickVal: any, bool: boolean) {
    let columnsHead = [
      "Company Type",
      "Company Name",
      "Parent Name",
      "Identification Number                                          (Note: Must be a four digit number)",
      "Company Description",
      "Address",
      "Country Name",
      "State Name",
      "City Name",
      "Zip Code",
      "Phone (000-000-0000)",
      "Business Email",
      "Company Website",
      "Status",
      "Inserted Status",
    ];
    let arr = [];
    const wb = new ExcelJS.Workbook();
    /**
     * workbook to set active tab there
     */
    wb.views = [
      {
        x: 0,
        y: 0,
        width: 10000,
        height: 20000,
        firstSheet: 0,
        activeTab: 1,
        visibility: "visible", // Set activeTab to 0
      },
    ];

    /** instructions */
    const wsIns = wb.addWorksheet("Instructions");
    /**upload sheet */
    const ws = wb.addWorksheet("Upload Sheet");
    /** for systempickvalue tab data worksheet */
    const wsPick = wb.addWorksheet("SystemPickValues");

    columnsHead.forEach((elem, i) => {
      arr.push({ key: "col " + i, header: " " });
    });
    ws.columns = arr;
    ws.columns.forEach((column) => {
      column.width =
        column.header.length < 12 ? 12 + 15 : column.header.length + 15;
    });

    let im = wb.addImage({
      base64: logoBase64,
      extension: "png",
    });
    ws.addImage(im, "A1:B1");
    ws.getRow(1).height = 100;
    ws.getRow(2).height = 30;

    if (json.length === 0) {
    }
    if (bool === true) {
      json.forEach((element, index) => {
        console.log(element);
        ws.getRow(index + 4).values = [
          element.CompanySubdivisionType,
          element.CompanyName,
          element.ParentName,
          element.CompanyIndentNumber,
          element.CompanyDescription,
          element.Address,
          element.CountryName,
          element.StateName,
          element.CompanyCity,
          element.ZipCode,
          element.CompanyPhone,
          element.BusinessEmail,
          element.CompanyWebSite === undefined ||
          element.CompanyWebSite === null || element.CompanyWebSite ==[]
            ? ""
            : element.CompanyWebSite.split("|").join(""),
          element.IsActive === true ? "Active" : "InActive",
          element.Status,
        ];
        ws.getRow(index + 4).alignment = {
          wrapText: true,
          horizontal: "justify",
        };
      });
    } else {
      json.forEach((element, index) => {
        ws.getRow(index + 4).values = [
          element.CompanyType,
          element.CompanyName,
          element.ParentName,
          element.CompanyIndentNumber,
          element.CompanyDescription,
          element.Address,
          element.Country,
          element.StateName,
          element.City,
          element.ZipCode,
          element.CompanyPhone,
          element.BusinessEmail,
          element.CompanyWebsite,
          element.CompanyStatus,
          element.Status,
        ];
        ws.getRow(index + 4).alignment = {
          wrapText: true,
          horizontal: "justify",
        };
      });
    }
    ws.getRow(2).values = ["Company Exported Data"];
    ws.getCell("A2").font = {
      size: 22,
    };

    ws.getRow(3).values = columnsHead;

    ws.getRow(3).height = 50;
    ws.getCell("A7");
    ws.getRow(3).alignment = {
      vertical: "middle",
      horizontal: "center",
      wrapText: true,
    };
    ws.getRow(3).font = {
      bold: true,
    };

    this.colorCell(ws, "A3");
    this.colorCell(ws, "B3");
    this.colorCell(ws, "D3");
    this.colorCell(ws, "F3");
    this.colorCell(ws, "G3");
    this.colorCell(ws, "H3");
    this.colorCell(ws, "I3");
    this.colorCell(ws, "J3");
    this.colorCell(ws, "K3");
    this.colorCell(ws, "M3");
    this.colorCell(ws, "N3");

    ws.getRow(3).border = {
      top: { style: "thin", color: { argb: "#000000" } },
      left: { style: "thin", color: { argb: "#000000" } },
      bottom: { style: "thin", color: { argb: "#000000" } },
      right: { style: "thin", color: { argb: "#000000" } },
    };
    /**
     * adding second tab data here for system pick values
     */
    let arr1 = [];
    if (json.length === 0 || bool === true) {
      companyDefaultSystempicks.forEach((elem, index) => {
        arr1.push({ key: "col " + index, header: " " });
      });
    } else {
      pickVal.forEach((elem, index) => {
        arr1.push({ key: "col " + index, header: " " });
      });
    }
    wsPick.columns = arr1;

    wsPick.columns.forEach((column) => {
      column.width =
        column.header.length < 12 ? 12 + 15 : column.header.length + 15;
    });

    if (json.length === 0 || bool === true) {
      companyDefaultSystempicks.forEach((elem, index) => {
        wsPick.getRow(index + 2).values = elem;
      });
    } else {
      pickVal.forEach((element, index) => {
        wsPick.getRow(index + 2).values = [
          element[1] === undefined ? "" : element[1],
          element[2] === undefined ? "" : element[2],
          element[3] === undefined ? "" : element[3],
        ];
        wsPick.getRow(index + 2).alignment = {
          wrapText: true,
        };
      });
    }
    /**instructions sheet values */
    wsIns.addImage(im, "D1:H1");
    wsIns.getRow(1).height = 100;
    wsIns.getRow(6).height = 50;

    wsIns.getCell("C2:I2").value =
      "Brookfield Properties Companies Spreadsheet";
    wsIns.getCell("C2:I2").font = {
      bold: true,
      size: 15,
      underline: "single",
    };
    /** this is bar header information */
    wsIns.getCell("B5:K5").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: {
        argb: "0xE2EFDA",
      },
    };
    ["B", "C", "D", "E", "F", "G", "H", "I", "J"].forEach((elem, index) => {
      this.colorCell(wsIns, elem + "5");
    });
    ["B", "C", "D", "E", "F", "G", "H", "I", "J"].forEach((elem, index) => {
      this.colorCell(wsIns, elem + "6");
    });

    wsIns.getCell(
      "B5"
    ).value = `Please list the Brookfield Properties, these Properties are customized to represent that`;
    wsIns.getCell(
      "B6"
    ).value = `company’s organizational structure and related positions of oversight. `;
    wsIns.getCell("B6").alignment = {
      vertical: "top",
    };

    /** set Intructions bar */
    wsIns.getCell("B8").value = "Set of Instructions for The Spreadsheet:";
    wsIns.getCell("B8").font = {
      bold: true,
    };
    /** generral information */
    wsIns.getCell("B10").value = "GENERAL INFO:";
    wsIns.getCell("B10").font = {
      bold: true,
    };
    /**general info detial about - */
    wsIns.getCell("B11").value = "-";
    wsIns.getCell("B11").alignment = {
      horizontal: "right",
    };
    wsIns.getCell("C11").value =
      "Please fill in the required fields to upload data into MAXIMUS";

    wsIns.getCell("B13").value = "-";
    wsIns.getCell("B13").alignment = {
      horizontal: "right",
    };
    wsIns.getCell("C13").value =
      "Dropdown value will appear in each cell if there is a selection to be made";

    wsIns.getCell("B16").value = "-";
    wsIns.getCell("B16").alignment = {
      horizontal: "right",
    };
    wsIns.getCell("B17").value = "-";
    wsIns.getCell("B17").alignment = {
      horizontal: "right",
    };
    wsIns.getCell("B19").value = "-";
    wsIns.getCell("B19").alignment = {
      horizontal: "right",
    };

    /** - box color field that are required */
    wsIns.getCell("C16").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: {
        argb: "0xE2EFDA",
      },
    };
    wsIns.getCell("C16").border = {
      top: { style: "thick", color: { argb: "#000000" } },
      left: { style: "thick", color: { argb: "#000000" } },
      bottom: { style: "thick", color: { argb: "#000000" } },
      right: { style: "thick", color: { argb: "#000000" } },
    };

    wsIns.getCell("C17").border = {
      top: { style: "thick", color: { argb: "#000000" } },
      left: { style: "thick", color: { argb: "#000000" } },
      bottom: { style: "thick", color: { argb: "#000000" } },
      right: { style: "thick", color: { argb: "#000000" } },
    };
    wsIns.getCell("C19").border = {
      top: { style: "thin", color: { argb: "#000000" } },
      left: { style: "thin", color: { argb: "#000000" } },
      bottom: { style: "thin", color: { argb: "#000000" } },
      right: { style: "thin", color: { argb: "#000000" } },
    };

    /** D${++} text starts */
    wsIns.getCell("D16").value =
      "Headers in Light Green are Mandatory or Required Fields";
    (wsIns.getCell("D17").value =
      "Headers in White are not Required entry Fields"),
      (wsIns.getCell("D19").value =
        "Headers cells that are include a red triangle at top right provide");
    // await ws.protect('the-password', {});
    const buf = await wb.xlsx.writeBuffer();
    saveAs(
      new Blob([buf]),
      this.generateFilename("companyImportlList", ".xlsx")
    );
  }
  colorCell(ws, cn) {
    ws.getCell(cn).fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: {
        // argb: "0xE2EFDA",
           argb: "0xEAF1DD",
      },
    };
  }
  /**
   * exporting pdf and its operation are here only pdf
   */
  async exportToPdf(companyObj: any) {
    this.comppanyService
      .getCompanyBYId({ companyID: +companyObj.CompanyID })
      .subscribe((companyDetailList) => {
        console.log("company detail list-->",companyDetailList);
        this.comppanyService
          .GetCompanyContact(+companyObj.CompanyID)
          .subscribe(async (companyContact) => {
            this.obj.companyDetail = await this.companyDetailModify(
              companyDetailList.CompanyById[0],
              ["CompanyName", "Subdivision", "CompanyWebSite", "CompanyPhone"]
            );
            this.obj.keyPerson = await this.keyContactMOdify(
              companyContact.GetCompanyContact
            );
            // this.obj.companyLogoBase64 = await this.toDataUrlBase64(
            //   environment.origin + "assets/images/icons/company.png"
            // );

            let urlPath = environment.origin;
            if (
              companyDetailList.CompanyById[0].CompanyImagePath === "" ||
              companyDetailList.CompanyById[0].CompanyImagePath === undefined ||
              companyDetailList.CompanyById[0].CompanyImagePath === null
            ) {
              urlPath = `${location.origin}/assets/images/imagenaBg.png`;
              // urlPath = `https://i.picsum.photos/id/866/200/200.jpg`;
            } else {
              urlPath =
                environment.imagePath +
                "companies/" +
                companyDetailList.CompanyById[0].CompanyImagePath;
            }

            this.obj.companyImageBase64 = await this.toDataUrlBase64(urlPath);

            this.pdfConvert();
          });
      });
  }

  companyDetailModify(companyDetail, keys) {
    if (
      companyDetail[keys[0]] === null ||
      companyDetail[keys[0]] === undefined ||
      companyDetail[keys[0]] === ""
    ) {
      companyDetail[keys[0]] = "";
    } else {
      companyDetail[keys[0]] = `${companyDetail[keys[0]]}`;
    }
    if (
      companyDetail[keys[1]] === null ||
      companyDetail[keys[1]] === undefined ||
      companyDetail[keys[1]] === ""
    ) {
      companyDetail[keys[1]] = "";
    } else {
      companyDetail[keys[1]] = `This is a Company Subdivision of ${
        companyDetail[keys[1]]
      }`;
    }
    if (
      companyDetail[keys[2]].length === 0 ||
      companyDetail[keys[2]] === undefined ||
      companyDetail[keys[2]] === null
    ) {
      companyDetail[keys[2]] = [""];
    } else {
      let tempWebsiteArray = [];
      companyDetail[keys[2]].forEach((element) => {
        tempWebsiteArray.push([element.url]);
      });

      companyDetail[keys[2]] = tempWebsiteArray;
    }
    if (
      companyDetail[keys[3]].length === 0 ||
      companyDetail[keys[3]] === undefined ||
      companyDetail[keys[3]] === null
    ) {
      companyDetail[keys[3]] = "";
    } else {
      companyDetail[keys[3]] = companyDetail[keys[3]].split("-");
    }
    return companyDetail;
  }
  keyContactMOdify(keyContactList) {
    let bigarr = [
      [
        "Person Name",
        "User ID",
        "Position Title",
        "User Profile Role",
        "Subdivision",
        "Workgroup/Property or Property Sub-Unit",
        "Email Address",
        "Contact",
      ],
    ];
    if (
      keyContactList.length === 0 ||
      keyContactList === null ||
      keyContactList === undefined
    ) {
      return bigarr;
    } else {
      keyContactList.forEach((element) => {
        bigarr.push([
          element.PersonsName,
          element.UserID,
          element.PositionTitle,
          element.UserProfile,
          element.CompanyName,
          element.WorkgroupOrProperty,
          element.EmailAddress,
          element.TelephoneNumber,
        ]);
      });
    }

    return bigarr;
  }
  toDataUrlBase64(url: string) {
    const toBase64 = fetch(url)
      .then((response) => response.blob())
      .then(
        (blob) =>
          new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve(reader.result);
            reader.onerror = reject;
            reader.readAsDataURL(blob);
          })
      );

    return toBase64;
  }
  pdfConvert() {
     console.log("obj file --->",this.obj);
    if(this.obj.companyDetail.CompanyWebSite[0]=="")
    {

      this.websitesheet='';

    }
    else
    {


      this.websitesheet=this.obj.companyDetail.CompanyWebSite;
    }
    var dd = {
      pageSize: "A3",
      info: {
        title: `${this.obj.companyDetail.CompanyName}`,
        author: `${this.obj.companyDetail.CompanyName}`,
        subject: "All Detail of Company and work group and Company",
        keywords: "Company Management",
        creationDate: `${new Date()}`,
      },
      content: [
        {
          alignment: "justify",
          columns: [
            {
              image: logoBase64,
              width: 150,
              height: 50,
            },
          ],
        },
        {
          text: "\n",
        },
        {
          canvas: [
            {
              type: "line",
              x1: 0,
              y1: 0,
              x2: 750,
              y2: 0,
              lineWidth: 1,
              lineColor: "lightgrey",
            },
          ],
        },
        {
          text: "\n",
        },
        {
          layout: "noBorders",
          table: {
            widths: [650, 100],
            body: [
              [
                "",
                {
                  text: `Status: ${
                    this.obj.companyDetail.IsActive === true
                      ? "Active"
                      : "InActive"
                  }`,
                  color: "#0x153A5B",
                  bold: true,
                },
              ],
            ],
          },
        },
        {
          text: "\n",
        },
        {
          layout: "noBorders",
          table: {
            widths: [170, 180, 100, 252],
            body: [
              [
                {
                  image: this.obj.companyImageBase64,
                  width: 150,
                  height: 150,
                },
                {
                  layout: "noBorders",
                  table: {
                    widths: [230],
                    body: [
                      [
                        {
                          text: this.obj.companyDetail.CompanyName,
                        },
                      ],
                      [
                        {
                          // text: "\nCompany Type:",
                          text: "",
                          style: "normal",
                        },
                      ],
                      // hnagd here
                      [
                        {
                          text: this.obj.companyDetail.CompanyType==null?'':this.obj.companyDetail.CompanyType,
                        },
                      ],
                      [
                        {
                          text: "\nCompany Description:",
                          style: "normal",
                        },
                      ],
                      // changes here
                      [
                        {
                          text: `${this.obj.companyDetail.CompanyDescription}`,
                        },
                      ],
                    ],
                  },
                },
                {
                  text: `ID: ${this.obj.companyDetail.CompanyIndentNumber}`,
                },
                {
                  layout: "noBorders",
                  table: {
                    body: [
                      [
                        {
                          text: this.obj.companyDetail.CompanyPhone != '' || undefined ? `Phone: (${this.obj.companyDetail.CompanyPhone[0]}) ${this.obj.companyDetail.CompanyPhone[1]}-${this.obj.companyDetail.CompanyPhone[2]}` : `Phone:`,
                          style: "normal",
                        },
                      ],
                      [
                        {
                          text: `\nEmail: ${this.obj.companyDetail.CompanyBusinessMail==''?'':this.obj.companyDetail.CompanyBusinessMail}`,
                          style: "normal",
                        },
                      ],
                      [
                        {
                          text: "\nWebsite:",
                          style: "normal",
                        },
                      ],
                      ...this.websitesheet,
                    ],
                  },
                },
              ],
            ],
          },
        },
        {
          text: "\n\nPhysical Address:",
          style: "header",
        },

        {
          text: `${this.obj.companyDetail.CompanyAddress}\n${this.obj.companyDetail.CompanyCity}\n${this.obj.companyDetail.StateName==null?'':this.obj.companyDetail.StateName} ${this.obj.companyDetail.CompanyZipCode==''?'':this.obj.companyDetail.CompanyZipCode}\n${this.obj.companyDetail.CountryName==null?'':this.obj.companyDetail.CountryName}`,
        },

        {
          style: "tableExample",
          layout: "noBorders",
          table: {
            headerRows: 1,
            dontBreakRows: true,
            keepWithHeaderRows: 1,

            body: [
              [
                {
                  text: "\nKey Contact Persons:",
                  style: "normal",
                },
              ],
              [
                {
                  table: {
                    headerRows: 1,
                    dontBreakRows: true,
                    keepWithHeaderRows: 1,
                    widths: [65.7, 40.7, 85.7, 85.7, 85.7, 165.7, 85.7, 85.7],
                    body: [...this.obj.keyPerson],
                    alignment: "center",
                  },
                  layout: {
                    fillColor: function (rowIndex, node, columnIndex) {
                      return rowIndex === 0 ? "#D9D9D9" : null;
                    },
                    hLineWidth: function (i, node) {
                      return i === 0 || i === node.table.body.length
                        ? 0.5
                        : 0.5;
                    },
                    vLineWidth: function (i, node) {
                      return i === 0 || i === node.table.widths.length
                        ? 0.5
                        : 0.5;
                    },
                    hLineColor: function (i, node) {
                      return i === 0 || i === node.table.body.length
                        ? "gray"
                        : "gray";
                    },
                    vLineColor: function (i, node) {
                      return i === 0 || i === node.table.widths.length
                        ? "gray"
                        : "gray";
                    },
                  },
                },
              ],
            ],
          },
        },
      ],

      styles: {
        header: {},
        bigger: {
          fontSize: 12,
          bold: true,
        },
        normal: {
          bold: true,
        },
      },
      defaultStyle: {
        columnGap: 10,
        fontSize: 9,
      },
      colorFont: {
        bold: true,
        // color: "#0x153A5B",
        color: "#0x153A5B",
      },
    };
    pdfMake
      .createPdf(dd)
      .download(
        this.generateFilename(this.obj.companyDetail.CompanyName, ".pdf")
      );
    // pdfMake.createPdf(dd).open();
    // created with actual name of property name / compant name of pdf Maker.
  }
}
