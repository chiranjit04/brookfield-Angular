import {
  Component,
  OnInit,
  ViewChild,
  Output,
  ElementRef,
  EventEmitter,
} from "@angular/core";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { CompanyService } from "../companies/companies.service";
import { DataSharingService } from "../dataSharing.service";
import { Router } from "@angular/router";
import Swal from "sweetalert2";
import { MatDialog } from "@angular/material";
import { CompanyChartDialogComponent } from "../companies/company-chart-dialog/company-chart-dialog.component";
import { CompanyExportToPdfService } from "./companyExportToPdf.service";
import { ModelcompanytypeComponent } from "./modelcompanytype/modelcompanytype.component";
import { ToastrService } from "ngx-toastr";
import { UserPermissionService } from "../../../../services/user-permission.service";
import { StorageService } from "../../../../services/storage.service";
import { ServiceService } from "./../../../administration/service/service.service";

export interface PeriodicElement {
  compyname: string;
  comsubname: string;
  comid: string;
  comaddress: string;
  comstate: string;
  comzipcode: string;
  comsubtype: string;
  compaction: string;
}
const ELEMENT_DATA: PeriodicElement[] = [
  {
    compyname: "",
    comsubname: "",
    comid: "",
    comaddress: "",
    comstate: "",
    comzipcode: "",
    comsubtype: "",
    compaction: "",
  },
];
@Component({
  selector: "app-companylisttable",
  templateUrl: "./companylisttable.component.html",
  styleUrls: ["./companylisttable.component.scss"],
  providers: [CompanyService],
})
export class CompanylisttableComponent implements OnInit {
  companyObj: any;
  companyParam: any;
  isDataFound = true;
  /** out event emitter */
  @Output() listCompany = new EventEmitter<string>();
  /** */
  selectedCompanyID = false;
  CompanyDetails = null;

  displayedColumns: string[] = [
    "CompanyName",
    "CompanySubdivision",
    "ParentName",
    "CompanyIndentNumber",
    "Address",
    "StateName",
    "ZipCode",
    "CompanySubdivisionType",
    "compaction",
  ];
  companydataSource = new MatTableDataSource(ELEMENT_DATA);
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  insertedStatus = false;
  actions = true;
  constructor(
    public comapny: CompanyService,
    private dataShare: DataSharingService,
    private route: Router,
    public dialog: MatDialog,
    public companyChartDialog: MatDialog,
    private tostre: ToastrService,
    private companyExportToPdf: CompanyExportToPdfService,
    public UserPermission: UserPermissionService,
    private storage: StorageService,
    private adminService: ServiceService
  ) {
    this.CompanyDetails = JSON.parse(localStorage.getItem("CompanyDetails"));
    if (this.CompanyDetails) {
      this.selectedCompanyID = this.CompanyDetails.CompanyID;
    }

    this.companydataSource = new MatTableDataSource();
    this.companydataSource.sort = this.sort;
  }

  ngOnInit() {
    // if(this.selectedCompanyID){
    //   this.listCompany.emit(this.CompanyDetails);
    // }

    this.dataShare.currentMessage.subscribe((x: any) => {
      if (typeof x === "string") return;

      if (this.displayedColumns.indexOf("Status") > 0) {
        this.displayedColumns.pop();
        this.displayedColumns.push("compaction");
        this.insertedStatus = false;
        this.actions = true;
      }
      // console.log(x.companySearchList);
      this.companyObj = x.companySearchList;
      if (x.companySearchList.length != 0) {
        this.isDataFound = true;
      } else {
        this.isDataFound = false;
      }
      // console.log("list====>");
      // console.log(x.companySearchList);

      this.companydataSource = new MatTableDataSource(x.companySearchList);
      this.checkCompanyIsSingle(x.companySearchList);
      this.companydataSource.sort = this.sort;
      // this.sort.disableClear =true;
    });
    this.dataShare.currentObj.subscribe((x: any) => {
      this.companyParam = x;
      // console.log(this.companyParam);
    });

    this.dataShare.importCompanyStream.subscribe((impSource) => {
      if (typeof impSource === "string") return;

      if (this.displayedColumns.indexOf("Status") < 0) {
        this.displayedColumns.pop();
        this.displayedColumns.push("Status");
        this.insertedStatus = true;
        this.actions = false;
      }
      this.companydataSource = new MatTableDataSource(impSource);
      this.checkCompanyIsSingle(impSource);
    });

    if (this.displayedColumns.indexOf("Status") > 0) {
      this.companydataSource = new MatTableDataSource();
      this.companydataSource.sort = this.sort;
      this.displayedColumns.pop();
      this.displayedColumns.push("compaction");
      this.insertedStatus = false;
      this.actions = true;
    }
  }
  changeCompanyStatus(event, data: any) {
    // event.stopPropagation();
    // console.log(data)
    let msg = data.IsActive ? "deactivate" : "activate";
    let param = {
      CompanyID: +data.CompanyID,
    };
    // Swal.fire({
    //   //title: 'Are you sure you want to delete ?',
    //   text: "Are you sure you want to " + msg + " this?",
    //   showCancelButton: true,
    //   confirmButtonText: "Yes",
    //   cancelButtonText: "Cancel",
    // }).then((result) => {
    //   if (result.value) {
    this.comapny.changeCompanyStatus(param).subscribe((response: any) => {
      // console.log("response--->", response);
      if (response.status === true) {
        // this.tostre.success(
        //   (msg === "deactivate"
        //     ? "Deactivate"
        //     : msg === "activate"
        //     ? "Activate"
        //     : msg) + " successfully.",
        //   "",
        //   {
        //     positionClass: "toast-top-right",
        //   }
        // );
        this.tostre.success(this.adminService.statusMsg);
        this.companyObj.splice(
          this.companyObj.findIndex((a: any) => a.CompanyID == data.CompanyID),
          1
        );
        // let obj1 = this.companyObj.find(
        //   (x: any) => x.CompanyID == data.CompanyID
        // );
        // let index = this.companyObj.indexOf(obj1);
        // this.companyObj.fill((obj1.IsActive = !obj1.IsActive), index, index++);
        this.companydataSource = new MatTableDataSource(this.companyObj);
        this.checkCompanyIsSingle(this.companyObj);
        //let sts = data.IsActive ? false: true;
        //data.IsActive = sts;
        this.setCompanyToLocalStorage(data);
      }
    });
    //   }
    // });
  }
  changeCompanyStatus1(event, data: any) {
    // event.stopPropagation();
    // console.log(data)
    let msg = data.IsActive ? "deactivate" : "activate";
    let param = {
      CompanyID: +data.CompanyID,
    };
    Swal.fire({
      //title: 'Are you sure you want to delete ?',
      text: "Are you sure you want to " + msg + " this?",
      showCancelButton: true,
      confirmButtonText: "Yes",
      cancelButtonText: "Cancel",
    }).then((result) => {
      if (result.value) {
        this.comapny.changeCompanyStatus(param).subscribe((response: any) => {
          if (response.status === true) {
            let obj1 = this.companyObj.find(
              (x: any) => x.CompanyID == data.CompanyID
            );
            let index = this.companyObj.indexOf(obj1);
            this.companyObj.fill(
              (obj1.IsActive = !obj1.IsActive),
              index,
              index++
            );

            this.companydataSource = new MatTableDataSource(this.companyObj);
            this.checkCompanyIsSingle(this.companyObj);
            //let sts = data.IsActive ? false: true;
            //data.IsActive = sts;
            this.setCompanyToLocalStorage(data);
          }
        });
      }
    });
  }
  editCompany(e) {
    this.setCompanyToLocalStorage(e);
    this.route.navigate([
      "/products/administration/organizationmanagement/companies/editcompanies/" +
        btoa(e.CompanyID),
    ]);
  }

  setCompanyToLocalStorage(data: any) {
    //console.log(data)
    // if(this.selectedCompanyID == data.CompanyID){
    //   this.selectedCompanyID = false;
    //   localStorage.removeItem("CompanyDetails");
    // }else{
    //   this.selectedCompanyID = data.CompanyID;
    //   localStorage.setItem("CompanyDetails", JSON.stringify(data));
    // }

    // localStorage.setItem("CompanyDetails", JSON.stringify(data));
    this.storage.setData("CompanyDetails", JSON.stringify(data));
    this.listCompany.emit(data);
    if (this.selectedCompanyID == data.CompanyID) {
      this.selectedCompanyID = false;
      this.storage.removeData("CompanyDetails");
    } else this.selectedCompanyID = data.CompanyID;
  }
  selectRow: any = false;
  deleteCompany(event, data: any) {
    event.stopPropagation();
    // console.log(data)
    Swal.fire({
      //title: 'Are you sure you want to delete ?',
      // text: "Are you sure you want to remove this?",
      text: this.adminService.deleteMsg,
      showCancelButton: true,
      confirmButtonText: "Yes",
      cancelButtonText: "No",
    }).then((result) => {
      if (result.value) {
        this.comapny
          .DeleteCompany(data.CompanyID)
          .subscribe((response: any) => {
            if (response.status === true) {
              let obj1 = this.companyObj.find(
                (x) => x.CompanyID == data.CompanyID
              );
              let index = this.companyObj.indexOf(obj1);
              this.companyObj.splice(index, 1);

              this.companydataSource = new MatTableDataSource(this.companyObj);
              this.checkCompanyIsSingle(this.companyObj);
              if (this.selectedCompanyID == data.CompanyID) {
                localStorage.removeItem("CompanyDetails");
              }
            }
          });
      }
    });
  }
  deleteCompany1(event, data: any) {
    // event.stopPropagation();
    // console.log(data)
    // Swal.fire({
    //   //title: 'Are you sure you want to delete ?',
    //   text: "Are you sure you want to remove this?",
    //   showCancelButton: true,
    //   confirmButtonText: "Yes",
    //   cancelButtonText: "Cancel",
    // }).then((result) => {
    //   if (result.value) {
    this.comapny.DeleteCompany(data.CompanyID).subscribe((response: any) => {
      if (response.status === true) {
        // this.tostre.success("Activity deleted successfully.", "", {
        //   positionClass: "toast-top-right",
        // });
        let obj1 = this.companyObj.find((x) => x.CompanyID == data.CompanyID);
        let index = this.companyObj.indexOf(obj1);
        this.companyObj.splice(index, 1);

        this.companydataSource = new MatTableDataSource(this.companyObj);
        this.checkCompanyIsSingle(this.companyObj);
        if (this.selectedCompanyID == data.CompanyID) {
          localStorage.removeItem("CompanyDetails");
        }
      }
    });
    //}
    //});
  }
  archiveCompany(event, data: any) {
    // event.stopPropagation();
    // if (data.IsArchive) {
    //   return;
    // }
    var type = data.IsArchive ? "unarchive" : "archive";
    // UpdateCompanyArchive
    Swal.fire({
      //title: 'Are you sure you want to delete ?',
      text: "Are you sure you want to " + type + " this?",
      showCancelButton: true,
      confirmButtonText: "Yes",
      cancelButtonText: "No",
    }).then((result) => {
      if (result.value) {
        this.comapny
          .UpdateCompanyArchive(data.CompanyID)
          .subscribe((response) => {
            let obj1 = this.companyObj.find(
              (x) => x.CompanyID == data.CompanyID
            );
            let index = this.companyObj.indexOf(obj1);
            this.companyObj.splice(index, 1);

            this.companydataSource = new MatTableDataSource(this.companyObj);
            this.checkCompanyIsSingle(this.companyObj);
            if (this.selectedCompanyID == data.CompanyID) {
              localStorage.removeItem("CompanyDetails");
            }
          });
      }
    });
  }

  openDialogChart(event, elem) {
    window.localStorage.setItem("CompanyDetails", JSON.stringify(elem));
    // console.log("helll");
    const dialogCompanyRef = this.companyChartDialog.open(
      CompanyChartDialogComponent,
      {
        maxWidth: "90vw",
        width: "90%",
        height: "98vh",
      }
    );
    dialogCompanyRef.afterClosed().subscribe((x) => {
      // console.log("hello");
    });
    event.stopPropagation();
  }
  exportToPdf(companyObj) {
    this.companyExportToPdf.exportToPdf(companyObj);
  }

  viewcomsubdiv(Company) {
    const dialogRef = this.dialog.open(ModelcompanytypeComponent, {
      width: "400px",
      panelClass: "my-dialog-container-class2",
      data: { CompanyID: Company.CompanyID },
    });
    dialogRef.afterClosed().subscribe((result) => {});
  }

  private checkCompanyIsSingle(compList: any) {
    if (Array.isArray(compList)) {
      if (compList.length === 1) {
        // this.setCompanyToLocalStorage(compList[0]);
        this.selectedCompanyID = compList[0].CompanyID;
        this.storage.setData("CompanyDetails", JSON.stringify(compList[0]));
        this.listCompany.emit(compList[0]);
      }
    }
  }
}
