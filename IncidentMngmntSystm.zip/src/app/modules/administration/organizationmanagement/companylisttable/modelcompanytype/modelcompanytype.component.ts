import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material';
import { ModelcompanytypeService } from './modelcompanytype.service';

@Component({
  selector: 'app-modelcompanytype',
  templateUrl: './modelcompanytype.component.html',
  styleUrls: ['./modelcompanytype.component.scss']
})
export class ModelcompanytypeComponent implements OnInit {
  subdivionObj:any;
  companyID: any;
  constructor(
    public companyTypeService:ModelcompanytypeService,
    @Inject(MAT_DIALOG_DATA) public data: any) { }
  ngOnInit() {
    this.companyID = this.data.CompanyID;
    this.getCompanySubdivisionbyPropertyId(this.companyID);
  }

  getCompanySubdivisionbyPropertyId(CompanyID) {
    let param = {
      "CompanyID": parseInt(CompanyID)
    }
    this.companyTypeService.getCompanyTypeListbyCompanyId(param).subscribe((x)=>{
      console.log(x);
      this.subdivionObj = x.getCompanyTypeListbyCompanyId;
    });
  }
}
