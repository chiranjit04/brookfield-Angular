import { TestBed } from '@angular/core/testing';

import { ModelcompanytypeService } from './modelcompanytype.service';

describe('ModelcompanytypeService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ModelcompanytypeService = TestBed.get(ModelcompanytypeService);
    expect(service).toBeTruthy();
  });
});
