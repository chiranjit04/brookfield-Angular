import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModelcompanytypeComponent } from './modelcompanytype.component';

describe('ModelcompanytypeComponent', () => {
  let component: ModelcompanytypeComponent;
  let fixture: ComponentFixture<ModelcompanytypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModelcompanytypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModelcompanytypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
