import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { environment } from "../../../../../../environments/environment";
import { Observable } from "rxjs";

@Injectable({
  providedIn: "root",
})
export class ModelcompanytypeService {
  _LocalUrl: string;
  constructor(private http: HttpClient) {
    this._LocalUrl = environment.origin;
    // this._LocalUrl = 'http://localhost:1601/';
  }
  getCompanyTypeListbyCompanyId(param: any): Observable<any> {
    return this.http.post<any>(this._LocalUrl + "api/GetCompanyTypeListbyCompanyId", param);
  }  
}
