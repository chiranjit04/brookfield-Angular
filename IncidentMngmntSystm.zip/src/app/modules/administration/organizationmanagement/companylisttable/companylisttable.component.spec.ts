import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompanylisttableComponent } from './companylisttable.component';

describe('CompanylisttableComponent', () => {
  let component: CompanylisttableComponent;
  let fixture: ComponentFixture<CompanylisttableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompanylisttableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompanylisttableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
