import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";

import { OrganizationmanagementRoutingModule } from "./organizationmanagement-routing.module";
import { OrganizationmanagementComponent } from "./organizationmanagement.component";
import { CompaniesComponent } from "./companies/companies.component";
import { PermissionsComponent } from "./permissions/permissions.component";
import { ProfilesComponent } from "./profiles/profiles.component";
import { WorkgroupsComponent } from "./workgroups/workgroups.component";
import { UsersComponent } from "./users/users.component";
import { Ng2SearchPipeModule } from "ng2-search-filter";

import { CompanylisttableComponent } from "./companylisttable/companylisttable.component";

import { UserModalComponent } from "./users/adduser.component";
import { AddcompaniesComponent } from "./addcompanies/addcompanies.component";
import { KeycontactlistComponent } from "./keycontactlist/keycontactlist.component";
import { AllpersonlistComponent } from "./allpersonlist/allpersonlist.component";
import { AddprofileComponent } from "./profiles/addprofile/addprofile.component";
import { JobtitlesComponent } from "./jobtitles/jobtitles.component";
import { AddjobtitleComponent } from "./jobtitles/addjobtitle/addjobtitle.component";
import { UserlistComponent } from "./users/userlist/userlist.component";
import { SelectcompanyComponent } from "./workgroups/selectcompany/selectcompany.component";
import { AssignpropertiesComponent } from "./workgroups/assignproperties/assignproperties.component";
import { ViewworkgroupComponent } from "./workgroups/viewworkgroup/viewworkgroup.component";
import { TranceferuserComponent } from "./users/tranceferuser/tranceferuser.component";
import { AccepttranceferuserComponent } from "./users/accepttranceferuser/accepttranceferuser.component";
import { CompanyChartDialogComponent } from "./companies/company-chart-dialog/company-chart-dialog.component";
import { UploadFileListComponent } from "./users/uploadFileList/uploadfilelist.component";
import { ModelAssociatedJobComponent } from "./profiles/model-associated-job/model-associated-job.component";
import { ModelcompanytypeComponent } from "./companylisttable/modelcompanytype/modelcompanytype.component";
import { SharedModule } from "src/app/shared/shared.module";
import { ModelMasterAdminComponent } from "./users/model-master-admin/model-master-admin.component";
import { SharedMaterialModule } from "../../../shared/shared-material.module";

//  import { UploadJobTitle } from './jobtitles/uploadJobtitleFile/uploadjobtitle.component';
@NgModule({
  declarations: [
    OrganizationmanagementComponent,
    CompaniesComponent,
    PermissionsComponent,
    ProfilesComponent,
    WorkgroupsComponent,
    UsersComponent,
    UserModalComponent,
    CompanylisttableComponent,
    AddcompaniesComponent,
    KeycontactlistComponent,
    AllpersonlistComponent,
    AddprofileComponent,
    JobtitlesComponent,
    AddjobtitleComponent,
    UserlistComponent,
    SelectcompanyComponent,
    AssignpropertiesComponent,
    ViewworkgroupComponent,
    TranceferuserComponent,
    AccepttranceferuserComponent,
    CompanyChartDialogComponent,
    UploadFileListComponent,
    ModelAssociatedJobComponent,
    ModelcompanytypeComponent,
    ModelMasterAdminComponent,
    // UploadJobTitle,
  ],
  imports: [
    CommonModule,
    OrganizationmanagementRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    Ng2SearchPipeModule,
    SharedModule,
    SharedMaterialModule,
  ],
  providers: [
    {
      provide: MatDialogRef,
      useValue: {},
    },
    {
      provide: MAT_DIALOG_DATA,
      useValue: {}, // Add any data you wish to test if it is passed/used correctly
    },
  ],
  entryComponents: [
    TranceferuserComponent,
    AccepttranceferuserComponent,
    CompanyChartDialogComponent,
    ModelAssociatedJobComponent,
    ModelcompanytypeComponent,
    ModelMasterAdminComponent,
  ],
})
export class OrganizationmanagementModule {}
/**added */
