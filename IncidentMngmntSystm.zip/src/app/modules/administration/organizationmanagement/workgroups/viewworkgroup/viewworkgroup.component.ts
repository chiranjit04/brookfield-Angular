import { Component, OnInit } from "@angular/core";
import { FormGroup, FormControl, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import Swal from "sweetalert2";
import { WorkgroupService } from "../workgroup.service";
import { DataSharingService } from "../../dataSharing.service";
import { StorageService } from "../../../../../services/storage.service";
@Component({
  selector: "app-viewworkgroup",
  templateUrl: "./viewworkgroup.component.html",
  styleUrls: ["./viewworkgroup.component.scss"],
})
export class ViewworkgroupComponent implements OnInit {
  authToken = null;
  userData = null;
  currentUserID = 0;

  companies = [];
  selectedCompanyID: any = false;

  Workgroups = [];
  selectedWorkgroupID: any = false;

  properties = [];
  selectedPropertyID: any = false;

  workgroupCompanyID: any = 0;

  constructor(
    private workgroupService: WorkgroupService,
    private dataSharingService: DataSharingService,
    private storage: StorageService
  ) {
    //... Read User Data ...
    this.authToken = this.storage.getData("token");
    this.userData = JSON.parse(this.storage.getData("UserData"));
    this.currentUserID = this.userData[0].UserID;
  }

  ngOnInit() {
    //this.getCompanies()
    // this.getWorkgroup()
    //this.getProperties(0)
    //... Get company from sharing ...
    this.dataSharingService.managePropertyWorkGroupStream.subscribe(
      (response) => {
        let result: any = response;
        // console.log("ram = ", result)
        if (typeof result === "string") {
          return;
        }

        this.companies = result.companies || [];

        this.companies.sort((a, b) =>
          (a.ParentName || "") < (b.ParentName || "")
            ? -1
            : (a.ParentName || "") > (b.ParentName || "")
            ? 1
            : 0
        );

        // this.properties = result.properties;
        this.selectedCompanyID = false;
        this.selectedWorkgroupID = false;
        this.Workgroups = [];
        this.properties = [];
      }
    );
  }

  /* Company Section */
  getCompanies() {
    let result: any;
    this.workgroupService
      .getCompanies(this.currentUserID)
      .subscribe((response) => {
        result = response;
        // this.companies = result.comapnySubdivision
        this.companies = result.companyList;
      });
  }
  selectCompany(data: any) {
    this.selectedWorkgroupID = false;
    this.selectedPropertyID = false;
    if (data.CompanyID == this.selectedCompanyID) {
      this.selectedCompanyID = false;
    } else {
      this.selectedCompanyID = data.CompanyID;
    }
    this.workgroupService
      .getWorkGroupList(this.selectedCompanyID)
      .subscribe((response) => {
        let result: any;
        result = response;
        this.Workgroups = result.Workgroup;
        // console.log(this.Workgroups)
      });
    this.workgroupService
      .GetAsignedPopertybyCompanyWorkGroup({
        CompanyID: this.selectedCompanyID,
        WorkGroupID: null,
      })
      .subscribe((elem) => {
        // console.log(elem);
        this.properties = elem.GetAsignedPopertybyCompanyWorkGroup;
      });
  }

  /* Sub Division Section */
  getWorkgroup() {
    let result: any;
    this.workgroupService.getWorkGroupList(0).subscribe((response) => {
      result = response;
      this.Workgroups = result.Workgroup;
      // console.log(this.Workgroups)
    });
  }
  selectWorkgroup(data: any) {
    this.selectedPropertyID = false;
    // console.log(data)
    if (data.WorkGroupID == this.selectedWorkgroupID) {
      this.selectedWorkgroupID = false;
      this.workgroupCompanyID = 0;

      this.getProperties(0);
    } else {
      this.selectedWorkgroupID = data.WorkGroupID;
      this.workgroupCompanyID = data.CompanyID;
      this.getProperties(this.selectedWorkgroupID);
    }
  }

  getProperties(WorkGroupID: any) {
    // this.workgroupService
    //   .GetWorKGroupPropertyList(WorkGroupID, "", "", this.userData[0].UserID)
    //   .subscribe((response) => {
    //     let result: any;
    //     result = response;
    //     this.properties = result.WorKGroupPropertyList;
    //     // console.log("aaaa -- ",this.properties)
    //   });

    this.workgroupService
      .GetAsignedPopertybyCompanyWorkGroup({
        CompanyID: this.selectedCompanyID,
        WorkGroupID: this.selectedWorkgroupID,
      })
      .subscribe((elem) => {
        // console.log(elem);
        this.properties = elem.GetAsignedPopertybyCompanyWorkGroup;
      });
  }

  selectProperty(data: any) {
    if (this.selectedWorkgroupID) {
      if (data.IsAssign == 1) {
        this.AssignWorkGroupToProperty(data, 0);
      } else if (data.PropertyID == this.selectedPropertyID) {
        this.selectedPropertyID = false;
        this.AssignWorkGroupToProperty(data, 0);
      } else {
        this.selectedPropertyID = data.PropertyID;
        this.AssignWorkGroupToProperty(data, 1);
      }
    } else {
      Swal.fire({
        text: "Please first select a workgroup",
      });
    }
  }

  AssignWorkGroupToProperty(data: any, action: any) {
    // console.log(data);
    let finalData = {
      PropertyID: +data.PropertyID,
      CompanyID: +this.workgroupCompanyID,
      WorkGroupID: +this.selectedWorkgroupID,
      UserId: +this.userData[0].UserID,
      IsAssined: action,
    };
    this.workgroupService
      .UpdateAssignWorkGroupToProperty(finalData)
      .subscribe((response) => {
        // console.log(response)
        this.getProperties(this.selectedWorkgroupID);
      });
  }
}
