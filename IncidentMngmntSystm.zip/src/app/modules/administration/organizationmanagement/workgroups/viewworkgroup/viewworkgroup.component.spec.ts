import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewworkgroupComponent } from './viewworkgroup.component';

describe('ViewworkgroupComponent', () => {
  let component: ViewworkgroupComponent;
  let fixture: ComponentFixture<ViewworkgroupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewworkgroupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewworkgroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
