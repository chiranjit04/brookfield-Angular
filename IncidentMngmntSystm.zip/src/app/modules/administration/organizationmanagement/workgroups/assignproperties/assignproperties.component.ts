import { Component, OnInit, ViewChild } from "@angular/core";
import { WorkgroupService } from "../workgroup.service";
import { DataSharingService } from "../../dataSharing.service";
import { MatTableDataSource } from "@angular/material/table";
import { MatSort } from "@angular/material/sort";
import { UserPermissionService } from '../../../../../services/user-permission.service';
import { StorageService } from '../../../../../services/storage.service';
@Component({
  selector: "app-assignproperties",
  templateUrl: "./assignproperties.component.html",
  styleUrls: ["./assignproperties.component.scss"],
})
export class AssignpropertiesComponent implements OnInit {
  PropertyDetail = null;
  PropertyID = 0;
  PropertyName = "";
  PropertyNumber = "";
  PropertyDescription = "";

  authToken = null;
  userData = null;
  currentUserID = false;

  // propertybycompany: any
  propertybyworkgroup: any = [];
  workgrouplist: any;
  assignedworkgroup: any;
  selectedPropertyId = false;
  selectedWorkgroupId = false;

  displayedColumns: string[] = [
    "CompanyName",
    "CompanySubdivision",
    "WorkGroupName",
    "WorkGroupTypeName",
  ];
  dataSource = new MatTableDataSource();

  @ViewChild(MatSort, { static: true }) sort: MatSort;

  constructor(
    private WorkgroupService: WorkgroupService,
    private dataSharingService: DataSharingService,
    private UserPermission: UserPermissionService,
    private storage: StorageService
  ) {
    this.PropertyDetail = JSON.parse(this.storage.getData("PropertyDetail"));
    // console.log(this.PropertyDetail)
    if (this.PropertyDetail) {
      this.PropertyID = this.PropertyDetail.PropertyID;
      this.PropertyName = this.PropertyDetail.PropertyName;
      this.PropertyNumber = this.PropertyDetail.PropertyIdentNumber;
      this.PropertyDescription = this.PropertyDetail.PropertyDescription;
    }
    this.authToken = this.storage.getData("token");
    this.userData = JSON.parse(this.storage.getData("UserData"));
    this.currentUserID = this.userData[0].UserID;

    this.dataSource = new MatTableDataSource();
    this.dataSource.sort = this.sort;
  }

  ngOnInit() {
    // this.getWorKGroupPropertyList(0, "", "", this.currentUserID)
    this.dataSharingService.assignPropertyWorkGroupStream.subscribe(
      (response) => {
        let result: any = response;
        //console.log("rama = ", result)
        if (typeof result === "string") return;

        this.propertybyworkgroup = result.propertybyworkgroup;
        
        (this.propertybyworkgroup || []).sort((a, b) => (a.PropertyName || "") < (b.PropertyName || "") ? -1 : ((a.PropertyName ||  "") > (b.PropertyName || "") ? 1 : 0))
       
        this.selectedPropertyId = false;
        this.assignedworkgroup = [];
        this.dataSource = null;
      }
    );

    this.getWorkGroupCompanybyPropertyId(0);
  }

  /**
   * Get Workgroup Property List
   * @param WorkGroupID
   * @param PropertyName
   * @param PropertyID
   * @param UserID
   */
  getWorKGroupPropertyList(WorkGroupID, PropertyName, PropertyID, UserID) {
    const obj = {
      WorkGroupID: WorkGroupID,
      PropertyName: PropertyName,
      PropertyIdentNumber: PropertyID,
      UserId: this.currentUserID,
    };

    let result;
    this.WorkgroupService.GetWorKGroupPropertyList(
      "",
      "",
      "",
      UserID
    ).subscribe((res) => {
      result = res;
      this.propertybyworkgroup = result.WorKGroupPropertyList;
      
    });
  }

  /**
   * Select Property
   * @param PropertyId
   *
   */
  propertySelected(PropertyId) {
    // console.log(PropertyId)

    if (this.selectedPropertyId == PropertyId) {
      this.selectedPropertyId = false;
      // this.selectedWorkgroupPropertyId = false
      this.assignedworkgroup = [];
      this.dataSource = null;
    } else {
      this.selectedPropertyId = PropertyId;
      this.assignedworkgroup = this.getWorkGroupCompanybyPropertyId(PropertyId);
      this.dataSource = new MatTableDataSource(this.assignedworkgroup);
      this.dataSource.sort = this.sort;
    }
  }
  /***
   *
   * Select Workgroup
   */

  selectWorkgroup(data) {
    const obj = {
      PropertyID: +this.selectedPropertyId,
      CompanyID: +data.CompanyID,
      WorkGroupID: +data.WorkGroupID,
      UserId: +this.currentUserID,
      IsAssined: data.IsAssiged ? 0 : 1,
    };

    // console.log("data - ", data)
    // console.log("obj - ", obj)

    //this.selectedPropertyId = false
    this.updateAssignWorkGroupToProperty(obj);

    /* if (this.selectedWorkgroupId == data.WorkGroupID) {
      this.selectedWorkgroupId = false
      this.updateAssignWorkGroupToProperty(obj)

    }
    else {

      this.selectedWorkgroupId = data.WorkGroupID
      this.updateAssignWorkGroupToProperty(obj)
    } */
  }

  /**
   * Get Workgroup by PropertyID
   * @param PropertyID
   *
   */

  getWorkGroupCompanybyPropertyId(PropertyID) {
    const obj = {
      PropertyID: +PropertyID,
    };
    let result;
    this.WorkgroupService.getWorkGroupCompanybyPropertyId(obj).subscribe(
      (res) => {
        result = res;
        this.assignedworkgroup = result.getWorkGroupCompanybyPropertyId;
        console.log("assigned list", this.assignedworkgroup);
        this.dataSource = new MatTableDataSource(this.assignedworkgroup);
        this.dataSource.sort = this.sort;
      }
    );
  }

  /**
   *
   * Assign Workgroup to Property
   * @param obj
   *
   */

  updateAssignWorkGroupToProperty(obj) {
    this.WorkgroupService.UpdateAssignWorkGroupToProperty(obj).subscribe(
      (res) => {
        //console.log("res======>", res)
        this.assignedworkgroup = this.getWorkGroupCompanybyPropertyId(
          this.selectedPropertyId
        );
        this.dataSource = new MatTableDataSource(this.assignedworkgroup);
        this.dataSource.sort = this.sort;
      }
    );
  }
}
