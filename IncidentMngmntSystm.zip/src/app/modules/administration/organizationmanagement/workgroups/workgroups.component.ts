import { Component, OnInit, ViewChild, ElementRef } from "@angular/core";
import { DataSharingService } from "../dataSharing.service";
import { MatSort } from "@angular/material/sort";
import { WorkgroupService } from "./workgroup.service";
import { MatTableDataSource } from "@angular/material/table";
import Swal from "sweetalert2";
import { Router } from "@angular/router";
import { Observable } from "rxjs";
import { FormControl } from "@angular/forms";
import { startWith, map } from "rxjs/operators";
import * as ExcelJS from "exceljs";
import { ToastrService } from "ngx-toastr";
import { WorkgroupImportExport } from "./workgroup-import-export";
import { MatAutocompleteTrigger } from "@angular/material/autocomplete/typings/autocomplete-trigger";
import { UserPermissionService } from "../../../../services/user-permission.service";
import { StorageService } from "../../../../services/storage.service";
@Component({
  selector: "app-workgroups",
  templateUrl: "./workgroups.component.html",
  styleUrls: ["./workgroups.component.scss"],
})
export class WorkgroupsComponent implements OnInit {
  @ViewChild("fileInput", { static: false }) importFile;
  downloadToExcel: Array<any> = [];
  SystemPickValues: any = [];
  insertedStatus: boolean = false;
  defaultStatus: boolean = true;
  message: any = false;
  companylist: any;
  streets: any[] = [];
  filteredStreets: any;
  companyControl: any = new FormControl();
  authToken = null;
  userData = null;
  currentUserID = 0;
  selectedWorkgroupID = false;
  companies = [];
  //selectedCompanyID:any = false

  Workgroups = [];
  //selectedWorkgroupID:any = false

  properties = [];
  //selectedPropertyID:any = false

  propertybyworkgroup: any = [];

  isShown = false;

  workgroupList: any;

  CompanyDetails: any;
  CompanyID = 0;
  CompanyName = "";
  SubCompanyHeader = "";
  CompanyNameHeader = "";
  constructor(
    private dataSharingService: DataSharingService,
    private workgroupService: WorkgroupService,
    public router: Router,
    public exportToExcel: WorkgroupImportExport,
    private tostre: ToastrService,
    public UserPermission: UserPermissionService,
    private storage: StorageService
  ) {
    //... Read User Data from Storage ...
    this.authToken = this.storage.getData("token");
    if (this.authToken == null) {
      this.router.navigate(["/login"]);
      return;
    }
    this.userData = JSON.parse(this.storage.getData("UserData"));
    this.currentUserID = this.userData[0].UserID;

    /* check module permission of the user */
    if (this.UserPermission.checkPermission("access_workgroups") == false) {
      this.router.navigate(["/products/list"]);
      this.tostre.warning(
        "You don't have permission to access this module.",
        "",
        {
          positionClass: "toast-top-right",
        }
      );
      return;
    }

    // this.dataSource = new MatTableDataSource;
    this.CompanyDetails = JSON.parse(this.storage.getData("CompanyDetails"));
    if (this.CompanyDetails) {
      this.CompanyID = this.CompanyDetails.CompanyID;
      this.CompanyName = this.CompanyDetails.CompanyName;
      this.CompanyNameHeader =
        this.CompanyDetails.CompanyName +
        " - " +
        this.CompanyDetails.CompanyIndentNumber;
      if (this.CompanyDetails.ParentName) {
        /**
         * if parent name and parent company name are some
         */
        if (
          this.CompanyDetails.ParentName ===
          this.CompanyDetails.ParentCompanyName
        ) {
          this.SubCompanyHeader =
            "This is a Company Subdivision of Company: " +
            this.CompanyDetails.ParentCompanyName +
            " - " +
            this.CompanyDetails.ParentCompanyIndentNumber;
        } else {
          /**
           * if not same
           */
          this.SubCompanyHeader =
            "This is a Subdivision of Company Subdivision: " +
            this.CompanyDetails.ParentCompanyName +
            " - " +
            this.CompanyDetails.ParentCompanyIndentNumber;
        }
        // this.SubCompanyHeader =
        //   "This is a Company Subdivision of Company : " +
        //   this.CompanyDetails.ParentName +
        //   " - " +
        //   this.CompanyDetails.ParentIdentNumber;
      }
    }
    this.isCompanySelected();
  }

  displayedColumns: string[] = [
    "CompanyName",
    "SubDivision",
    "WorkGroupName",
    "WorkGroupNo",
    "WorkgroupType",
    "CreatedDate",
    "IsActive",
  ];
  dataSource = new MatTableDataSource();

  @ViewChild(MatSort, null) sort: MatSort;

  isCompanySelected() {
    if (this.CompanyID == 0) {
      // Swal.fire({ text: "Please first select a Company." });

      this.tostre.error("Please first select a Company.", "", {
        positionClass: "toast-top-right",
      });

      this.router.navigate([
        "products/administration/organizationmanagement/companies",
      ]);
    }
    if (this.CompanyID && !this.CompanyDetails.IsActive) {
      // Swal.fire({
      //   text: "Selected company is inactive. Please select an active company",
      // });
      this.showInvalid(
        "Selected company is inactive. Please select an active company"
      );
      this.router.navigate([
        "products/administration/organizationmanagement/companies",
      ]);
    }
    if (this.CompanyID && this.CompanyDetails.IsArchive) {
      Swal.fire({
        text: "Selected company is archived. Please select an active company",
      });
      this.router.navigate([
        "products/administration/organizationmanagement/companies",
      ]);
    }
  }

  checkCompany() {
    if (this.CompanyID && this.CompanyDetails.IsActive) {
      return true;
    } else if (this.CompanyDetails.IsActive == false) {
      // Swal.fire({
      //   text: "Selected company is inactive.",
      // }).then((result) => {
      this.showInvalid("Selected company is inactive.");
      this.router.navigate([
        "products/administration/organizationmanagement/companies",
      ]);
      // });
      return false;
    } else {
      Swal.fire({
        text: "Please first select a Company.",
      }).then((result) => {
        this.router.navigate([
          "products/administration/organizationmanagement/companies",
        ]);
      });
      return false;
    }
  }

  ngOnInit() {
    this.storage.removeData("justCreated");
    //if (this.checkCompany()) {
    this.companyDetail();
    this.getWorkgroupList(this.CompanyID);
    this.companyControl.value = this.CompanyName;
    //}
  }

  companyDetail() {
    this.workgroupService.getCompanySubdivision().subscribe((res) => {
      this.companylist = res.companySearchList;

      if (this.storage.getData("CompanyDetails")) {
        const selectedComp = JSON.parse(this.storage.getData("CompanyDetails"));
      }

      for (let i = 0; i < this.companylist.length; i++) {
        const arr = this.companylist[i].CompanyName;
        this.streets.push({
          companyID: this.companylist[i].CompanyID,
          companyName: this.companylist[i].CompanyName,
          ParentIdentNumber: this.companylist[i].ParentIdentNumber,
          ParentName: this.companylist[i].ParentName,
          CompanyIndentNumber: this.companylist[i].CompanyIndentNumber,
        });
      }

      this.streets.sort((a, b) =>
        a.companyName < b.companyName
          ? -1
          : a.companyName > b.companyName
          ? 1
          : 0
      );

      this.filteredStreets = this.companyControl.valueChanges.pipe(
        startWith(""),
        map((val: any) => (val.length >= 0 ? this._filter(val) : []))
      );
    });
  }

  _filter(val: any): any[] {
    return this.streets
      .map((x) => x)
      .filter((option) => {
        return option.companyName.toLowerCase().includes(val.toLowerCase());
      });
  }

  checkOne(test) {
    this.filteredStreets = this.companyControl.valueChanges.pipe(
      startWith(""),
      map((val: any) => (val.length >= 0 ? this._filter(val) : []))
    );
    test.blur();
  }

  onSelectCreateWorkgroup(event: any) {
    //this.CompanyID = null;
    this.dataSharingService.changeBoolean(false);
    if (event.index == 0) {
      this.getCompanyCreate();
      // console.log("ID is coming here or not", this.CompanyID);
      // this.getWorkgroupList(this.CompanyID);
      // this.workgroupService
      //   .getWorkGroupList(+this.CompanyID)
      //   .subscribe((data) => {
      //     // this.workGroupList = data.Workgroup;
      //   });
      this.dataSharingService.changeManagePropertyWorkGroup({
        companies: null,
        properties: null,
      });
      this.dataSharingService.changeAssignPropertyWorkGroup({
        propertybyworkgroup: null,
      });
    }
    if (event.index == 1) {
      this.getWorKGroupPropertyList(0, "", "", this.currentUserID);
      this.dataSharingService.changeCreateWorkGroup({ companies: null });
      this.dataSharingService.changeManagePropertyWorkGroup({
        companies: null,
        properties: null,
      });
    }
    if (event.index == 2) {
      //... caling view workgroup ..
      this.getCompanies();
      this.getProperties(0);
      this.dataSharingService.changeCreateWorkGroup({ companies: null });
      this.dataSharingService.changeAssignPropertyWorkGroup({
        propertybyworkgroup: null,
      });
    }
  }

  /* Company Section */
  getCompanyCreate() {
    let result: any;
    this.workgroupService
      .fetchAllComapny(this.currentUserID)
      .subscribe((response) => {
        result = response;
        // this.companies = result.getCompanybyUserid;
        this.dataSharingService.changeCreateWorkGroup({
          companies: result.getCompanybyUserid,
        });
      });
  }

  /* Company Section */
  getCompanies() {
    let result: any;
    this.workgroupService
      .getCompanies(this.currentUserID)
      .subscribe((response) => {
        result = response;
        this.companies = result.companyList;
        this.dataSharingService.changeManagePropertyWorkGroup({
          companies: this.companies,
          properties: this.properties,
        });
      });
  }

  getProperties(WorkGroupID: any) {
    this.workgroupService
      .GetWorKGroupPropertyList(WorkGroupID, "", "", this.userData[0].UserID)
      .subscribe((response) => {
        let result: any;
        result = response;
        this.properties = result.WorKGroupPropertyList;
        this.dataSharingService.changeManagePropertyWorkGroup({
          companies: this.companies,
          properties: this.properties,
        });
      });
  }

  getWorKGroupPropertyList(WorkGroupID, PropertyName, PropertyID, UserID) {
    const obj = {
      WorkGroupID: WorkGroupID,
      PropertyName: PropertyName,
      PropertyIdentNumber: PropertyID,
      UserId: this.currentUserID,
    };

    let result: any;
    this.workgroupService
      .GetWorKGroupPropertyList("", "", "", UserID)
      .subscribe((res) => {
        result = res;
        this.propertybyworkgroup = result.WorKGroupPropertyList;
        this.dataSharingService.changeAssignPropertyWorkGroup({
          propertybyworkgroup: this.propertybyworkgroup,
        });
      });
  }

  toggleShow() {
    this.isShown = !this.isShown;
    this.getWorkgroupList(this.CompanyID);
    //this.getPropertyPatrolZoneList(this.PropertyID, 0)
  }
  calledToExcel() {
    // WorkGroupStatus
    // console.log(this.downloadToExcel, this.SystemPickValues);
    if (this.downloadToExcel[0].hasOwnProperty("Status") === true) {
      this.exportToExcel.exportExcelSheet(
        this.downloadToExcel,
        this.SystemPickValues,
        false
      );
    } else {
      this.downloadToExcel.forEach((elem) => {
        elem["WorkGroupStatus"] =
          elem.IsActive === true ? "Active" : "InActive";
      });

      this.exportToExcel.exportExcelSheet(this.downloadToExcel, [], true);
    }
  }
  getWorkgroupList(CompanyId) {
    const obj = {
      CompanyID: +CompanyId,
    };
    let result: any;
    this.workgroupService.getWorkGroupData(obj).subscribe((res) => {
      result = res;
      this.workgroupList = result.workgroupList;
      this.downloadToExcel = result.workgroupList;
      this.dataSource = new MatTableDataSource(this.workgroupList);
      this.dataSource.sort = this.sort;
      this.sort.disableClear = true;
    });
  }

  ClearSearch() {
    this.CompanyNameHeader = "";
    this.SubCompanyHeader = "";
    this.companyControl.value = "";
    this.workgroupList = [];
    this.dataSource = new MatTableDataSource(this.workgroupList);
  }
  ngOnViewInit() {
    this.dataSource.sort = this.sort;
    this.sort.disableClear = true;
  }

  changeCompany(companyID, companyName, event, companyObj) {
    if (!event.isUserInput) return;
    if (companyID != "") {
      this.CompanyID = +companyID;
      this.CompanyName = companyName;
      this.CompanyNameHeader =
        companyName + " - " + companyObj.CompanyIndentNumber;
      if (companyObj.ParentName) {
        this.SubCompanyHeader =
          "This is a Company Subdivision of Company : " +
          companyObj.ParentName +
          " - " +
          companyObj.ParentIdentNumber;
      } else {
        this.SubCompanyHeader = "";
      }
      this.getWorkgroupList(companyID);
    }
    //else {
    //   this.dataSource = new MatTableDataSource(this.workgroupList);
    // }
  }
  /**
   * import excel sheet logic here
   */
  importToExcel() {
    this.SystemPickValues = [];
    if (this.importFile.nativeElement.files[0] === undefined) return;

    /** validate xlsx file */
    if (
      this.importFile.nativeElement.files[0].type !==
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" &&
      this.importFile.nativeElement.files[0].name
        .split(".")
        .lastIndexOf("xlsx") < 0
    ) {
      Swal.fire("This not excel file");
      return;
    }

    let wb = new ExcelJS.Workbook();
    let reader: FileReader = new FileReader();
    let propertyImportArr = [];
    reader.readAsArrayBuffer(this.importFile.nativeElement.files[0]);

    reader.onload = () => {
      let buffer: any = reader.result;
      wb.xlsx.load(buffer).then((workbook) => {
        workbook.eachSheet((sheet, id) => {
          if (sheet.name === "Upload Sheet") {
            sheet.eachRow((row, rowIndex) => {
              if (rowIndex > 3) {
                propertyImportArr.push(row.values);
              }
            });
            // console.log(propertyImportArr);
            this.PropertyImportSend(propertyImportArr);
          }
          if (sheet.name === "SystemPickValues") {
            sheet.eachRow((row, rowIndex) => {
              this.SystemPickValues.push(row.values);
            });
          }
        });
      });
    };
    reader.onerror = () => {
      Swal.fire("Error in Reading File ");
    };

    /** clearing tha value of element for override that data */
    this.importFile.nativeElement.value = "";
  }

  changeT() {
    this.isShown = false;
  }

  PropertyImportSend(arr) {
    let importedData = [];
    let userDetail = JSON.parse(this.storage.getData("UserData"))[0].UserID;
    let keys = [
      "CompanyName",
      "WorkGroupTypeName",
      "WorkGroupName",
      "Description",
      "WorkGroupNo",
      "WorkGroupStatus",
      "test",
      "Status",
      "Message",
    ];
    // console.log(userDetail);
    let demo: any = this.defaultImport();
    // console.log(Object.keys(importPrototype));
    try {
      arr.forEach((elem, i) => {
        demo["RecNo"] = i + 1;
        demo["UserID"] = +userDetail;

        keys.forEach((e, index) => {
          // if (index == 3) {
          //   if (
          //     elem[index + 1] === undefined ||
          //     elem[index + 1] === undefined
          //   ) {
          //     importedData = null;
          //     let err = new Error();
          //     err.name = elem[index + 1 - 2];
          //     err.message = i + 4;
          //     throw err;
          //   }
          // }
          demo[e] = elem[index + 1] === undefined ? "" : elem[index + 1];
        });
        // demo["BusinessEmail"] =
        //   typeof demo["BusinessEmail"] === "object"
        //     ? demo["BusinessEmail"].text
        //     : demo["BusinessEmail"];

        // demo["CompanyWebsite"] =
        //   typeof demo["CompanyWebsite"] === "object"
        //     ? demo["CompanyWebsite"].text
        //     : demo["CompanyWebsite"];
        //
        importedData.push(demo);

        demo = this.defaultImport();
      });
    } catch (err) {
      Swal.fire(
        "invalid Identification Number in " +
          err.name +
          " Row number: " +
          err.message
      );
    }
    if (importedData === null) {
      return;
    }
    this.workgroupService
      .workgroupImport({ workImp: importedData })
      .subscribe((res) => {
        let t = this.modifyStateOfList(res.workimp[0]);

        this.downloadToExcel = t;

        this.tableUpdate(this.downloadToExcel);
        this.showValid(
          "Process successfully and please check the table to edit"
        );
      });
  }
  modifyStateOfList(importProperty) {
    return importProperty.map((elem, index) => {
      return {
        CompanyName: elem.CompanyName,
        WorkgroupType: elem.WorkGroupTypeName,
        WorkGroupName: elem.WorkGroupName,
        Description: elem.Description,
        WorkGroupNo: elem.WorkGroupNo,
        WorkGroupStatus: elem.WorkGroupStatus,
        UserID: elem.UserID,
        Status: `${elem.Status} ${elem.Message}`,
      };
      // let uniionObject = Object.assign(this.defaultImport(), elem);

      // Object.defineProperty(uniionObject, "Status", {
      //   value: `${elem.Status} ${elem.Message}`,
      // });

      // return uniionObject;
    });
  }
  defaultImport() {
    return {
      CompanyName: "",
      WorkGroupTypeName: "",
      WorkGroupName: "",
      Description: "",
      WorkGroupNo: "",
      WorkGroupStatus: "",
      UserID: null,
      test: "",
      Status: "",
      Message: "",
    };
  }

  tableUpdate(data) {
    if (data[0].hasOwnProperty("Status") === true) {
      this.displayedColumns.pop();
      this.displayedColumns.push("Status");
      this.insertedStatus = true;
      this.defaultStatus = false;

      this.dataSource = new MatTableDataSource(data);
    } else {
      this.displayedColumns.pop();
      this.displayedColumns.push("Status");
      this.insertedStatus = false;
      this.defaultStatus = true;
    }
  }

  onItemCLick(data: any) {
    if (this.selectedWorkgroupID == data.WorkGroupID) {
      this.selectedWorkgroupID = !this.selectedWorkgroupID;
    } else {
      this.selectedWorkgroupID = data.WorkGroupID;
    }
  }

  // toastr warning/success message
  showInvalid(msg) {
    this.tostre.warning(msg, "", {
      positionClass: "toast-top-right",
    });
  }

  showValid(validMsg) {
    this.tostre.success(validMsg, "", {
      positionClass: "toast-top-right",
    });
  }
}
