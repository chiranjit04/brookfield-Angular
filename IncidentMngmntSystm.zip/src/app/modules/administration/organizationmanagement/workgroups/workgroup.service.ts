import { Injectable } from "@angular/core";
import { Observable, of } from "rxjs";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { environment } from "../../../../../environments/environment";
import { map } from "rxjs/internal/operators/map";

@Injectable({
  providedIn: "root",
})
export class WorkgroupService {
  // observable: Observable<any>;
  url: any;
  returnVariable: Observable<Object>;
  constructor(private http: HttpClient) {
    this.url = environment.origin + "api/";
    // this.url = 'http://localhost:1601/api/';
  }

  fetchAllComapny(userID: number = 0): Observable<any> {
    let data = {
      UserId: +userID,
    };
    //  old - GetCompanybyUserid
    return this.http.post<any[]>(`${this.url}GetCompanybyUseridOM`, data).pipe(
      map((elem: any) => {
        // return {
        //   GetCompanybyUserid: elem.GetCompanybyUseridOM,
        // };
        return elem;
      })
    );
  }

  fetchAllComapnySubdivison(userID: number = 0, CompanyID) {
    let data = {
      UserId: +userID,
      ComapnyId: +CompanyID,
    };
    console.log("really", data);
    return this.http.post<any>(
      `${this.url}GetComapnySubdivisonbyUseridOM`,
      data
    );
  }

  createWorkgroup(formData: any) {
    // let data = {
    //   "UserId": +(userID)
    // }
    console.log("what is in the service", formData);
    return this.http.post<any>(`${this.url}UpdateWorkGroup`, formData);
  }

  getWorkGroupList(CompanyID: any) {
    console.log("service calls", CompanyID);
    let data = {
      CompanyID: +CompanyID,
    };
    console.log("service", data);
    return this.http.post<any>(`${this.url}getWorkgroup`, data);
  }

  onWorkgroupDelete(WorkGroupID) {
    const options = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
      }),
      body: {
        WorkGroupID: +WorkGroupID,
      },
    };
    try {
      return this.http.delete<any>(`${this.url}DeleteWorkGroup`, options);
    } catch (error) {
      throw error;
    }
  }

  getWorkGroupTypeList(CompanyID) {
    let data = {
      CompanyID: +CompanyID,
    };
    return this.http.post<any>(`${this.url}GetWorkgroupType`, data);
  }

  createWorkgroupType(formData: any) {
    // let data = {
    //   "UserId": +(userID)

    // }
    console.log("what is in the service of type", formData);
    return this.http.post<any>(`${this.url}UpdateWorkGroupType`, formData);
  }

  onWorkgroupTypeDelete(WorkGroupTypeId) {
    const options = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
      }),
      body: {
        WorkGroupTypeId: +WorkGroupTypeId,
      },
    };
    try {
      return this.http.delete<any>(`${this.url}DeleteWorkGroupType`, options);
    } catch (error) {
      throw error;
    }
  }

  getCompanies(userID: number = 0): Observable<any[]> {
    let data = {
      UserId: +userID,
    };
    return this.http.post<any[]>(`${this.url}GetCompanyByUserOM`, data);
  }

  GetWorKGroupPropertyList(
    WorkGroupID: any,
    PropertyName: any,
    PropertyIdentNumber: any,
    userID: number = 0
  ): Observable<any> {
    let data = {
      WorkGroupID: +WorkGroupID,
      PropertyName: PropertyName,
      PropertyIdentNumber: PropertyIdentNumber,
      UserId: +userID,
    };
    // old -> GetWorKGroupPropertyList
    return this.http
      .post<any[]>(`${this.url}GetWorKGroupPropertyListOM`, data)
      .pipe(
        map((elem: any) => {
          // return {
          //   GetWorKGroupPropertyList: elem.GetWorKGroupPropertyListOM,
          // };
          return elem;
        })
      );
  }

  /**
   *
   * Get WorkGroup Company by PropertyID
   * @param obj
   */

  getWorkGroupCompanybyPropertyId(obj) {
    return this.http.post(this.url + "GetWorkGroupCompanybyPropertyId", obj);
  }

  /**
   * Get Assigned Workgroup
   *
   */

  getAssigedWorkGroup() {
    return this.http.get(this.url + "GetAssigedWorkGroup");
  }

  UpdateAssignWorkGroupToProperty(data: any) {
    return this.http.post<any[]>(
      `${this.url}UpdateAssignWorkGroupToProperty`,
      data
    );
  }

  getWorkGroupdisplayNo(CompanyID) {
    let data = {
      ComapnyId: +CompanyID,
    };
    return this.http.post<any>(`${this.url}GetWorkGroupdisplayNo`, data);
  }

  assignWorkGroupType(CompanyID, ComapnyTypeId, WorkGroupID) {
    let data = {
      CompanyID: +CompanyID,
      ComapnyTypeId: +ComapnyTypeId,
      WorkGroupID: +WorkGroupID,
    };
    return this.http.post<any[]>(`${this.url}AssignWorkGroupType`, data);
  }

  onWorkgroupActive(WorkGroupID, IsActive) {
    let data = {
      WorkGroupID: +WorkGroupID,
      IsActive: +IsActive,
    };
    return this.http.post<any[]>(`${this.url}ActivateWorkGroup`, data);
  }

  getWorkGroupData(param) {
    return this.http.post<any>(`${this.url}WorkgroupList`, param);
  }

  getCompanySubdivision() {
    const body = {
      CompanyID: 0,
      CompanyTypeID: 0,
      StateId: 0,
      Status: 1,
      IsActive: null,
      IsArchive: 0,
      Zip: null,
      Address: null,
      ShortFilter: null,
    };
    return this.http.post<any>(`${this.url}companySearchListOM`, body).pipe(
      map((elem) => {
        return {
          companySearchList: elem.companySearchListOM,
        };
      })
    );
  }
  //
  workgroupImport(data: any): Observable<any> {
    return this.http.post<any>(this.url + "workgroupImport", data);
  }

  GetAsignedPopertybyCompanyWorkGroup(param: any) {
    return this.http.post<any>(
      this.url + "GetAsignedPopertybyCompanyWorkGroup",
      param
    );
  }
}
