import { Component, OnInit, Input } from "@angular/core";
import { FormGroup, FormControl, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import Swal from "sweetalert2";
import { WorkgroupService } from "../../workgroups/workgroup.service";
import { DataSharingService } from "../../dataSharing.service";
import { UserPermissionService } from "../../../../../services/user-permission.service";
import { StorageService } from "../../../../../services/storage.service";
import { ServiceService } from './../../../service/service.service';
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-selectcompany",
  templateUrl: "./selectcompany.component.html",
  styleUrls: ["./selectcompany.component.scss"],
})
export class SelectcompanyComponent implements OnInit {
  authToken = null;
  userData = null;
  currentUserID = 0;
  currentCompanyID = 0;
  displayNo: any;
  boll: any = false;

  companies = [];
  selectedCompany = false;

  subdivisions = [];
  selectedSubdivision = false;
  selectedWorkgroup = false;
  selectedWorkgroupType: any;
  WorkGroupTypeId = false;

  addwgp = false;
  addEditwgp = false;
  addwgtf = false;
  addEditwgtf = false;
  selectWorkgroup = false;
  groupEditable = false;
  toggleEditForm = false;
  // workgroupEditable = false;

  workGroupList = [];
  workGroupTypeList = [];

  @Input() selectedCompanyID: any;
  workgroupForm = new FormGroup({
    WorkGroupID: new FormControl(""),
    CompanyID: new FormControl(""),
    WorkGroupTypeID: new FormControl(""),
    WorkGroupName: new FormControl("", [
      Validators.required,
      Validators.maxLength(100),
    ]),
    Description: new FormControl("", [
      Validators.required,
      Validators.maxLength(500),
    ]),
    WorkGroupNo: new FormControl(""),
    UserId: new FormControl(""),
    IsActive: new FormControl(""),
  });
  submitted = false;
  get workgroupF() {
    return this.workgroupForm.controls;
  }

  //Edit workgroup form

  workgroupEditForm = new FormGroup({
    WorkGroupID: new FormControl(""),
    CompanyID: new FormControl(""),
    WorkGroupTypeID: new FormControl(""),
    WorkGroupName: new FormControl("", [
      Validators.required,
      Validators.maxLength(100),
    ]),
    Description: new FormControl("", [
      Validators.required,
      Validators.maxLength(500),
    ]),
    IsActive: new FormControl(""),
  });
  // submittedEdit = false;
  get workgroupEditF() {
    return this.workgroupEditForm.controls;
  }

  //Add WorkgroupType form

  workgroupTypeForm = new FormGroup({
    WorkGroupTypeId: new FormControl(""),
    WorkGroupTypeName: new FormControl("", [
      Validators.required,
      Validators.maxLength(100),
    ]),
    CompanyID: new FormControl(""),
    UserId: new FormControl(""),
  });
  // submitted = false;
  get workgroupTypeF() {
    return this.workgroupTypeForm.controls;
  }

  //Edit Workgroup type form
  workgroupTypeEditForm = new FormGroup({
    WorkGroupTypeId: new FormControl(""),
    WorkGroupTypeName: new FormControl("", [
      Validators.required,
      Validators.maxLength(100),
    ]),
    CompanyID: new FormControl(""),
    UserId: new FormControl(""),
  });
  // submittedEdit = false;
  get workgroupTypeEditF() {
    return this.workgroupTypeEditForm.controls;
  }

  constructor(
    private workgroupService: WorkgroupService,
    private dataSharingService: DataSharingService,
    public UserPermission: UserPermissionService,
    private storage: StorageService,
    private adminService:ServiceService,
    private toastr: ToastrService
  ) {
    //... Read User Data ...
    this.authToken = this.storage.getData("token");
    this.userData = JSON.parse(this.storage.getData("UserData"));
    this.currentUserID = this.userData[0].UserID;
  }

  ngOnInit() {
    // this.selectedCompanyID = null;

    // console.log("called" + this.selectedCompanyID);
    let selectdeId = this.selectedCompanyID;
    this.dataSharingService.currentBoolean.subscribe((data) => {
      this.addwgp = data;
      this.addwgtf = data;
    });
    this.addwgp = false;
    this.addwgtf = false;
    this.getCompanies();
    this.dataSharingService.createWorkGroupStream.subscribe((response) => {
      let result: any = response;
      this.companies = result.companies;
      //this.selectedCompany = false;
      // this.subdivisions = [];
      // this.workGroupList = [];
      // this.workGroupTypeList = [];
      this.selectedSubdivision = false;
      this.selectWorkgroup = false;
      this.selectedWorkgroupType = false;
    });
    // this.getSubdivisions();
    this.getWorkGroupList(this.selectedCompanyID || this.selectedSubdivision);
    this.selectCompany({ CompanyID: this.selectedCompanyID });
    this.selectedCompanyID = selectdeId;
    this.selectedSubdivision = selectdeId;
    // this.getWorkGroupTypeList();
  }

  /* Company Section */
  getCompanies() {
    let result: any;
    this.workgroupService
      .fetchAllComapny(this.currentUserID)
      .subscribe((response) => {
        result = response;
        this.companies = result.getCompanybyUserid;
      });
  }

  selectCompany(data: any) {
    //  console.log("coming or not",this.selectedCompanyID,(this.selectedCompanyID == data.CompanyID));
    if (this.selectedCompanyID == data.CompanyID) {
      this.selectedCompanyID = !this.selectedCompanyID;
      //   console.log("selected company id-->",this.selectedCompanyID);
    } else {
      this.selectedCompanyID = data.CompanyID;
    }
    //  console.log("selected ",(data.CompanyID == this.selectedCompany));
    if (data.CompanyID == this.selectedCompany) {
      this.selectedCompany = false;
      this.addwgp = false;
      this.workgroupForm.reset();
      this.addEditwgp = false;
      this.workgroupEditForm.reset();
      this.addwgtf = false;
      this.workgroupTypeForm.reset();
      this.addEditwgtf = false;
      this.workgroupTypeEditForm.reset();
      this.subdivisions = [];
      this.workGroupList = [];
      this.workGroupTypeList = [];
    } else {
      this.addwgp = false;
      this.selectedCompany = data.CompanyID;
      this.selectedSubdivision = false;

      this.getBothLists(this.selectedCompany);
    }
  }

  getBothLists(selection: any) {
    // this.workgroupService.getWorkGroupList(selection).subscribe(data => {
    //   console.log("the data must be", data);
    //   this.workGroupList = data.Workgroup;
    // });
    this.workgroupService
      .fetchAllComapnySubdivison(this.currentUserID, selection)
      .subscribe((data) => {
        // console.log("the data must be here-----", data);
        this.subdivisions = data.getComapnySubdivisonbyUserid;
      });
    this.getWorkGroupList(selection);
    this.getWorkGroupTypeList(selection);
  }

  /* Sub Division Section */
  getSubdivisions() {
    let result: any;
    this.workgroupService
      .fetchAllComapnySubdivison(this.currentUserID, this.currentCompanyID)
      .subscribe((response) => {
        result = response;
        this.subdivisions = result.getComapnySubdivisonbyUserid;
      });
  }
  selectSubdivision(data: any) {
    if (data.CompanyID == this.selectedSubdivision) {
      this.selectedSubdivision = false;
      this.addwgp = false;
      this.workgroupForm.reset();
      this.addEditwgp = false;
      this.workgroupEditForm.reset();
      this.addwgtf = false;
      this.workgroupTypeForm.reset();
      this.addEditwgtf = false;
      this.workgroupTypeEditForm.reset();
      this.workgroupService
        .getWorkGroupList(this.selectedCompany)
        .subscribe((data) => {
          this.workGroupList = data.Workgroup;
        });
      this.getWorkGroupTypeList(this.selectedCompany);
    } else {
      // this.selectedCompany = false;
      this.addwgp = false;
      this.selectedWorkgroupType = false;
      this.selectWorkgroup = false;
      this.selectedSubdivision = data.CompanyID;
      this.getWorkGroupList(this.selectedSubdivision);
      this.getWorkGroupTypeList(this.selectedSubdivision);
      // this.workgroupService
      //   .getWorkGroupList(this.selectedSubdivision)
      //   .subscribe(data => {
      //     console.log("the data must be", data);
      //     this.workGroupList = data.Workgroup;
      //   });
    }
  }

  selectWorkgroupItem(event, data: any) {
    //event.preventDefault();
    // console.log("tile");
    if (data.WorkGroupID == this.selectWorkgroup) {
      this.selectWorkgroup = false;
      this.selectedWorkgroupType = false;
    } else {
      this.selectWorkgroup = data.WorkGroupID;
      this.selectedWorkgroupType = +data.WorkGroupTypeId;
      // this.getWorkGroupList(data.CompanyID);
    }
  }

  getWorkGroupList(CompanyID: any) {
    // this.selectedCompanyID = CompanyID;
    this.workgroupService.getWorkGroupList(+CompanyID).subscribe((data) => {
      this.workGroupList = data.Workgroup;
    });
    this.selectedWorkgroup = this.selectedWorkgroup;
  }

  // elemName = document.getElementById('toll')

  openWorkgroupForm() {
    // this.addwgp =
    this.submitted = false;
    this.addEditwgp = false;
    this.addwgtf = false;
    this.addEditwgtf = false;
    this.workgroupForm.reset();
    if (this.selectedSubdivision) {
      this.addwgp = !this.addwgp;
      this.workgroupService
        .getWorkGroupdisplayNo(this.selectedSubdivision)
        .subscribe((data) => {
          this.displayNo = data.getWorkGroupdisplayNo[0][""];
          this.workgroupForm.patchValue({ WorkGroupID: 0 });
          this.workgroupForm.patchValue({
            CompanyID: +this.selectedSubdivision,
          });
          this.workgroupForm.patchValue({
            WorkGroupTypeID: +0,
          });
          this.workgroupForm.patchValue({ WorkGroupNo: this.displayNo });
          this.workgroupForm.patchValue({ UserId: this.currentUserID });
          this.workgroupForm.patchValue({ IsActive: 1 });
        });
    } else if (this.selectedCompany) {
      this.addwgp = !this.addwgp;
      this.workgroupService
        .getWorkGroupdisplayNo(this.selectedCompany)
        .subscribe((data) => {
          this.displayNo = data.getWorkGroupdisplayNo[0][""];
          this.workgroupForm.patchValue({ WorkGroupID: 0 });
          this.workgroupForm.patchValue({
            CompanyID: +this.selectedCompany,
          });
          this.workgroupForm.patchValue({
            WorkGroupTypeID: +0,
          });
          this.workgroupForm.patchValue({ WorkGroupNo: this.displayNo });
          this.workgroupForm.patchValue({ UserId: this.currentUserID });
          this.workgroupForm.patchValue({ IsActive: 1 });
        });
    } else {
      Swal.fire({
        text: "Please select Company or Subdivision first.",
      });
    }
  }

  getWorkGroupdisplayNo(ComapnyId: any) {
    this.workgroupService.getWorkGroupdisplayNo(ComapnyId).subscribe((data) => {
      this.displayNo = data.getWorkGroupdisplayNo[0][""];
      // console.log("yes");
    });
  }

  resetWorkgroupForm() {
    this.workgroupForm.reset();
    this.addwgp = !this.addwgp;
  }

  createWorkgroup() {
    this.submitted = true;
    this.addwgp = false;
    if (this.workgroupForm.get("WorkGroupName").value == null || "") {
      this.addwgp = true;
      // console.log("Requied here");
      return;
    } else {
      let formData = this.workgroupForm.value;

      // console.log("wiping out", formData);
      if (
        !this.workGroupList.find(
          (elem) =>
            formData.WorkGroupName.trim().toLowerCase().replace(/\s+/g, "") ==
            elem.WorkGroupName.trim().toLowerCase().replace(/\s+/g, "")
        )
      ) {
        formData.WorkGroupName = formData.WorkGroupName.trim();

        //formData.Description = formData.Description ? formData.Description.trim() : null;
        formData.WorkGroupTypeID = +this.WorkGroupTypeId;
        if (formData.WorkGroupName == "") {
          this.workgroupForm.controls["WorkGroupName"].setErrors({
            invalid: true,
          });
          return false;
        }
        // if (formData.Description == "") {
        //   this.workgroupForm.controls["Description"].setErrors({
        //     invalid: true,
        //   });
        //   return false;
        // }
        this.workgroupService.createWorkgroup(formData).subscribe((data) => {
          // console.log("what is coming let us see", data);

          if (this.selectedSubdivision) {
            // console.log("3");
            this.getWorkGroupList(this.selectedSubdivision);
          } else {
            // console.log("4");
            this.getWorkGroupList(this.selectedCompany);
          }
        });
      } else {
        this.addwgp = true;
        Swal.fire({
          // title: "This Reporting Set already exists"
          title: `${formData.WorkGroupName} already exists in Workgroup.`,
        });
      }

      // console.log(formData);

      let result: any;
    }
  }

  onWorkgroupActive(event, item) {
    item.IsActive = !item.IsActive;
    event.stopPropagation();
    this.workgroupService
      .onWorkgroupActive(item.WorkGroupID, item.IsActive)
      .subscribe((data) => {
        this.toastr.success(this.adminService.statusMsg);
      });
  }

  //Edit WorkGroup section

  openEditWorkgroupForm(event, data: any) {
    // event.stopPropagation();
    if (this.selectWorkgroup == data.WorkGroupID) {
      this.selectWorkgroup = !this.selectWorkgroup;
    }
    this.submitted = false;
    this.addwgp = false;
    this.addwgtf = false;
    this.addEditwgtf = false;
    this.workgroupEditForm.reset();

    if (this.selectedCompany || this.selectedSubdivision) {
      this.toggleEditForm = !this.toggleEditForm;
      this.addEditwgp = true;

      this.workgroupEditForm.patchValue({ WorkGroupID: data.WorkGroupID });
      this.workgroupEditForm.patchValue({
        CompanyID: +(this.selectedCompany || this.selectedSubdivision),
      });
      this.workgroupEditForm.patchValue({
        WorkGroupTypeID: +data.WorkGroupTypeId,
      });
      this.workgroupEditForm.patchValue({ WorkGroupName: data.WorkGroupName });
      this.workgroupEditForm.patchValue({ Description: data.Description });
      this.workgroupEditForm.patchValue({ IsActive: 1 });
    } else {
      Swal.fire({
        text: "Please select Company or Subdivision first.",
      });
      this.addEditwgp = false;
    }

    // event.stopPropagation();
  }

  EditWorkgroupSubmit(CompanyID: any, WorkGroupID: any, WorkGroupTypeId: any) {
    this.selectedWorkgroupType = +WorkGroupTypeId;
    // event.preventDefault();
    this.selectWorkgroup = WorkGroupID;

    this.submitted = true;

    if (this.workgroupEditForm.get("WorkGroupName").value == "") {
      return;
    } else {
      let formData = this.workgroupEditForm.value;
      formData.WorkGroupName = (formData.WorkGroupName || "").trim();
      formData.Description = (formData.Description || "").trim();
      formData.CompanyID = +CompanyID;
      if (formData.WorkGroupName == "") {
        this.workgroupEditForm.controls["WorkGroupName"].setErrors({
          invalid: true,
        });
        return false;
      }
      // if (formData.Description == "") {
      //   this.workgroupEditForm.controls["Description"].setErrors({
      //     invalid: true,
      //   });
      //   return false;
      // }

      this.workgroupService.createWorkgroup(formData).subscribe((data) => {
        // console.log("what is coming let us see in edit", data);
        // this.getWorkGroupList(
        //   this.selectedCompany || this.selectedSubdivision,
        //   this.WorkGroupTypeId
        // );

        if (this.WorkGroupTypeId) {
          this.getWorkGroupList(this.WorkGroupTypeId);
        } else if (this.selectedSubdivision) {
          this.getWorkGroupList(this.selectedSubdivision);
        } else {
          this.getWorkGroupList(this.selectedCompany);
        }
      });
      // console.log("Need something new", formData);

      // let result: any;
    }
    this.addwgp = false;
    this.selectedWorkgroup = WorkGroupID;
  }

  onWorkgroupDelete(WorkGroupID: any) {
    if (this.selectWorkgroup == WorkGroupID) {
      this.selectWorkgroup = !this.selectWorkgroup;
    }
    if (this.selectedCompany || this.selectedSubdivision) {
      this.addwgp = false;
      this.addwgtf = false;
      this.addEditwgtf = false;
      Swal.fire({
        // text: "Are you sure want to delete ?",
        text: this.adminService.deleteMsg,
        showCancelButton: true,
        confirmButtonText: "Yes",
        cancelButtonText: "No",
      }).then((result) => {
        if (result.value) {
          this.workgroupService
            .onWorkgroupDelete(WorkGroupID)
            .subscribe((data) => {
              // console.log("It is deleted", data);
              if (this.selectedSubdivision) {
                // console.log("1");
                this.getWorkGroupList(this.selectedSubdivision);
                // console.log("let us check 1", this.WorkGroupTypeId);
              } else {
                // console.log("2");
                this.getWorkGroupList(this.selectedCompany);
                // console.log("let us check 2", this.WorkGroupTypeId);
              }
            });
        }
      });
    } else {
      Swal.fire({
        text: "Please select Company or Subdivision first.",
      });
    }
  }

  //workgroup type

  getWorkGroupTypeList(CompanyID: any) {
    this.workgroupService.getWorkGroupTypeList(CompanyID).subscribe((data) => {
      // console.log("type list", data);
      this.workGroupTypeList = data.getWorkgroupType;
    });
  }

  //select workgrouptype
  onWorkGroupTypeSelect(WorkGroupTypeId: any) {
    if (this.selectedCompany || this.selectedSubdivision) {
      this.WorkGroupTypeId = WorkGroupTypeId;
      if (this.selectedWorkgroupType == WorkGroupTypeId) {
        this.selectedWorkgroupType = false;
      } else {
        this.selectedWorkgroupType = WorkGroupTypeId;
        if (this.selectedSubdivision) {
          this.workgroupService
            .assignWorkGroupType(
              this.selectedSubdivision,
              WorkGroupTypeId,
              this.selectWorkgroup
            )
            .subscribe((data) => {});
        } else {
          this.workgroupService
            .assignWorkGroupType(
              this.selectedCompany,
              WorkGroupTypeId,
              this.selectWorkgroup
            )
            .subscribe((data) => {});
        }
      }
    } else {
      Swal.fire({
        text: "Please select Company or Subdivision first.",
      });
      // this.addEditwgp = false;
    }
  }

  // onWorkgroupEditOpen() {}

  onWorkgroupTypeOpen() {
    this.submitted = false;
    // this.addwgtf = false;
    this.addEditwgtf = false;
    this.addwgp = false;
    this.addEditwgp = false;
    this.workgroupTypeForm.reset();
    if (this.selectedCompany || this.selectedSubdivision) {
      this.addwgtf = !this.addwgtf;
      this.workgroupTypeForm.patchValue({ WorkGroupTypeId: 0 });
      if (this.selectedSubdivision) {
        this.workgroupTypeForm.patchValue({
          CompanyID: this.selectedSubdivision,
        });
      } else {
        this.workgroupTypeForm.patchValue({ CompanyID: this.selectedCompany });
      }
      this.workgroupTypeForm.patchValue({ UserId: this.currentUserID });
    } else {
      Swal.fire({
        text: "Please select Company or Subdivision first.",
      });
    }
  }

  //Creating a workgroup type
  createWorkgroupType() {
    this.submitted = true;
    this.addwgtf = false;
    if (this.workgroupTypeForm.invalid) {
      this.addwgtf = true;
      return;
    } else {
      this.addEditwgtf = !this.addEditwgtf;
      let formData = this.workgroupTypeForm.value;
      if (
        !this.workGroupTypeList.find(
          (elem) =>
            formData.WorkGroupTypeName.trim()
              .toLowerCase()
              .replace(/\s+/g, "") ==
            elem.WorkGroupTypeName.trim().toLowerCase().replace(/\s+/g, "")
        )
      ) {
        formData.WorkGroupTypeName = formData.WorkGroupTypeName.trim();
        // formData.Description = formData.Description.trim();
        if (formData.WorkGroupTypeName == "") {
          this.workgroupTypeForm.controls["WorkGroupTypeName"].setErrors({
            invalid: true,
          });
          return false;
        }

        this.workgroupService
          .createWorkgroupType(formData)
          .subscribe((data) => {
            if (this.selectedSubdivision) {
              this.getWorkGroupTypeList(this.selectedSubdivision);
            } else {
              this.getWorkGroupTypeList(this.selectedCompany);
            }
          });
      } else {
        this.addwgtf = true;
        Swal.fire({
          // title: "This Reporting Set already exists"
          title: `${formData.WorkGroupTypeName} already exists in WorkGroup Type.`,
        });
      }

      let result: any;
    }
  }

  resetWorkgroupTypeForm() {
    this.workgroupTypeForm.reset();
    this.addwgtf = !this.addwgtf;
  }

  //Open WorkgroupType Edit form

  openEditWorkgroupTypeForm(event, data: any) {
    // event.preventDefault();

    // event.preventDefault();
    this.addwgtf = false;
    this.addwgp = false;
    this.addEditwgp = false;
    this.workgroupTypeEditForm.reset();

    // this.workgroupTypeEditForm.reset();
    if (this.selectedCompany || this.selectedSubdivision) {
      // this.toggleEditForm = !this.toggleEditForm;
      this.addEditwgtf = !this.addEditwgtf;
      this.workgroupTypeEditForm.patchValue({
        WorkGroupTypeId: +data.WorkGroupTypeId,
      });
      this.workgroupTypeEditForm.patchValue({
        WorkGroupTypeName: data.WorkGroupTypeName,
      });
      // this.workgroupTypeEditForm.patchValue({
      //   CompanyID: +
      // });
      if (this.selectedSubdivision) {
        this.workgroupTypeEditForm.patchValue({
          CompanyID: this.selectedSubdivision,
        });
      } else {
        this.workgroupTypeEditForm.patchValue({
          CompanyID: this.selectedCompany,
        });
      }
      this.workgroupTypeEditForm.patchValue({
        UserId: this.currentUserID,
      });

      // this.workgroupTypeEditForm.patchValue({
      //   DisplayOrder: 1
      // });
      // event.stopPropagation();
    } else {
      Swal.fire({
        text: "Please select Company or Subdivision first.",
      });
      this.addEditwgtf = false;
    }
  }

  EditWorkgroupTypeSubmit() {
    if (this.workgroupTypeEditForm.invalid) {
      return;
    } else {
      let formData = this.workgroupTypeEditForm.value;
      formData.WorkGroupTypeName = formData.WorkGroupTypeName.trim();

      if (formData.WorkGroupTypeName == "") {
        this.workgroupTypeEditForm.controls["WorkGroupTypeName"].setErrors({
          invalid: true,
        });
        return false;
      }

      this.workgroupService.createWorkgroupType(formData).subscribe((data) => {
        if (this.selectedSubdivision) {
          this.getWorkGroupTypeList(this.selectedSubdivision);
        } else {
          this.getWorkGroupTypeList(this.selectedCompany);
        }
      });

      // let result: any;
    }
    this.addwgp = false;
  }

  onWorkgroupTypeDelete(WorkGroupTypeId: any) {
    if (this.selectedCompany || this.selectedSubdivision) {
      this.addwgtf = false;
      this.addwgp = false;
      // this.addEditwgp = false;
      Swal.fire({
        // text: "Are you sure you want to delete ?",
        text: this.adminService.deleteMsg,
        showCancelButton: true,
        confirmButtonText: "Yes",
        cancelButtonText: "No",
      }).then((result) => {
        if (result.value) {
          this.workgroupService
            .onWorkgroupTypeDelete(WorkGroupTypeId)
            .subscribe((data) => {
              if (this.selectedSubdivision) {
                this.getWorkGroupTypeList(this.selectedSubdivision);
              } else {
                this.getWorkGroupTypeList(this.selectedCompany);
              }
            });
        }
      });
    } else {
      Swal.fire({
        text: "Please select Company or Subdivision first.",
      });
    }
  }

  resetWorkgroupTypeEditForm() {
    this.workgroupTypeEditForm.reset();
    this.addEditwgtf = !this.addEditwgtf;
  }

  resetAll() {
    let shadesEl = document.querySelectorAll(".show");
    for (let i = 0; i < shadesEl.length; i++) {
      shadesEl[i].classList.remove("show");
    }

    // this.workgroupEditable = false;

    this.addwgp = false;

    this.submitted = false;

    this.workgroupForm.reset();
  }
}
