import { Injectable } from "@angular/core";
import * as ExcelJS from "exceljs";
import { saveAs } from "file-saver";
import  { logoBase64 } from "src/assets/images/logo/brookfieldlogo";
// import { logoBase64 } from "../../propertymanagement/locationmanagement/brookfieldlogo";
@Injectable({
  providedIn: "root",
})
export class WorkgroupImportExport {
  defaultSystemvalue = [
    ["", "Live Test Owner Company", "Active", "Cluster"],
    ["", "Live Test Management Company", "Active", "Company Wide"],
    ["", "Live Test Security Company", "", "Portfolio/Division"],
    ["", "SubDivisionComany", "", "Regional"],
    ["", "SubDivisionComany1", "", "Regional Group2"],
    ["", "SubDivisionComany2", "", "Regional Manager"],
    ["", "chicago company", "", "Vertical inside"],
    ["", "Test Company 01", "", ""],
    ["", "test company 002", "", ""],
  ];
  constructor() {}
  /** importing excel sheet as original and */
  importExcelSheet() {}
  /** exporting as default export and export as with error or modification */
  async exportExcelSheet(json: any, pickVal: any, bool: boolean) {
    console.log("okay buddy");
    let columnsHead = [
      "Company Name",
      "WorkGroup Type Name",
      "WorkGroup Name",
      "Description",
      "WorkGroup No",
      "Status",
      "Inserted Status",
    ];
    let arr = [];
    const wb = new ExcelJS.Workbook();
    /**
     * workbook to set active tab there
     */
    wb.views = [
      {
        x: 0,
        y: 0,
        width: 10000,
        height: 20000,
        firstSheet: 0,
        activeTab: 1,
        visibility: "visible", // Set activeTab to 0
      },
    ];

    /** instructions */
    const wsIns = wb.addWorksheet("Instructions");
    /**upload sheet */
    const ws = wb.addWorksheet("Upload Sheet");
    /** for systempickvalue tab data worksheet */
    const wsPick = wb.addWorksheet("SystemPickValues");

    columnsHead.forEach((elem, i) => {
      arr.push({ key: "col " + i, header: " " });
    });
    ws.columns = arr;
    ws.columns.forEach((column) => {
      column.width =
        column.header.length < 12 ? 12 + 15 : column.header.length + 15;
    });

    let im = wb.addImage({
      base64: logoBase64,
      extension: "png",
    });
    ws.addImage(im, "A1:B1");
    ws.getRow(1).height = 100;
    ws.getRow(2).height = 30;

    if (json.length === 0) {
    }
    if (bool === true) {
      json.forEach((element, index) => {
        console.log(element);
        ws.getRow(index + 4).values = [
          element.CompanyName,
          element.WorkgroupType,
          element.WorkGroupName,
          element.Description,
          element.WorkGroupNo,
          element.WorkGroupStatus,
          element.Status,
        ];
        ws.getRow(index + 4).alignment = {
          wrapText: true,
          horizontal: "justify",
        };
      });
    } else {
      json.forEach((element, index) => {
        ws.getRow(index + 4).values = [
          element.CompanyName,
          element.WorkgroupType,
          element.WorkGroupName,
          element.Description,
          element.WorkGroupNo,
          element.WorkGroupStatus,
          element.Status,
        ];
        ws.getRow(index + 4).alignment = {
          wrapText: true,
          horizontal: "justify",
        };
      });
    }
    //
    ws.getRow(2).values = ["Workgroup Upload Form"];
    ws.getCell("A2").font = {
      size: 22,
    };

    ws.getRow(3).values = columnsHead;

    ws.getRow(3).height = 50;
    ws.getCell("A7");
    ws.getRow(3).alignment = {
      vertical: "middle",
      horizontal: "center",
      wrapText: true,
    };
    ws.getRow(3).font = {
      bold: true,
    };

    this.colorCell(ws, "A3");
    this.colorCell(ws, "C3");
    this.colorCell(ws, "F3");

    ws.getRow(3).border = {
      top: { style: "thin", color: { argb: "#000000" } },
      left: { style: "thin", color: { argb: "#000000" } },
      bottom: { style: "thin", color: { argb: "#000000" } },
      right: { style: "thin", color: { argb: "#000000" } },
    };
    /**
     * adding second tab data here for system pick values
     */
    let arr1 = [];
    if (json.length === 0 || bool === true) {
      this.defaultSystemvalue.forEach((elem, index) => {
        arr1.push({ key: "col " + index, header: " " });
      });
    } else {
      pickVal.forEach((elem, index) => {
        arr1.push({ key: "col " + index, header: " " });
      });
    }
    wsPick.columns = arr1;

    wsPick.columns.forEach((column) => {
      column.width =
        column.header.length < 12 ? 12 + 15 : column.header.length + 15;
    });

    if (json.length === 0 || bool === true) {
      this.defaultSystemvalue.forEach((elem, index) => {
        wsPick.getRow(index + 2).values = elem;
      });
    } else {
      pickVal.forEach((element, index) => {
        wsPick.getRow(index + 2).values = [
          element[1] === undefined ? "" : element[1],
          element[2] === undefined ? "" : element[2],
          element[3] === undefined ? "" : element[3],
          element[4] === undefined ? "" : element[4],
        ];
        wsPick.getRow(index + 2).alignment = {
          wrapText: true,
        };
      });
    }
    /**instructions sheet values */
    wsIns.addImage(im, "D1:H1");
    wsIns.getRow(1).height = 100;
    wsIns.getRow(6).height = 50;

    wsIns.getCell("C2:I2").value =
      "Brookfield Properties Workgroups Spreadsheet";
    wsIns.getCell("C2:I2").font = {
      bold: true,
      size: 15,
      underline: "single",
    };
    /** this is bar header information */
    wsIns.getCell("B5:K5").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: {
        argb: "0xE2EFDA",
      },
    };
    ["B", "C", "D", "E", "F", "G", "H", "I", "J"].forEach((elem, index) => {
      this.colorCell(wsIns, elem + "5");
    });
    ["B", "C", "D", "E", "F", "G", "H", "I", "J"].forEach((elem, index) => {
      this.colorCell(wsIns, elem + "6");
    });

    wsIns.getCell(
      "B5"
    ).value = `Please list the Brookfield Properties, these Properties are customized to represent that`;
    wsIns.getCell(
      "B6"
    ).value = `company’s organizational structure and related positions of oversight. `;
    wsIns.getCell("B6").alignment = {
      vertical: "top",
    };

    /** set Intructions bar */
    wsIns.getCell("B8").value = "Set of Instructions for The Spreadsheet:";
    wsIns.getCell("B8").font = {
      bold: true,
    };
    /** generral information */
    wsIns.getCell("B10").value = "GENERAL INFO:";
    wsIns.getCell("B10").font = {
      bold: true,
    };
    /**general info detial about - */
    wsIns.getCell("B11").value = "-";
    wsIns.getCell("B11").alignment = {
      horizontal: "right",
    };
    wsIns.getCell("C11").value =
      "Please fill in the required fields to upload data into MAXIMUS";

    wsIns.getCell("B13").value = "-";
    wsIns.getCell("B13").alignment = {
      horizontal: "right",
    };
    wsIns.getCell("C13").value =
      "Dropdown value will appear in each cell if there is a selection to be made";

    wsIns.getCell("B16").value = "-";
    wsIns.getCell("B16").alignment = {
      horizontal: "right",
    };
    wsIns.getCell("B17").value = "-";
    wsIns.getCell("B17").alignment = {
      horizontal: "right",
    };
    wsIns.getCell("B19").value = "-";
    wsIns.getCell("B19").alignment = {
      horizontal: "right",
    };

    /** - box color field that are required */
    wsIns.getCell("C16").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: {
        argb: "0xE2EFDA",
      },
    };
    wsIns.getCell("C16").border = {
      top: { style: "thick", color: { argb: "#000000" } },
      left: { style: "thick", color: { argb: "#000000" } },
      bottom: { style: "thick", color: { argb: "#000000" } },
      right: { style: "thick", color: { argb: "#000000" } },
    };

    wsIns.getCell("C17").border = {
      top: { style: "thick", color: { argb: "#000000" } },
      left: { style: "thick", color: { argb: "#000000" } },
      bottom: { style: "thick", color: { argb: "#000000" } },
      right: { style: "thick", color: { argb: "#000000" } },
    };
    wsIns.getCell("C19").border = {
      top: { style: "thin", color: { argb: "#000000" } },
      left: { style: "thin", color: { argb: "#000000" } },
      bottom: { style: "thin", color: { argb: "#000000" } },
      right: { style: "thin", color: { argb: "#000000" } },
    };

    /** D${++} text starts */
    wsIns.getCell("D16").value =
      "Headers in Light Green are Mandatory or Required Fields";
    (wsIns.getCell("D17").value =
      "Headers in White are not Required entry Fields"),
      (wsIns.getCell("D19").value =
        "Headers cells that are include a red triangle at top right provide");
    // await ws.protect('the-password', {});
    const buf = await wb.xlsx.writeBuffer();
    saveAs(
      new Blob([buf]),
      this.generateFilename("workgroupImportlList", ".xlsx")
    );
  }
  colorCell(ws, cn) {
    ws.getCell(cn).fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: {
        argb: "0xEAF1DD",
      },
    };
  }
  public generateFilename(companyName: string, extension: string): string {
    return `${
      companyName === "" || companyName === undefined || companyName === null
        ? "defaultworkgroupName"
        : companyName
    }-${Date.now()}.${extension}`;
  }
}
