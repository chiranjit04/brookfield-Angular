import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrganizationmanagementComponent } from './organizationmanagement.component';

describe('OrganizationmanagementComponent', () => {
  let component: OrganizationmanagementComponent;
  let fixture: ComponentFixture<OrganizationmanagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrganizationmanagementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrganizationmanagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
