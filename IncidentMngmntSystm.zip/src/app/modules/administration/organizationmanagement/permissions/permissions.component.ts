import { CONFIG_LEVEL } from "./model";
import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  ElementRef,
  OnInit,
  Renderer2,
  ViewChild,
} from "@angular/core";
import { PermisionService } from "../permissions/permision.service";
import { ActivatedRoute, Router } from "@angular/router";
import Swal from "sweetalert2";
import { ToastrService } from "ngx-toastr";
import { FormBuilder, FormControl } from "@angular/forms";
import { MatTableDataSource } from "@angular/material/table";
import { map, startWith } from "rxjs/operators";
import { JobtitlesService } from "../jobtitles/jobtitles.service";
import { Observable } from "rxjs";
import * as XLSX from "xlsx";

import { UserPermissionService } from "../../../../services/user-permission.service";
import { StorageService } from "../../../../services/storage.service";
import { MatAutocompleteTrigger } from "@angular/material";

const ELEMENT_DATA: any = [];

@Component({
  selector: "app-permissions",
  templateUrl: "./permissions.component.html",
  styleUrls: ["./permissions.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PermissionsComponent implements OnInit {
  showAll: boolean;
  APIdata: any;
  DummyApiData: any;
  profileInTask: any;
  taskListForFilter: any;
  selectedComp: any;
  selected: any;
  profileShowArr = [];
  Aarray = [];
  taskShowArr = [];
  loading: boolean = false;
  displayedColumns = ["Title"];
  @ViewChild("tableRef", { static: false }) tableRef: ElementRef;
  @ViewChild("hashComp", { static: false }) hashComp: ElementRef | any;
  @ViewChild("hashComp2", { static: false }) hashComp2: ElementRef | any;

  @ViewChild(MatAutocompleteTrigger, { static: false })
  autocomplete: MatAutocompleteTrigger;

  @ViewChild("hashComp1", { static: false }) visible: any;

  profilesList = [];
  streets: string[] = [];
  filteredStreets: Observable<any>;
  companyControl = new FormControl();

  ELEMENT_DATA: any[] = [];
  // tslint:disable-next-line: no-use-before-declare
  dataSourceMain: any = new MatTableDataSource(ELEMENT_DATA);

  dataSource = [];
  stateCtrl = new FormControl();
  filteredStates: any;
  companylist: any;
  checkTask: boolean;
  highlight: any;
  classChange = false;
  showLoader: boolean;
  CompanyID: any;
  CompanyName: any;
  CompanyDetails: any;
  arrLength: number;
  SubCompanyHeader = "";
  CompanyNameHeader = "";
  storeData: any;
  jsonData: any;
  fileUploaded: File;
  worksheet: any;
  htmlData: any;
  currentUserID: any;
  userData: any;
  showEditView = false;
  editViewMain = false;
  flagObj: boolean = true;
  dataCol = [];

  @ViewChild("hashComp1", { static: false }) hashComp1Elem: any;
  constructor(
    public fb: FormBuilder,
    public permissionService: PermisionService,
    public jobtitleService: JobtitlesService,
    public tostre: ToastrService,
    public router: Router,
    public UserPermission: UserPermissionService,
    private storage: StorageService,
    public cdr: ChangeDetectorRef
  ) {
    /**
     * get permission lists
     */

    this.CompanyDetails = JSON.parse(this.storage.getData("CompanyDetails"));
    if (this.CompanyDetails) {
      this.userData = JSON.parse(this.storage.getData("UserData"));
      this.currentUserID = this.userData[0].UserID;

      this.CompanyID = this.CompanyDetails.CompanyID;
      this.CompanyName = this.CompanyDetails.CompanyName;
      this.CompanyNameHeader =
        this.CompanyDetails.CompanyName +
        " - " +
        this.CompanyDetails.CompanyIndentNumber;
      if (this.CompanyDetails.ParentName) {
        if (
          this.CompanyDetails.ParentName ===
          this.CompanyDetails.ParentCompanyName
        ) {
          this.SubCompanyHeader =
            "This is a Company Subdivision of Company: " +
            this.CompanyDetails.ParentCompanyName +
            " - " +
            this.CompanyDetails.ParentCompanyIndentNumber;
        } else {
          /**
           * if not same
           */
          this.SubCompanyHeader =
            "This is a Subdivision of Company Subdivision: " +
            this.CompanyDetails.ParentCompanyName +
            " - " +
            this.CompanyDetails.ParentCompanyIndentNumber;
        }
      }
    }
  }

  setThis() {
    this.filteredStreets = this.companyControl.valueChanges.pipe(
      startWith(""),
      map((company) => {
        if (company === "") {
          return this.companylist;
        }
        let list = company.length >= 1 ? this._filter(company) : [];

        if (list.length == 1 && list[0]["CompanyName"] == company) {
          list = [];
        }
        // this.autocomplete.openPanel();
        this.cdr.detectChanges();
        // setTimeout(() =>this.cdr.detach(),  1000)
        return list;
      })
    );
  }

  ngOnInit() {
    this.checkCompany();

    this.setThis();
    this.storage.removeData("justCreated");
    this.storage.removeData("changedID");
    this.companyDetail();
    this.getTaskList();

    this.getProfileListAll("");
    this.UserPermission.startPermission();
    this.setBack();
  }
  trackByIndex = (index, item) => index;

  private _filterStates(value: string): any[] {
    const filterValue = value.toLowerCase();
    return this.profileInTask.filter((Title) =>
      Title.Title.toLowerCase().includes(filterValue)
    );
  }

  _filter(value: any): any[] {
    const filterValue = value.toLowerCase();
    return (this.companylist || []).filter((comp) =>
      comp.CompanyName.toLowerCase().includes(filterValue)
    );
  }

  // private _normalizeValue(value: any): any {
  //   return value.toLowerCase().replace(/\s/g, '');
  // }

  openFileBrowser(event: any) {
    event.preventDefault();
    const element: HTMLElement = document.getElementById("file") as HTMLElement;
    element.click();
  }

  uploadedFile(event) {
    this.fileUploaded = event.target.files[0];
    this.readExcel();
  }

  async readExcel() {
    const readFile = new FileReader();
    readFile.onload = (e) => {
      this.storeData = readFile.result;
      const data = new Uint8Array(this.storeData);
      const arr = new Array();
      for (let i = 0; i !== data.length; ++i) {
        arr[i] = String.fromCharCode(data[i]);
      }
      const bstr = arr.join("");
      const workbook = XLSX.read(bstr, { type: "binary" });
      const firstsheetname = workbook.SheetNames[1];
      this.worksheet = workbook.Sheets[firstsheetname];
      const range = XLSX.utils.decode_range(this.worksheet["!ref"]);
      range.s.r = 2; // <-- zero-indexed, so setting to 1 will skip row 0
      this.worksheet["!ref"] = XLSX.utils.encode_range(range);
      this.readAsJson();
    };

    readFile.readAsArrayBuffer(this.fileUploaded);
  }

  async readAsJson() {
    this.jsonData = XLSX.utils.sheet_to_json(this.worksheet, { raw: false });
    /**
     *  check the permission is valid or not
     */

    let flag = false;

    for (let i of this.jsonData) {
      if (
        (i["USER PROFILES"] || "").toUpperCase() === "ADMINISTRATION" ||
        (i["USER PROFILES"] || "").toUpperCase() === "ASSET MANAGEMENT"
      ) {
        flag = true;
      }
    }

    if (!flag) {
      this.tostre.error("Not a Permission import File", "", {
        positionClass: "toast-top-right",
      });
      return;
    }
    /**
     *
     */
    let arrofobj = [];
    const assign = [];
    const unAssign = [];
    this.jsonData.splice(0, 1);
    for (let i = 0; i < this.jsonData.length; i++) {
      arrofobj = [];
      // tslint:disable-next-line: forin
      for (const property in this.jsonData[i]) {
        arrofobj.push(this.jsonData[i][property]);
      }
      arrofobj.splice(0, 1);

      for (let j = 0; j < this.APIdata.length; j++) {
        const Ids =
          this.dataSource[i].RoleTasksID + "~" + this.APIdata[j].ProfileID;
        arrofobj[j] === "no" ? unAssign.push(Ids) : assign.push(Ids);
      }
    }

    const body = {
      RecNo: 1,
      AssignIds: assign.toString() + ",",
      UnAssignIds: unAssign.toString() + ",",
      Status: "",
      Message: "",
    };
    //console.log("Kind", body);
    this.permissionService.UpdatePermission(body).subscribe((res) => {
      //console.log(res);
      if (res.statusCode === 200) {
        this.showLoader = false;
        //console.log("firstCall");
        this.getTaskList();
        this.getProfileListAll("");
        this.setBack();
        this.showValid("Process successfully. Please check the table.");
      }
    });
  }
  permissionRow;
  async exportPermissio() {
    // const data = this.dataSource;

    // const excelArr = [];
    // // Title
    // for (let i in this.dataSource) {
    //   const obj = {
    //     Title: data[i].Title,
    //   };
    //   this.APIdata.forEach((element) => {
    //     if (data[i].ProfileIDs[0].some((res) => res == element.ProfileID)) {
    //       obj[element.ProfileName] = data[i].ResourceKey ? "yes" : "";
    //     } else {
    //       obj[element.ProfileName] = data[i].ResourceKey ? "no" : "";
    //     }
    //   });
    //   excelArr.push(obj);
    // }
    // this.permissionService.exportPermissionFile(excelArr);
    this.downloadFlag = true;
    this.getTaskList();
    this.getProfileListAll("");
  }

  async exportPermissionWithFlag() {
    const data = this.dataSource;

    const excelArr = [];
    // Title
    for (let i in this.dataSource) {
      const obj = {
        Title: data[i].Title,
      };
      this.APIdata.forEach((element) => {
        if (data[i].ProfileIDs[0].some((res) => res == element.ProfileID)) {
          obj[element.ProfileName] = data[i].ResourceKey ? "yes" : "";
        } else {
          obj[element.ProfileName] = data[i].ResourceKey ? "no" : "";
        }
      });
      excelArr.push(obj);
    }
    this.permissionService.exportPermissionFile(excelArr);
  }

  /** On selection of task it will scroll and highlight the row */
  @ViewChild("textSearch", { static: false }) text: any;

  scroll(viewId, event, name) {
    let el: any = document.getElementById("view" + viewId);
    let name1: any = document.getElementById("permission");

    el.scrollIntoView({ block: "center" });
    el.classList.add("selected");
    this.text.nativeElement.click();

    name1.value = name;

    this.selected = viewId;

    setTimeout(() => {
      el.classList.remove("selected");
    }, 2000);
  }

  downloadFlag: boolean = false;
  /** getting Profile and Task list */

  async getProfileListAll(id, ref?: any) {
    this.profileShowArr = [];
    this.taskShowArr = [];

    if (id) {
      this.storage.setData("changedID", JSON.stringify(id));
    }
    const companyDetails = this.storage.getData("CompanyDetails");
    const changedID = this.storage.getData("changedID");
    if (companyDetails || id || changedID) {
      if (id) {
      } else if (companyDetails) {
        this.selectedComp = JSON.parse(companyDetails);
        this.companyControl.setValue(this.selectedComp.CompanyName);
      }
      this.highlight = "";
      this.selected = "";
      if (changedID) {
        id = JSON.parse(changedID);
      } else {
        id = id;
      }
      this.permissionService
        .getProfileList(id ? id : this.selectedComp.CompanyID)
        .subscribe((res) => {
          //console.log(res.GetProfileRecordList);
          if (res.GetProfileRecordList.length > 0) {
            this.classChange = false;
            this.APIdata = [];
            // this.DummyApiData = [];

            this.APIdata = res.GetProfileRecordList;

            let index = this.APIdata.findIndex((accu) => accu.ProfileID == 1);
            let temp = this.APIdata[index];
            let toSwap = this.APIdata[0];

            this.APIdata[index] = toSwap;
            this.APIdata[toSwap] = temp;

            this.showAll = false;
            this.displayedColumns = ["Title"];
            this.APIdata.forEach((element) => {
              this.displayedColumns.push(element.ProfileName);
            });
            this.APIdata = this.APIdata.map((elem) => {
              return {
                ...elem,
                hash: Math.floor(Math.random() * 1000) + elem.ProfileID,
              };
            });

            //console.log(this.APIdata);
            this.arrLength = this.displayedColumns.length;

            this.dataCol = this.APIdata;
          } else {
            const msg = "There is no profile against selected company";
            this.showInvalid(msg);
          }

          if (ref) {
            ref.blur();
          }
          if (this.downloadFlag) {
            this.downloadFlag = false;
            this.exportPermissionWithFlag();
          }
          this.cdr.detectChanges();
        });
    } else {
      this.classChange = true;
      // const msg = "Company not selected";
      // this.showInvalid(msg);
      this.cdr.detectChanges();
    }
  }

  /** permission list */
  async getTaskList() {
    this.loading = true;
    this.permissionService.getTaskLIst().subscribe((res) => {
      this.profileInTask = [];
      let taskRecordList = res.GetTaskRecordList;
      for (let inx in taskRecordList) {
        if (taskRecordList[inx].ResourceKey === "") {
          this.profileInTask.push(taskRecordList[inx]);
        }
      }
      this.dataSource = taskRecordList;

      let profile = [];
      taskRecordList.forEach((element, i) => {
        const pro = element.ProfileIDs;
        profile = pro.split(",");
        this.dataSource[i].ProfileIDs = [profile];
      });

      this.dataSourceMain.connect().next(this.dataSource);
      this.loading = false;
      this.setBack();
      this.cdr.detectChanges();
    });
  }

  /** getting company list for dropdown */

  async companyDetail() {
    this.permissionService.GetCompanySubdivision().subscribe((res) => {
      this.companylist = res.companySearchList;
      if (this.storage.getData("CompanyDetails")) {
        const selectedComp = JSON.parse(this.storage.getData("CompanyDetails"));
        let a = "";
        if (
          this.companylist.some((data) =>
            data.CompanyID === selectedComp.CompanyID
              ? (a = data.CompanyID)
              : ""
          )
        ) {
          //console.log(selectedComp.CompanyID);
        } else {
          this.showInvalid("Selected company is inactive.");
          // Swal.fire({
          //   text: "Selected company is inactive.",
          // }).then((result) => {
          this.router.navigate([
            "products/administration/organizationmanagement/companies",
          ]);
          // });
          return false;
        }
      }
    });
  }

  /** get profiles by CompanyID */
  showAllId: any = 0;
  async changeCompany(compName, event, companyObj, ref) {
    this.hideCross = true;
    this.hideTable = true;
    this.showSelect = false;

    let id = "";
    if (!event.isUserInput) {
      return;
    }

    if (
      this.companylist.some((data) =>
        data.CompanyName === compName ? (id = data.CompanyID) : ""
      )
    ) {
      this.CompanyNameHeader =
        companyObj.CompanyName + " - " + companyObj.CompanyIndentNumber;
      if (companyObj.ParentName) {
        this.SubCompanyHeader =
          "This is a Company Subdivision of Company : " +
          companyObj.ParentName +
          " - " +
          companyObj.ParentCompanyIndentNumber;
      } else {
        this.SubCompanyHeader = "";
      }
      this.showAllId = id;
      //console.log("test 2");
      this.getTaskList();
      this.getProfileListAll(id, ref);

      this.setBack();
      //console.log("test");
    }

    this.cdr.detectChanges();
  }

  /** To select particuler task permission */

  async selectTaskToshow(event, index, taskName) {
    if (!event.checked) {
      if (this.taskShowArr.length > 0) {
        if (this.taskShowArr.some((data) => data.Title === taskName)) {
          const i = this.taskShowArr.findIndex(
            (data) => data.Title === taskName
          );
          this.taskShowArr.splice(i, 1);
        }
      }
    } else {
      this.taskShowArr.push(this.dataSource[index]);
    }

    //console.log(this.taskShowArr);
  }

  /** To selected particuler profile. */

  async selectProfileToShow(event, indexx, proName, data?: any) {
    if (!event.checked) {
      if (this.profileShowArr.length > 0) {
        if (this.profileShowArr.some((data) => data.ProfileName === proName)) {
          const i = this.profileShowArr.findIndex(
            (data) => data.ProfileName === proName
          );
          this.profileShowArr.splice(i, 1);
        }
      }
      this.loading = false;
      this.cdr.detectChanges();
    } else {
      //console.log(this.APIdata[indexx]);
      //console.log(this.APIdata);
      this.profileShowArr.push(this.APIdata[indexx]);
      this.loading = false;

      this.cdr.detectChanges();
    }
  }

  /** To show selected rows and columns. */

  async showOnlyProfile() {
    if (this.profileShowArr.length == 0 && this.taskShowArr.length == 0) {
      this.showInvalid("First check profile or permission.");
    }
    if (this.profileShowArr.length > 0) {
      this.showAll = true;
      this.APIdata = this.profileShowArr;

      this.displayedColumns = ["Title"];
      this.APIdata.forEach((element) => {
        this.displayedColumns.push(element.ProfileName);
      });
    }
    if (this.taskShowArr.length > 0) {
      this.showAll = true;
      this.dataSource = this.taskShowArr;
      this.dataSourceMain.connect().next(this.dataSource);
      this.dataSourceMain.disconnect();
    } else {
    }
    this.cdr.detectChanges();
  }

  /** Sending the value of checkbox // Service call */

  async taskStatusChange(event, ProfileID, RoleTasksID, doo?, events?) {
    if (+ProfileID === 1) {
      return;
    }
    const param = RoleTasksID + "~" + ProfileID;
    let body = { AssignIds: "", UnAssignIds: "" + "," };
    if (event.disabled) {
      return;
    }

    if (!event.checked) {
      body = {
        AssignIds: null,
        UnAssignIds: param + ",",
      };
    } else {
      body = {
        AssignIds: param + ",",
        UnAssignIds: null,
      };
    }

    this.permissionService.UpdatePermission(body).subscribe((res) => {
      this.cdr.detectChanges();
    });
  }

  async showInvalid(msg) {
    this.tostre.error(msg, "", {
      positionClass: "toast-top-right",
    });
  }

  async showValid(validMsg) {
    this.tostre.success(validMsg, "", {
      positionClass: "toast-top-right",
    });
  }

  async checkCompany() {
    if (!this.CompanyID) {
      this.showInvalid("Please first select a Company.");

      this.router.navigate([
        "products/administration/organizationmanagement/companies",
      ]);
    }
    if (this.CompanyID && !this.CompanyDetails.IsActive) {
      // Swal.fire({
      //   text: "Selected company is inactive. Please select an active company",
      // });
      this.showInvalid(
        "Selected company is inactive. Please select an active company"
      );
      this.router.navigate([
        "products/administration/organizationmanagement/companies",
      ]);
    }
    if (this.CompanyID && this.CompanyDetails.IsArchive) {
      // Swal.fire({
      //   text: "Selected company is archived. Please select an active company",
      // });
      this.showInvalid(
        "Selected company is archived. Please select an unarchive company"
      );
      this.router.navigate([
        "products/administration/organizationmanagement/companies",
      ]);
    }
  }

  hideCross: boolean = true;
  hideTable: boolean = true;
  showSelect: boolean = false;
  removeData(ref) {
    ref.value = "";
    this.hideCross = false;
    this.hideTable = false;
    this.showSelect = true;
    this.cdr.detectChanges();
  }
  checkData() {
    this.profileInTask = this.profileInTask;

    this.cdr.detectChanges();
  }

  /***
   * work for test value
   */
  check;
  widthObj: any;
  calculatedWidth = {
    height: null,
    width: null,
  };
  refValueOfSecond;
  @ViewChild("refTable", { static: false }) table: any;
  @ViewChild("tableWidth", { static: false, read: ElementRef }) tableWidth: any;
  @ViewChild("refValue", { static: false, read: ElementRef }) refValue: any;
  @ViewChild("forScroll", { static: false }) forScroll: any;
  @ViewChild("loadCheck", { static: false, read: ElementRef }) loadCheck: any;

  ngAfterViewInit() { }
  /** */
  checkPointer() {
    let domReact = this.tableWidth.nativeElement.getBoundingClientRect();

    //console.log(domReact);
    this.calculatedWidth = {
      height: domReact.width,
      width: domReact.height,
    };
    // this.widthObj = this.calculatedWidth
    this.refValue.nativeElement.style.width = domReact.width + "px";

    this.table.nativeElement.onscroll = (e) =>
      this.forScroll.nativeElement.scroll(
        (e.target as HTMLElement).scrollLeft,
        0
      );
    this.forScroll.nativeElement.onscroll = (e) =>
      this.table.nativeElement.scroll((e.target as HTMLElement).scrollLeft, 0);
    /**
     * TODO: Don't remove
     * don't remove this line it is width checker
     */

    if (this.calculatedWidth.width > 500) {
      if (this.check) {
        // clearInterval(this.check);
      }
    }
  }

  receiveMessage(event) {
    this.refValueOfSecond = event;
  }

  /**
   * relevant selection
   */

  async setRelevant(row, column) {
    if (+column.ProfileID === 1) {
      return;
    }
    let bool: boolean = false;
    let arr = [];
    let indexInit = this.dataSource.findIndex((accu) => {
      if (row.RoleTasksID === accu.RoleTasksID) {
        return true;
      }
    });

    let incrIndex = indexInit + 1;
    let lastIndex = null;
    let length = this.dataSource.length;
    for (let i = incrIndex; i < length; i++) {
      if (!this.dataSource[i].ResourceKey) {
        lastIndex = i;
        break;
      }
      if (i === length - 1) {
        lastIndex = i;
        bool = true;
      }
    }
    let tempArray = this.dataSource;

    let slicedData = tempArray.slice(
      incrIndex,
      bool ? lastIndex + 1 : lastIndex
    );

    /**
     * check for status all true or false at top level
     */

    let checkFirst = this.parent.findIndex(
      (accu) => accu.name === slicedData[0].ResourceKey && accu.level === 1
    );

    let checkStatus = true;

    for (let i of slicedData) {
      let dom: any = document.querySelector(
        `#elem${column.hash}${i.RoleTasksID}`
      );
      if (!dom.checked) {
        checkStatus = false;
      }
    }

    if (checkFirst >= 0) {
      let dom: any = document.querySelector(
        `#elem${column.hash}${slicedData[0].RoleTasksID}`
      );

      if (dom.disabled) {
        //console.log("disabled");
        return;
      }
      dom.checked = !checkStatus;
      arr.push(slicedData[0].RoleTasksID + "~" + column.ProfileID);
      let u = this.parent[checkFirst];
      this.checkFirstLevel(u, column.hash, checkStatus);
    } else {
      let dom: any = document.querySelector(
        `#elem${column.hash}${slicedData[0].RoleTasksID}`
      );

      if (dom.disabled) {
        //console.log("disabled");
        return;
      }

      for (let j in slicedData) {
        if (+j === 0) {
          continue;
        }
        let dom: any = document.querySelector(
          `#elem${column.hash}${slicedData[j].RoleTasksID}`
        );

        dom.disabled = checkStatus;
      }
    }

    for (let i of slicedData) {
      let dom: any = document.querySelector(
        `#elem${column.hash}${i.RoleTasksID}`
      );
      dom.checked = !checkStatus;
      arr.push(i.RoleTasksID + "~" + column.ProfileID);
    }

    this.taskStatusChangeEdit(
      { checked: checkStatus, disabled: false },
      arr.join(","),
      true // is chuck
    );
  }

  async fullSelection(column) {
    if (+column.ProfileID === 1) {
      return;
    }
    let checkStatus = true;
    let arr = [];

    for (let i of this.dataSource) {
      let dom: any = document.querySelector(
        `#elem${column.hash}${i.RoleTasksID}`
      );
      if (!dom) {
      } else {
        if (!dom.checked) {
          checkStatus = false;
        }
      }
    }

    for (let i of this.dataSource) {
      let dom: any = document.querySelector(
        `#elem${column.hash}${i.RoleTasksID}`
      );
      if (!dom) {
      } else {
        dom.checked = !checkStatus;
        if (i.RoleTasksID != 2) {
          dom.disabled = checkStatus;
        }
      }
      arr.push(i.RoleTasksID + "~" + column.ProfileID);
    }

    this.taskStatusChangeEdit(
      { checked: checkStatus, disabled: false },
      arr.join(","),
      true
    );
  }

  async taskStatusChangeEdit(event, param, isChunck?) {
    let body = { AssignIds: "", UnAssignIds: "" + "," };
    if (event.disabled) {
      this.tostre.warning("You Dont't have permission", "", {
        positionClass: "toast-top-right",
      });
      return;
    }

    if (event.checked) {
      body = {
        AssignIds: null,
        UnAssignIds: param + ",",
      };
    } else {
      body = {
        AssignIds: param + ",",
        UnAssignIds: null,
      };
    }

    this.permissionService.UpdatePermission(body).subscribe((res) => {
      if (!isChunck) {
        this.getTaskList();
        this.getProfileListAll("");
      }

      this.Aarray = [];

      this.cdr.detectChanges();
    });
  }

  async changeStatus(event, main, hash, index, events) {
    let profileID = this.APIdata.find((accu) => accu.hash === hash);

    profileID = profileID.ProfileID;

    if (+profileID === 1) {
      let masterCheckboxRef: any = document.querySelector(
        "#elem" + hash + main.RoleTasksID
      );

      masterCheckboxRef.checked = !masterCheckboxRef.checked;
      return;
    }
    if (+main.RoleTasksID === 2) {
      let flag = !event.checked;

      if (flag) {
        let copyData = this.dataSource.slice(0, 155);
        for (let i of copyData) {
          if (+i.RoleTasksID > 2) {
            let elem: any = document.querySelector(
              "#elem" + hash + "" + i.RoleTasksID
            );

            if (elem) {
              elem.disabled = flag;
            }
          }
        }
      } else {
        let findSeparate = this.parent.filter((accu) => accu.level === 1);

        findSeparate.forEach((elem) => {
          this.checkFirstLevel(elem, hash, !event.checked, true);
        });
      }
    } else {
      let checkFirst = this.parent.findIndex(
        (accu) => accu.name === main.ResourceKey && accu.level === 1
      );
      let checkSecond = this.parent.findIndex(
        (accu) => accu.name === main.ResourceKey && accu.level === 2
      );

      if (checkFirst >= 0) {
        //
        let u = this.parent[checkFirst];
        this.checkFirstLevel(u, hash, !event.checked);
      }
      if (checkSecond >= 0) {
        this.checkSecondLevel(index, hash);
      }
    }
  }

  /** To*/
  async checkFirstLevel(index, profileID: any, flag, mainFlag?) {
    let temp = [];
    temp.push(
      ...[
        index,
        ...(this.parent.filter((accu) => accu.parent === index.name) || []),
      ]
    );

    for (let i in temp) {
      let relevant = this.dataSource.findIndex(
        (accu) => accu.ResourceKey === temp[i].name
      );

      if (+i === 0) {
        if (mainFlag) {
          let checkFirst: any = document.querySelector(
            "#elem" + profileID + this.dataSource[relevant].RoleTasksID
          );
          if (!checkFirst.checked) {
            checkFirst.disabled = false;
            return;
          }
        }
        this.level2Relevant(
          !mainFlag ? relevant + 1 : relevant,
          profileID,
          flag,
          +i
        );
      } else {
        this.level2Relevant(relevant, profileID, flag, +i);
      }
    }
    return;
  }

  async checkSecondLevel(findOne, profileID, isChecked = false) {
    let level2Find = this.parent.filter(
      (accu) =>
        accu.level === 2 && this.dataSource[findOne].ResourceKey === accu.name
    );

    for (let j of level2Find) {
      let oneLevel2 = this.dataSource.findIndex(
        (accu) => accu.ResourceKey === j.name
      );

      if (oneLevel2 >= 0) {
        let l2: any = document.querySelector(
          "#elem" + profileID + this.dataSource[oneLevel2].RoleTasksID
        );

        l2.disabled = false;
        if (!l2.checked) {
          this.level2Relevant(oneLevel2 + 1, profileID, true, 0);
          continue;
        } else {
          this.level2Relevant(oneLevel2 + 1, profileID, false, 0);
        }
      }
    }
    return;
  }

  async level2Relevant(oneLevel2, profileID, flag, isFirst?) {
    if (isFirst !== 0) {
      if (!flag) {
        let check: any = document.querySelector(
          "#elem" + profileID + this.dataSource[oneLevel2].RoleTasksID
        );

        if (!check.checked) {
          check.disabled = false;
          oneLevel2 = oneLevel2 + 1;

          return;
        } else {
          check.disabled = false;
        }
      }
    }
    let length = this.dataSource.length;

    for (let k = oneLevel2; k < length; k++) {
      let resource = this.dataSource[k];

      if (!resource.ResourceKey) {
        break;
      }
      let innerLevel2: any = document.querySelector(
        "#elem" + profileID + resource.RoleTasksID
      );
      if (innerLevel2) {
        innerLevel2.disabled = flag;
      }
    }
    return;
  }
  async setBack() {
    /** TODO: this will set as interval for check when all loaded successfully matrix data */
    const interval = setInterval(() => {
      if (!(this.APIdata || []).length) {
        return;
      }

      if (!this.dataSource.length) {
        return;
      }
      let lastAPiData = this.APIdata[this.APIdata.length - 1];
      let lastDataSource = this.dataSource[this.dataSource.length - 1];

      if (lastDataSource && lastAPiData) {
        let getDom = document.querySelector(
          // `#elem${lastAPiData.ProfileID}${lastDataSource.RoleTasksID}`
          `#elem${lastAPiData.hash}${lastDataSource.RoleTasksID}`
        );
        if (getDom) {
          clearInterval(interval);
          for (let i of this.APIdata) {
            let f: any = document.querySelector(
              // "#elem" + i.ProfileID + this.dataSource[1].RoleTasksID
              "#elem" + i.hash + this.dataSource[1].RoleTasksID
            );
            this.checkSelectionAndEnableSubGroup(i.hash);
            if (!f.checked) {
              let copyData = this.dataSource.slice(0, 155);
              for (let j of copyData) {
                let first: any = document.querySelector(
                  // "#elem" + i.ProfileID + j.RoleTasksID
                  "#elem" + i.hash + j.RoleTasksID
                );
                if (first && +j.RoleTasksID > 2) {
                  first.disabled = true;
                }
              }
            } else {
              /** for enabled */
              // this.checkSelectionAndEnableSubGroup(i.ProfileID);
              this.checkSelectionAndEnableSubGroup(i.hash);
            }
          }
        }
      }
    }, 500);
  }

  async checkSelectionAndEnableSubGroup(profileID) {
    let findSeparate = this.parent.filter((accu) => accu.level === 1);

    findSeparate.forEach((elem) => {
      this.checkFirstLevelInit(elem, profileID, false, true);
    });
  }
  async checkFirstLevelInit(index, profileID, flag, mainFlag) {
    let temp = [];
    temp.push(
      ...[
        index,
        ...(this.parent.filter((accu) => accu.parent === index.name) || []),
      ]
    );

    let relevant = this.dataSource.findIndex(
      (accu) => accu.ResourceKey === temp[0].name
    );

    let checkFirst: any = document.querySelector(
      "#elem" + profileID + this.dataSource[relevant].RoleTasksID
    );

    if (checkFirst.checked) {
      // true
      for (let tt in temp) {
        let h = this.dataSource.findIndex(
          (accu) => accu.ResourceKey === temp[tt].name
        );
        let findSome: any = document.querySelector(
          "#elem" + profileID + this.dataSource[h].RoleTasksID
        );
        if (findSome.checked) {
          findSome.disabled = false;

          this.level2RelevantInit(+h + 1, profileID, false);
        } else {
          this.level2RelevantInit(+h + 1, profileID, true);
        }
      }
    } else {
      // false
      for (let oo in temp) {
        let h = this.dataSource.findIndex(
          (accu) => accu.ResourceKey === temp[oo].name
        );

        if (+oo === 0) {
          this.level2RelevantInit(+h + 1, profileID, true);
        } else {
          this.level2RelevantInit(+h, profileID, true);
        }
      }
    }
  }

  async level2RelevantInit(oneLevel2, profileID, flag) {
    let length = this.dataSource.length;

    for (let i = oneLevel2; i < length; i++) {
      let hdata = this.dataSource[i];
      if (!hdata.ResourceKey) {
        break;
      }

      (document.querySelector(
        "#elem" + profileID + hdata.RoleTasksID
      ) as any).disabled = flag;
    }
  }
  /** TODO: move this below static identifier array into separate model folder  */
  parent = CONFIG_LEVEL;

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
  }
}
