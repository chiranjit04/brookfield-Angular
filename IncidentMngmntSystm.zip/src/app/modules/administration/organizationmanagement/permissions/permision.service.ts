import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { environment } from "../../../../../environments/environment";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Workbook } from "exceljs";
// import * as logoFile from "../../propertymanagement/patrolzonemanagement/brookfieldlogo1.js";
import  * as logoFile from "src/assets/images/logo/brookfieldlogo";
import * as fs from "file-saver";
import { map } from "rxjs/operators";

@Injectable({
  providedIn: "root",
})
export class PermisionService {
  returnVariable: Observable<any>;
  Url: any;

  constructor(private http: HttpClient) {
    this.Url = environment.origin + "api/";
  }

  GetCompanySubdivision() {
    const body = {
      CompanyID: 0,
      CompanyTypeID: 0,
      StateId: 0,
      Status: 1,
      IsActive: null,
      IsArchive: 0,
      Zip: null,
      Address: null,
      ShortFilter: null,
    };
    // companySearchList
    this.returnVariable = this.http
      .post(this.Url + "CompanySearchListOM", body)
      .pipe(
        map((elem: any) => {
          return {
            companySearchList: elem.companySearchListOM,
          };
        })
      );
    return this.returnVariable;
  }

  getProfileList(CompId) {
    const body = {
      CompanyId: CompId,
    };
    this.returnVariable = this.http.post(
      this.Url + "GetProfileRecordList",
      body
    );
    return this.returnVariable;
  }

  getTaskLIst() {
    const body = {
      RoleTasksID: 0,
      Title: null,
      ResourceKey: null,
      IsActive: 1,
    };
    this.returnVariable = this.http.post(this.Url + "GetTaskRecordList", body);
    return this.returnVariable;
  }

  UpdatePermission(body) {
    this.returnVariable = this.http.post(
      this.Url + "UpdateProfilePermission",
      body
    );
    return this.returnVariable;
  }

  exportPermissionFile(json: any) {
    json = json.map((elem) => {
      if (
        elem.Title.toUpperCase() === "ADMINISTRATION" ||
        elem.Title.toUpperCase() === "ASSET MANAGEMENT" ||
        elem.Title.toUpperCase() === "ASSIGN PROPERTY PROFILE FORMS" ||
        elem.Title.toUpperCase() === "BANNING PROGRAM" ||
        elem.Title.toUpperCase() === "DYNAMIC RECORD FORMS" ||
        elem.Title.toUpperCase() === "GOE MANAGEMENT" ||
        elem.Title.toUpperCase() === "INCIDENT SUBJECT" ||
        elem.Title.toUpperCase() === "PROPERTY USE AREA" ||
        elem.Title.toUpperCase() === "REPORTING SET"
      ) {
        let obj = {};

        Object.keys(elem).forEach((elemInner) => {
          if (elemInner === "Title") {
            obj[elemInner] = elem[elemInner];
          } else {
            obj[elemInner] = "";
          }
        });

        return obj;
      }
      return elem;
    });
    const header = ["USER PROFILES"];
    const neObj = {};
    // tslint:disable-next-line: forin
    for (const property in json[0]) {
      header.push(property);
    }
    for (let i = 1; i < header.length; i++) {
      neObj[header[i]] = "";
    }
    neObj["Title"] = "PERMISSION ACCESS";
    json.splice(0, 0, neObj);
    console.log(json);
    console.log(neObj);
    header.splice(1, 1);
    const workbook = new Workbook();
    const worksheetOne = workbook.addWorksheet("Instructions");
    const worksheet = workbook.addWorksheet("Permissions Data");
    const worksheetTwo = workbook.addWorksheet("System Pick Values");

    let objectList = [];
    objectList = json.map((ob) => Object.values(ob));

    worksheet.mergeCells("A1:B1");
    const imageRow = worksheet.getRow(1);
    imageRow.height = 100;

    // Add Image
    const logo = workbook.addImage({
      base64: logoFile.logoBase64,
      extension: "png",
    });

    worksheet.addImage(logo, {
      tl: { col: 0.5, row: 0.5 },
      ext: { width: 350, height: 85 },
    });
    const title = "Permission Exported Data";
    const titleRow = worksheet.addRow([title]);
    titleRow.font = { name: "Calibri", family: 4, size: 16, bold: true };
    worksheet.getRow(2).height = 30;
    worksheet.mergeCells("A2:C2");
    // Add Header Row
    const headerRow = worksheet.addRow(header);

    // Set a specific row height
    headerRow.height = 42.5;
    headerRow.font = { name: "Calibri", family: 4, size: 11, bold: true };
    headerRow.alignment = {
      vertical: "middle",
      horizontal: "center",
    };
    // Cell Style : Fill and Border
    headerRow.eachCell((cell, number) => {
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "0xEAF1DD" },
        bgColor: { argb: "FF0000FF" },
      };
      cell.border = {
        top: { style: "thin" },
        left: { style: "thin" },
        bottom: { style: "thin" },
        right: { style: "thin" },
      };
    });

    objectList.forEach((d) => {
      const row = worksheet.addRow(d);
      row.alignment = { horizontal: "center", wrapText: true };
      const qty = row.getCell(4);
    });
    for (let i = 0; i < header.length; i++) {
      worksheet.getColumn(i + 1).width = 30;
    }
    worksheet.getRow(4).height = 42.5;
    worksheet.getRow(4).font = {
      name: "Calibri",
      family: 4,
      size: 11,
      bold: true,
    };
    worksheet.getRow(4).alignment = {
      vertical: "middle",
      horizontal: "center",
    };
    worksheet.getCell("A4").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "C9DEC9" },
      bgColor: { argb: "FF0000FF" },
    };
    worksheet.addRow([]);
    worksheetOne.getColumn(3).width = 13;
    worksheetOne.getColumn(4).width = 13;

    // Add the Header Image
    worksheetOne.mergeCells("D1:H6");
    worksheetOne.addImage(logo, "D1:H6");
    worksheetOne.addRow([]);
    worksheetOne.getCell("C7").value =
      "Brookfield Properties Permissions Spreadsheet";
    worksheetOne.getCell("C7").font = {
      name: "Calibri",
      family: 4,
      size: 16,
      underline: true,
      bold: true,
    };
    worksheetOne.getRow(7).height = 25;
    worksheetOne.addRow([]);
    worksheetOne.addRow([]);

    // tslint:disable-next-line: max-line-length
    worksheetOne.getCell("B10").value =
      "Please list the Brookfield Permission, these Permission are customized to represent that every profile has its access specific .";
    worksheetOne.getCell("B10").alignment = {
      vertical: "top",
      horizontal: "left",
      wrapText: true,
    };

    worksheetOne.mergeCells("B10", "K13");

    worksheetOne.getCell("B10").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "C9DEC9" },
      bgColor: { argb: "FF0000FF" },
    };

    worksheetOne.getCell("B15").value =
      "Set of Instructions for the Spreadsheet:";
    worksheetOne.getCell("B15").font = {
      name: "Calibri",
      family: 4,
      size: 12,
      bold: true,
    };
    worksheetOne.addRow([]);
    worksheetOne.getCell("B17").value = "GENERAL INFO:";
    worksheetOne.getCell("B23").alignment = { horizontal: "center" };
    worksheetOne.getCell("B17").font = {
      name: "Calibri",
      family: 4,
      size: 12,
      bold: true,
    };
    worksheetOne.getCell("B18").value = "-";
    worksheetOne.getCell("B18").alignment = { horizontal: "right" };
    worksheetOne.getCell("C18").value =
      "Please fill in the required fields to upload data into MAXIMUS.";
    worksheetOne.addRow([]);
    worksheetOne.getCell("B20").value = "-";
    worksheetOne.getCell("B20").alignment = { horizontal: "right" };
    worksheetOne.getCell("C20").value =
      "Dropdown values will appear in each cell if there is a selection to be made,";
    worksheetOne.getCell("C21").value = " otherwise enter appropriate data.";
    worksheetOne.addRow([]);
    worksheetOne.getCell("B23").value = "-";
    worksheetOne.getCell("B23").alignment = { horizontal: "right" };
    worksheetOne.getCell("C23").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "C9DEC9" },
      bgColor: { argb: "FF0000FF" },
    };
    worksheetOne.getCell("C23").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheetOne.getCell("D23").value =
      "Headers in Light Green are Mandatory or Required fields.";
    worksheetOne.getCell("B24").value = "-";
    worksheetOne.getCell("B24").alignment = { horizontal: "right" };
    worksheetOne.getCell("C24").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "" },
      bgColor: { argb: "" },
    };
    worksheetOne.getCell("C24").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheetOne.getCell("D24").value =
      "Headers in White are not Required entry fields.";
    worksheetOne.addRow([]);
    worksheetOne.getCell("B26").value = "-";
    worksheetOne.getCell("B26").alignment = { horizontal: "right" };
    worksheetOne.getCell("C26").fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "" },
      bgColor: { argb: "" },
    };
    worksheetOne.getCell("C26").border = {
      top: { style: "thin" },
      left: { style: "thin" },
      bottom: { style: "thin" },
      right: { style: "thin" },
    };
    worksheetOne.getCell("D26").value =
      "Header cells that include a red triangle at top right provide";
    worksheetOne.getCell("D27").value =
      "information about the field when you mouse over the cell.";

    worksheetOne.addRow([]);

    // Worksheet for System Pick Values
    worksheetTwo.getCell("C2").value = "Active";
    worksheetTwo.getCell("C3").value = "InActive";

    // Generate Excel File with given name
    workbook.xlsx.writeBuffer().then((data: any) => {
      const blob = new Blob([data], {
        type:
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });
      fs.saveAs(blob, "PermissionExportData.xlsx");
    });
  }
}
