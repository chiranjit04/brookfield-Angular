import { BanningmanagementComponent } from './banningmanagement/banningmanagement.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdministrationhomeComponent } from './administrationhome/administrationhome.component';
import { GlobaloperationsenvironmentComponent } from './globaloperationsenvironment/globaloperationsenvironment.component';
import { MyenvironmentComponent } from '../administration/myenvironment/myenvironment.component';
import { AssignCompaniesComponent } from './assign-companies/assign-companies.component';
import { IncidentsubjecttableComponent } from './incidentsubjecttable/incidentsubjecttable.component';
import { ReportingsetsComponent } from './reportingsets/reportingsets.component';
import { SectorsComponent } from './sectors/sectors.component';
import { Assignpropertiecomponent } from './assign-properties/assignpropertie.component';
import { GoeDetailComponent } from './myenvironment/goe-detail/goe-detail.component';
import { CreategoeComponent } from './myenvironment/creategoe/creategoe.component';
import { AssignpropertyprofileComponent } from './assignpropertyprofile/assignpropertyprofile.component'
import { AssetmanagementComponent } from './assetmanagement/assetmanagement.component';
import { AuthGuard } from "./../../guard/auth.guard";
import { DispositioncodesComponent } from './dispositioncodes/dispositioncodes.component';
import { AdddispositionComponent } from './dispositioncodes/adddisposition/adddisposition.component';

const appRoutes: Routes = [
  {
    path: '', 
    component: AdministrationhomeComponent,
    canActivate: [ AuthGuard ],
    children:
      [
        { path: '', redirectTo: 'goe/mygoe', pathMatch: 'full' },
        { path: 'goe', redirectTo: 'goe/mygoe', pathMatch: 'full' },        
        { path: 'goe/mygoe', component: MyenvironmentComponent },
        { path: 'goe/banningmanagement', component: BanningmanagementComponent },
        { path: 'goe/assetmanagement', component: AssetmanagementComponent },
        { path: 'goe/assign-properties', component: Assignpropertiecomponent },
        { path: 'goe/incident-subject', component: IncidentsubjecttableComponent },
        { path: 'goe/reporting-sets', component: ReportingsetsComponent },
        { path: 'goe/property-use-area', component: SectorsComponent },
        { path: 'goe/mygoe/create', component: CreategoeComponent },
        { path: 'goe/mygoe/detail/:id', component: GoeDetailComponent },
        { path: 'goe/dispositioncodes', component: DispositioncodesComponent },
        { path: 'goe/dispositioncodes/add', component: AdddispositionComponent },

        { path: 'goe/dynamicrecord', loadChildren: () => import('./dynamicrecordforms/dynamicrecordforms.module').then(m => m.DynamicrecordformsModule) },
        { path: 'goe/assignpropertyprofile', component: AssignpropertyprofileComponent },

        { path: 'organizationmanagement', loadChildren: () => import('./organizationmanagement/organizationmanagement.module').then(m => m.OrganizationmanagementModule) },
        { path: 'propertymanagement', loadChildren: () => import('./propertymanagement/propertymanagement.module').then(m => m.PropertymanagementModule) },
        
      ],
  },  
];

@NgModule({
  imports: [RouterModule.forChild(appRoutes)],
  exports: [RouterModule]
})
export class AdministrationRoutingModule { }
