import { Component, OnInit } from "@angular/core";
import { AssignpropertyService } from 'src/app/services/assign-property.services';
import Swal from 'sweetalert2';
import { StorageService } from '../../../services/storage.service';

@Component({
    selector:'app-assignproperty',
    templateUrl:'./assignproperties.component.html',
    styleUrls:['./assignpropertie.component.scss'],
    providers:[AssignpropertyService]
})

export class Assignpropertiecomponent implements OnInit {
    username:string;
    getpropertyforsubdivision:any;
    getpropertybypropertytype:any;
    protypeid=false;
    propid:any;
    propri=false;
    PropertyID:any;
    pty=false;
    lengths:any;
constructor(private disp:AssignpropertyService, private storage: StorageService){
    this.username=this.storage.getData('username');
this.getGlobalEnvironmentPropertytypesList();
this.getGlobalEnvironmentPropertybyIdAll();
this.getPropertySubDivisionAll();
}

globalEnvironmentName = this.storage.getData('GlobalEnvironmentName')
isco=true;
propertyTypes=[];
PropertybyId=[];
PropertySubDivision=[];
tyid:any;
selectedPtype = false
selectedPtype1 = false
selectedPtype2 = false

getGlobalEnvironmentPropertytypesList(){
    let result:any
    this.disp.getGlobalEnvironmentPropertytypesList().subscribe(res=>{
        console.log(res,'rrrrrrrrrrrrrrrrrrrrrrrrr');
        result = res;
        this.propertyTypes = result.GetGlobalEnvironmentPropertytypesList       
    });
}


getGlobalEnvironmentPropertybyId(t){
    this.disp.getGlobalEnvironmentPropertybyId(t).subscribe(res=>{
        this.PropertybyId = res.GetGlobalEnvironmentPropertybyId   
        console.log(this.PropertybyId, 'isassigned            getGlobalEnvironmentPropertybyId...');    
    });
}

getPropertySubDivision(ge){
    console.log( this.pty , ' this.pty        ')
    
ge.propertyID=ge.propertyID;
    this.disp.getPropertySubDivision(ge).subscribe(res=>{
        console.log(ge,'...................pbodysubdivision...   ');  
        console.log(ge.propertyID,'.pbodysubdivision...   '); 
        console.log(res.GetPropertySubDivision.length,'resresresresresresresresresresresresres.pbodysubdivision...   ');  
        if(res.GetPropertySubDivision.length>0){
            console.log(res.GetPropertySubDivision.propertyID,'res.GetPropertySubDivision.propertyID...   '); 
            this.propri=false;           
           
        }else{
            this.lengths=0;
            //  if(this.pty){
            // }else{
                console.log(ge,'...................AssignPropertyToGeo   ');  
                this.propid=ge.propertyID;
                this.AssignPropertyToGeo(ge);
                this.propri=true;             
           // }
        }
        this.PropertySubDivision=res.GetPropertySubDivision;
      
    });

}

getproperties(t, index){
    this.protypeid=true;
    this.getpropertybypropertytype=t.PropertyTypeId;
   this.pty=true;
    this.isco=index;
    this.tyid=t.PropertyTypeID;
    const pbody={
        "PropertyTypeId":t.PropertyTypeID,
        "GlobalEnvironmentID":0,
        "UserName":this.username
        }

        const pbodysubdivision={
            "GlobalEnvironment":1,
            "UserName":this.username,
            "propertyTypeID":t.PropertyTypeID,
            "propertyID":0
            }

    if(index == this.selectedPtype){
        this.selectedPtype = false
    }else{
     console.log(pbodysubdivision,'.pbodysubdivision...   ');   
        this.getGlobalEnvironmentPropertybyId(pbody);
        this.getPropertySubDivision(pbodysubdivision)
        this.selectedPtype = index
       
    }

}


getSubDivisionByproperties(t, index){
    this.pty=false;
    this.propri=true;

    this.getpropertyforsubdivision=t.PropertyID;
    console.log(t,'t t t  t'); 
    const pbodysubdivision={
        'GlobalEnvironment':1,
        'UserName':this.username,
        'propertyTypeID':0,
        'propertyID':t.PropertyID,
        'IsAssigned':t.IsAssigned
        }
    if(index == this.selectedPtype1){
        this.selectedPtype1 = false
    }else{
     console.log(pbodysubdivision,'.......check            getSubDivisionByproperties');   
      
     this.getPropertySubDivision(pbodysubdivision);       
        this.selectedPtype1 = index
    }

}

getPropertySubDivisionAll(){
    const pbody={
        "propertyTypeID":0,
      "GlobalEnvironment":1,
      "propertyID":0,
      "UserName":this.username,
      }
this.disp.getPropertySubDivision(pbody).subscribe(res=>{
    this.PropertySubDivision=res.GetPropertySubDivision;
   
    console.log(res, 'getPropertySubDivisionAll');
});
}

getGlobalEnvironmentPropertybyIdAll(){   
    const pbody={
        "PropertyTypeId":0,
        "GlobalEnvironmentID":1,
        "UserName":this.username
        }
    
this.disp.getGlobalEnvironmentPropertybyId(pbody).subscribe(res=>{
    this.PropertybyId = res.GetGlobalEnvironmentPropertybyId;
    res.GetGlobalEnvironmentPropertybyId.forEach(element => {
        console.log( element,'res.GetGlobalEnvironmentPropertybyId');
        if(element.IsAssigned){
           this.selectedPtype1 = false;
         //  console.log(this.selectedPtype1, 'this.selectedPtype1  ');
         //   console.log(element.IsAssigned, 'res.GetGlobalEnvironmentPropertybyId.IsAssigned');
          //  console.log(this.PropertybyId.length, 'this.PropertybyId.length             ');
        } else{}
  });
});

}


AssignPropertyToGeo(t){
  
    console.log(t, t.IsAssigned, 't------------------             ');
 //   console.log(t.IsAssigned, 'tttttttttttt----------------------------------ttttttttttttttttttttttt  ');
   let isa;
    if(t.IsAssigned==0 || t.IsAssigned==null){
       isa=1;
       console.log(isa, 'isa------------------             ');
    }else{
         isa=0;
         console.log(isa, 'isa------------------         else    ');
    }

    if(this.propri){

        t.PropertyID=this.propid;
        const pbody={
            'GoeId':1,
            'propertyId':t.PropertyID,
            'IsAssign':isa,
            'UserName':this.username
        }
    }else{
        t.PropertyID=t.PropertyID;
        const pbody={
            'GoeId':1,
            'PropertyId':t.PropertyID,
            'IsAssign':isa,
            'UserName':this.username
        }
    }
   // if(){
    const pbody={
        'GoeId':1,
        'PropertyId':t.PropertyID,
        'IsAssign':isa,
        'UserName':this.username
    }
    const pbodys={
        "PropertyTypeId":this.tyid,
        "GlobalEnvironmentID":0,
        "UserName":this.username
        }
      
  
    this.disp.AssignPropertyToGeo(pbody).subscribe(res=>{
//if(this.lengths==0){}else{
        console.log(res, 'resresresresresres        ');
        //this.getGlobalEnvironmentPropertybyId(pbodys);
        if(this.propri){
            const g={
                "propertyTypeID":0,
              "GlobalEnvironment":1,
              "propertyID":this.getpropertyforsubdivision,
              "UserName":this.username,
              }
           //  this.getPropertySubDivision(g);
              console.log(g, 'gggggggggggggggg        ');
      }else{
          this.getPropertySubDivisionAll();
      }
  //  }
//       if(this.protypeid){
//         const pro={
//             "propertyTypeID":this.getpropertybypropertytype,
//           "GlobalEnvironment":1,
//           "propertyID":0,
//           "UserName":this.username,
//           }
// this.getGlobalEnvironmentPropertybyId(pro);
//       }else{
//         this.getGlobalEnvironmentPropertybyIdAll();
//       }
    
 //   }   
}
    )

}




ngOnInit(){}

}

