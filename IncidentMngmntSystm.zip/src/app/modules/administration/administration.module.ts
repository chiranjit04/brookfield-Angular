import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedMaterialModule } from './../../shared/shared-material.module';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { AdministrationRoutingModule } from './administration-routing.module';
// import { OrganizationmanagementComponent } from './organizationmanagement/organizationmanagement.component';
import { GlobaloperationsenvironmentComponent } from './globaloperationsenvironment/globaloperationsenvironment.component';
import { AdministrationnavComponent } from './administrationnav/administrationnav.component';
import { AdministrationhomeComponent } from './administrationhome/administrationhome.component';
import { GlobalModule } from '../global/global.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { MyenvironmentComponent } from '../administration/myenvironment/myenvironment.component';
import { AssignCompaniesComponent } from './assign-companies/assign-companies.component';
import { IncidentsubjecttableComponent } from './incidentsubjecttable/incidentsubjecttable.component';
import { ReportingsetsComponent } from './reportingsets/reportingsets.component';
import { SectorsComponent } from './sectors/sectors.component';
import { Assignpropertiecomponent } from './assign-properties/assignpropertie.component';
// import { CreatedgoeComponent } from './myenvironment/goe-detail/createdgoe/createdgoe.component';
import { GoeDetailComponent } from './myenvironment/goe-detail/goe-detail.component';
import { RestricteduseComponent } from './myenvironment/goe-detail/restricteduse/restricteduse.component';
import { GoeleadersComponent } from './myenvironment/goe-detail/goeleaders/goeleaders.component';
import { GoeadminComponent } from './myenvironment/goe-detail/goeadmin/goeadmin.component';
import { RestricteduselistComponent } from './myenvironment/goe-detail/restricteduselist/restricteduselist.component';
import { AssignpropertiestogoeComponent } from './myenvironment/goe-detail/assignpropertiestogoe/assignpropertiestogoe.component';
import { GeoleaderlistComponent } from './myenvironment/goe-detail/geoleaderlist/geoleaderlist.component';
import { GeoadminlistComponent } from './myenvironment/goe-detail/geoadminlist/geoadminlist.component';
import { CreategoeComponent } from './myenvironment/creategoe/creategoe.component';
import { AssignpropertyprofileComponent } from './assignpropertyprofile/assignpropertyprofile.component';
import { BanningmanagementComponent } from './banningmanagement/banningmanagement.component';
import { AssetmanagementComponent } from './assetmanagement/assetmanagement.component';
import { UplaodiconComponent } from './assetmanagement/uplaodicon/uplaodicon.component';

// import { CompaniesComponent, ModelDialogComponent } from './companies/companies.component';
// import { PermissionsComponent } from './permissions/permissions.component';
// import { ProfilesComponent } from './profiles/profiles.component';
// import { WorkgroupsComponent } from './workgroups/workgroups.component';
// import { UsersComponent, UserModalComponent } from './users/users.component';
// import { ModelDialogComponent } from '../dispatch/companies/companies.component';
import { OrganizationmanagementModule } from './organizationmanagement/organizationmanagement.module'
import { PropertymanagementModule } from './propertymanagement/propertymanagement.module'
import { SharedModule } from 'src/app/shared/shared.module';
import { DispositioncodesComponent } from './dispositioncodes/dispositioncodes.component';
import { AdddispositionComponent } from './dispositioncodes/adddisposition/adddisposition.component';
import { DispositionService } from './dispositioncodes/disposition.service';
import { IpaddressComponent } from './myenvironment/goe-detail/ipaddress/ipaddress.component';

@NgModule({
  declarations: [
    //OrganizationmanagementComponent,
    GlobaloperationsenvironmentComponent,
    AdministrationnavComponent,
    AdministrationhomeComponent,

    MyenvironmentComponent,
    AssignCompaniesComponent,
    IncidentsubjecttableComponent,
    ReportingsetsComponent,
    SectorsComponent,
    Assignpropertiecomponent,
    // CreatedgoeComponent,
     RestricteduseComponent,
     GoeDetailComponent,
     GoeleadersComponent,
     GoeadminComponent,
     RestricteduselistComponent,
     AssignpropertiestogoeComponent,
     GeoleaderlistComponent,
     GeoadminlistComponent,
     CreategoeComponent,
     AssignpropertyprofileComponent,
     BanningmanagementComponent,
     AssetmanagementComponent,
     UplaodiconComponent,
     DispositioncodesComponent,
     AdddispositionComponent,
     IpaddressComponent,
    //  CompaniesComponent,
    //  PermissionsComponent,
    //  ProfilesComponent,
    //  WorkgroupsComponent,
    //  UsersComponent,
    //  ModelDialogComponent,
    //  UserModalComponent,

  ],
  imports: [
    CommonModule,
    AdministrationRoutingModule,
    GlobalModule,
    FormsModule,
    ReactiveFormsModule,
    Ng2SearchPipeModule,
    DragDropModule,
    SharedModule,
    SharedMaterialModule
    // OrganizationmanagementModule,
    // PropertymanagementModule
  ],
  entryComponents: [
    GoeDetailComponent,
    RestricteduseComponent,
    GoeleadersComponent,
    GoeadminComponent,
    // UserModalComponent
    UplaodiconComponent,
    IpaddressComponent,
  ],
  providers:[DispositionService]
})
export class AdministrationModule { }
