import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from "@angular/router";
import { AuthService } from "../../../services/auth.service";
import { PWAService } from "../../../../app/pwa.service";
import { StorageService } from "../../../services/storage.service";
import { Observable, BehaviorSubject } from "rxjs";
import { environment } from "src/environments/environment";
import * as CryptoJS from "crypto-js";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: 'app-sso-login',
  templateUrl: './sso-login.component.html',
  styleUrls: ['./sso-login.component.scss']
})
export class SsoLoginComponent implements OnInit {

  private currentUserSubject: BehaviorSubject<any>;
  public currentUser: Observable<any>;
  private PASSWORD_PRIVATE_KEY: string;

  PropertyId:any;
  UserID:any;
  UserName:any;
  isLoading:any = false;
  previousUrl: string;
  refurl:any = document.referrer;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private auth: AuthService,
    private PWA: PWAService,
    private storage: StorageService,
    private tostre: ToastrService,
  ) {
    this.isLoading = true; 
    this.currentUserSubject = new BehaviorSubject<any>(
      JSON.parse(this.storage.getData("UserData"))
    );
    this.currentUser = this.currentUserSubject.asObservable();
    this.PASSWORD_PRIVATE_KEY = environment.PASSWORD_PRIVATE_KEY;
    
    console.log('refurl:', this.refurl);
  }

  ngOnInit() {    
    let samlToken = this.route.snapshot.queryParams.token;
    let authToken = this.route.snapshot.queryParams.authtoken

    if(samlToken){
      this.ValidateSsoUser(samlToken);
    }else if(authToken){
      let bytes:any;
      let decryptedData:any;
      try {
        bytes = CryptoJS.AES.decrypt(decodeURIComponent(authToken), 'sso-login-post');
        decryptedData = JSON.parse(bytes.toString(CryptoJS.enc.Utf8)); 
        // console.log("decryptedData", decryptedData);
      } catch (error) {
        this.tostre.error("Invalid User.");
        this.isLoading = false;
      }
      
      let param = {
        // DeviceType: decryptedData.DeviceType,
        // Password: decryptedData.Password,
        // UserName: decryptedData.UserName,
        EmailAddress: decryptedData.Email,
        IsSSOUser: decryptedData.IsSSOUser,
        DeviceType: "Web",
      }
      this.UserLogin(param);
    } else{
      this.router.navigate(["/login"]);
      return;
    }   
  }

  // This method is used for get (redirect) method sso login
  ValidateSsoUser(samlToken:any){
    let param = {
      "SAMLResponse": decodeURIComponent(samlToken),
      "request_type": "get",
      "refurl": this.refurl
    }
    this.auth.ValidateSsoUser(param).subscribe((result:any) => {
      if(result.status && result.token){
        let data = result;
        this.UserID = data.UserData[0].UserID;

        this.storage.setData("UserData", JSON.stringify(data.UserData));
        this.storage.setData("token", data.token);
        this.storage.setData("ModulePermission", JSON.stringify(data.permissions));
        this.storage.setSessionData("isLoggedIn", 1);
        this.currentUserSubject.next(data.UserData);
        this.UserID = data.UserData[0].UserID;
        this.UserName = data.UserData[0].FirstName;
        this.PropertyId = data.UserData[0].ProfileID;
        this.storage.setData("PropertyId", this.PropertyId);
        this.storage.setData("UserID", this.UserID);
        this.storage.setData("username", this.UserName);
        this.PWA.pwaSubscribe(this.UserID);

        this.isLoading = false;  
        this.router.navigate(["products/list"]);
        return;        
      }else{
        this.tostre.error("Invalid User.");
        this.isLoading = false;
      }
    })
  }

  // This method is used for post method sso login
  UserLogin(param:any){
    // this.auth.loginUser(param).subscribe((result:any)=>{
    this.auth.SSOUserLogin(param).subscribe((result:any)=>{
      if(result.token){
        let data = result;
        this.UserID = data.UserData[0].UserID;

        this.storage.setData("UserData", JSON.stringify(data.UserData));
        this.storage.setData("token", data.token);
        this.storage.setData("ModulePermission", JSON.stringify(data.permissions));
        this.storage.setSessionData("isLoggedIn", 1);
        this.currentUserSubject.next(data.UserData);
        this.UserID = data.UserData[0].UserID;
        this.UserName = data.UserData[0].FirstName;
        this.PropertyId = data.UserData[0].ProfileID;
        this.storage.setData("PropertyId", this.PropertyId);
        this.storage.setData("UserID", this.UserID);
        this.storage.setData("username", this.UserName);
        this.PWA.pwaSubscribe(this.UserID);
        
        this.isLoading = false;
        this.router.navigate(["products/list"]);
        return;
      }else{
        this.tostre.error("Invalid User.");
        this.isLoading = false;
      }
    })
  }

}
