import { SharedMaterialModule } from "../../../shared/shared-material.module";

export const libsImports = [SharedMaterialModule];
