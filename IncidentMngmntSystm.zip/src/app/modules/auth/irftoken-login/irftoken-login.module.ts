import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import { IRFTokenLoginRoutingModule } from "./irftoken-login-routing.module";
import { irfComponents } from "./exports";
import { libsImports } from "./imports";
import { IRFLoginService } from "./service/irftoken-login.service";
import { HttpClientModule } from "@angular/common/http";
@NgModule({
  declarations: [...irfComponents],
  imports: [
    CommonModule,
    IRFTokenLoginRoutingModule,
    ...libsImports,
    HttpClientModule,
  ],
  providers: [IRFLoginService],
})
export class IRFTokenLoginModule {}
