import { Component, OnInit } from "@angular/core";
import { delay } from "rxjs/internal/operators/delay";

import { map } from "rxjs/internal/operators/map";
import { IRFLoginService } from "../../service/irftoken-login.service";

import { TypeList } from "../../service/Irf-enum";

@Component({
  selector: "app-irflogin",
  templateUrl: "./irflogin.component.html",
  styleUrls: ["./irflogin.component.scss"],
})
export class IRFLoginComponent implements OnInit {
  /** for loading message and flag of loading */
  public message: string;
  public loading: boolean;
  constructor(public irfLOginService: IRFLoginService) {}

  ngOnInit() {
    this.checkTokenExists();
  }

  private checkTokenExists() {
    const token = this.irfLOginService.getRouteQueryParam("access-token");
    /**
     * fallback url of mail login page because of error token and no token same here
     */
    if (!token) {
      /** redirection to MainPage Fallback */
      this.showLoading("redirecting to main Login", true);
      this.refer("login", 4000);
      return;
    } else {
      /** got token  send to verify from server to token is valid or not */
      this.validateToken(token);
    }
  }

  /** load and Refer to Main Page */

  private showLoading(message: string, flag: boolean) {
    this.message = message;
    this.loading = flag;
  }
  /**validate token from server  */

  private validateToken(token: string) {
    /** verify token here */
    this.showLoading("Please wait...", true);
    this.irfLOginService
      .incidentReportLinkVerificatiion({
        "access-token": token,
        deviceType: "Web",
      })
      .pipe(
        map((elem: any) => {
          return (
            ((elem || {}).data || {}).incidentReportLinkVerificatiion || {}
          );
        })
      )
      .subscribe((elem) => {
        //
        // this.refer("login", 2000);
        /** set up token first */
        if (elem.status) {
          this.setUplocalStorageAndSessionStorage(
            "token",
            elem.token,
            TypeList.LOCAL_STORAGE
          );
          this.setUplocalStorageAndSessionStorage(
            "UserData",
            JSON.stringify(elem.userData),
            TypeList.LOCAL_STORAGE
          );
          this.setUplocalStorageAndSessionStorage(
            "loginUser",
            JSON.stringify(elem.userData[0]),
            TypeList.LOCAL_STORAGE
          );
          //** call for get some essential data and save to localstoarge all data */
          this.setRequiredData(elem);
        } else {
          this.showLoading("Login Failed Redirecting to Login page...", true);
          this.refer("login", 1000);
        }
      });
  }

  private refer(path: string, delayNum: number = 0) {
    const refer$ = this.irfLOginService
      .referToMainLogin(path, delayNum)
      .subscribe((elem) => {
        this.showLoading("", false);
        refer$.unsubscribe();
      });
  }

  private setRequiredData(verifiedObject: any) {
    this.irfLOginService
      .setRequiredKeysForIRF({
        moduleId: 4,
        incidentId: verifiedObject.incidentId,
      })
      .subscribe((elem) => {
        /**
         * series vise set the data token will set first
         */

        const permissionData = elem[0]; // profile permissiion for access modules
        const overViewData = elem[1];

        /** set Permissio of Profile in report board in localStorage */
        this.setUplocalStorageAndSessionStorage(
          "reportBoardPermission",
          JSON.stringify(permissionData),
          TypeList.LOCAL_STORAGE
        );
        /** create objet of incident report Ids */
        const {
          PropertyId,
          IncidentCaseId,
          IncidentCaseFileID,
          CaseUserID,
        } = overViewData[0];
        const incidentReportsIds = {
          FieldID: "",
          caseNumber: IncidentCaseId,
          caseUserID: CaseUserID,
          incidentCaseFileID: IncidentCaseFileID,
          incidentID: verifiedObject.incidentId,
          propertyID: PropertyId,
        };
        this.setUplocalStorageAndSessionStorage(
          "IDsforReporttab",
          JSON.stringify(incidentReportsIds),
          TypeList.LOCAL_STORAGE
        );
        this.setUplocalStorageAndSessionStorage(
          "sameWindow",
          "1",
          TypeList.LOCAL_STORAGE
        );
        this.setUplocalStorageAndSessionStorage(
          "isPassUserName",
          "1",
          TypeList.LOCAL_STORAGE
        );
        this.setUplocalStorageAndSessionStorage(
          "isLoggedIn",
          "1",
          TypeList.SESSION_STORAGE
        );
        this.setUplocalStorageAndSessionStorage(
          "UserSelectedPropertyID",
          PropertyId,
          TypeList.LOCAL_STORAGE
        );
      });

    /** all items sets to localstoareg and sessionStorage */
    this.showLoading("Login Successful.", true);
    this.refer("products/incidentreporttabs/overview", 1000);
  }

  /** set to localStorage for incidentId to verify login items */

  private setUplocalStorageAndSessionStorage(keyName, value, type) {
    if (TypeList.LOCAL_STORAGE === type) {
      window.localStorage.setItem(keyName, value);
    } else {
      window.sessionStorage.setItem(keyName, value);
    }
  }
}
