import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IRFLoginComponent } from './irflogin.component';

describe('IRFLoginComponent', () => {
  let component: IRFLoginComponent;
  let fixture: ComponentFixture<IRFLoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IRFLoginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IRFLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
