import { IRFLoginComponent } from "./component/irflogin/irflogin.component";

export const irfComponents = [IRFLoginComponent];

/**
 * export service here
 */

// import { IRFLoginService } from "./service/irftoken-login.service";

// export let IRFLoginServiceList = [IRFLoginService];
