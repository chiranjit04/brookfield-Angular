import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { IRFLoginComponent } from "./component/irflogin/irflogin.component";

const routes: Routes = [
  {
    path: "",
    component: IRFLoginComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class IRFTokenLoginRoutingModule {}
