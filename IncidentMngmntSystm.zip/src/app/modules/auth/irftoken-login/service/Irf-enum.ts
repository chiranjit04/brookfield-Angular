enum TypeList {
  LOCAL_STORAGE,
  SESSION_STORAGE,
}

export { TypeList };
