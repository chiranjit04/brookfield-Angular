import { Injectable } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { HttpClient } from "@angular/common/http";
import { forkJoin, Observable } from "rxjs";
import { from } from "rxjs/internal/observable/from";
import { delay } from "rxjs/internal/operators/delay";
import { map } from "rxjs/internal/operators/map";
import { take } from "rxjs/internal/operators/take";
import { environment } from "src/environments/environment";
import { UserPermissionService } from "src/app/services/user-permission.service";
import { ReportbookServiceService } from "src/app/modules/incidentreportbook/reportbook/reportbook-service.service";

@Injectable()
export class IRFLoginService {
  baseUrl: string = "";
  constructor(
    public route: ActivatedRoute,
    private router: Router,
    private http: HttpClient,
    private userPermission: UserPermissionService,
    private reportBoardService: ReportbookServiceService
  ) {
    this.baseUrl = `${environment.origin}api/`;
  }

  public getRouteQueryParam(keyName: string): string | null {
    const token = this.route.snapshot.queryParams;

    return (token || {}).hasOwnProperty("access-token") ? token[keyName] : null;
  }

  /** re route to login page if not query params shows */

  public referToMainLogin(
    path: string = "/login",
    delayNum: number = 0
  ): Observable<string> {
    const route$ = from(path).pipe(
      delay(delayNum),
      map((elem: string) => {
        this.router.navigate([path]);
        return elem;
      }),
      take(1)
    );

    return route$;
  }

  /** route to incident report board Overvirew Data */

  //   public

  /** hit to URL to get token verification */

  public incidentReportLinkVerificatiion(param: {}): any {
    return this.http.post(
      `${this.baseUrl}IncidentNotifications/incidentReportLinkVerificatiion`,
      param
    );
  }

  public setRequiredKeysForIRF(irfObject) {
    const { moduleId, incidentId } = irfObject;
    const permission = this.userPermission
      .GetUserProfilePermission({
        ModuleIDs: moduleId,
      })
      .pipe(
        map((elem: any) => {
          return elem.ProfilePermissionList;
        })
      );
    const getOverviewIrfData = this.reportBoardService
      .GetCaseFileOverviewData({
        IncidentID: incidentId,
      })
      .pipe(
        map((elem: any) => {
          return elem.data.GetIncidentCaseBoard;
        })
      );

    return forkJoin(permission, getOverviewIrfData);
  }
}
