import { Component, OnInit, Injectable } from "@angular/core";
import { AuthService } from "src/app/services/auth.service";
import { PWAService } from "../../../../app/pwa.service";
import { StorageService } from "../../../services/storage.service";
import { Router } from "@angular/router";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { ToastrService } from "ngx-toastr";
import { Observable, BehaviorSubject } from "rxjs";
import * as CryptoJS from "crypto-js";
import { environment } from "src/environments/environment";
import { ChangepasswordComponent } from "./../../home/product-list/changepassword/changepassword.component";
import { THIS_EXPR } from "@angular/compiler/src/output/output_ast";
import {
  MatDialog,
  MAT_DIALOG_DATA,
  MatDialogRef,
} from "@angular/material/dialog";
import { ForgotComponent } from "./forgot/forgot.component";

@Injectable()
@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.scss"],
})
export class LoginComponent implements OnInit {
  hide = true;

  loginform: FormGroup;
  UserName: string;
  Name: string;
  PropertyId: any;
  UserID: any;
  username: string;
  TFASecretKey: any = true;
  tempSecret: any = false;
  tfaFlag = false;

  GetUserLoginData: any = {};
  platForm: any;
  er = false;
  private currentUserSubject: BehaviorSubject<any>;
  public currentUser: Observable<any>;
  private PASSWORD_PRIVATE_KEY: string;
  // loginUserData: any = {UserName: 'brook', Password: 'password','DeviceID':'WEB'};

  tfa: any = {};
  authcode: string;
  errorMessage: any;
  ipAddress: any = null;

  constructor(
    private AUTH: AuthService,
    private ROUTER: Router,
    private fb: FormBuilder,
    public tostre: ToastrService,
    private PWA: PWAService,
    private storage: StorageService,
    public dialog: MatDialog
  ) {
    this.platForm = environment.isPlatform;
    this.currentUserSubject = new BehaviorSubject<any>(
      JSON.parse(this.storage.getData("UserData"))
    );
    this.currentUser = this.currentUserSubject.asObservable();
    this.PASSWORD_PRIVATE_KEY = environment.PASSWORD_PRIVATE_KEY;
  }

  ngOnInit() {
    this.storage.clearData();
    this.storage.clearSessionData();

    this.AUTH.getIPAddress().subscribe((resp: any) => {
      this.ipAddress = resp["origin"];
      // console.log("IPADDR",  this.ipAddress)
    });
  }

  clearform() { }

  loge(d, c) {
    if (d == 13) {
      //this.loginUser(c);
    }
  }

  loginUser_02042021(t) {
    if (t.UserName == "" || t.Password == "") {
      this.showSuccess();
      this.er = true;
    } else {
      t.DeviceType = "Web";
      // this.ipAddress = '192.168.0.107';
      t.ipaddress = this.ipAddress;

      // t.Password= CryptoJS.AES.encrypt(t.Password, this.PASSWORD_PRIVATE_KEY).toString();
      this.AUTH.loginUser(t).subscribe(
        (res) => {
          if (res.message === "User not found." || res.token === null) {
            this.showInvalid();
            this.ROUTER.navigate(["/login"]);
          } else {
            this.UserID = res.UserData[0].UserID;
            /* this.storage.setData("UserData", JSON.stringify(res.UserData));
            this.storage.setData("token", res.token);
            this.storage.setData("ModulePermission", JSON.stringify(res.permissions));
            this.storage.setSessionData("isLoggedIn", 1);
            this.currentUserSubject.next(res.UserData);
            this.UserID = res.UserData[0].UserID;
            this.UserName = res.UserData[0].FirstName;
            this.PropertyId = res.UserData[0].ProfileID;
            this.storage.setData("PropertyId", this.PropertyId);
            this.storage.setData("UserID", this.UserID);
            this.storage.setData("username", this.UserName);
            this.PWA.pwaSubscribe(this.UserID); */
            // this.ROUTER.navigate(["products/list"]);

            // if(res.UserData[0].GroupTypeID == 1){
            //   this.UpdateAuth(res);
            // }
            /* Check TFA is not enabled then setup TFA for user group 2 else validate by TFA code  */
            /* if(res.UserData[0].GroupTypeID == 2){
              this.TFASecretKey = res.UserData[0].TFASecretKey;
              if(!res.UserData[0].TFASecretKey){
                this.AUTH.setupAuth({uname:t.UserName}).subscribe((result:any)=>{
                  this.tfa = result;
                  this.tempSecret = result.tempSecret;
                });
              }else{
                this.tfaFlag = true;
                this.tempSecret = this.TFASecretKey;
              }
              this.GetUserLoginData = res;
            } */

            // if(res.UserData[0].GroupTypeID == 3){
            //   this.GetUserLoginData = res;
            //   this.verifyWhiteList(res.UserData[0].UserID, res.ipaddress);
            //   // this.UpdateAuth(res);
            // }

            this.GetUserLoginData = res;

            this.AUTH.verifyWhiteList({
              UserID: this.UserID,
              IPAddress: this.ipAddress,
            }).subscribe((resp: any) => {
              if (resp.isWhiteListIP == 1) {
                this.UpdateAuth(this.GetUserLoginData);
              } else {
                //res.UserData[0].IsAllow2F = true;
                if (res.UserData[0].IsAllow2F) {
                  this.TFASecretKey = res.UserData[0].TFASecretKey;
                  if (!res.UserData[0].TFASecretKey) {
                    this.AUTH.setupAuth({ uname: t.UserName }).subscribe(
                      (result: any) => {
                        this.tfa = result;
                        this.tempSecret = result.tempSecret;
                      }
                    );
                  } else {
                    this.tfaFlag = true;
                    this.tempSecret = this.TFASecretKey;
                  }
                } else {
                  this.tostre.error("You are attempting to login from an unauthorized location. Please contact support.", "", {
                    positionClass: "toast-bottom-right",
                  });
                  //this.showInvalid();
                }
              }
            });
          }
        },
        (err) => console.log(err)
      );
    }
  }

  loginUser(t) {
    if (t.UserName == "" || t.Password == "") {
      this.showSuccess();
      this.er = true;
    } else {
      t.DeviceType = "Web";
      t.ipaddress = this.ipAddress;

      this.AUTH.loginUser(t).subscribe((res: any) => {
        if (res.message === "User not found." || res.token === null) {
          this.showInvalid();
          this.ROUTER.navigate(["/login"]);
        } else {
          this.UserID = res.UserData[0].UserID;
          this.GetUserLoginData = res;

          if (res.machineinfo == 1) {
            this.UpdateAuth(this.GetUserLoginData);
          } else {
            if (res.UserData[0].IsAllow2F) {
              this.TFASecretKey = res.UserData[0].TFASecretKey;
              if (!res.UserData[0].TFASecretKey) {
                this.AUTH.setupAuth({ uname: t.UserName }).subscribe(
                  (result: any) => {
                    this.tfa = result;
                    this.tempSecret = result.tempSecret;
                  }
                );
              } else {
                this.tfaFlag = true;
                this.tempSecret = this.TFASecretKey;
              }
            } else {
              this.tostre.error("You are attempting to login from an unauthorized location. Please contact support.", "", {
                positionClass: "toast-bottom-right",
              });
            }
          }
        }
      }, (err) => console.log(err));
    }
  }

  showSuccess() {
    this.tostre.warning("Username and Password required.", "", {
      positionClass: "toast-bottom-right",
    });
  }

  showInvalid() {
    this.tostre.error("Username or password is not valid.", "", {
      positionClass: "toast-bottom-right",
    });
  }

  verifyTFA() {
    let param = {
      UserID: this.UserID,
      token: this.authcode,
      tempSecret: this.tempSecret,
    };
    this.AUTH.verifyAuth(param).subscribe((data: any) => {
      const result = data;
      if (result["status"] === 200) {
        this.errorMessage = null;
        this.tfa.secret = this.tfa.tempSecret;
        this.tfa.tempSecret = "";
        this.UpdateAuth(this.GetUserLoginData);
        // this.ROUTER.navigate(["products/list"]);
      } else {
        this.errorMessage = result["message"];
      }
    });
  }

  disabledTFA() {
    this.AUTH.deleteAuth().subscribe((data: any) => {
      const result = data.body;
      if (data["status"] === 200) {
        console.log(result);
        this.authcode = "";
        // this.getAuthDetails();
      }
    });
  }

  UpdateAuth(data: any) {
    /**
     * for password expiration check
     */

    if (!Number.isInteger(data.UserData[0].RemainingDays)) {
      // this.tostre.warning("Password Expired contact to your admin", "", {
      //   positionClass: "toast-top-right",
      // });
      // return;
    } else {
      if (Number.isInteger(data.UserData[0].RemainingDays)) {
        if (data.UserData[0].RemainingDays <= 0) {
          // this.tostre.warning("Password Expired contact to your admin", "", {
          //   positionClass: "toast-top-right",
          // });
          // return;
        }
        // this.tostre.warning(
        //   data.UserData[0].RemainingDays +
        //   " Remaining days left in expiration of password.",
        //   "",
        //   {
        //     positionClass: "toast-top-right",
        //   }
        // );
      }
    }
    this.storage.setData("UserData", JSON.stringify(data.UserData));
    this.storage.setData("token", data.token);
    this.storage.setData("ModulePermission", JSON.stringify(data.permissions));
    this.storage.setSessionData("isLoggedIn", 1);
    this.currentUserSubject.next(data.UserData);
    this.UserID = data.UserData[0].UserID;
    this.UserName = data.UserData[0].FirstName;
    this.PropertyId = data.UserData[0].ProfileID;
    this.storage.setData("PropertyId", this.PropertyId);
    this.storage.setData("UserID", this.UserID);
    this.storage.setData("username", this.UserName);
    this.PWA.pwaSubscribe(this.UserID);
    this.storage.setSessionData("isSameWindow", 1);
    this.ROUTER.navigate(["products/list"]);
    if (Number.isInteger(data.UserData[0].RemainingDays)) {
      if (data.UserData[0].RemainingDays <= 0) {
        this.checkUserLoggedInFirstTime();
        this.tostre.warning("Your Password has been expire, please Change your Password.", "", {
          positionClass: "toast-top-right",
        });
        // return;
      } else {
        this.tostre.warning(
          data.UserData[0].RemainingDays +
          " Remaining days left in expiration of password.",
          "",
          {
            positionClass: "toast-top-right",
          }
        );
      }
    }

    /* this.AUTH.updateLoginTypeRegistry({ UserID: this.UserID, MACAddress: "", LoginType: "Login"}).subscribe((elem) => {
      console.log(elem);
    }); */
  }

  /* verifyWhiteList(UserID:number, ipaddress:string){
    this.AUTH.verifyWhiteList({"UserID":UserID,"IPAddress": ipaddress}).subscribe((resp:any) => {
        if(resp.isWhiteListIP == 1){
          this.UpdateAuth(this.GetUserLoginData);
        }else{
          this.tostre.error("You don't have white list IP. Please contact to Administration.", "", {
            positionClass: "toast-bottom-right",
          });
        }
    });
  } */
  checkUserLoggedInFirstTime() {
    const dialogRef = this.dialog.open(ChangepasswordComponent, {
      width: "30%",
      maxWidth: "60vw",
      disableClose: true,
      data: true,
    });
  }
  forgotPwd(event: any) {
    event.preventDefault();
    const dialogRef = this.dialog.open(ForgotComponent, {
      width: "30%",
      maxWidth: "100vw",
      disableClose: true,
      autoFocus: false,
    });

    // dialogRef.afterClosed().subscribe((result) => {
    //   console.log(`Dialog result: ${result}`);
    // });
  }
}
