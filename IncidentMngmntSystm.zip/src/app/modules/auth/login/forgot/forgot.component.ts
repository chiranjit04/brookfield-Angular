import { Component, OnInit, Inject, Optional } from "@angular/core";
import { FormBuilder, FormControl, FormGroup, Validators } from "@angular/forms";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { ToastrService } from "ngx-toastr";
import { AuthService } from "src/app/services/auth.service";

@Component({
  selector: 'app-forgot',
  templateUrl: './forgot.component.html',
  styleUrls: ['./forgot.component.scss']
})
export class ForgotComponent implements OnInit {

  forgotForm: FormGroup;
  submitted:any = false;
  success: any = '';
  
  constructor(
    public dialogRef: MatDialogRef<ForgotComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: any,
    private formBuilder: FormBuilder,
    private auth: AuthService,
    public tostre: ToastrService,
    ) { }

  ngOnInit() {
    this.forgotForm = this.formBuilder.group({
      UserName: new FormControl('', [Validators.required]),
      Email: new FormControl('', [Validators.required, Validators.email])
    });
  }

  get forgotFormF() { return this.forgotForm.controls; }

  close(){
    this.dialogRef.close(true);
  }

  onSubmit(){
    this.submitted = true;

    if(this.forgotForm.invalid){
      return;
    }

    let formdata = this.forgotForm.value;    
    this.auth.forgotPwd(formdata).subscribe((result:any)=>{
      // console.log(result);      
      if(result.status == true){
        this.tostre.success(result.message)
        this.forgotForm.reset();
        this.dialogRef.close(true);
      }else{
        this.tostre.error(result.message)
      }
      this.submitted = false;      
    })
  }

}
