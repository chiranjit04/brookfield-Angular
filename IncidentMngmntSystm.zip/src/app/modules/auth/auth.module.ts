import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './login/login.component';
import { GlobalModule } from '../global/global.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ForgotComponent } from './login/forgot/forgot.component';
import { SsoLoginComponent } from './sso-login/sso-login.component';
import { SharedMaterialModule } from '../../shared/shared-material.module';
@NgModule({
  declarations: [
    LoginComponent,
    ForgotComponent,
    SsoLoginComponent,    
  ],
  imports: [
    CommonModule, 
    GlobalModule, 
    FormsModule,
    ReactiveFormsModule,
    SharedMaterialModule,
  ],
  exports: [
    LoginComponent
  ],
  providers:[
    LoginComponent
  ],
  entryComponents:[
    ForgotComponent
  ]
})
export class AuthModule {}
