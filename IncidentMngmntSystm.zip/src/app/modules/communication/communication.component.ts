import { Component, OnInit } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { ToastrService } from "ngx-toastr";
import { of } from "rxjs/internal/observable/of";
import { map } from "rxjs/internal/operators/map";
import { switchMap } from "rxjs/internal/operators/switchMap";
import { retry } from "rxjs/operators";
import { UserPermissionService } from "src/app/services/user-permission.service";

import {
  RouteCheckLevelOne,
  modelOfRoute,
  checkExistsAccordingToPermission,
} from "./route-check";
@Component({
  selector: "app-communication",
  templateUrl: "./communication.component.html",
  styleUrls: ["./communication.component.scss"],
})
export class CommunicationComponent implements OnInit {
  constructor(
    private router: Router,
    private readonly toasterService: ToastrService,
    private readonly UserPermission: UserPermissionService,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {}
  ngAfterViewInit() {
    const routeCheck = RouteCheckLevelOne();
    routeCheck
      .pipe(
        map((elem) => {
          const checkUserPermission = localStorage.getItem(
            "UserPermissionData"
          );

          if (checkUserPermission) {
            return { isPermissionExists: true, route: elem };
          } else {
            return { isPermissionExists: true, route: elem };
          }
        }),
        switchMap((element: any) => {
          if (element.isPermissionExists) {
            return this.UserPermission.GetUserProfilePermission({
              ModuleIDs: "5",
            }).pipe(
              map((elem: any) => {
                return {
                  ProfilePermissionList: elem.ProfilePermissionList,
                  route: element,
                };
              })
            );
          } else {
            return of({ forward: true, route: element });
          }
        }),
        map((elem: any) => {
          console.log("call twice");
          if (elem.hasOwnProperty("forward")) {
            return elem;
          } else {
            localStorage.setItem(
              "UserPermissionData",
              JSON.stringify(elem.ProfilePermissionList)
            );
            /**
             * re check that
             */
            const modulePermission = window.localStorage.getItem(
              "UserPermissionData"
            );

            if (!modulePermission) {
              return {
                name: "products/list",
                module: false,
                accessible: false,
              };
            }

            /** now operate module json extracts */

            const parsedModulePermissions = JSON.parse(modulePermission);

            if ((parsedModulePermissions[0] || {}).ModuleID !== 5) {
              return {
                name: "products/list",
                module: false,
                accessible: false,
              };
            }

            const accessibleRoute = modelOfRoute.find((module) => {
              if (
                checkExistsAccordingToPermission(
                  module.permission,
                  parsedModulePermissions
                )
              ) {
                return true;
              }
            });

            /** matched routed modules as string route name */

            if (!accessibleRoute) {
              return {
                name: "products/list",
                module: true,
                accessible: false,
              };
            }

            return {
              name: accessibleRoute.name,
              module: true,
              accessible: true,
            };
            /*** */
            // return elem;
          }
        })
        // map((elem: any) => {
        //   debugger;
        //   return elem.route || {};
        // }),
      )
      .subscribe((routeChecks: any) => {
        console.log("check ones", routeChecks);
        if (!routeChecks.accessible && routeChecks.module) {
          this.router.navigate(["products/list"]);
          /**
           * toaster need to @Inject into another dependency into module
           */
          this.toasterService.warning("You don't have permission.", "", {
            positionClass: "toast-top-right",
          });
        } else if (routeChecks.name === "products/list") {
          // this.router.navigate([routeChecks.route.name], {
          //   relativeTo: this.route,
          // });
          // this.router.navigate(["products/communication"]);
          this.router.navigate(["products/communication/" + routeChecks.name]);
        } else {
          this.router.navigate(["products/communication/" + routeChecks.name]);
        }
        // routesCheckOneTime$.unsubscribe();
      });
  }
}
