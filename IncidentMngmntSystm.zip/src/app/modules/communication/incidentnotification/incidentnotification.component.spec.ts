import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IncidentnotificationComponent } from './incidentnotification.component';

describe('IncidentnotificationComponent', () => {
  let component: IncidentnotificationComponent;
  let fixture: ComponentFixture<IncidentnotificationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IncidentnotificationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IncidentnotificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
