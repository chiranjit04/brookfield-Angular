import { Component, OnInit, ViewChild } from "@angular/core";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { NotificationserviceService } from "../notificationservice.service";
import { MatDatepickerInputEvent } from "@angular/material/datepicker";
import { FormControl } from '@angular/forms';

export interface PeriodicElement {
  column1: string;
  column2: string;
  column3: string;
  column4: string;
  column5: string;
  column6: string;
  column7: string;
  column8: string;
  column9: string;
  column10: string;
}

@Component({
  selector: "app-sentregister",
  templateUrl: "./sentregister.component.html",
  styleUrls: ["./sentregister.component.scss"],
})
export class SentregisterComponent implements OnInit {
  registeryTableDetails: any = [];

  //Date Variables
  ToDate: any;
  FromDate: any;
  searchProperty: any;
  startDate = new FormControl(new Date());
  endDate = new FormControl(new Date());

  displayedColumns: string[] = [
    "SentDateTime",
    "UserName",
    "JobTitle",
    "UserID",
    "CompanyName",
    "RecipientPropertyName",
    "RecipientPropertyID",
    "IncidentSubjectName",
    "LogRecordNumber",
    "IncidentReportFileNumber",
    "IncidentNotificationTitle",
    "IncidentNotificationID",
  ];
  dataSource: MatTableDataSource<any>;
  searchLog: any;

  @ViewChild(MatSort, { static: false }) sort: MatSort;

  constructor(public NotificationserviceService: NotificationserviceService) {
    console.log(this.startDate.value + ' ' + this.endDate.value);
    this.FromDate = this.startDate.value;
    this.ToDate = this.endDate.value;
  }

  ngOnInit() {
    // this.dataSource.sort = this.sort;
    this.dataSource = new MatTableDataSource([])
    //this.GetIncidentNotificationSentRegistry();
    this.initContent();
  }

  initContent() {
    let currentDate = new Date();
    let month = currentDate.getMonth() + 1;
    let day = currentDate.getDate();
    let year = currentDate.getFullYear();
    this.FromDate = month + "/" + day + "/" + year + " 00:00:00";


    this.ToDate = month + "/" + day + "/" + year + " 23:59:59";;

    this.GetIncidentNotificationSentRegistry();
  }

  GetIncidentNotificationSentRegistry() {
    let data = {
      UserID: 0,
      LogRecordNumber: null,
      IncidentReportFileNumber: null,
      PropertyID: null,
      FromDate: this.FromDate,
      ToDate: this.ToDate,
    };
    this.NotificationserviceService.GetIncidentNotificationSentRegistry(
      data
    ).subscribe((data) => {
      console.log(
        "Sent registery details",
        data.data.getIncidentNotificationSentRegistry
      );
      this.registeryTableDetails =
        data.data.getIncidentNotificationSentRegistry;
      this.updateTable();
      this.dataSource = new MatTableDataSource(this.registeryTableDetails);
      this.dataSource.sort = this.sort;
      this.sort.disableClear = true;
    });
  }

  applyFilter(filterValue: any) {
    this.dataSource.filterPredicate = function (data, filter: string): boolean {
      let boo = false
      if (data.UserID != null && data.RecipientPropertyID != null && data.RecipientPropertyName != null) {
        boo = data.UserID.includes(filter) || data.RecipientPropertyID.includes(filter) || data.RecipientPropertyName.toLowerCase().includes(filter)
      }
      return boo
    };
    console.log(filterValue)
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
    console.log(filterValue)
    this.dataSource.filter = filterValue;
  }

  FilterToUser(event) {
    this.dataSource.filterPredicate = function (data, filter: string): boolean {
      let boo = false
      if (data.UserID != null) {
        boo = data.UserID.includes(filter)
      }
      return boo
    };
    let filterValue = event;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }


  LogNumberFilter(event) {
    this.dataSource.filterPredicate = (data: any, filter: string) =>
      data.LogRecordNumber.indexOf(filter) != -1;
    let filterValue = event;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  ReportFileNumberFilter(event) {
    this.dataSource.filterPredicate = (data: any, filter: string) => {
      let r =
        (!data.IncidentReportFileNumber
          ? ""
          : data.IncidentReportFileNumber
        ).indexOf(filter) != -1;

      return r;
    };

    let filterValue = event;

    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  fromDate(type: string, event: MatDatepickerInputEvent<Date>) {
    let month = event.value.getMonth() + 1;
    let day = event.value.getDate();
    let year = event.value.getFullYear();
    // console.log("date converted", "0" + month + "/" + day + "/" + year);
    this.FromDate = month + "/" + day + "/" + year + " 00:00:00";
    if (!this.ToDate) {
    } else {
      this.GetIncidentNotificationSentRegistry();
    }
  }

  toDate(type: string, event: MatDatepickerInputEvent<Date>) {
    let month = event.value.getMonth() + 1;
    let day = event.value.getDate();
    let year = event.value.getFullYear();
    this.ToDate = month + "/" + day + "/" + year + " 23:59:59";
    if (!this.FromDate) {
    } else {
      this.GetIncidentNotificationSentRegistry();
    }
  }

  updateTable() {
    // let myTable = this.registeryTableDetails.filter(
    //   (m) => {
    //     let itrDate: any = new Date((m.SentDateTime || "").split(" ")[0]);

    //     if (itrDate >= this.FromDate && itrDate <= this.ToDate) {
    //       return true;
    //     }
    //   }
    //   // new Date(m.SentDateTime.split(" ")[0]) >= new Date(this.FromDate) &&
    //   // new Date(m.SentDateTime.split(" ")[0]) <= new Date(this.ToDate)
    // );
    // console.log(this.FromDate)
    // this.dataSource = new MatTableDataSource(myTable);
    // this.dataSource.sort = this.sort;
  }
}
