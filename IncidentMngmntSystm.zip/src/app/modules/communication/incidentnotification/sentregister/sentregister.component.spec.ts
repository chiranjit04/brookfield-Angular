import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SentregisterComponent } from './sentregister.component';

describe('SentregisterComponent', () => {
  let component: SentregisterComponent;
  let fixture: ComponentFixture<SentregisterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SentregisterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SentregisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
