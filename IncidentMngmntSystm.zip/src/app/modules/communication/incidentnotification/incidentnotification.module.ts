import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { IncidentnotificationRoutingModule } from "./incidentnotification-routing.module";
import { IncidentnotificationComponent } from "./incidentnotification.component";
import { CreatemanageComponent } from "./createmanage/createmanage.component";
import { SentregisterComponent } from "./sentregister/sentregister.component";

import { Ng2SearchPipeModule } from "ng2-search-filter";
import { ShowingTriggerListComponent } from "./showing-trigger-list/showing-trigger-list.component";
import { ShowPersonComponent } from "./show-person/show-person.component";

import { AddnotificationComponent } from "./addnotification/addnotification.component";
import { IncidenttriggerComponent } from "./addnotification/incidenttrigger/incidenttrigger.component";
import { SpecifyrecipientComponent } from "./addnotification/specifyrecipient/specifyrecipient.component";
import { SharedMaterialModule } from "../../../shared/shared-material.module";

@NgModule({
  declarations: [
    AddnotificationComponent,
    IncidentnotificationComponent,
    CreatemanageComponent,
    SentregisterComponent,
    ShowingTriggerListComponent,
    ShowPersonComponent,
    SpecifyrecipientComponent,
    IncidenttriggerComponent
  ],
  imports: [
    CommonModule,
    IncidentnotificationRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    Ng2SearchPipeModule,
    SharedMaterialModule,
  ],
  entryComponents: [ShowingTriggerListComponent, ShowPersonComponent],
})
export class IncidentnotificationModule { }
