import { Component, OnInit } from "@angular/core";
import { NotificationserviceService } from "../notificationservice.service";

@Component({
  selector: "app-show-person",
  templateUrl: "./show-person.component.html",
  styleUrls: ["./show-person.component.scss"],
})
export class ShowPersonComponent implements OnInit {
  IncidentNotificationID: any;
  selectedPerson: any = [];

  constructor(public NotificationserviceService: NotificationserviceService) {}

  ngOnInit() {
    this.GetSendToUserByIncidentNotificationID();
  }

  GetSendToUserByIncidentNotificationID() {
    console.log("Id coming or not", this.IncidentNotificationID);
    this.NotificationserviceService.GetSendToUserByIncidentNotificationID(
      this.IncidentNotificationID
    ).subscribe((data) => {
      console.log("All the Users", data);
      this.selectedPerson = data.data.getSendToUserByIncidentNotificationID;
    });
  }
}
