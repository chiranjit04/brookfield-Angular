import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IncidenttriggerComponent } from './incidenttrigger.component';

describe('IncidenttriggerComponent', () => {
  let component: IncidenttriggerComponent;
  let fixture: ComponentFixture<IncidenttriggerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IncidenttriggerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IncidenttriggerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
