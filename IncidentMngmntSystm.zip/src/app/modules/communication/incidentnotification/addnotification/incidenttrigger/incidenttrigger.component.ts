import {
  Component,
  OnInit,
  Output,
  EventEmitter,
  Input,
  ViewChild,
} from "@angular/core";
import { NotificationserviceService } from "../../notificationservice.service";
import { ActivatedRoute, Router } from "@angular/router";
import {
  FormBuilder,
  FormGroup,
  FormControl,
  Validators,
} from "@angular/forms";

import { startWith, map } from "rxjs/operators";
import { MatRadioChange } from "@angular/material";
import { StorageService } from "../../../../../services/storage.service";
import { ToastrService } from "ngx-toastr";
@Component({
  selector: "app-incidenttrigger",
  templateUrl: "./incidenttrigger.component.html",
  styleUrls: ["./incidenttrigger.component.scss"],
})
export class IncidenttriggerComponent implements OnInit {
  //Global Variables
  GlobalEnvironmentDetails = null;
  GlobalEnvironmentID = 0;
  GlobalEnvironmentName = "";
  GOENumber = "";
  userData = null;
  currentUserID: any;
  IncidentNotificationID: any;

  isDisabled: any;
  waitForSaveBtn: boolean = false;
  //Local Variables and arrays
  triggerIncomingList: any = [];
  QueryList: any = [];
  savedTriggers: any = [];
  ISCITypeList: any = [];
  ISCICategoryList: any = [];
  ISCISubjectList: any = [];
  finalSubjectList: any = [];
  finalQueryList: any = [];
  streets: any = [];
  queryListOnSubmit: any = [];
  subjectListOnSubmit: any = [];
  selectIncomingTrigger: any = false;
  selecteCategoryItem: any = false;
  selectedSubjectItem: any = false;
  selectedFinalSubjectItem: any = false;
  selectedFinalSubjectItemValue: any;
  selectedFinalQueryItem: any = false;
  selectedFinalQueryItemValue: any;
  selectedNotification: any;
  filteredTypeList: any;
  filteredStreets: any;
  subjectValue: any;
  selectedQueryItem: any = null;
  selectedQueryItemValue: any;
  IsEditable: any;
  IsAdvanced: any;
  IncidentTypeID: any;
  selectedTypeID: any;
  incomingEditableValues: any;
  bindingRadio: any;
  isAllowIRFRadio: any;
  IncidentCategoryIDs: any;
  test: any = false;
  testSUbjects: any = false;
  testCategory: any = false;
  showIncidentCross: any = false;
  disableAllowIRF: boolean = false;
  //Local Storage Variable
  checkingName: any;

  //FormGroup
  NameandDescriptionForm: FormGroup;

  //Form Controls
  ISCITypeListControl: any = new FormControl();

  @ViewChild("tabMatGroup", { static: false }) tabSelection;
  editEvent: boolean = false;

  constructor(
    public NotificationserviceService: NotificationserviceService,
    private formBuilder: FormBuilder,
    private _Activatedroute: ActivatedRoute,
    private route: Router,
    private storage: StorageService,
    private toaster: ToastrService
  ) {
    this.GlobalEnvironmentDetails = JSON.parse(
      this.storage.getData("GlobalEnvironmentDetails")
    );
    if (this.GlobalEnvironmentDetails) {
      //this.groupData = this.organise(this.exportreport);
      // this.GlobalEnvironmentID = this.GlobalEnvironmentDetails.GlobalEnvironmentId;
      this.GlobalEnvironmentName = this.GlobalEnvironmentDetails.GlobalEnvironmentName;
      this.GOENumber = this.GlobalEnvironmentDetails.GOENo;
    }
    this.userData = JSON.parse(this.storage.getData("UserData"));
    this.currentUserID = this.userData[0].UserID;
    this._Activatedroute.paramMap.subscribe((params) => {
      this.IncidentNotificationID = params.get("id");
    });
    if (this.IncidentNotificationID == 0) {
      this.NotificationserviceService.changeMessage(0);
    }
    this.NotificationserviceService.currentGOE.subscribe((data) => {
      this.GlobalEnvironmentID = data;
    });
    this.GetIncidentTriggerList();
  }
  @Input() set saveEvent(event) {
    // console.log("form all save event");

    // console.log(event);
    if (event) {
      this.onSave(true);
    }
  }

  @Input() set editEventSave(event) {
    if (event) {
      this.onSave(false);
    }

  }


  ngOnInit() {
    this.getSubjectListAll();
    this.NameandDescriptionForm = this.formBuilder.group({
      Title: new FormControl("", [Validators.max(100), Validators.min(0)]),
      Description: new FormControl(""),
    });

    this.GetISCITypeList();
    this.GetNotificationQueriesList();
    this.getEditableData();
    this.route.routerState.root.queryParams.subscribe((params) => {
      // Defaults to 0 if no query param provided.
      console.log("Green Tea", params);
      if (params.isDisabled == "true") {
        this.isDisabled = true;
      } else {
        this.isDisabled = false;
      }
    });
  }
  ngAfterViewInit(): void {
    //Called after ngAfterContentInit when the component's view has been initialized. Applies to components only.
    //Add 'implements AfterViewInit' to the class.
    // this.getSubjectListAll();
  }
  getSubjectListAll() {
    let gId = JSON.parse(
      !this.storage.getData("_notify_")
        ? "{}"
        : this.storage.getData("_notify_")
    );

    this.NotificationserviceService.GetIncidentSubjectNF({
      GlobalEnvironmentID: gId.GlobalEnvironmentID,
    }).subscribe((elem) => {
      let d = elem.data.GetSubjectListNF;

      this.ISCISubjectList = d;
    });
  }
  getEditableData() {
    if (this.IncidentNotificationID != 0) {
      this.NotificationserviceService.onNotificationEdit(
        this.IncidentNotificationID
      ).subscribe((data) => {
        this.incomingEditableValues = data.data.getIncidentNotificationByID[0];
        this.NameandDescriptionForm.patchValue({
          Title: this.incomingEditableValues.NotificationName,
          Description: this.incomingEditableValues.NotificationDescription,
        });
        this.storage.setData('notificationCreatedBY', this.incomingEditableValues.CreatedByUserID);
        this.bindingRadio = this.incomingEditableValues.IsEditable ? "1" : "0";
        this.isAllowIRFRadio = this.incomingEditableValues.IsSendIRF ? "1" : "0";
        this.IsEditable = this.bindingRadio;
        this.ISCITypeListControl.patchValue(
          this.incomingEditableValues.IncidentType
        );

        this.GetIncidentCategoryList(
          +this.incomingEditableValues.IncidentTypeId
        );
        this.GetIncidentNotificationSubjects();
        this.GetIncidentNotificationsTrigger();
        //
        if (this.incomingEditableValues.IncidentTypeId != null) {
          this.GetIncidentNotificationCategory();
        }
        this.GetIncidentNotificationQueries();
      });
    }
  }

  // **************Binding Existing data********************
  GetIncidentNotificationsTrigger() {
    this.NotificationserviceService.GetIncidentNotificationsTrigger(
      this.IncidentNotificationID
    ).subscribe((data) => {
      this.savedTriggers = data.data.getIncidentNotificationsTrigger.map(
        (data) => {
          let obj = {
            IncidentTriggerID: data.IncidentTriggerID,
            IncidentTriggerName: data.IncidentTriggerName,
          };
          return obj;
        }
      );
      if (this.savedTriggers.some(x => x.IncidentTriggerID == 5)) {
        this.disableAllowIRF = false;
      }
      else {
        this.isAllowIRFRadio = "0";
        this.disableAllowIRF = true;
      }
    });
  }

  GetIncidentNotificationSubjects() {
    this.NotificationserviceService.GetIncidentNotificationSubjects(
      this.IncidentNotificationID
    ).subscribe((data) => {
      console.log(
        "Getting subjects for binding",
        data.data.getIncidentNotificationSubjects
      );
      this.finalSubjectList = data.data.getIncidentNotificationSubjects.map(
        (data) => {
          let obj = {
            ISCICategoryID: data.IncidentSubjectID,
            ISCICategoryName: data.IncidentSubjectName,
          };
          return obj;
        }
      );
      if (this.finalSubjectList.length > 0) {
        this.testSUbjects = true;
        let element = document.getElementById("assigntwo3");
        element.setAttribute("style", "background-color: #fadcaa");
      }
    });
  }

  GetIncidentNotificationCategory() {
    this.NotificationserviceService.GetIncidentNotificationCategory(
      this.IncidentNotificationID
    ).subscribe((data) => {
      let value = data.data.getIncidentNotificationCategory;
      let obj = {
        ISCICategoryID: +value
          .map((data) => data.IncidentCategoryID)
          .toString(),

        ISCICategoryName: value
          .map((data) => data.IncidentCategoryName)
          .toString(),
      };
      this.onISCICategoryClick(obj, obj.ISCICategoryID, event);
    });
  }

  GetIncidentNotificationQueries() {
    this.NotificationserviceService.GetIncidentNotificationQueries(
      this.IncidentNotificationID
    ).subscribe((data) => {
      console.log(
        "Incoming query data",
        data.data.getIncidentNotificationQueries
      );

      this.finalQueryList = data.data.getIncidentNotificationQueries.map(
        (data) => {
          let obj = {
            QueryID: data.IncidentQueryID,
            QueryTitle: data.QueryTitle,
          };
          return obj;
        }
      );

      if (data.data.getIncidentNotificationQueries.length > 0) {
        this.test = true;

        if (this.tabSelection) {
          this.tabSelection.selectedIndex = 1;
        }
        let element = document.getElementById("assigntwo4");
        let timeElem = setInterval(() => {
          if (!element) {
            element = document.getElementById("assigntwo4");
          } else {
            element.setAttribute("style", "background-color: #fadcaa");

            clearInterval(timeElem);
          }
        }, 500);
      }
    });
  }

  //************************************************************ */
  GetIncidentTriggerList() {
    this.NotificationserviceService.GetIncidentTriggerList().subscribe(
      (data) => {
        this.triggerIncomingList = data.data.getIncidentTriggerList;
      }
    );
  }

  GetNotificationQueriesList() {
    this.NotificationserviceService.GetNotificationQueriesList().subscribe(
      (data) => (this.QueryList = data.data.getNotificationQueriesList)
    );
  }

  onTriggerClick(data: any) {
    if (this.finder(data) === true) {
      this.savedTriggers.forEach((e, i) => {
        if (e.IncidentTriggerID === data.IncidentTriggerID)
          return this.savedTriggers.splice(i, 1);
      });
    } else {
      this.savedTriggers.push(data);
    }
    if (this.savedTriggers.some(x => x.IncidentTriggerID == 5)) {
      this.disableAllowIRF = false;
    }
    else {
      this.isAllowIRFRadio = "0";
      this.disableAllowIRF = true;
    }
  }

  finder(item: any) {
    let y =
      this.savedTriggers.find(
        (i) => i.IncidentTriggerID === item.IncidentTriggerID
      ) != undefined
        ? true
        : false;
    return y;
  }

  clearQueryBox() {
    this.finalQueryList = [];
    this.selectedQueryItem = false;
    this.IsAdvanced = 0;
    this.IncidentTypeID = this.selectedTypeID;
  }

  clearSubjectBox() {
    this.ISCITypeListControl.patchValue("");
    this.ISCICategoryList = [];
    this.ISCISubjectList = [];
    this.finalSubjectList = [];
    this.IsAdvanced = 1;
    this.IncidentTypeID = 0;
  }

  // Subject

  GetISCITypeList() {
    this.NotificationserviceService.getISCITypeList(
      this.GlobalEnvironmentID
    ).subscribe((data) => {
      console.log("ISCI Type List", data.data.getIncidentSubjectTypeList);
      this.ISCITypeList = data.data.getIncidentSubjectTypeList;

      for (let i = 0; i < this.ISCITypeList.length; i++) {
        const arr = this.ISCITypeList[i].ISCICategoryName;
        this.streets.push({
          ISCICategoryID: this.ISCITypeList[i].ISCICategoryID,
          ISCICategoryName: this.ISCITypeList[i].ISCICategoryName,
          Level: this.ISCITypeList[i].Level,
          ISCICategoryDescription: this.ISCITypeList[i].ISCICategoryDescription,
          IsActive: this.ISCITypeList[i].IsActive,
          IsAllowDelete: this.ISCITypeList[i].IsAllowDelete,
        });
      }
      this.fiterISCIList();
    });
  }

  fiterISCIList() {
    this.filteredStreets = this.ISCITypeListControl.valueChanges.pipe(
      startWith(""),
      map((val: any) =>
        (val && val.length >= 0 ? this._filter(val) : this.streets))
    );
  }

  _filter(val: any): any[] {
    return this.streets
      .map((x) => x)
      .filter((option) =>
        option.ISCICategoryName.toLowerCase().includes(val)
      );
  }

  changeISCITypeList(ISCICategoryID: any, event) {
    if (!event.isUserInput) return;
    this.showIncidentCross = true;
    this.selecteCategoryItem = false;
    this.selectedSubjectItem = false;
    this.selectedTypeID = ISCICategoryID;
    this.GetIncidentCategoryList(ISCICategoryID);
  }

  onIncidentClear() {
    this.showIncidentCross = false;
    this.ISCITypeListControl.patchValue("");
    this.ISCICategoryList = [];
    this.ISCISubjectList = [];
    this.getSubjectListAll();
  }

  GetIncidentCategoryList(ISCICategoryID: any) {
    let data = {
      GlobalEnvironmentID: this.GlobalEnvironmentID,
      ParentID: ISCICategoryID,
    };
    this.NotificationserviceService.GetIncidentCategoryList(data).subscribe(
      (data) => {
        this.ISCICategoryList = data.data.getIncidentSubjectCategoryList;
      }
    );
  }

  onISCICategoryClick(data: any, ISCICategoryID: any, event) {
    this.test = false;
    this.testCategory = true;
    this.IncidentCategoryIDs = data.ISCICategoryID;
    this.selecteCategoryItem = ISCICategoryID;
    this.selectedSubjectItem = false;
    this.GetIncidentSubjectList(ISCICategoryID);
  }

  GetIncidentSubjectList(ISCICategoryID: any) {
    let data = {
      GlobalEnvironmentID: this.GlobalEnvironmentID,
      ParentID: ISCICategoryID,
    };
    this.NotificationserviceService.GetIncidentSubjectList(data).subscribe(
      (data) => {
        this.ISCISubjectList = data.data.getIncidentSubjectList;
        // this.showSelected();
      }
    );
  }

  /**
   *
   */
  showSelected() {
    this.finalSubjectList.forEach((elem) => {
      this.setFlag(elem);
    });
  }

  setFlag(obj) {
    this.ISCISubjectList.forEach((elem) => {
      if (elem.ISCICategoryID == obj.ISCICategoryID) {
        elem.selected = true;
      }
    });
  }
  /**
   *
   */
  onISCISubjectClick(data: any, ISCICategoryID: any) {
    this.selectedSubjectItem = ISCICategoryID;
    this.subjectValue = data;
  }

  onFinalSubjectClick(data: any, ISCICategoryID: any) {
    this.selectedFinalSubjectItem = ISCICategoryID;
    this.selectedFinalSubjectItemValue = data;
  }

  onAddSubject() {
    if (!this.selectedSubjectItem) {
      // Swal.fire("Please select a Subject to add");
      this.toaster.warning("Please select a Subject to add");
      return;
    }
    let element = document.getElementById("assigntwo3");
    element.setAttribute("style", "background-color: #fadcaa");
    this.clearQueryBox();

    let value = this.subjectValue;
    //
    console.log("Value One", value);
    if (
      this.finalSubjectList.find(
        (data: any) => data.ISCICategoryName == value.ISCICategoryName
      )
    ) {
      // Swal.fire(`${value.ISCICategoryName} is already added`);
      this.toaster.warning(`${value.ISCICategoryName} is already added`);
    } else {
      this.finalSubjectList.push(value);
    }
    this.subjectListOnSubmit = this.finalSubjectList
      .map((data) => data.ISCICategoryID)
      .toString();
  }

  onAddAllSubject() {
    let element = document.getElementById("assigntwo3");
    element.setAttribute("style", "background-color: #fadcaa");
    this.clearQueryBox();
    let idss = new Set(
      this.finalSubjectList.map(({ ISCICategoryID }) => ISCICategoryID)
    );

    let Two = this.ISCISubjectList.filter(
      ({ ISCICategoryID }) => !idss.has(ISCICategoryID)
    );

    if (
      this.finalSubjectList.filter((data) =>
        this.ISCISubjectList.includes(data)
      )
    ) {
      this.finalSubjectList = this.finalSubjectList.concat(Two);
      // Swal.fire("Some Properties already Added");
    } else {
      this.finalSubjectList = this.finalSubjectList.concat(
        this.ISCISubjectList
      );
    }
    this.subjectListOnSubmit = this.finalSubjectList
      .map((data) => data.ISCICategoryID)
      .toString();
  }

  removeSubject() {
    if (this.selectedFinalSubjectItem) {
      let value = this.selectedFinalSubjectItemValue; //id and name
      let index = this.finalSubjectList.indexOf(value);
      this.finalSubjectList.splice(index, 1);
    } else {
      // Swal.fire("Please Select a Subject to Remove");
      this.toaster.warning("Please Select a Subject to Remove");
    }
    this.selectedFinalSubjectItem = null;
    this.subjectListOnSubmit = this.finalSubjectList
      .map((data) => data.ISCICategoryID)
      .toString();
  }

  clearAllSubjects() {
    this.finalSubjectList = [];
    this.subjectListOnSubmit = "";
  }

  //Query**************************************************************

  onQueryItemCLick(data: any, IRCQueryID: any) {
    this.selectedQueryItem = IRCQueryID;
    this.selectedQueryItemValue = data;
  }

  onFinalQueryClick(data: any, IRCQueryID: any) {
    this.selectedFinalQueryItem = IRCQueryID;
    this.selectedFinalQueryItemValue = data;
  }

  onAddQuery() {
    if (this.finalQueryList.length == 1) {
      this.toaster.warning("Only one Incident Query may be selected.");
      return;
    }
    if (!this.selectedQueryItem) {
      // Swal.fire("Please select a Query to add");
      this.toaster.warning("Please select a Query to add");
      return;
    }

    let element = document.getElementById("assigntwo4");
    element.setAttribute("style", "background-color: #fadcaa");
    this.clearSubjectBox();

    let value = this.selectedQueryItemValue;
    console.log("Value One", value);
    if (
      this.finalQueryList.find(
        (data: any) => data.QueryTitle == value.QueryTitle
      )
    ) {
      // Swal.fire(`${value.QueryTitle} is already added`);
      this.toaster.warning(`${value.QueryTitle} is already added`);
    } else {
      this.finalQueryList.push(value);
      console.log("Added values", value);
    }
    //  console.log("lucifier", this.finalQueryList);
    this.queryListOnSubmit = this.finalQueryList
      .map((data) => data.QueryID)
      .toString();
  }

  onAddAllQuery() {
    let element = document.getElementById("assigntwo4");
    element.setAttribute("style", "background-color: #fadcaa");
    this.clearSubjectBox();
    let idss = new Set(this.finalQueryList.map(({ QueryID }) => QueryID));

    let Two = this.QueryList.filter(({ QueryID }) => !idss.has(QueryID));

    if (this.finalQueryList.filter((data) => this.QueryList.includes(data))) {
      this.finalQueryList = this.finalQueryList.concat(Two);
    } else {
      this.finalQueryList = this.finalQueryList.concat(this.QueryList);
    }
    this.queryListOnSubmit = this.finalQueryList
      .map((data) => data.QueryID)
      .toString();
  }

  onRemoveQuery() {
    if (this.selectedFinalQueryItem) {
      let value = this.selectedFinalQueryItemValue; //id and name
      let index = this.finalQueryList.indexOf(value);
      this.finalQueryList.splice(index, 1);
    } else {
      // Swal.fire("Please Select a Query to Remove");
      this.toaster.warning(`Please Select a Query to Remove`);
    }
    this.selectedFinalQueryItem = null;
    this.queryListOnSubmit = this.finalQueryList
      .map((data) => data.QueryID)
      .toString();
  }

  onClearAllQuery() {
    this.finalQueryList = [];
    this.queryListOnSubmit = "";
  }

  //********************************************************************************
  onChange(mrChange: MatRadioChange) {
    console.log("radio chnages with values", mrChange.value);
    // let mrButton: MatRadioButton = mrChange.source;
    this.IsEditable = mrChange.value;
    console.log("ross", this.IsEditable);
  }

  onAllowIRFChange(mrChange: MatRadioChange) {
    this.isAllowIRFRadio = mrChange.value;
    console.log("ross", this.IsEditable);
  }

  onBlurTitle() {
    let formValue = this.NameandDescriptionForm.value;
    this.checkingName = formValue.Title;
    console.log("Hello baby", formValue.Title);
    this.NotificationserviceService.changeTitle(formValue.Title);
    // this.storage.setData("formTitle", formValue.Title);
  }

  //Update and Save **************************************************************
  UpdateIncidentNotifications(flag) {
    let formValue = this.NameandDescriptionForm.value;

    let data = {
      IncidentNotificationID: +this.IncidentNotificationID,
      GlobalEnvironmentID: +this.GlobalEnvironmentID,
      NotificationName: formValue.Title,
      NotificationDescription: formValue.Description,
      IsEditable: +this.IsEditable,
      IsAllowIRF: +this.isAllowIRFRadio,
      IsAdvanced: this.IsAdvanced,
      IncidentTypeID: +this.IncidentTypeID,
      IsActive: 1,
      currentUserId: +this.currentUserID,
    };

    // console.log("data going for update notification Initially", data);
    this.NotificationserviceService.UpdateIncidentNotifications(data).subscribe(
      (data) => {
        console.log(
          "Notification Saved Successfully",
          data.data.updateIncidentNotifications
        );
        let incomingData =
          data.data.updateIncidentNotifications[0].IncidentNotificationID;
        this.storage.setData("IncidentNotificationID", incomingData);
        this.NotificationserviceService.changeMessage(incomingData);
        //
        if (flag)
          this.messageSaveAllFromTigger.emit("fromsave");
        this.toaster.success("Saved Successfully.");
        this.UpdateIncidentNotificationQueries(incomingData);
        this.UpdateIncidentNotificationSubjects(incomingData);
        this.UpdateIncidentNotificationsTrigger(incomingData);
        this.UpdateIncidentNotificationCategory(incomingData);
        setTimeout(() => {
          this.waitForSaveBtn = false;
        }, 700)

      }, () => {
        this.waitForSaveBtn = false;
      }
    );
  }

  UpdateIncidentNotificationQueries(IncidentNotificationID: any) {
    let data = {
      IncidentNotificationID: +IncidentNotificationID,
      IncidentQueryIDs: this.finalQueryList
        .map((elem) => elem.QueryID)
        .toString(),
    };

    console.log("new id here", data);
    this.NotificationserviceService.UpdateIncidentNotificationQueries(
      data
    ).subscribe((data) => console.log("here is query updates", data));
  }

  UpdateIncidentNotificationSubjects(IncidentNotificationID: any) {
    let data = {
      IncidentNotificationID: +IncidentNotificationID,
      // IncidentSubjectIDs: this.subjectListOnSubmit,
      IncidentSubjectIDs: this.finalSubjectList
        .map((data) => data.ISCICategoryID)
        .toString(),
    };

    console.log("new subject here", data);
    this.NotificationserviceService.UpdateIncidentNotificationSubjects(
      data
    ).subscribe((data) => console.log("here is subject updated", data));
  }

  UpdateIncidentNotificationCategory(IncidentNotificationID: any) {
    let data = {
      IncidentNotificationID: +IncidentNotificationID,
      IncidentCategoryIDs: this.IncidentCategoryIDs,
    };
    this.NotificationserviceService.UpdateIncidentNotificationCategory(
      data
    ).subscribe((data) => {
      console.log("Update Category", data);
    });
  }

  UpdateIncidentNotificationsTrigger(IncidentNotificationID: any) {
    let data = {
      IncidentNotificationID: +IncidentNotificationID,
      IncidentTriggerIDs: this.savedTriggers
        .map((data) => data.IncidentTriggerID)
        .toString(),
    };
    console.log("triggers all ids", data);
    this.NotificationserviceService.UpdateIncidentNotificationsTrigger(
      data
    ).subscribe((data) => console.log("here are triggers updated", data));
  }

  onSave(flag: boolean = true) {
    if (!this.storage.getData("flagPointer")) {
      this.toaster.error("Please select Specify Recipient.");
      return;
    }
    let titleToSubmit = this.NameandDescriptionForm.get("Title").value;
    if (titleToSubmit.length <= 0) {
      // Swal.fire("Please fill Incident Notification Title.");
      this.toaster.success("Please fill Incident Notification Title.");
      return;
    }
    this.waitForSaveBtn = true;
    this.UpdateIncidentNotifications(flag);
    // Swal.fire({ text: "Saved Successfully" }).then(() => {
    //   // location.reload();
    // });


  }

  blurInputs(ref: any) {
    ref.blur();
    //this.GetISCITypeList();
  }
  @Output() messageSaveAllFromTigger = new EventEmitter<any>();
  ngOnDestroy(): void {
    this.waitForSaveBtn = false;
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    // if (this.behave$) {
    //   this.behave$.unsubscribe();
    // }
    //
  }
}
