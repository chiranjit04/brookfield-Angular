import { Component, OnInit, ViewChild, ViewContainerRef } from "@angular/core";
import { FormControl } from "@angular/forms";

@Component({
  selector: "app-addnotification",
  templateUrl: "./addnotification.component.html",
  styleUrls: ["./addnotification.component.scss"],
})
export class AddnotificationComponent implements OnInit {
  constructor() { }
  @ViewChild("tabMatGroup", { static: false }) tabSelection;
  fromSpecifyEvent = "";
  fromTiggersEvent = "";
  editEvent: boolean = false;
  ngOnInit() { }

  flag = true;

  receiveMessage(event) {
    console.log("changed");
    //this.tabSelection.selectedIndex = 0;
    this.fromSpecifyEvent = "hello";
  }

  receiveMessageFromSpecify(event) {
    console.log("from specify ");
  }

  receiveMessageFromIncidentTrigger(event) {
    console.log("from tigger ");
    this.fromTiggersEvent = "hello";
  }
  onEditNotificationSave(event) {
    this.editEvent = !this.editEvent;
  }
}
