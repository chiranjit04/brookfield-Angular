import { SpecifyrecipientComponent } from './specifyrecipient/specifyrecipient.component';
import { IncidenttriggerComponent } from './incidenttrigger/incidenttrigger.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AddnotificationComponent } from './addnotification.component';
import { AuthGuard } from "./../../../../guard/auth.guard";

const routes: Routes = [
  { 
    path: '', 
    component: AddnotificationComponent,
    canActivate: [ AuthGuard ],
    children:[
      {path:'', component:IncidenttriggerComponent, redirectTo:'incidenttrigger'},
      {path:'specifyrecipient', component:SpecifyrecipientComponent},
      {path:'incidenttrigger', component:IncidenttriggerComponent},
    ] 
  }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AddnotificationRoutingModule { }
