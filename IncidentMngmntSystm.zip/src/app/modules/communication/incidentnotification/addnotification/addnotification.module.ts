import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { AddnotificationRoutingModule } from "./addnotification-routing.module";
// import { AddnotificationComponent } from './addnotification.component';
import { IncidenttriggerComponent } from "./incidenttrigger/incidenttrigger.component";
// import { SpecifyrecipientComponent } from './specifyrecipient/specifyrecipient.component';
import { AddnotificationComponent } from "./addnotification.component";
import { SpecifyrecipientComponent } from "./specifyrecipient/specifyrecipient.component";
import { SharedMaterialModule } from "../../../../shared/shared-material.module";

@NgModule({
  declarations: [

  ],
  imports: [
    CommonModule,
    AddnotificationRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    SharedMaterialModule,
  ],
  exports: [
    // AddnotificationComponent,
    // IncidenttriggerComponent,
    // SpecifyrecipientComponent
  ],
  // providers: [IncidenttriggerComponent],
})
export class AddnotificationModule { }
