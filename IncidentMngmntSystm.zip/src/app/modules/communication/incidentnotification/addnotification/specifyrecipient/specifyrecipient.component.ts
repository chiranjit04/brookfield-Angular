import {
  Component,
  OnInit,
  ViewChild,
  EventEmitter,
  Output,
  Input,
  Renderer2,
} from "@angular/core";
import { MatCheckboxModule } from "@angular/material/checkbox";
import { JobtitlesService } from "../../../../administration/organizationmanagement/jobtitles/jobtitles.service";
import { InspectionFormsService } from "../../../../inspections/inspectionforms/inspectionforms.service";
import { startWith, map } from "rxjs/operators";
import Swal from "sweetalert2";
import { NotificationserviceService } from "../../notificationservice.service";
import { MatRadioChange } from "@angular/material";
import { ActivatedRoute, Router } from "@angular/router";
import { IncidenttriggerComponent } from "../incidenttrigger/incidenttrigger.component";
import { StorageService } from "../../../../../services/storage.service";
import { ToastrService } from "ngx-toastr";
import {
  FormBuilder,
  FormGroup,
  FormControl,
  Validators,
} from "@angular/forms";
import { Subscription } from "rxjs";

@Component({
  selector: "app-specifyrecipient",
  templateUrl: "./specifyrecipient.component.html",
  styleUrls: ["./specifyrecipient.component.scss"],
})
export class SpecifyrecipientComponent implements OnInit {
  //Radio
  selectingRecipent: number = 0;
  chooseRecipent: any = [
    { "value": 1, "text": "Send To me only" },
    { "value": 2, "text": "Send to me in addition to user specified below" },
  ];
  radioValue: any;
  isDisabled: any = false;
  disableonView: any;
  //Global Variables
  userData = null;
  currentUserID = 0;

  //Local Variables
  flagPointer: boolean = false;
  filteredStreets: any;
  filteredStreetsProperty: any;
  filteredStreetsPosition: any;
  filteredStreetsByPerson: any;
  filterStreetsNew: any;
  filterWorkGroups: any;
  filterWorkGroupsProperty: any;
  filterWorkGroupsByPerson: any;
  filterWorkGroupsNew: any;
  filterJobTitle: any;
  filterUsers: any;
  streets: any[] = [];
  workGroupStreet: any[] = [];
  workGroupStreetProperty: any = [];
  workGroupStreetByPerson: any = [];
  workGroupStreetNew: any[] = [];
  jobTitleStreet: any[] = [];
  companyControl: any = new FormControl();
  companyControlProperty: any = new FormControl();
  companyControlPosition: any = new FormControl();
  companyControlByPerson: any = new FormControl();
  companyControler: any = new FormControl();
  workGroupControl: any = new FormControl();
  workGroupControlProperty: any = new FormControl();
  workGroupControlByPerson: any = new FormControl();
  workGroupControlNew: any = new FormControl();
  jobTitleControl: any = new FormControl();
  UserControl: any = new FormControl();
  jumpControl: any = new FormControl();
  //
  RatingTypeItem: any = [];
  isSelected = false;
  tenStarSelected = false;
  manualSelected = false;
  gradeSelected = false;
  SelectedInspectionFrequencyId = false;
  SelectedJobTitleID = false;
  SelectedUserID = false;
  SelectedPropertyId = false;
  SelectedPropertyIdPosition: any = false;
  SelectedUserByProperty: any = false;
  SelectedWorkgroup: any = false;
  rightSelectedPropertyId: any = false;
  rightSelectedPerson: any = false;
  rightSelectedByPerson: any = false;
  rightSelectedPosition: any = false;
  rightSelectedJobTitleID = false;
  rightSelectedUserId = false;
  percenttoggleRenewed = false;
  SelectedRatingMethod: any = false;
  SelectedRatingOptionOne: any = false;
  SelectedRatingOptionTwo: any = false;
  SelectedRatingOptionThree: any = false;
  SelectedRatingOptionFour: any = false;
  SelectedRatingOptionFive: any = false;
  SelectedRatingOptionSix: any = false;
  permitOption: any = false;
  rightSelected: any;
  OverAll: any = 0;
  IsRatingOverride: any;
  InspectionFormPropertyID: any = 0;
  InspectionTypeId: any;
  InspectionCategotyId: any;
  InspectionFailRateId: any;
  InspectionFormAssignmentID: any = 0;
  totalValCategory: any;
  totalSubValCategory: any;
  totalItemValCategory: any;

  InspectionRatingTypeId: any;
  propertyValue: any;
  jobTitleValue: any;
  workGroupValue: any;
  UserValue: any;
  changedWorkGroupID: any;
  rightPropertyValue: any;
  WorkGroupID: any;

  CategoryID: any;
  companylist: any;
  workGroupList: any;
  workGroupListProperty: any = [];
  workGroupListPosition: any = [];
  workGroupListByPerson: any = [];
  workGroupListNew: any;
  propertyList: any = [];
  propertyListTwo: any = [];
  userList: any = [];
  specifiedPropertyList: any = [];
  specifiedPersonList: any = [];
  specifiedByPersonList: any = [];
  specifiedPositionList: any = [];
  selectedPropertyList: any = [];
  selectedPersonList: any = [];
  selectedByPersonList: any = [];
  selectedPositionList: any = [];
  selectedJobTitle: any = [];
  selectedJobTitleFromTable: any = [];
  selectedUser: any = [];
  InspectionFormTags: any = [];
  jobTitle: any = [];
  userListByPropertyId: any = [];
  jobTitleListByCompanyId: any = [];
  jobTitlePosition: any = [];
  userListByWorkGroup: any = [];
  InspectionAssociationTypeID: any;
  PropertyIDsforSubmit: any;
  JobTitleIDsforSubmit: any;
  UserIDsforSubmit: any;
  WorkGroupforSubmit: any;
  incomingData: any;
  CompanyDetails: any;
  globalEnvId: any;

  selectedFinalJTItems: any = [];
  incomingAssociationType: any = [];
  selectedFinalJT: any = false;
  SelectedJobTitlePosition: any = false;
  selectByPerson: any = false;
  ContitionalElement = false;
  blurWg: any = false;
  blurWgTwo: any = false;
  CompanyID: any;
  IncidentNotificationID: any;
  AssociationTypeID: any;
  anyID: any;
  showCompanyOneCross: any = false;
  showWrkgrpOneCross: any = false;
  showCompanyTwoCross: any = false;
  showCompanyThreeCross: any = false;
  showWrkthreeCross: any = false;
  notificationSubscrition: Subscription;
  currentIncidentNotificationID: any;
  notificationMeUserID: string | number;
  waitForSaveBtn: boolean = false;

  constructor(
    private jobtitlesservice: JobtitlesService,
    private InspectionFormsService: InspectionFormsService,
    public NotificationserviceService: NotificationserviceService,
    private _Activatedroute: ActivatedRoute,
    private route: Router,
    private toaster: ToastrService,
    private storage: StorageService,
    private ren: Renderer2
  ) {
    this.notificationSubscrition = this.NotificationserviceService.currentMessage.subscribe((message) => {
      this.IncidentNotificationID = this.storage.getData("IncidentNotificationID");
    });
    this.userData = JSON.parse(this.storage.getData("UserData"));
    this.currentUserID = this.userData[0].UserID;
    this.NotificationserviceService.currentGOE.subscribe(
      (data) => (this.globalEnvId = data)
    );
    this.CompanyDetails = JSON.parse(this.storage.getData("CompanyDetails"));
    if (this.CompanyDetails) {
      this.CompanyID = parseInt(this.CompanyDetails.CompanyID);
    }
  }
  @Input() set fromSaveEvent(event) {
    if (!event) return; // done
    this.IncidentNotificationID = this.storage.getData(
      "IncidentNotificationID"
    );
    if (event) {
      this.onSaveRecipent();
    }
  }
  ngOnInit() {
    this.companyDetail();
    this.notificationSubscrition = this.NotificationserviceService.currentMessage.subscribe((message) => {
      this.IncidentNotificationID = this.storage.getData("IncidentNotificationID");
      this.currentIncidentNotificationID = this.storage.getData("IncidentNotificationID");
      this.dataComingForEdit();
    });
    this.route.routerState.root.queryParams.subscribe((params) => {
      if (params.isDisabled == "true") {
        this.disableonView = true;
      } else {
        this.disableonView = false;
      }
    });
    this.workGroupControlByPerson.disable();
    this.workGroupControl.disable();
  }

  radioChange(event: any, element: any) {
    this.flagPointer = true;
    this.storage.setData("flagPointer", 1);
    //console.log("radio value on change", event.value);

    if (event.value == 1 && (element.checked == false)) {
      this.isDisabled = true;
      this.UserIDsforSubmit = this.storage.getData('notificationCreatedBY') ? this.storage.getData('notificationCreatedBY') : this.currentUserID;
      this.AssociationTypeID = 1;
      this.radioValue = event.value;
    }
    else if (event.value == 2 && (element.checked == false)) {
      this.isDisabled = false;
      this.radioValue = event.value;
    }
    else {
      setTimeout(() => {
        element.checked = false;
        this.ren.removeClass(element['_elementRef'].nativeElement, 'cdk-focused');
        this.ren.removeClass(element['_elementRef'].nativeElement, 'cdk-program-focused');
      });
      this.radioValue = 0;
      this.isDisabled = false;
    }

  }

  itemMatch(objItem: any) {
    return this.selectedFinalJTItems.find(
      (i) => i.JobTitleID === objItem.JobTitleID
    ) != undefined
      ? true
      : false;
  }

  getCompanyName() {
    this.incomingData.CompanyName;
  }
  /**
   *
   * @param value
   */

  /** */
  ChoosenJobTitle(value) {
    // if (!this.rightSelectedPropertyId) {
    //   Swal.fire({ text: "Please select a Property first." });
    //   return;
    // }
    if (this.specifiedPropertyList.length == 0) {
      return;
    }
    this.selectedFinalJT = value;
    if (this.itemMatch(value) === true) {
      this.selectedFinalJTItems.forEach((e, i) => {
        if (e.JobTitleID === value.JobTitleID)
          return this.selectedFinalJTItems.splice(i, 1);
      });
    } else {
      this.selectedFinalJTItems.push(value);
    }
    this.JobTitleIDsforSubmit = this.selectedFinalJTItems
      .map((data) => data.JobTitleID)
      .toString();
    //console.log("what Rick is planning", this.selectedFinalJTItems);
  }

  //Functions for selection one and removing other
  selectedPositionTitle() {
    this.AssociationTypeID = 2;

    this.companyControlProperty.patchValue("");
    this.workGroupControlProperty.patchValue("");
    this.companyControlPosition.patchValue("");
    this.companyControlByPerson.patchValue("");
    this.workGroupControlByPerson.patchValue("");
    this.specifiedPersonList = [];
    this.userListByPropertyId = [];
    this.propertyListTwo = [];
    this.workGroupListPosition = [];
    this.jobTitlePosition = [];
    this.specifiedPositionList = [];
    this.userListByWorkGroup = [];
    this.specifiedByPersonList = [];

    document
      .getElementById("assigntoWorkGroup")
      .setAttribute("style", "background-color: #d9d9d9");
    document
      .getElementById("assign42")
      .setAttribute("style", "background-color: #d9d9d9");
  }


  selectedWorkGroupByPosition() {
    this.AssociationTypeID = 3;

    this.companyControl.patchValue("");
    this.workGroupControl.patchValue("");
    this.companyControlProperty.patchValue("");
    this.workGroupControlProperty.patchValue("");
    this.companyControlByPerson.patchValue("");
    this.workGroupControlByPerson.patchValue("");
    this.specifiedPropertyList = [];
    this.propertyList = [];
    this.jobTitleListByCompanyId = [];
    this.specifiedPersonList = [];
    this.userListByPropertyId = [];
    this.propertyListTwo = [];
    this.userListByWorkGroup = [];
    this.specifiedByPersonList = [];
    document
      .getElementById("assigntwo12")
      .setAttribute("style", "background-color: #d9d9d9");

    document
      .getElementById("assign42")
      .setAttribute("style", "background-color: #d9d9d9");
  }

  selectedByPerson() {
    this.AssociationTypeID = 4;

    this.companyControl.patchValue("");
    this.workGroupControl.patchValue("");
    this.companyControlProperty.patchValue("");
    this.workGroupControlProperty.patchValue("");
    this.companyControlPosition.patchValue("");
    this.specifiedPropertyList = [];
    this.propertyList = [];
    this.jobTitleListByCompanyId = [];
    this.specifiedPersonList = [];
    this.userListByPropertyId = [];
    this.propertyListTwo = [];
    this.workGroupListPosition = [];
    this.jobTitlePosition = [];
    this.specifiedPositionList = [];
    document
      .getElementById("assigntwo12")
      .setAttribute("style", "background-color: #d9d9d9");

    document
      .getElementById("assigntoWorkGroup")
      .setAttribute("style", "background-color: #d9d9d9");
  }

  companyDetail() {
    let data = {
      currentUserId: this.currentUserID,
      GlobalEnvironmentID: this.globalEnvId,
    };
    this.NotificationserviceService.GetCompanyListByUserID(data).subscribe(
      (data) => {
        this.companylist = data.data.GetCompanyListByUserID;

        // for (let i = 0; i < this.companylist.length; i++) {
        //   const arr = this.companylist[i].CompanyName;
        //   this.streets.push({
        //     companyID: this.companylist[i].CompanyID,
        //     companyName: this.companylist[i].CompanyName,
        //     ParentIdentNumber: this.companylist[i].ParentIdentNumber,
        //     ParentName: this.companylist[i].ParentName,
        //     CompanyIndentNumber: this.companylist[i].CompanyIndentNumber,
        //   });
        // }


        // this.filteredStreetsProperty = this.companyControlProperty.valueChanges.pipe(
        //   startWith(""),
        //   map((val: any) => (val && val.length >= 0 ? this._filter(val) : []))
        // );
        this.filterByWorkGroup();
        this.filterByPositionTitle();
        this.filterByPersonPosition();
        // this.filterStreetsNew = this.companyControler.valueChanges.pipe(
        //   startWith(""),
        //   map((val: any) => (val && val.length >= 0 ? this._filter(val) : []))
        // );
      }
    );
  }

  filterByWorkGroup() {
    this.filteredStreets = this.companyControl.valueChanges.pipe(
      startWith(""),
      map((val: any) => (val && val.length >= 0 ? this._filter(val) : this.companylist))
    );
  }

  filterByPositionTitle() {
    this.filteredStreetsPosition = this.companyControlPosition.valueChanges.pipe(
      startWith(""),
      map((val: any) => (val && val.length >= 0 ? this._filter(val) : this.companylist))
    );
  }
  filterByPersonPosition() {
    this.filteredStreetsByPerson = this.companyControlByPerson.valueChanges.pipe(
      startWith(""),
      map((val: any) => (val && val.length >= 0 ? this._filter(val) : this.companylist))
    );
  }

  // checkOne() {
  //   this.filteredStreets = this.companyControl.valueChanges.pipe(
  //     startWith(""),
  //     map((val: any) => (val ? (val.length > 0 ? this._filter(val) : []) : []))
  //   );
  //   //console.log("List is coming or not", this.streets);
  //   // test.blur();
  // }

  // checkOneProperty() {
  //   //console.log("hitting checks");
  //   this.filteredStreetsProperty = this.companyControlProperty.valueChanges.pipe(
  //     startWith(""),
  //     map((val: any) => (val ? (val.length > 0 ? this._filter(val) : []) : []))
  //   );
  //   //console.log("List is coming or not", this.streets);
  //   // test.blur();
  // }

  // checkOnePosition() {
  //   this.filteredStreetsPosition = this.companyControlPosition.valueChanges.pipe(
  //     startWith(""),
  //     map((val: any) => (val ? (val.length > 0 ? this._filter(val) : []) : []))
  //   );
  //   //console.log("List is coming or not", this.streets);
  //   // test.blur();
  // }

  // checkOneByPerson() {
  //   this.filteredStreetsByPerson = this.companyControlByPerson.valueChanges.pipe(
  //     startWith(""),
  //     map((val: any) => (val ? (val.length > 0 ? this._filter(val) : []) : []))
  //   );
  //   //console.log("List is coming or not", this.streets);
  //   // test.blur();
  // }

  // checkOneNew(test) {
  //   this.filterStreetsNew = this.companyControler.valueChanges.pipe(
  //     startWith(""),
  //     map((val: any) => (val ? (val.length > 0 ? this._filter(val) : []) : []))
  //   );
  //   test.blur();
  // }

  // checkTwo(test) {
  //   this.filterWorkGroups = this.workGroupControl.valueChanges.pipe(
  //     startWith(""),
  //     map((val: any) => (val ? (val.length >= 0 ? this._filterWorkGroup(val) : []) : [])));
  //   test.blur();
  //   this.blurWg = true;
  // }

  // checkTwoProperty(test) {
  //   this.filterWorkGroupsProperty = this.workGroupControlProperty.valueChanges.pipe(
  //     startWith(""),
  //     map((val: any) =>
  //       val.length >= 1 ? this._filterWorkGroupProperty(val) : []
  //     )
  //   );
  //   test.blur();
  //   this.blurWgTwo = true;
  // }

  // checkTwoByPerson(test) {
  //   this.filterWorkGroupsByPerson = this.workGroupControlByPerson.valueChanges.pipe(
  //     startWith(""),
  //     map((val: any) =>
  //       val ? (val.length >= 0 ? this._filterWorkGroupByPerson(val) : []) : [])
  //   );
  //   test.blur();
  // }

  // checkTwoNew(test) {
  //   //console.log("Zombie");
  //   this.filterWorkGroupsNew = this.workGroupControlNew.valueChanges.pipe(
  //     startWith(""),
  //     map((val: any) => (val ? (val.length >= 0 ? this._filterWorkGroupNew(val) : []) : []))
  //   );
  //   test.blur();
  // }

  // checkJobTitle(test) {
  //   this.filterJobTitle = this.jobTitleControl.valueChanges.pipe(
  //     startWith(""),
  //     map((val: any) => (val.length >= 0 ? this._filterJobTitle(val) : []))
  //   );
  //   test.blur();
  // }

  // checkUserList(test) {
  //   this.filterUsers = this.UserControl.valueChanges.pipe(
  //     startWith(""),
  //     map((val: any) => (val.length >= 0 ? this._filterUserList(val) : []))
  //   );
  //   test.blur();
  // }

  _filter(val: any = ""): any[] {
    return this.companylist
      .map((x) => {
        if (Array.isArray(x)) {
          return x[0];
        } else {
          return x;
        }
      })
      .filter((option) => {
        return option.CompanyName.toLowerCase().includes(val);
      });
  }

  _filterWorkGroup(val: any = ""): any[] {
    return this.workGroupList
      .map((x) => x)
      .filter((option) =>
        option.WorkGroupName.toLowerCase().includes(val)
      );
  }

  _filterWorkGroupProperty(val: any = ""): any[] {
    return this.workGroupListProperty
      .map((x) => x)
      .filter((option) =>
        option.WorkGroupName.toLowerCase().includes(val)
      );
  }

  _filterWorkGroupByPerson(val: any = ""): any[] {
    return this.workGroupListByPerson
      .map((x) => x)
      .filter((option) =>
        option.WorkGroupName.toLowerCase().includes(val)
      );
  }

  _filterWorkGroupNew(val: any = ""): any[] {
    return this.workGroupListNew
      .map((x) => x)
      .filter((option) =>
        option.WorkGroupName.toLowerCase().includes(val)
      );
  }

  _filterJobTitle(val: any = ""): any[] {
    return this.jobTitle
      .map((x) => x)
      .filter((option) =>
        option.JobTitleName.toLowerCase().includes(val)
      );
  }

  _filterUserList(val: any = ""): any[] {
    return this.userList
      .map((x) => x)
      .filter((option) =>
        option.UserName.toLowerCase().includes(val)
      );
  }

  onCompanyBlur(val: any) {
    //console.log("value", val);
    if (val == "" || null) {
      //console.log("why");
      this.propertyList = [];
      this.propertyListTwo = [];
      this.userListByPropertyId = [];
      this.specifiedPersonList = [];
      this.specifiedPropertyList = [];
      this.jobTitleListByCompanyId = [];
      this.workGroupListPosition = [];
      this.jobTitlePosition = [];
      this.specifiedPositionList = [];
      this.userListByWorkGroup = [];
      //this.specifiedByPersonList = [];
      this.workGroupControl.reset();
      this.workGroupControlProperty.reset();
      this.workGroupControlByPerson.reset();

      return;
    }
  }

  onWorkgroupBlur(val: any) {
    //console.log("value", val);
    if (val == "" || null) {
      //console.log("why");
      this.WorkGroupID = null;
      this.WorkGroupforSubmit = null;
      this.userListByPropertyId = [];
      this.SelectedPropertyIdPosition = false;
      this.selectByPerson = false;

      this.InspectionFormsService.getPropertyListByCompanyId(
        this.CompanyID
      ).subscribe((data) => {
        //console.log("Ids", this.CompanyID);

        // let elementOne = document.getElementById("workgroup");

        if (this.blurWg) {
          this.propertyList = data.data.getPropertyListByCompanyId;
        }

        if (this.AssociationTypeID == 2) {
          //console.log("is it hitting here??");
          this.propertyList = data.data.getPropertyListByCompanyId;
        }

      });
      this.InspectionFormsService.GetJobTitleByCompanyId(
        this.CompanyID
      ).subscribe((data) => {
        this.jobTitleListByCompanyId = data.data;
        // this.JobTitleIDsforSubmit = data.data
        //   .map((data) => data.JobTitleID)
        //   .toString();
        //console.log("mobile data", data.data);
      });

      this.InspectionFormsService.GetUserbyCompany(this.CompanyID).subscribe(
        (data) => {
          //console.log("user by comp", data.data.getUserbyCompany);
          // if (this.blurWg) {
          //   this.userListByWorkGroup = data.data.getUserbyCompany;
          // }
          // if (this.blurWgTwo) {
          //   this.userListByPropertyId = data.data.getUserbyCompany;
          // }

          if (this.AssociationTypeID == 4) {
            this.userListByWorkGroup = data.data.getUserbyCompany;
          }
        }
      );

      return;
    }
  }

  changeCompany(companyID: any, event) {
    //console.log("What are we up for man");
    if (!event.isUserInput) return;
    this.workGroupControl.enable();
    this.workGroupControl.reset();
    this.showCompanyOneCross = true;
    this.propertyList = [];
    this.specifiedPropertyList = [];
    this.CompanyID = companyID;
    this.WorkGroupID = null;
    this.SelectedPropertyIdPosition = false;
    this.selectedFinalJTItems = [];
    this.InspectionFormsService.GetJobTitleByCompanyId(companyID).subscribe(
      (data) => {
        this.jobTitleListByCompanyId = data.data;
      }
    );
    this.InspectionFormsService.getPropertyListByCompanyId(companyID).subscribe(
      (data) => {
        this.propertyList = data.data.getPropertyListByCompanyId;
      }
    );
    this.InspectionFormsService.getWorkgroup(companyID).subscribe((data) => {
      //console.log("The workgroup list", data);
      this.workGroupStreet = data.Workgroup;
      //
      // for (let i = 0; i < this.workGroupList.length; i++) {
      //   // const arr = this.companylist[i].CompanyName;
      //   this.workGroupStreet.push({
      //     companyID: this.workGroupList[i].CompanyID,
      //     companyName: this.workGroupList[i].CompanyName,
      //     WorkGroupID: this.workGroupList[i].WorkGroupID,
      //     WorkGroupName: this.workGroupList[i].WorkGroupName,
      //     WorkGroupNo: this.workGroupList[i].WorkGroupNo,
      //   });
      // }
      //console.log("workgroup streets", this.workGroupStreet);
      this.filterWorkGroups = this.workGroupControl.valueChanges.pipe(
        startWith(""),
        map((val: any[]) => (val && val.length >= 0 ? this._filterWorkGroup(val) : this.workGroupStreet))
      );
      ///**************************************************************** */
    });



  }

  onCompanyClear() {
    this.showCompanyOneCross = false;
    this.showWrkgrpOneCross = false;
    this.workGroupControl.disable();
    this.propertyList = [];
    this.specifiedPropertyList = [];
    this.companyControl.patchValue("");
    this.workGroupControl.reset();
  }

  selectPropertyPositoinTitle(value: any) {
    //console.log("Samsung", value);
    this.PropertyIDsforSubmit = value.PropertyID.toString();
    this.SelectedPropertyIdPosition = value;
    this.rightSelectedPropertyId = false;
    // this.selectedFinalJTItems = [];
  }

  onPropertySelect(value: any) {
    //console.log("property select value", value);
    this.SelectedPropertyId = value.PropertyID;
    this.PropertyIDsforSubmit = value.PropertyID.toString();
    this.propertyValue = value;
    this.rightSelectedPropertyId = false;
    //BY PROPERTY + PERSON
    this.InspectionFormsService.GetUserByProperties(
      this.SelectedPropertyId
    ).subscribe((data) => {
      //console.log("User by property", data.data);
      this.userListByPropertyId = data.data;
      // this.UserIDsforSubmit = data.data.map((data) => data.UserID);
    });
  }

  onUserPropertySelect(value: any) {
    //console.log("user val", value);
    this.SelectedUserByProperty = value;
    this.rightSelectedPerson = false;
  }

  //this.selectedFormID
  onRightPropertySelect(value: any) {
    //console.log("What is on the right side", value);
    this.rightSelectedPropertyId = value;
    this.PropertyIDsforSubmit = value.PropertyID.toString();
    this.rightPropertyValue = value;
    this.SelectedPropertyIdPosition = false;
  }

  onAddProperties() {
    this.flagPointer = true;
    this.storage.setData("flagPointer", 1);
    if (!this.SelectedPropertyIdPosition) {
      Swal.fire("Please select a Property to add");
      return;
    }
    //Choosing BY PROPERTY + POSITION TITLE
    let element = document.getElementById("assigntwo12");
    element.setAttribute("style", "background-color: #fadcaa");
    this.selectedPositionTitle();

    let value = this.SelectedPropertyIdPosition;
    //console.log("Value One", value);
    if (
      this.specifiedPropertyList.find(
        (data: any) => data.PropertyName == value.PropertyName
      )
    ) {
      Swal.fire({
        text: `${value.PropertyName} already added`,
      });
    } else {
      this.specifiedPropertyList.push(value);
      //console.log("Added values", value);
    }
    this.selectedPropertyList = this.specifiedPropertyList;
    this.PropertyIDsforSubmit = this.selectedPropertyList
      .map((data) => data.PropertyID)
      .toString();
    //console.log("lucifier", this.specifiedPropertyList);
  }

  onAddAllProperties() {
    this.flagPointer = true;
    this.storage.setData("flagPointer", 1);
    let element = document.getElementById("assigntwo12");
    element.setAttribute("style", "background-color: #fadcaa");
    this.selectedPositionTitle();
    let propertyNames = this.propertyList;
    //console.log("solvein this", propertyNames);

    let PropertyListIdArray = this.propertyList.map((data) => {
      let obj = {
        PropertyID: data.PropertyID,
        PropertyName: data.PropertyName,
      };
      return obj;
    });

    let specifiedPropertyListIdArray = this.specifiedPropertyList.map(
      (data) => {
        let obj = {
          PropertyID: data.PropertyID,
          PropertyName: data.PropertyName,
        };
        return obj;
      }
    );

    let idss = new Set(
      specifiedPropertyListIdArray.map(({ PropertyID }) => PropertyID)
    );

    let Two = PropertyListIdArray.filter(
      ({ PropertyID }) => !idss.has(PropertyID)
    );

    if (
      specifiedPropertyListIdArray.filter((data) =>
        PropertyListIdArray.includes(data)
      )
    ) {
      //console.log("Specified List", this.specifiedPropertyList);
      this.specifiedPropertyList = this.specifiedPropertyList.concat(Two);
      // Swal.fire("Some Properties already Added");
    } else {
      //console.log("left", this.propertyList);
      this.specifiedPropertyList = this.specifiedPropertyList.concat(
        this.propertyList
      );
    }
    this.PropertyIDsforSubmit = this.specifiedPropertyList
      .map((data) => data.PropertyID)
      .toString();
  }

  onRemoveAllProperties() {
    this.specifiedPropertyList = [];
    this.PropertyIDsforSubmit = [];
    this.selectedFinalJTItems = [];
  }

  onRemoveProperties() {
    if (this.rightSelectedPropertyId) {
      let value = this.rightSelectedPropertyId; //id and name
      let index = this.specifiedPropertyList.indexOf(value);
      this.specifiedPropertyList.splice(index, 1);
      if (this.specifiedPropertyList.length == 0) {
        this.selectedFinalJTItems = [];
      }

      // this.selectedFinalJTItems = [];
    } else {
      Swal.fire("Please Select a Property to Remove");
    }
    this.rightSelectedPropertyId = null;
    this.PropertyIDsforSubmit = this.specifiedPropertyList
      .map((data) => data.PropertyID)
      .toString();
  }

  //BY PROPERTY + PERSON
  // changeCompanyProperty(companyID: any, event) {
  //   // if (!event.isUserInput) return;
  //   this.workGroupControlProperty.reset();
  //   this.propertyListTwo = [];
  //   this.userListByPropertyId = [];
  //   this.specifiedPersonList = [];
  //   this.WorkGroupID = null;
  //   this.SelectedPropertyId = false;
  //   this.SelectedUserByProperty = false;
  //   this.CompanyID = companyID;
  //   //console.log("Company ID", companyID);
  //   this.InspectionFormsService.getWorkgroup(companyID).subscribe((data) => {
  //     //console.log("The workgroup list", data.Workgroup);
  //     this.workGroupListProperty = data.Workgroup;

  //     for (let i = 0; i < this.workGroupListProperty.length; i++) {
  //       // const arr = this.companylist[i].CompanyName;
  //       this.workGroupStreetProperty.push({
  //         companyID: this.workGroupListProperty[i].CompanyID,
  //         companyName: this.workGroupListProperty[i].CompanyName,
  //         WorkGroupID: this.workGroupListProperty[i].WorkGroupID,
  //         WorkGroupName: this.workGroupListProperty[i].WorkGroupName,
  //         WorkGroupNo: this.workGroupListProperty[i].WorkGroupNo,
  //       });
  //     }
  //     //console.log("workgroup streets", this.workGroupStreetProperty);
  //     this.filterWorkGroupsProperty = this.workGroupControlProperty.valueChanges.pipe(
  //       startWith(""),
  //       map((val: any) =>
  //         val.length >= 1 ? this._filterWorkGroupProperty(val) : []
  //       )
  //     );
  //   });
  //   this.InspectionFormsService.getPropertyListByCompanyId(companyID).subscribe(
  //     (data) => {
  //       this.propertyListTwo = data.data.getPropertyListByCompanyId;
  //       // this.PropertyIDsforSubmit = data.data.getPropertyListByCompanyId
  //       //   .map((data) => data.PropertyID)
  //       //   .toString();
  //       //console.log(
  //         "property from company",
  //         data.data.getPropertyListByCompanyId
  //       );
  //     }
  //   );
  //   this.InspectionFormsService.GetUserbyCompany(companyID).subscribe(
  //     (data) => {
  //       //console.log("user by comp", data.data.getUserbyCompany);
  //       this.userListByPropertyId = data.data.getUserbyCompany;
  //     }
  //   );
  // }

  //BY WORKGROUP + POSITION TITLE
  onRightPositionSelect(value: any) {
    this.rightSelectedPosition = value;
    this.SelectedJobTitlePosition = false;
  }

  async changeCompanyPosition(companyID: any, event) {
    if (!event.isUserInput) return;
    this.showCompanyTwoCross = true;
    this.jobTitlePosition = [];
    this.specifiedPositionList = [];
    this.WorkGroupID = null;
    this.SelectedJobTitlePosition = false;
    this.CompanyID = companyID;
    //console.log("Company ID", companyID);
    await this.InspectionFormsService.getWorkgroup(companyID).subscribe((data) => {
      this.workGroupListPosition = data.Workgroup;
    });
    await this.InspectionFormsService.GetJobTitleByCompanyId(companyID).subscribe(
      (data) => {
        this.jobTitlePosition = data.data;
      }
    );
  }

  onCompTwoClear() {
    this.showCompanyTwoCross = false;
    this.companyControlPosition.patchValue("");
    this.workGroupListPosition = [];
    this.jobTitlePosition = [];
  }

  onWorkgroupClick(value: any) {
    this.SelectedWorkgroup = value.WorkGroupID;
    this.WorkGroupforSubmit = value.WorkGroupID;
    this.SelectedJobTitlePosition = false;
    //console.log("Id hera", value.WorkGroupID);
    this.WorkGroupID = value.WorkGroupID;
    this.InspectionFormsService.GetJobTitleByWorkGroups(
      value.WorkGroupID
    ).subscribe((data) => (this.jobTitlePosition = data.data));
  }

  onJobTitlePositionClick(value: any) {
    this.SelectedJobTitlePosition = value;
    this.rightSelectedPosition = false;
    //console.log("JJ", value);
  }

  onAddPostion() {
    this.flagPointer = true;
    this.storage.setData("flagPointer", 1);
    if (!this.SelectedJobTitlePosition) {
      Swal.fire("Please select a Job Title to add");
      return;
    }

    let element = document.getElementById("assigntoWorkGroup");
    element.setAttribute("style", "background-color: #fadcaa");

    this.selectedWorkGroupByPosition();

    let value = this.SelectedJobTitlePosition;
    //console.log("Value One", value);
    if (
      this.specifiedPositionList.find(
        (data: any) => data.JobTitleName == value.JobTitleName
      )
    ) {
      // this.specifiedPropertyList.push(value.PropertyName);
      Swal.fire({
        text: `${value.JobTitleName} already added`,
      });
    } else {
      this.specifiedPositionList.push(value);
      // this.InspectionFormsService.GetJobTitleByProperties(value)
      // .subscribe
      //console.log("Added values", value);
    }
    this.selectedPositionList = this.specifiedPositionList;
    this.JobTitleIDsforSubmit = this.specifiedPositionList
      .map((data) => data.JobTitleID)
      .toString();
    //console.log("lucifier", this.selectedPropertyList);
  }

  onAddAllPosition() {
    this.flagPointer = true;
    this.storage.setData("flagPointer", 1);
    let element = document.getElementById("assigntoWorkGroup");
    element.setAttribute("style", "background-color: #fadcaa");

    this.selectedWorkGroupByPosition();
    let idss = new Set(
      this.specifiedPositionList.map(({ JobTitleID }) => JobTitleID)
    );

    let Two = this.jobTitlePosition.filter(
      ({ JobTitleID }) => !idss.has(JobTitleID)
    );

    if (
      this.specifiedPositionList.filter((data) =>
        this.jobTitlePosition.includes(data)
      )
    ) {
      //console.log("Specified Person List", this.specifiedPositionList);
      this.specifiedPositionList = this.specifiedPositionList.concat(Two);
      // Swal.fire("Some Properties already Added");
    } else {
      this.specifiedPositionList = this.specifiedPositionList.concat(
        this.jobTitlePosition
      );
    }
    this.JobTitleIDsforSubmit = this.specifiedPositionList
      .map((data) => data.JobTitleID)
      .toString();
  }

  onRemoveAllPosition() {
    this.specifiedPositionList = [];
    this.JobTitleIDsforSubmit = [];
  }

  onRemovePosition() {
    if (this.rightSelectedPosition) {
      let value = this.rightSelectedPosition; //id and name
      let index = this.specifiedPositionList.indexOf(value);
      this.specifiedPositionList.splice(index, 1);
    } else {
      Swal.fire("Please Select a Job Title to Remove");
    }
    this.rightSelectedPosition = null;
    this.JobTitleIDsforSubmit = this.specifiedPositionList
      .map((data) => data.JobTitleID)
      .toString();
  }

  /////////////////////////////////////////////
  //BY PERSON
  changeCompanyByPerson(companyID: any, event) {
    if (!event.isUserInput) return;
    this.showCompanyThreeCross = true;
    this.workGroupControlByPerson.enable();
    this.workGroupControlByPerson.reset();
    this.userListByWorkGroup = [];
    //this.specifiedByPersonList = [];
    this.selectByPerson = false;
    this.WorkGroupID = null;
    // this.userListByPropertyId = [];
    // this.specifiedPersonList = [];
    // this.SelectedPropertyId = false;
    this.CompanyID = companyID;
    //console.log("Company ID", companyID);
    this.InspectionFormsService.getWorkgroup(companyID).subscribe((data) => {
      //console.log("The workgroup list BY Person", data.Workgroup);
      this.workGroupListByPerson = data.Workgroup;
      // this.WorkGroupforSubmit = data.Workgroup.map(
      //   (data) => data.WorkGroupID
      // ).toString();
      for (let i = 0; i < this.workGroupListByPerson.length; i++) {
        // const arr = this.companylist[i].CompanyName;
        this.workGroupStreetByPerson.push({
          companyID: this.workGroupListByPerson[i].CompanyID,
          companyName: this.workGroupListByPerson[i].CompanyName,
          WorkGroupID: this.workGroupListByPerson[i].WorkGroupID,
          WorkGroupName: this.workGroupListByPerson[i].WorkGroupName,
          WorkGroupNo: this.workGroupListByPerson[i].WorkGroupNo,
        });
      }
      //console.log("workgroup streets", this.workGroupStreetByPerson);
      this.filterWorkGroupsByPerson = this.workGroupControlByPerson.valueChanges.pipe(
        startWith(""),
        map((val: any) => {
          // if (!val) {
          //   return [];
          // }
          return (val && val.length >= 0 ? this._filterWorkGroupByPerson(val) : this.workGroupStreetByPerson);
        })
      );
    });

    this.InspectionFormsService.GetUserbyCompany(companyID).subscribe(
      (data) => {
        //console.log("user by comp", data.data.getUserbyCompany);
        this.userListByWorkGroup = data.data.getUserbyCompany;
      }
    );
  }

  onCompThreeClear() {
    this.showCompanyThreeCross = false;
    this.showWrkthreeCross = false;
    this.companyControlByPerson.patchValue("");
    this.workGroupControlByPerson.patchValue("");
    this.userListByWorkGroup = [];
    this.workGroupControlByPerson.disable();
  }

  showpersonByWorkgroup(event, WorkGroupID: any) {
    this.showWrkthreeCross = true;
    this.WorkGroupID = WorkGroupID;
    this.WorkGroupforSubmit = WorkGroupID;
    this.selectByPerson = false;
    this.InspectionFormsService.GetUserByWorkGroups(
      Array.isArray(WorkGroupID) ? WorkGroupID[0] : WorkGroupID
    ).subscribe((data) => {
      //console.log("Person by workgroup", data.data);
      this.userListByWorkGroup = data.data;
    });
  }

  onWrkThreeClear() {
    this.showWrkthreeCross = false;
    this.workGroupControlByPerson.patchValue("");
    this.WorkGroupID = null;

    this.InspectionFormsService.GetUserbyCompany(this.CompanyID).subscribe(
      (data) => {
        //console.log("user by comp", data.data.getUserbyCompany);
        this.userListByWorkGroup = data.data.getUserbyCompany;
      }
    );
  }

  onleftPersonSelect(value: any) {
    this.rightSelectedByPerson = false;
    this.selectByPerson = value;
    this.UserIDsforSubmit = value.UserID;
  }

  onAddByPerson() {
    this.flagPointer = true;
    this.storage.setData("flagPointer", 1);
    if (!this.selectByPerson) {
      Swal.fire("Please select a Person to add");
      return;
    }
    let element = document.getElementById("assign42");
    element.setAttribute("style", "background-color: #fadcaa");

    this.selectedByPerson();

    let value = this.selectByPerson;
    //console.log("Value One", value);
    if (
      this.specifiedByPersonList.find(
        (data: any) => data.UserName == value.UserName
      )
    ) {
      Swal.fire({
        text: `${value.UserName} is already added`,
      });
    } else {
      this.specifiedByPersonList.push(value);
    }
    this.selectedByPersonList = this.specifiedByPersonList;
    this.UserIDsforSubmit = this.specifiedByPersonList
      .map((data) => data.UserID)
      .toString();
    //console.log("lucifier", this.selectedByPersonList);
  }

  onAddAllByPerson() {
    this.flagPointer = true;
    this.storage.setData("flagPointer", 1);
    let element = document.getElementById("assign42");
    element.setAttribute("style", "background-color: #fadcaa");
    element.style.backgroundColor = "#fadcaa";

    this.selectedByPerson();

    let idss = new Set(this.specifiedByPersonList.map(({ UserID }) => UserID));

    let Two = this.userListByWorkGroup.filter(
      ({ UserID }) => !idss.has(UserID)
    );

    if (
      this.specifiedByPersonList.filter((data) =>
        this.userListByWorkGroup.includes(data)
      )
    ) {
      this.specifiedByPersonList = this.specifiedByPersonList.concat(Two);
      // Swal.fire("Some Properties already Added");
    } else {
      this.specifiedByPersonList = this.specifiedByPersonList.concat(
        this.userListByWorkGroup
      );
    }
    this.UserIDsforSubmit = this.specifiedByPersonList
      .map((data) => data.UserID)
      .toString();
  }

  onRemoveAllByPerson() {
    this.specifiedByPersonList = [];
    this.UserIDsforSubmit = [];
  }

  onRemoveByPerson() {
    if (this.rightSelectedByPerson) {
      let value = this.rightSelectedByPerson; //id and name
      let index = this.specifiedByPersonList.indexOf(value);
      this.specifiedByPersonList.splice(index, 1);
    } else {
      Swal.fire("Please Select a Person to Remove");
    }
    this.rightSelectedByPerson = null;
    this.UserIDsforSubmit = this.specifiedByPersonList
      .map((data) => data.UserID)
      .toString();
  }

  onRightPersonBySelect(value: any) {
    this.selectByPerson = false;
    this.rightSelectedByPerson = value;
  }

  // WorkGroupID,
  //     this.currentUserID
  showProperties(event, WorkGroupID: any) {
    //console.log("CurrentUserID", this.currentUserID);
    this.showWrkgrpOneCross = true;
    if (!event.isUserInput) return;
    this.WorkGroupID = WorkGroupID;
    this.WorkGroupforSubmit = WorkGroupID;
    this.InspectionFormsService.getPropertyByWorkGroupId(
      WorkGroupID,
      this.currentUserID
    ).subscribe((data) => {
      //console.log("Properties of workgroup", data.data.Properties);
      this.propertyList = data.data.Properties;
    });
    this.InspectionFormsService.GetJobTitleByWorkGroups(WorkGroupID).subscribe(
      (data) => {
        //console.log("khalid", data.data);
        this.jobTitleListByCompanyId = data.data;
      }
    );
  }

  onWorkgroupClear(val: any) {
    this.showWrkgrpOneCross = false;
    this.workGroupControl.patchValue("");
    // this.onWorkgroupBlur(val);
    this.propertyListOne();
  }

  propertyListOne() {
    this.InspectionFormsService.getPropertyListByCompanyId(
      this.CompanyID
    ).subscribe((data) => {
      //console.log("Ids", this.CompanyID);
      this.propertyList = data.data.getPropertyListByCompanyId;
    });
  }

  showPropertiesTwo(event, WorkGroupID: any) {
    //console.log("CurrentUserID", this.currentUserID);
    if (!event.isUserInput) return;
    this.userListByPropertyId = [];
    this.SelectedPropertyId = false;
    this.SelectedUserByProperty = false;
    this.WorkGroupID = WorkGroupID;
    this.InspectionFormsService.getPropertyByWorkGroupId(
      WorkGroupID,
      this.currentUserID
    ).subscribe((data) => {
      //console.log("Properties of workgroup", data.data.Properties);
      this.propertyListTwo = data.data.Properties;
      // this.PropertyIDsforSubmit = data.data.Properties.map(
      //   (data) => data.PropertyID
      // ).toString();
    });
    this.InspectionFormsService.GetUserbyCompany(this.CompanyID).subscribe(
      (data) => {
        //console.log("user by comp", data.data.getUserbyCompany);
        this.userListByPropertyId = data.data.getUserbyCompany;
      }
    );
  }

  //BY PROPERTY + PERSON

  // onRightPersonSelect(value: any) {
  //   //console.log("What is on the right side", value);
  //   this.rightSelectedPerson = value;
  //   this.SelectedUserByProperty = false;
  // }

  // onAddPerson() {
  //   if (!this.SelectedUserByProperty) {
  //     return;
  //   }
  //   let element = document.getElementById("assigntwo2");
  //   element.setAttribute("style", "background-color: #fadcaa");
  //   this.selectedPerson();

  //   let value = this.SelectedUserByProperty;
  //   //console.log("Value One", value);
  //   if (
  //     this.specifiedPersonList.find(
  //       (data: any) => data.UserName == value.UserName
  //     )
  //   ) {
  //     Swal.fire({
  //       text: `${value.UserName} is already added`,
  //     });
  //   } else {
  //     if (this.SelectedPropertyId) {
  //       this.specifiedPersonList.push(value);
  //     } else {
  //       this.PropertyIDsforSubmit = null;
  //       this.specifiedPersonList.push(value);
  //       this.SelectedPropertyId = false;
  //     }

  //     //console.log("Added values", value);
  //   }
  //   this.selectedPersonList = this.specifiedPersonList;
  //   this.UserIDsforSubmit = this.specifiedPersonList
  //     .map((data) => data.UserID)
  //     .toString();
  //   //console.log("lucifier", this.selectedPersonList);
  // }

  // onAddAllPerson() {
  //   let element = document.getElementById("assigntwo2");
  //   element.setAttribute("style", "background-color: #fadcaa");
  //   this.selectedPerson();
  //   let idss = new Set(this.specifiedPersonList.map(({ UserID }) => UserID));

  //   let Two = this.userListByPropertyId.filter(
  //     ({ UserID }) => !idss.has(UserID)
  //   );

  //   if (
  //     this.specifiedPersonList.filter((data) =>
  //       this.userListByPropertyId.includes(data)
  //     )
  //   ) {
  //     //console.log("Specified Person List", this.specifiedPersonList);
  //     this.specifiedPersonList = this.specifiedPersonList.concat(Two);
  //     // Swal.fire("Some Properties already Added");
  //   } else {
  //     this.specifiedPersonList = this.specifiedPersonList.concat(
  //       this.userListByPropertyId
  //     );
  //   }
  //   this.UserIDsforSubmit = this.specifiedPersonList
  //     .map((data) => data.UserID)
  //     .toString();
  // }

  // onRemoveAllPerson() {
  //   this.specifiedPersonList = [];
  //   this.UserIDsforSubmit = [];
  // }

  // onRemovePerson() {
  //   if (this.rightSelectedPerson) {
  //     let value = this.rightSelectedPerson; //id and name
  //     let index = this.specifiedPersonList.indexOf(value);
  //     this.specifiedPersonList.splice(index, 1);
  //   } else {
  //     Swal.fire("Please Select a Person to Remove");
  //   }
  //   this.rightSelectedPerson = null;
  //   this.UserIDsforSubmit = this.specifiedPersonList
  //     .map((data) => data.UserID)
  //     .toString();
  // }

  //*******************************Grtting data for binding******************************** */
  dataComingForEdit() {
    if (this.IncidentNotificationID != 0) {
      this.GetIncidentNotificationSettings();
      // this.GetIncidentNotificationWorkGroup();
      //this.GetIncidentNotificationAssociation();
    }
  }
  @ViewChild("eleven", { static: false }) elementRef: any;
  @ViewChild("OneEleven", { static: false }) elementReff: any;
  @ViewChild("OneTwelve", { static: false }) elementRefer: any;
  GetIncidentNotificationAssociation() {
    this.NotificationserviceService.GetIncidentNotificationAssociation(
      this.IncidentNotificationID ||
      this.storage.getData("IncidentNotificationID")
    ).subscribe(async (data) => {

      let value = data.data.getIncidentNotificationAssociation;
      if (value.length) {
        this.AssociationTypeID = value[0].AssociationTypeID;
      }
      let filterID = value.filter((x) => x.UserID == (this.storage.getData('notificationCreatedBY') ? this.storage.getData('notificationCreatedBY') : this.currentUserID));

      if (this.AssociationTypeID == 1) {
        this.flagPointer = true;
        this.selectingRecipent = 1;
        this.radioValue = 1;
        this.storage.setData("flagPointer", 1);
      }
      if (this.AssociationTypeID == 2) {
        this.selectingRecipent = filterID.length != 0 ? 2 : 0;
        this.radioValue = filterID.length != 0 ? 2 : 0;
        this.flagPointer = true;
        this.storage.setData("flagPointer", 1);
        await this.GetIncidentNotificationProperty();
        this.elementReff.nativeElement.style.backgroundColor = "#d9d9d9";
        this.elementRefer.nativeElement.style.backgroundColor = "#d9d9d9";
        this.elementRef.nativeElement.style.backgroundColor = "#fadcaa";
        this.selectedFinalJTItems = value.filter((data) => {
          let obj = {
            JobTitleID: data.JobTitleID,
            JobTitle: data.JobTitle,
          };
          return obj;
        });
        //this.jobTitleListByCompanyId = value;
      }
      if (this.AssociationTypeID == 3) {
        this.selectingRecipent = filterID.length != 0 ? 2 : 0;
        this.radioValue = filterID.length != 0 ? 2 : 0;
        this.flagPointer = true;
        this.storage.setData("flagPointer", 1);
        this.elementRef.nativeElement.style.backgroundColor = "#d9d9d9";
        this.elementRefer.nativeElement.style.backgroundColor = "#d9d9d9";
        this.elementReff.nativeElement.style.backgroundColor = "#fadcaa";
        this.specifiedPositionList = value.filter((data) => {
          let obj = {
            JobTitleID: data.JobTitleID,
            JobTitleName: data.JobTitle,
          };
          if (obj.JobTitleID) {
            return true;
          }
        });
        this.JobTitleIDsforSubmit = this.specifiedPositionList
          .map((data) => data.JobTitleID)
          .toString();
      }
      if (this.AssociationTypeID == 4) {
        this.selectingRecipent = filterID.length != 0 ? 2 : 0;
        this.radioValue = filterID.length != 0 ? 2 : 0;
        this.flagPointer = true;
        this.storage.setData("flagPointer", 1);
        this.elementRef.nativeElement.style.backgroundColor = "#d9d9d9";
        this.elementReff.nativeElement.style.backgroundColor = "#d9d9d9";
        this.elementRefer.nativeElement.style.backgroundColor = "#fadcaa";
        this.specifiedByPersonList = value.filter((data) => {
          let obj = {
            UserID: data.UserID,
            UserName: data.Persons,
          };
          if (obj.UserID) {
            return obj;
          }
        });

        this.UserIDsforSubmit = this.specifiedByPersonList
          .map((data) => data.UserID)
          .toString();
        //console.log("9955", this.specifiedByPersonList);
      }
      //console.log("Brooklyn", this.AssociationTypeID);
    });
  }

  // IncomingAssociationData() {
  //   if (this.AssociationTypeID == 2) {
  //   }
  // }

  GetIncidentNotificationProperty() {
    this.NotificationserviceService.GetIncidentNotificationProperty(
      this.storage.getData("IncidentNotificationID")
    ).subscribe((data) => {
      if (
        Array.isArray(this.AssociationTypeID)
          ? this.AssociationTypeID[0]
          : this.AssociationTypeID == 2
      ) {
        this.specifiedPropertyList = data.data.getIncidentNotificationProperty.map(
          (data) => {
            let obj = {
              PropertyID: data.PropertyID,
              PropertyName: data.PropertyName,
            };
            return obj;
          }
        );
      }
    });
  }

  // GetIncidentNotificationWorkGroup() {
  //   this.NotificationserviceService.GetIncidentNotificationWorkGroup(
  //     this.IncidentNotificationID ||
  //     this.storage.getData("IncidentNotificationID")
  //   ).subscribe((data) => {

  //   });
  // }

  // GetIncidentAssociationTypeList() {
  //   this.NotificationserviceService.GetIncidentAssociationTypeList().subscribe(
  //     (data) => {
  //       this.incomingAssociationType = data.data.GetIncidentAssociationTypeList;
  //       document
  //         .getElementById("assigntoWorkGroup")
  //         .setAttribute("style", "background-color: #d9d9d9");
  //       document
  //         .getElementById("assign42")
  //         .setAttribute("style", "background-color: #d9d9d9");
  //     }
  //   );
  // }

  GetIncidentNotificationSettings() {
    this.NotificationserviceService.GetIncidentNotificationSettings(
      this.IncidentNotificationID ||
      this.storage.getData("IncidentNotificationID")
    ).subscribe(async (data) => {
      let value = data.data.getIncidentNotificationSettings;
      this.AssociationTypeID = value.map((data) => data.AssociationTypeID);
      let wrkID = value.map((data) => data.WorkGroupID);
      this.CompanyID = value.map((data) => data.CompanyID);
      let filterID = value.filter((x) => x.UserID == (this.storage.getData('notificationCreatedBY') ? this.storage.getData('notificationCreatedBY') : this.currentUserID));
      if (this.AssociationTypeID == 1) {
        this.isDisabled = true;
        this.selectingRecipent = 1;
        this.radioValue = 1;
        this.selectingRecipent = 1;
        this.GetIncidentNotificationAssociation();
        return;
      }
      if (this.AssociationTypeID == 2) {
        this.selectingRecipent = filterID.length != 0 ? 2 : 0;
        this.radioValue = filterID.length != 0 ? 2 : 0;
        if (wrkID[0] != null) {
          this.companyControl.patchValue(data.data.getIncidentNotificationSettings[0].CompanyName);
          this.callingWorkGroup();
          //this.showpersonByWorkgroup({}, wrkID[0]);
          this.changeCompany(this.CompanyID[0], { isUserInput: true });
          this.showProperties(
            { isUserInput: true },
            value.map((data) => data.WorkGroupID)
          );
          setTimeout(() => {
            this.GetIncidentNotificationAssociation();
            this.workGroupControl.patchValue(data.data.getIncidentNotificationSettings[0].WorkGroupName);
          }, 100);
        } else {
          this.companyControl.patchValue(value.map((data) => data.CompanyName));
          this.changeCompany(this.CompanyID[0], { isUserInput: true });
          this.GetIncidentNotificationAssociation();
        }

      }
      if (this.AssociationTypeID == 3) {
        this.selectingRecipent = filterID.length != 0 ? 2 : 0;
        this.radioValue = filterID.length != 0 ? 2 : 0;
        this.companyControlPosition.patchValue(
          value.map((data) => data.CompanyName)
        );
        this.changeCompanyPosition(this.CompanyID, { isUserInput: true });
        this.SelectedWorkgroup = wrkID[0];
        this.WorkGroupforSubmit = this.SelectedWorkgroup;
        setTimeout(() => {
          this.GetIncidentNotificationAssociation();
        }, 100);
      }
      if (this.AssociationTypeID == 4) {
        this.selectingRecipent = filterID.length != 0 ? 2 : 0;
        this.radioValue = filterID.length != 0 ? 2 : 0;
        let element = document.getElementById("assign42");
        if (wrkID[0] != null) {
          this.companyControlByPerson.patchValue(data.data.getIncidentNotificationSettings[0].CompanyName);
          // this.callingWorkGroup();
          // this.workGroupControlByPerson.patchValue(
          //   value.map((data) => data.WorkGroupName)
          // );
          this.callingWorkGroup();
          this.changeCompanyByPerson(this.CompanyID, { isUserInput: true });

          this.showpersonByWorkgroup(
            { isUserInput: true },
            value.map((data) => data.WorkGroupID)
          );
          setTimeout(() => {
            this.GetIncidentNotificationAssociation();
            this.workGroupControlByPerson.patchValue(data.data.getIncidentNotificationSettings[0].WorkGroupName);
          }, 100);
        } else {
          this.companyControlByPerson.patchValue(
            value.map((data) => data.CompanyName)
          );
          this.changeCompanyByPerson(this.CompanyID, { isUserInput: true });
          setTimeout(() => {
            this.GetIncidentNotificationAssociation();
          }, 100);
        }
      }
    });
  }

  callingWorkGroup() {
    this.InspectionFormsService.getWorkgroup(
      Array.isArray(this.CompanyID) ? this.CompanyID[0] : this.CompanyID
    ).subscribe((data) => {
      //console.log("The workgroup list", data.Workgroup);
      if (this.AssociationTypeID == 2) {
        this.workGroupList = data.Workgroup;
        // for (let i = 0; i < this.workGroupList.length; i++) {
        //   // const arr = this.companylist[i].CompanyName;
        //   this.workGroupStreet.push({
        //     companyID: this.workGroupList[i].CompanyID,
        //     companyName: this.workGroupList[i].CompanyName,
        //     WorkGroupID: this.workGroupList[i].WorkGroupID,
        //     WorkGroupName: this.workGroupList[i].WorkGroupName,
        //     WorkGroupNo: this.workGroupList[i].WorkGroupNo,
        //   });
        // }
        //console.log("workgroup streets", this.workGroupList);
        this.filterWorkGroups = this.workGroupControl.valueChanges.pipe(
          startWith(""),
          map((val: any) => {
            if (!val) {
              return this.workGroupList;
            }
            return (val && val.length >= 0 ? this._filterWorkGroup(val) : this.workGroupList);
          })
        );
      } else {
        this.workGroupListByPerson = data.Workgroup;
        // for (let i = 0; i < this.workGroupListByPerson.length; i++) {
        //   // const arr = this.companylist[i].CompanyName;
        //   this.workGroupStreetByPerson.push({
        //     companyID: this.workGroupListByPerson[i].CompanyID,
        //     companyName: this.workGroupListByPerson[i].CompanyName,
        //     WorkGroupID: this.workGroupListByPerson[i].WorkGroupID,
        //     WorkGroupName: this.workGroupListByPerson[i].WorkGroupName,
        //     WorkGroupNo: this.workGroupListByPerson[i].WorkGroupNo,
        //   });
        // }
        //console.log("workgroup streets", this.workGroupListByPerson);
        this.filterWorkGroupsByPerson = this.workGroupControlByPerson.valueChanges.pipe(
          startWith(""),
          map((val: any) => {
            if (!val) {
              return this.workGroupListByPerson;
            }
            return (val && val.length >= 0 ? this._filterWorkGroup(val) : this.workGroupListByPerson);
          })
        );
      }
    });
  }

  //
  getJobTitles() {
    return this.selectedFinalJTItems.map((elem) => elem.JobTitleID).toString();
  }
  /////UPDATE & SAVE**************************************************************
  UpdateIncidentNotificationAssociation() {
    this.notificationMeUserID = this.storage.getData('notificationCreatedBY') ? this.storage.getData('notificationCreatedBY') : this.currentUserID;
    let recipients = this.isDisabled
      ? this.notificationMeUserID
      : this.specifiedByPersonList.map((elem) => elem.UserID).toString();
    if (this.radioValue == 2) {
      recipients = recipients ? recipients + ',' + this.notificationMeUserID : this.notificationMeUserID;
    }
    else if (this.radioValue == 1) {
      recipients = this.notificationMeUserID;
    }
    else if (this.radioValue == 0) {
      recipients = this.specifiedByPersonList.filter((elem) => { if (elem.UserID != this.notificationMeUserID) { return elem.UserID; } }).map((elem) => elem.UserID).toString();
    }
    let data = {
      IncidentNotificationID:
        this.IncidentNotificationID ||
        this.storage.getData("IncidentNotificationID"),
      AssociationTypeID: +this.AssociationTypeID,
      JobTitleIDs:
        this.AssociationTypeID == 2
          ? this.getJobTitles()
          : this.specifiedPositionList
            .map((elem) => elem.JobTitleID)
            .toString(),
      UserIDs: recipients
    };
    //console.log(this.specifiedByPersonList, this.specifiedPositionList);

    //console.log("association submit data", data);
    this.NotificationserviceService.UpdateIncidentNotificationAssociation(
      data
    ).subscribe((data) =>
      console.log("Notification Association updated", data)
    );
  }

  UpdateIncidentNotificationProperty() {
    let data = {
      IncidentNotificationID:
        this.IncidentNotificationID ||
        this.storage.getData("IncidentNotificationID"),
      PropertyIDs: this.specifiedPropertyList
        .map((elem) => elem.PropertyID)
        .toString(),
    };

    //console.log("property submit data", data);
    this.NotificationserviceService.UpdateIncidentNotificationProperty(
      data
    ).subscribe((data) => console.log("Notification Properties updated", data));
  }

  UpdateIncidentNotificationWorkGroup() {
    let data = {
      IncidentNotificationID:
        this.IncidentNotificationID ||
        this.storage.getData("IncidentNotificationID"),
      WorkGroupIDs: this.WorkGroupforSubmit,
    };
    //console.log("Workgroup submit data", data);
    this.NotificationserviceService.UpdateIncidentNotificationWorkGroup(
      data
    ).subscribe((data) => console.log("Notification workgroup updated", data));
  }

  UpdateIncidentNotificationSettings() {
    let data = {
      IncidentNotificationID:
        this.IncidentNotificationID ||
        this.storage.getData("IncidentNotificationID"),
      AssociationTypeID: this.AssociationTypeID,
      CompanyID: this.CompanyID,
      WorkgroupID: this.WorkGroupforSubmit,
    };
    this.NotificationserviceService.UpdateIncidentNotificationSettings(
      data
    ).subscribe((data) => console.log("Notification settings updated", data));
  }
  ///////////////////////////////////////////////
  message: string = "Save Create";

  @Output() messageEvent = new EventEmitter<string>();

  //SAVE BUTTON**********************************************************
  onSaveRecipent() {
    if (!this.flagPointer) {
      this.toaster.warning("please Select Specify Recipient");
      return;
    } else {
      this.waitForSaveBtn = true;
      let t = this.storage.getData("IncidentNotificationID");
      if (!t) {
        this.currentIncidentNotificationID = 0;
        this.messageEventTab.emit("Start");
      }
      let time = setInterval(() => {
        let t = this.storage.getData("IncidentNotificationID");
        if (!t) {
          clearInterval(time);
        } else {
          clearInterval(time);
          if (this.currentIncidentNotificationID && this.currentIncidentNotificationID != 0)
            this.messageToSaveAll.emit("save");
          this.UpdateIncidentNotificationAssociation();
          this.UpdateIncidentNotificationProperty();
          this.UpdateIncidentNotificationWorkGroup();
          this.UpdateIncidentNotificationSettings();
          this.toaster.success("Saved Successfully.");
          setTimeout(() => {
            this.waitForSaveBtn = false;
            this.route.navigate([
              "/products/communication/incidentnotification/createmanage",
            ]);

          }, 600);
          // this.messageEventTab.emit("Start");
          // this.messageToSaveAll.emit("save");
        }
        //   }
      }, 500);


    }
  }

  blurInputs(ref: any) {
    // this.GetISCITypeList();
    ref.blur();
  }


  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    // this.NotificationserviceService.changeFunt("StartNot");

    this.IncidentNotificationID = null;
    /**
     *
     */

    this.selectingRecipent = 0;
    this.chooseRecipent = [
      { "value": 1, "text": "Send To me only" },
      { "value": 2, "text": "Send to me in addition to user specified below" },
    ];
    this.radioValue = null;
    this.isDisabled = false;
    this.disableonView = null;
    //Global Variables
    this.userData = null;
    this.currentUserID = 0;

    //Local Variables
    this.flagPointer = false;
    this.filteredStreets = null;
    this.filteredStreetsProperty = null;
    this.filteredStreetsPosition = null;
    this.filteredStreetsByPerson = null;
    this.filterStreetsNew = null;
    this.filterWorkGroups = null;
    this.filterWorkGroupsProperty = null;
    this.filterWorkGroupsByPerson = null;
    this.filterWorkGroupsNew = null;
    this.filterJobTitle = null;
    this.filterUsers = null;
    this.streets = null;
    this.workGroupStreet = [];
    this.workGroupStreetProperty = [];
    this.workGroupStreetByPerson = [];
    this.workGroupStreetNew = [];
    this.jobTitleStreet = [];

    this.RatingTypeItem = [];
    this.isSelected = false;
    this.tenStarSelected = false;
    this.manualSelected = false;
    this.gradeSelected = false;
    this.SelectedInspectionFrequencyId = false;
    this.SelectedJobTitleID = false;
    this.SelectedUserID = false;
    this.SelectedPropertyId = false;
    this.SelectedPropertyIdPosition = false;
    this.SelectedUserByProperty = false;
    this.SelectedWorkgroup = false;
    this.rightSelectedPropertyId = false;
    this.rightSelectedPerson = false;
    this.rightSelectedByPerson = false;
    this.rightSelectedPosition = false;
    this.rightSelectedJobTitleID = false;
    this.rightSelectedUserId = false;
    this.percenttoggleRenewed = false;
    this.SelectedRatingMethod = false;
    this.SelectedRatingOptionOne = false;
    this.SelectedRatingOptionTwo = false;
    this.SelectedRatingOptionThree = false;
    this.SelectedRatingOptionFour = false;
    this.SelectedRatingOptionFive = false;
    this.SelectedRatingOptionSix = false;
    this.permitOption = false;
    this.rightSelected;
    this.OverAll = 0;
    this.IsRatingOverride;
    this.InspectionFormPropertyID = 0;
    this.InspectionTypeId = null;
    this.InspectionCategotyId = null;
    this.InspectionFailRateId = null;
    this.InspectionFormAssignmentID = 0;
    this.totalValCategory = null;
    this.totalSubValCategory = null;
    this.totalItemValCategory = null;

    this.InspectionRatingTypeId = null;
    this.propertyValue = null;
    this.jobTitleValue = null;
    this.workGroupValue = null;
    this.UserValue = null;
    this.changedWorkGroupID = null;
    this.rightPropertyValue = null;
    this.WorkGroupID = null;

    this.CategoryID = null;
    this.companylist = null;
    this.workGroupList = null;
    this.workGroupListProperty = [];
    this.workGroupListPosition = [];
    this.workGroupListByPerson = [];
    this.workGroupListNew;
    this.propertyList = [];
    this.propertyListTwo = [];
    this.userList = [];
    this.specifiedPropertyList = [];
    this.specifiedPersonList = [];
    this.specifiedByPersonList = [];
    this.specifiedPositionList = [];
    this.selectedPropertyList = [];
    this.selectedPersonList = [];
    this.selectedByPersonList = [];
    this.selectedPositionList = [];
    this.selectedJobTitle = [];
    this.selectedJobTitleFromTable = [];
    this.selectedUser = [];
    this.InspectionFormTags = [];
    this.jobTitle = [];
    this.userListByPropertyId = [];
    this.jobTitleListByCompanyId = [];
    this.jobTitlePosition = [];
    this.userListByWorkGroup = [];
    this.InspectionAssociationTypeID = null;
    this.PropertyIDsforSubmit = null;
    this.JobTitleIDsforSubmit = null;
    this.UserIDsforSubmit = null;
    this.WorkGroupforSubmit = null;
    this.incomingData = null;
    this.CompanyDetails = null;
    this.globalEnvId = null;

    this.selectedFinalJTItems = [];
    this.incomingAssociationType = [];
    this.selectedFinalJT = false;
    this.SelectedJobTitlePosition = false;
    this.selectByPerson = false;
    this.ContitionalElement = false;
    this.blurWg = false;
    this.blurWgTwo = false;
    this.CompanyID;
    this.IncidentNotificationID;
    this.AssociationTypeID = null;
    this.anyID;
    this.showCompanyOneCross = false;
    this.showWrkgrpOneCross = false;
    this.showCompanyTwoCross = false;
    this.showCompanyThreeCross = false;
    this.showWrkthreeCross = false;
    this.notificationSubscrition.unsubscribe();
  }

  @Output() messageEventTab = new EventEmitter<string>();
  @Output() messageToSaveAll = new EventEmitter<string>();
}
