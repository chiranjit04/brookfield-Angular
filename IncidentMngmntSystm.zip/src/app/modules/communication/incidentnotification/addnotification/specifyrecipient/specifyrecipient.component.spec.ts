import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SpecifyrecipientComponent } from './specifyrecipient.component';

describe('SpecifyrecipientComponent', () => {
  let component: SpecifyrecipientComponent;
  let fixture: ComponentFixture<SpecifyrecipientComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SpecifyrecipientComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SpecifyrecipientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
