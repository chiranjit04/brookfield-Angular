import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowingTriggerListComponent } from './showing-trigger-list.component';

describe('ShowingTriggerListComponent', () => {
  let component: ShowingTriggerListComponent;
  let fixture: ComponentFixture<ShowingTriggerListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowingTriggerListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowingTriggerListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
