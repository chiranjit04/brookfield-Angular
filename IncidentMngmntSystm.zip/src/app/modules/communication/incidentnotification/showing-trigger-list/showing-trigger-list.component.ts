import { Component, OnInit } from "@angular/core";
import { NotificationserviceService } from "../notificationservice.service";

@Component({
  selector: "app-showing-trigger-list",
  templateUrl: "./showing-trigger-list.component.html",
  styleUrls: ["./showing-trigger-list.component.scss"],
})
export class ShowingTriggerListComponent implements OnInit {
  IncidentNotificationID: any;
  incomingTriggerList: any = [];
  constructor(public NotificationserviceService: NotificationserviceService) {}

  ngOnInit() {
    this.GetIncidentTriggerByIncidentNotificationID();
  }
  GetIncidentTriggerByIncidentNotificationID() {
    console.log("Is popup hiitting here", this.IncidentNotificationID);
    this.NotificationserviceService.GetIncidentTriggerByIncidentNotificationID(
      this.IncidentNotificationID
    ).subscribe((data) => {
      // console.log(
      //   "All the triggers",
      //   data.data.getIncidentTriggerByIncidentNotificationID
      // );
      this.incomingTriggerList =
        data.data.getIncidentTriggerByIncidentNotificationID;
    });
  }
}
