import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-incidentnotification',
  templateUrl: './incidentnotification.component.html',
  styleUrls: ['./incidentnotification.component.scss']
})
export class IncidentnotificationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
