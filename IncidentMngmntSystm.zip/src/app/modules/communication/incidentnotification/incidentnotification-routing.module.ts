import { SpecifyrecipientComponent } from "./addnotification/specifyrecipient/specifyrecipient.component";
import { IncidenttriggerComponent } from "./addnotification/incidenttrigger/incidenttrigger.component";
import { AddnotificationComponent } from "./addnotification/addnotification.component";
// import { IncidenttriggerComponent } from './add-notification/incidenttrigger/incidenttrigger.component';
// import { SpecifyRecipietComponent } from './add-notification/specify-recipiet/specify-recipiet.component';

import { SentregisterComponent } from "./sentregister/sentregister.component";
import { CreatemanageComponent } from "./createmanage/createmanage.component";

import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

import { IncidentnotificationComponent } from "./incidentnotification.component";
import { AuthGuard } from "./../../../guard/auth.guard";

const routes: Routes = [
  {
    path: "",
    canActivate: [AuthGuard],
    component: IncidentnotificationComponent,
    children: [
      {
        path: "",
        component: CreatemanageComponent,
        pathMatch: "full",
        redirectTo: "createmanage",
      },
      {
        path: "createmanage",
        component: CreatemanageComponent,
      },
      {
        path: "sentregister",
        component: SentregisterComponent,
      },

      {
        path: "createmanage/addnotification/:id",
        component: AddnotificationComponent,
        children: [
          {
            path: "",
            redirectTo: "incidenttrigger",
            pathMatch: "full",
            component: IncidenttriggerComponent,
          },

          {
            path: "incidenttrigger",
            component: IncidenttriggerComponent,
          },

          {
            path: "specifyrecipient",
            component: SpecifyrecipientComponent,
          },
        ],
      },
    ],
  },

  {
    path: "addnotification",
    canActivate: [AuthGuard],
    loadChildren: () =>
      import("./addnotification/addnotification.module").then(
        (m) => m.AddnotificationModule
      ),
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class IncidentnotificationRoutingModule {}
