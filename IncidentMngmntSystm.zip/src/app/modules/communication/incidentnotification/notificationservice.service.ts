import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { environment } from "../../../../environments/environment";
import { Observable, of, throwError, from } from "rxjs";
import { catchError, map, tap, take } from "rxjs/operators";
import { BehaviorSubject } from "rxjs";
import { StorageService } from "../../../services/storage.service";

@Injectable({
  providedIn: "root",
})
export class NotificationserviceService {
  observable: Observable<any>;
  url: any;
  IncidentNotificationID: any;

  private messageSource = new BehaviorSubject(
    this.storage.getData("IncidentNotificationID")
  );
  currentMessage = this.messageSource.asObservable();

  // emitter
  private callFunt = new BehaviorSubject("default message");
  currentFunt = this.callFunt.asObservable();

  //Title transfer
  private titleSource = new BehaviorSubject("default message");
  currentTitle = this.titleSource.asObservable();

  //GOE transfer
  private GOESource = new BehaviorSubject(1);
  currentGOE = this.GOESource.asObservable();

  // private messageFlag = new BehaviorSubject("default message");
  // currentMessage = this.messageSource.asObservable();

  constructor(private http: HttpClient, private storage: StorageService) {
    this.url = environment.origin + "api/";
    this.messageSource = new BehaviorSubject(
      this.storage.getData("IncidentNotificationID")
    );
  }

  changeGOE(message: any) {
    this.GOESource.next(message);
  }

  changeTitle(message: any) {
    this.titleSource.next(message);
  }

  changeMessage(message: any) {
    this.messageSource.next(message);
  }

  changeFunt(message: any) {
    this.callFunt.next(message);
  }

  GetIncidentNotificationList(data: any) {
    console.log("shind", data);
    return this.http
      .post<any>(
        `${this.url}IncidentNotifications/GetIncidentNotificationList`,
        data
      )
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }

  GetIncidentTriggerList() {
    return this.http
      .get<any>(`${this.url}IncidentNotifications/GetIncidentTriggerList`)
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }

  GetIncidentNotificationsTrigger(IncidentNotificationID: any) {
    let data = {
      IncidentNotificationID: +IncidentNotificationID,
    };
    return this.http
      .post<any>(
        `${this.url}IncidentNotifications/GetIncidentNotificationsTrigger`,
        data
      )
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }

  GetIncidentNotificationQueries(IncidentNotificationID: any) {
    let data = {
      IncidentNotificationID: +IncidentNotificationID,
    };
    return this.http
      .post<any>(
        `${this.url}IncidentNotifications/GetIncidentNotificationQueries`,
        data
      )
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }

  GetIncidentNotificationSubjects(IncidentNotificationID: any) {
    let data = {
      IncidentNotificationID: +IncidentNotificationID,
    };
    return this.http
      .post<any>(
        `${this.url}IncidentNotifications/GetIncidentNotificationSubjects`,
        data
      )
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }

  getISCITypeList(GlobalEnvironmentID: any) {
    let data = {
      GlobalEnvironmentID: GlobalEnvironmentID,
    };
    return this.http
      .post<any>(
        `${this.url}IncidentNotifications/GetIncidentSubjectTypeList`,
        data
      )
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }

  GetIncidentCategoryList(data: any) {
    return this.http
      .post<any>(
        `${this.url}IncidentNotifications/GetIncidentSubjectCategoryList`,
        data
      )
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }

  GetIncidentSubjectList(data: any) {
    return this.http
      .post<any>(
        `${this.url}IncidentNotifications/GetIncidentSubjectList`,
        data
      )
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }

  GetNotificationQueriesList() {
    return this.http
      .get<any>(`${this.url}IncidentNotifications/GetNotificationQueriesList`)
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }

  GetPauseNotificationList() {
    return this.http
      .get<any>(`${this.url}IncidentNotifications/GetPauseNotificationList`)
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }

  ChangeIncidentNotificationStatus(IncidentNotificationID: any) {
    let data = {
      IncidentNotificationID: IncidentNotificationID,
    };
    return this.http
      .post<any>(
        `${this.url}IncidentNotifications/ChangeIncidentNotificationStatus`,
        data
      )
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }

  DeleteIncidentNotification(IncidentNotificationID: any) {
    let data = {
      IncidentNotificationID: IncidentNotificationID,
    };
    return this.http
      .post<any>(
        `${this.url}IncidentNotifications/DeleteIncidentNotification`,
        data
      )
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }

  onNotificationEdit(IncidentNotificationID: any) {
    let data = {
      IncidentNotificationID: IncidentNotificationID,
    };
    return this.http
      .post<any>(
        `${this.url}IncidentNotifications/GetIncidentNotificationByID`,
        data
      )
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }

  GetIncidentNotificationProperty(IncidentNotificationID: any) {
    let data = {
      IncidentNotificationID: IncidentNotificationID,
    };
    return this.http
      .post<any>(
        `${this.url}IncidentNotifications/GetIncidentNotificationProperty`,
        data
      )
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }

  GetIncidentNotificationWorkGroup(IncidentNotificationID: any) {
    let data = {
      IncidentNotificationID: IncidentNotificationID,
    };
    return this.http
      .post<any>(
        `${this.url}IncidentNotifications/GetIncidentNotificationWorkGroup`,
        data
      )
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }

  getGoeByUser(CurrentUserID: any) {
    let data = {
      UserId: +CurrentUserID,
    };
    return this.http
      .post<any>(`${this.url}getGoeByUser`, data)
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }

  GetIncidentNotificationCategory(IncidentNotificationID: any) {
    let data = {
      IncidentNotificationID: IncidentNotificationID,
    };
    return this.http
      .post<any>(
        `${this.url}IncidentNotifications/GetIncidentNotificationCategory`,
        data
      )
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }

  GetIncidentNotificationAssociation(IncidentNotificationID: any) {
    let data = {
      IncidentNotificationID: IncidentNotificationID,
    };
    return this.http
      .post<any>(
        `${this.url}IncidentNotifications/GetIncidentNotificationAssociation`,
        data
      )
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }

  GetIncidentAssociationTypeList() {
    return this.http
      .get<any>(
        `${this.url}IncidentNotifications/GetIncidentAssociationTypeList`
      )
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }

  GetIncidentNotificationSettings(IncidentNotificationID: any) {
    let data = {
      IncidentNotificationID: IncidentNotificationID,
    };
    return this.http
      .post<any>(
        `${this.url}IncidentNotifications/GetIncidentNotificationSettings`,
        data
      )
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }

  GetIncidentNotificationSentRegistry(data: any) {
    return this.http
      .post<any>(
        `${this.url}IncidentNotifications/GetIncidentNotificationSentRegistry`,
        data
      )
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }

  GetIncidentTriggerByIncidentNotificationID(IncidentNotificationID: any) {
    let data = {
      IncidentNotificationID: IncidentNotificationID,
    };
    return this.http
      .post<any>(
        `${this.url}IncidentNotifications/GetIncidentTriggerByIncidentNotificationID`,
        data
      )
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }

  GetSendToUserByIncidentNotificationID(IncidentNotificationID: any) {
    let data = {
      IncidentNotificationID: IncidentNotificationID,
    };
    return this.http
      .post<any>(
        `${this.url}IncidentNotifications/GetSendToUserByIncidentNotificationID`,
        data
      )
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }

  GetNotificationEmailDetailsByUserID(data: any) {
    return this.http
      .post<any>(
        `${this.url}IncidentNotifications/GetNotificationEmailDetailsByUserID`,
        data
      )
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }

  UpdateIncidentNotifications(data: any) {
    return this.http
      .post<any>(
        `${this.url}IncidentNotifications/UpdateIncidentNotifications`,
        data
      )
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }

  UpdateIncidentNotificationQueries(data: any) {
    return this.http
      .post<any>(
        `${this.url}IncidentNotifications/UpdateIncidentNotificationQueries`,
        data
      )
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }

  UpdateIncidentNotificationSubjects(data: any) {
    return this.http
      .post<any>(
        `${this.url}IncidentNotifications/UpdateIncidentNotificationSubjects`,
        data
      )
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }

  UpdateIncidentNotificationsTrigger(data: any) {
    return this.http
      .post<any>(
        `${this.url}IncidentNotifications/UpdateIncidentNotificationsTrigger`,
        data
      )
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }

  //Specify Recipent page
  UpdateIncidentNotificationAssociation(data: any) {
    return this.http
      .post<any>(
        `${this.url}IncidentNotifications/UpdateIncidentNotificationAssociation`,
        data
      )
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }

  UpdateIncidentNotificationProperty(data: any) {
    return this.http
      .post<any>(
        `${this.url}IncidentNotifications/UpdateIncidentNotificationProperty`,
        data
      )
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }

  UpdateIncidentNotificationWorkGroup(data: any) {
    return this.http
      .post<any>(
        `${this.url}IncidentNotifications/UpdateIncidentNotificationWorkGroup`,
        data
      )
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }

  UpdateIncidentNotificationCategory(data: any) {
    return this.http
      .post<any>(
        `${this.url}IncidentNotifications/UpdateIncidentNotificationCategory`,
        data
      )
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }

  UpdateIncidentNotificationSettings(data: any) {
    return this.http
      .post<any>(
        `${this.url}IncidentNotifications/UpdateIncidentNotificationSettings`,
        data
      )
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }

  UpdateUserSuspendedNotification(data) {
    return this.http
      .post<any>(
        `${this.url}IncidentNotifications/UpdateUserSuspendedNotification`,
        data
      )
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }

  GetCompanyListByUserID(data: any) {
    return this.http
      .post<any>(
        `${this.url}IncidentNotifications/GetCompanyListByUserID`,
        data
      )
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }

  GetIncidentSubjectNF(param) {
    return this.http
      .post<any>(`${this.url}IncidentNotifications/GetSubjectListNF`, param)
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }


  GetUserSuspendedNotificationStatus() {
    return this.http
      .get<any>(`${this.url}IncidentNotifications/GetUserSuspendedNotificationStatus`)
      .pipe(catchError((val) => of(`Error: ${val}`)));
  }
}
