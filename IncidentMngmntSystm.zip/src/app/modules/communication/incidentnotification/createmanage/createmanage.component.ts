// import {Component, OnInit, ViewChild} from '@angular/core';
// import {MatSort} from '@angular/material/sort';
// import {MatTableDataSource} from '@angular/material/table';
import { ActivatedRoute, Router } from "@angular/router";
import {
  FormBuilder,
  FormGroup,
  FormControl,
  Validators,
} from "@angular/forms";
import { MatDialog } from "@angular/material/dialog";
import { StorageService } from "../../../../services/storage.service";

export interface PeriodicElement {
  column1: string;
  column2: string;
  column3: string;
  column4: string;
  column5: string;
  column6: string;
  column7: string;
  action: string;
}
import { Component, ElementRef, OnInit, ViewChild } from "@angular/core";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { NotificationserviceService } from "../notificationservice.service";
import Swal from "sweetalert2";
import { ShowingTriggerListComponent } from "../showing-trigger-list/showing-trigger-list.component";
import { ShowPersonComponent } from "../show-person/show-person.component";
import { ToastrService } from "ngx-toastr";
@Component({
  selector: "app-createmanage",
  templateUrl: "./createmanage.component.html",
  styleUrls: ["./createmanage.component.scss"],
})
export class CreatemanageComponent implements OnInit {
  //Global Variables
  GlobalEnvironmentDetails = null;
  GlobalEnvironmentID: any;
  GlobalEnvironmentName = "";
  GOENumber = "";
  userData = null;
  currentUserID: any;

  //Local Variables
  notificationTable: any = [];
  pauseNotificationList: any = [];
  goeList: any = [];
  incomingTriggerList: any = [];
  incomingPersonList: any = [];
  notificationName: any;
  notificationDescription: any;
  IsEditable: any;
  IsAdvanced: any;
  IncidentTypeID: any;
  IsActive: any;
  selectAddNotification: any = false;
  PauseNotificationID: any;
  firstName: any;
  lastName: any;
  fullName: any;
  recipent: any;

  _record = false;

  //For Highlights
  selectedNotification: any = false;

  //Form Controls
  pauseNotificationControl: any = new FormControl();
  showAllControl: any = new FormControl();
  goeControl: any = new FormControl();

  displayedColumns: string[] = [
    "TITLE",
    "DESCRIPTION",
    "EDITABLE",
    "TRIGGERSS",
    "CREATEDBY",
    "CREATEDDATE",
    "SENDTO",
    "ACTION",
  ];
  dataSource: MatTableDataSource<any>;

  showAllList: any = [
    { name: "Show All", typeId: 1 },
    { name: "Show only created by me", typeId: 2 },
    { name: "Show only I will receive", typeId: 3 },
  ];

  @ViewChild(MatSort, { static: false }) sort: MatSort;

  constructor(
    public NotificationserviceService: NotificationserviceService,
    public dialog: MatDialog,
    private route: Router,
    private storage: StorageService,
    private toaster: ToastrService
  ) {
    this.GlobalEnvironmentDetails = JSON.parse(
      this.storage.getData("GlobalEnvironmentDetails")
    );

    // if (this.GlobalEnvironmentDetails) {
    //   //this.groupData = this.organise(this.exportreport);
    //   this.GlobalEnvironmentID = this.GlobalEnvironmentDetails.GlobalEnvironmentId;
    //   this.GlobalEnvironmentName = this.GlobalEnvironmentDetails.GlobalEnvironmentName;
    //   this.GOENumber = this.GlobalEnvironmentDetails.GOENo;
    // }
    this.userData = JSON.parse(this.storage.getData("UserData"));
    this.currentUserID = this.userData[0].UserID;
    this.firstName = this.userData[0].FirstName;
    this.lastName = this.userData[0].LastName;
    this.fullName = this.firstName.concat(this.lastName);

    /**
     *
     */
  }
  _gId;
  show;
  ngOnInit() {
    // this.dataSource.sort = this.sort;
    // this.dataSource = new MatTableDataSource([]);
    // this.dataSource.sort = this.sort;
    this._gId = this.storage.getData("_notify_");
    this.show = this.storage.getData("notifyShow");
    if (this._gId) {
      this._gId = JSON.parse(this._gId);
      this.GlobalEnvironmentID = this._gId.GlobalEnvironmentID;
    }

    if (this.show) {
      this.show = JSON.parse(this.show);
      this.show.typeId = this.show.typeId == 1 ? null : this.show.typeId;
      this.recipent = this.show.typeId;
    }
    this.GetIncidentNotificationList();
    this.GetPauseNotificationList();
    this.getGoeByUser();
    let _f = this.storage.getData("IncidentNotificationID");

    this.selectedNotification = _f;
  }

  ngAfterViewInit() {
    this.showAllControl.setValue((this.show || {}).name || "");
    this.goeControl.setValue((this._gId || {}).GlobalEnvironmentName || "");
  }

  GetUserSuspendedNotificationStatus() {
    this.NotificationserviceService.GetUserSuspendedNotificationStatus().subscribe((x: any) => {
      if (x.data.pausedNotification.length != 0) {
        let pauseNotification = x.data.pausedNotification[0];
        let filteredPause = this.pauseNotificationList.filter((x) => {
          return x.PauseNotificationID == pauseNotification.PauseNotificationID;
        })
        if (filteredPause.length != 0) {
          this.pauseNotificationControl.setValue(filteredPause[0].NotificationTitle);
        }
        else {
          this.pauseNotificationControl.setValue(this.pauseNotificationList[0].NotificationTitle);
        }
      }
      else {
        this.pauseNotificationControl.setValue(this.pauseNotificationList[0].NotificationTitle);
      }
    });
  }

  changeGOE(value: any, event) {
    if (!event.isUserInput) return;
    console.log("GOE value", value);
    this.GlobalEnvironmentID = value.GlobalEnvironmentID;
    this.GetIncidentNotificationList();
    this.NotificationserviceService.changeGOE(this.GlobalEnvironmentID);
    this.storage.setData("_notify_", JSON.stringify(value));
  }
  /**
   *
   */
  clearNotifyGoe() {
    this.GlobalEnvironmentID = null;
    this.GetIncidentNotificationList();
    this.storage.removeData("_notify_");
  }
  clearShowAll() {
    this.recipent = null;
    this.GetIncidentNotificationList();

    this.storage.removeData("notifyShow");
  }
  clearDur() {
    this.PauseNotificationID = null;
  }
  onClearGOE() {
    this.dataSource = null;
    this.GlobalEnvironmentID = null;
    this.goeControl.patchValue("");
  }

  cleanList() {
    console.log("kk", this.goeControl);
    if (this.goeControl.value == "") {
      this.dataSource = null;
      this.GlobalEnvironmentID = null;
      // this.goeControl.patchValue("");
    }
  }

  addNotification() {
    if (!this.GlobalEnvironmentID) {
      // Swal.fire("Please select a Global Environment to add a Notification");
      this.toaster.error(
        "Please select a Global Environment to add a Notification"
      );
      return;
    }
    this.storage.removeData('notificationCreatedBY');
    this.storage.removeData("flagPointer")
    this.storage.removeData("IncidentNotificationID");
    setTimeout(() => {
      this.route.navigate([
        "products/communication/incidentnotification/createmanage/addnotification/0",
      ]);
    }, 1000);
  }

  onNotificationSelect(data: any) {
    if (this.selectedNotification == data.IncidentNotificationID) {
      this.PauseNotificationID = null;
      this.selectedNotification = null;
      this.storage.removeData("IncidentNotificationID");
      // this.pauseNotificationControl.setValue("");
      return;
    }
    // this.pauseNotificationControl.setValue("");
    this.PauseNotificationID = null;
    console.log("yeahh", data);
    this.selectedNotification = data.IncidentNotificationID;
    this.storage.setData("IncidentNotificationID", data.IncidentNotificationID);
    this.notificationName = data.NotificationName;
    this.notificationDescription = data.NotificationDescription;
    this.IsEditable = this.IsEditable;
  }

  GetIncidentNotificationList() {
    let data = {
      GlobalEnvironmentID: this.GlobalEnvironmentID,
      Recipients: this.recipent,
      PauseAllNotificationToMe: "",
      CurrentUserId: +this.currentUserID,
    };
    console.log("getting the list through", data);
    this._record = false;
    this.NotificationserviceService.GetIncidentNotificationList(data).subscribe(
      (data) => {
        this.notificationTable = data.data.getIncidentNotificationList;

        this.dataSource = new MatTableDataSource(this.notificationTable);
        this.dataSource.sort = this.sort;
        this.sort.disableClear = true;
        console.log("where is the data", this.notificationTable);

        if (!this.notificationTable.length) {
          this._record = true;
        }
      }
    );
  }
  @ViewChild("showGOE", { static: false, read: ElementRef })
  showGoeFirst: ElementRef;
  getGoeByUser() {
    this.NotificationserviceService.getGoeByUser(this.currentUserID).subscribe(
      (data) => {
        console.log("Goe List", data.geoByUser);
        this.goeList = data.geoByUser;
        this.changeGOE(this.goeList[0], { isUserInput: true });
        this.showGoeFirst.nativeElement.value = this.goeList[0].GlobalEnvironmentName;
      }
    );
  }

  GetPauseNotificationList() {
    this.NotificationserviceService.GetPauseNotificationList().subscribe(
      (data) => {
        this.pauseNotificationList = data.data.getPauseNotificationList;
        this.GetUserSuspendedNotificationStatus();

      }
    );
  }

  changePauseNotificationList(value: any, event) {
    if (!event.isUserInput) return;
    this.PauseNotificationID = value.PauseNotificationID;
    this.UpdateUserSuspendedNotification();
    console.log("Getting pause notifivation value", value.NotificationTitle);
  }

  changeShowAll(value: any, event, obj) {
    if (!event.isUserInput) return;
    this.recipent = value == 1 ? null : value;
    this.GetIncidentNotificationList();
    this.storage.setData("notifyShow", JSON.stringify(obj));
  }

  // changeGOE(value: any, event) {
  //   if (!event.isUserInput) return;
  //   console.log("GOE value", value);
  //   this.GlobalEnvironmentID = value.GlobalEnvironmentID;
  //   this.GetIncidentNotificationList();
  // }

  onStatusClick(event, IncidentNotificationID: any, elem) {
    event.stopPropagation();
    this.NotificationserviceService.ChangeIncidentNotificationStatus(
      IncidentNotificationID
    ).subscribe((data) => {
      console.log("active/inactive", data, elem);
      if (elem.IsActive) {
        this.toaster.success("Notification Status Deactivated successfullly");
      } else {
        this.toaster.success("Notification Status Activated successfullly");
      }
      this.GetIncidentNotificationList();
    });
  }

  onDeleteNotification(event, IncidentNotificationID: any) {
    event.stopPropagation();
    Swal.fire({
      //title: 'Are you sure you want to delete ?',
      text: "Are you sure you want to remove this?",
      showCancelButton: true,
      confirmButtonText: "Yes",
      cancelButtonText: "Cancel",
    }).then((result) => {
      if (result.value) {
        this.NotificationserviceService.DeleteIncidentNotification(
          IncidentNotificationID
        ).subscribe((data) => {
          console.log("deleted data", data);
          this.GetIncidentNotificationList();
        });
      }
    });
  }

  //**************************************************** */

  onTriggerView(IncidentNotificationID: any) {
    console.log("Hitting ID", IncidentNotificationID);
    const dialogRef = this.dialog.open(ShowingTriggerListComponent, {
      width: "30%",
      maxWidth: "100vw",
    });
    dialogRef.componentInstance.IncidentNotificationID = IncidentNotificationID;
  }

  onPersonView(IncidentNotificationID: any) {
    console.log("Hitting ID Person", IncidentNotificationID);
    const dialogRef = this.dialog.open(ShowPersonComponent, {
      width: "30%",
      maxWidth: "100vw",
    });
    dialogRef.componentInstance.IncidentNotificationID = IncidentNotificationID;
  }

  // GetIncidentTriggerByIncidentNotificationID(IncidentNotificationID: any) {
  //   this.NotificationserviceService.GetIncidentTriggerByIncidentNotificationID(
  //     IncidentNotificationID
  //   ).subscribe((data) => {
  //     console.log(
  //       "All the triggers",
  //       data.data.getIncidentTriggerByIncidentNotificationID
  //     );
  //     this.incomingTriggerList =
  //       data.data.getIncidentTriggerByIncidentNotificationID;
  //   });
  // }

  // GetSendToUserByIncidentNotificationID() {
  //   this.NotificationserviceService.GetSendToUserByIncidentNotificationID(
  //     this.selectedNotification
  //   ).subscribe((data) => {
  //     console.log("All the Users", data);
  //   });
  // }

  onNotificationEdit(data: any, IncidentNotificationID: any, event?: any) {
    /** extract user data and check profile Id is 1 as Master Admin  */

    let userData: any = this.storage.getData("UserData")

    userData = JSON.parse(userData || "[{}]")


    if (userData[0].ProfileID === 1) {
      // write stuff here
    } else if (
      this.fullName.replaceAll(" ", "") != data.CreatedBy.replaceAll(" ", "") &&
      data.IsEditable == "No"
    ) {
      // Swal.fire(`You don't have permission to edit this Notification`);
      this.toaster.error("You don't have permission to edit this Notification");
      return;
    }
    event.stopPropagation();
    this.storage.setData("IncidentNotificationID", IncidentNotificationID);
    setTimeout(() => {
      this.route.navigate(
        [
          `products/communication/incidentnotification/createmanage/addnotification/${IncidentNotificationID}`,
        ],

        { queryParams: { isDisabled: false } }
      );
    }, 1000);
  }

  onNotificationView(IncidentNotificationID: any, event?: any) {
    this.storage.setData("IncidentNotificationID", IncidentNotificationID);
    event.stopPropagation();
    setTimeout(() => {
      this.route.navigate(
        [
          `products/communication/incidentnotification/createmanage/addnotification/${IncidentNotificationID}`,
        ],
        { queryParams: { isDisabled: true } }
      );
    }, 1000);
  }

  // GetNotificationEmailDetailsByUserID() {
  //   if (!this.selectedNotification) {
  //     // Swal.fire("Please select a Notification first.");
  //     this.toaster.warning("Please select a Notification first.");
  //     return;
  //   }
  //   let data = {
  //     CurrentUserID: +this.currentUserID,
  //     IncidentNotificationID: +this.selectedNotification,
  //   };
  //   this.NotificationserviceService.GetNotificationEmailDetailsByUserID(
  //     data
  //   ).subscribe((data) => {
  //     console.log("self mail", data);
  //     // Swal.fire("Mail sent successfully.");
  //   });
  // }

  UpdateUserSuspendedNotification() {
    let data = {
      IncidentNotificationID: this.selectedNotification
        ? +this.selectedNotification
        : null,
      PauseNotificationID: this.PauseNotificationID,
      UserID: this.currentUserID,
    };
    console.log("pause pause data", data);
    this.NotificationserviceService.UpdateUserSuspendedNotification(
      data
    ).subscribe((data) => console.log("Updated Pause notifications"));
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
  }

  onMatSortChange(event) {
    console.log(event);
    if (event.direction === "asc") {
      if (event.active === "TITLE") {
        this.notificationTable = this.sortAsc(
          this.notificationTable,
          "NotificationName"
        );
        this.dataSource = new MatTableDataSource(this.notificationTable);
      }

      if (event.active === "DESCRIPTION") {
        this.notificationTable = this.sortAsc(
          this.notificationTable,
          "NotificationDescription"
        );
        this.dataSource = new MatTableDataSource(this.notificationTable);
      }

      if (event.active === "EDITABLE") {
        this.notificationTable = this.sortAsc(
          this.notificationTable,
          "IsEditable"
        );
        this.dataSource = new MatTableDataSource(this.notificationTable);
      }

      if (event.active === "TRIGGERSS") {
        this.notificationTable = this.sortAsc(
          this.notificationTable,
          "NotificationTriggers"
        );
        this.dataSource = new MatTableDataSource(this.notificationTable);
      }

      if (event.active === "CREATEDBY") {
        this.notificationTable = this.sortAsc(
          this.notificationTable,
          "CreatedBy"
        );
        this.dataSource = new MatTableDataSource(this.notificationTable);
      }
      if (event.active === "CREATEDDATE") {
        this.notificationTable = this.sortAsc(
          this.notificationTable,
          "CreatedDate"
        );
        this.dataSource = new MatTableDataSource(this.notificationTable);
      }
      if (event.active === "SENDTO") {
        this.notificationTable = this.sortAsc(this.notificationTable, "SendTo");
        this.dataSource = new MatTableDataSource(this.notificationTable);
      }
    }
    if (event.direction === "desc") {
      if (event.active === "TITLE") {
        this.notificationTable = this.sortDesc(
          this.notificationTable,
          "NotificationName"
        );
        this.dataSource = new MatTableDataSource(this.notificationTable);
      }

      if (event.active === "DESCRIPTION") {
        this.notificationTable = this.sortDesc(
          this.notificationTable,
          "NotificationDescription"
        );
        this.dataSource = new MatTableDataSource(this.notificationTable);
      }

      if (event.active === "EDITABLE") {
        this.notificationTable = this.sortDesc(
          this.notificationTable,
          "IsEditable"
        );
        this.dataSource = new MatTableDataSource(this.notificationTable);
      }

      if (event.active === "TRIGGERSS") {
        this.notificationTable = this.sortDesc(
          this.notificationTable,
          "NotificationTriggers"
        );
        this.dataSource = new MatTableDataSource(this.notificationTable);
      }

      if (event.active === "CREATEDBY") {
        this.notificationTable = this.sortDesc(
          this.notificationTable,
          "CreatedBy"
        );
        this.dataSource = new MatTableDataSource(this.notificationTable);
      }
      if (event.active === "CREATEDDATE") {
        this.notificationTable = this.sortDesc(
          this.notificationTable,
          "CreatedDate"
        );
        this.dataSource = new MatTableDataSource(this.notificationTable);
      }
      if (event.active === "SENDTO") {
        this.notificationTable = this.sortDesc(
          this.notificationTable,
          "SendTo"
        );
        this.dataSource = new MatTableDataSource(this.notificationTable);
      }
    }
  }

  sortAsc(objects: any, keyName: string) {
    objects.sort((a, b) => {
      if (a[keyName] < b[keyName]) {
        return -1;
      }
      if (a[keyName] > b[keyName]) {
        return 1;
      }
      return 0;
    });

    return objects;
  }

  sortDesc(objects: any, keyName: string) {
    objects.sort((a, b) => {
      if (a[keyName] > b[keyName]) {
        return -1;
      }
      if (a[keyName] < b[keyName]) {
        return 1;
      }
      return 0;
    });

    return objects;
  }
}
