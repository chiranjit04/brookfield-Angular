import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreatemanageComponent } from './createmanage.component';

describe('CreatemanageComponent', () => {
  let component: CreatemanageComponent;
  let fixture: ComponentFixture<CreatemanageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreatemanageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreatemanageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
