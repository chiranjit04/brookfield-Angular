import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OpdocsComponent } from './opdocs.component';

describe('OpdocsComponent', () => {
  let component: OpdocsComponent;
  let fixture: ComponentFixture<OpdocsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OpdocsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OpdocsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
