import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ToastrService } from 'ngx-toastr';
import { map, startWith } from 'rxjs/operators';
import { StorageService } from 'src/app/services/storage.service';
import { OpdocsService } from '../opdocs.service';
import { environment } from "src/environments/environment";
import * as fs from "file-saver";

export interface PeriodicElement {
  column1: string;
  column2: string;
  column3: string;
  column4: string;
  column5: string;
  column6: string;
  column7: string;
  column8: string;
  column9: string;
}

@Component({
  selector: 'app-multipropertyview',
  templateUrl: './multipropertyview.component.html',
  styleUrls: ['./multipropertyview.component.scss']
})
export class MultipropertyviewComponent implements OnInit {

  displayedColumns: string[] = ['PropertyName', 'Category', 'DocName', 'Notes', 'FileTypeName', 'FileSize', 'UploadedDate', 'UplodedBy','Action'];
  dataSource: MatTableDataSource<any>;

  MultiPropertyViewForm: FormGroup;
  MultiPropertyViewFilters = {
    GlobalEnvironmentID: "",
    EnvironmentName: "",
    CompanyID: "",
    CompanyName: "",
    WorkGroupName: "",
    WorkGroupID: ""
  };
  categoryIDs = [];
  getGOEResponse: any = [];
  getgoeList: any = [];
  getCompanyResponse: any = [];
  getCompanyList: any = [];
  getWorkgroupList: any = [];
  getWorkgroupResponse: any = [];
  userData = null;
  UserID = null;
  GlobalEnvironmentID: any
  propertyList = [];
  propertyIndex = [];
  categoryList = [];
  timePeriod = [];
  currentPeriod = [];
  tableData: any;
  deleteArchive = [];
  selectedRow = [];
  tableRow = [];
  constructor(private storage: StorageService,
    private opdocsService: OpdocsService,
    private formBuilder: FormBuilder,
    private tostre: ToastrService) {
    this.userData = JSON.parse(this.storage.getData("UserData"));
    this.UserID = this.userData[0].UserID;
    this.GlobalEnvironmentID = this.userData[0].GlobalEnvironmentID;
    this.dataSource = new MatTableDataSource([]); 
  }

  ngOnInit() {
    this.MultiPropertyViewForm = this.formBuilder.group({
      EnvironmentName: "",
      CompanyName: "",
      WorkGroupName: "",
      UploadedAfter: [new Date()],
      UpoladedBefor: [new Date()],
      QuickCurrentPrior: [''],
      QuickTimePeriod: [''],
      IsDelete: [''],
      IsArchive: ['']
    });

    this.getGOEResponse = this.MultiPropertyViewForm.controls.EnvironmentName.valueChanges.pipe(
      startWith(""),
      map((value) => {
        let list = value.length >= 1 ? this.filterGOE(value) : [];
        if (list.length == 1 && list[0].EnvironmentName == value) {
          list = [];
        }
        return list;
      })
    );

    this.getCompanyResponse = this.MultiPropertyViewForm.controls.CompanyName.valueChanges.pipe(
      startWith(""),
      map((value) => {
        let list = value.length >= 1 ? this.filterCompany(value) : [];
        if (list.length == 1 && list[0].CompanyName == value) {
          list = [];
        }
        return list;
      })
    );

    this.getWorkgroupResponse = this.MultiPropertyViewForm.controls.WorkGroupName.valueChanges.pipe(
      startWith(""),
      map((value) => {
        let list = value.length >= 1 ? this.filterWorkgroup(value) : [];
        if (list.length == 1 && list[0].WorkGroupName == value) {
          list = [];
        }
        return list;
      })
    );

    this.GetGlobalEnvironmentByUserIDIR()
    this.getRestrictCompanybyGOE()
    this.getWorkgroupListByCompanyID()
    this.getTimePeriodArray();
    if (environment.onProd == 1) {
      this.UrlPath = environment.imagePath + "opDocs/";
    } else {
      this.UrlPath = environment.imagePath + "opDocs/";
    }
  }

  applyFilter(filterValue: string) {   
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches    
    if (!!filterValue) {
       this.dataSource.filter = filterValue;
    }
  }

  clearFilter(filterValue) {
    this.dataSource.filter = filterValue
  }

  getProperties(workgroupID, compID, goeID) {
    const request = {
      "GlobalEnvironmentID":goeID,
      "CompanyID":compID,
      "WorkgroupID":workgroupID,
      "OPDocsCategoryGroupID":0,
      "OPDocsCategoryID":0
  }
    this.opdocsService.GetOPDocsPropertyList(request).subscribe((res: any) => {
      this.propertyList = res.data.GetOPDocsPropertyList;
    })
  }

  selectedProperties(obj) {
    console.log(this.propertyIndex.findIndex(x => x == obj.PropertyID))
    if (this.propertyIndex.findIndex(x => x == obj.PropertyID) != -1) {
      let index = this.propertyIndex.findIndex(x => x == obj.PropertyID)
      this.propertyIndex.splice(index, 1);
      this.GetOPDocsCategoryListByProperty();
    } else {
      this.propertyIndex.push(obj.PropertyID);
      this.GetOPDocsCategoryListByProperty();
    }
  }

  GetOPDocsCategoryListByProperty() {
    const request = {
      "GlobalEnvironmentID": this.MultiPropertyViewFilters.GlobalEnvironmentID,
      "PropertIDs":this.propertyIndex.join()
  }
    this.opdocsService.GetOPDocsCategoryListByProperty(request).subscribe((res: any) => {
      this.categoryList = res.data.GetOPDocsCategoryListByProperty;
    })
  }

  getTimePeriodArray() {
    this.opdocsService.getTimePeriodArray().subscribe((res: any) => {
      this.timePeriod.push(res);
    });
    this.opdocsService.getCurrentPriorArray().subscribe((res: any)=> {
      this.currentPeriod.push(res);
    });
    this.opdocsService.getFilterValue().subscribe((res:any) => {
      this.deleteArchive.push(res);
    })
  }

  selectedCategory(obj) {
    if (this.categoryIDs.findIndex(x => x == obj.OPDocsCategoryID) != -1) {
      let index = this.categoryIDs.findIndex(x => x == obj.OPDocsCategoryID)
      this.categoryIDs.splice(index, 1);
    } else {
      this.categoryIDs.push(obj.OPDocsCategoryID);
    }
  }

  selectedTableRow(attr){
    if (this.selectedRow.findIndex(x => x == attr.OPFileCategoryPropertyID) != -1) {
        let index = this.selectedRow.findIndex(x => x == attr.OPFileCategoryPropertyID)
        this.selectedRow.splice(index, 1);
        this.tableRow.splice(index, 1);
      } else {
        this.selectedRow.push(attr.OPFileCategoryPropertyID);
        this.tableRow.push(attr);
      }
      console.log(this.tableRow)
  }

  UrlPath: any = "";

  downloadFile() {
    if(this.selectedRow.length > 1) {
      const param = {
        OPFileCategoryPropertyID: this.selectedRow.join()
      }
      this.opdocsService.GetMultiPropertyViewDownload(param).subscribe((res:any) => {
        console.log(res)
        let downloadData = res.data.GetMultiPropertyViewDownload[0];
        if (downloadData) {
          const zipFileName = downloadData.zipPath.split('/')[1]
          this.download(`${this.UrlPath}${zipFileName}`, zipFileName)
        }
      })
    } else if(this.selectedRow.length == 1){
        const name = this.tableRow[0].FileTypeName.split(" ")[1];
        this.download(`${this.UrlPath + 'FileFolder/'}${name}`, name);
    } else {
      this.tostre.warning("Please select any record.");
    }
  }

  download(pdfUrl: string, pdfName: string) {
    fs.saveAs(pdfUrl, pdfName);
  }

  DeleteOPFile(id) {
    const request =    {
      OPFileCategoryPropertyID: id
  }
    this.opdocsService.DeleteOPFileCategoryProperty(request).subscribe((res:any) => {
      console.log(res);
      if(res.status) {
        this.tostre.error(res.data.DeleteOPFileCategoryProperty[0].Message, "", {
          positionClass: "toast-top-right",
        });
        this.saveMultiProperty();
        // if(this.dataSource.data.findIndex(x => x.OPFileID == id)) {
        //   let index = this.dataSource.data.findIndex(x => x.OPFileID == id)
        //   this.dataSource.data.splice(index,1)
        // }
      }
    })
  }

  archiveFile(id) {
    const request =  {
      OPFileCategoryPropertyID: id
  }
    this.opdocsService.ArchiveOPFileCategoryProperty(request).subscribe(res => {
      console.log(res);
    })
  }

  saveMultiProperty() {
      const request = {
        GlobalEnvironmentID : this.MultiPropertyViewFilters.GlobalEnvironmentID,
        PropertIDs: this.propertyIndex.join(),
        OPDocsCategoryIDs: this.categoryIDs.join(),
        UploadedAfter: this.MultiPropertyViewForm.value.UploadedAfter,
        UpoladedBefor: this.MultiPropertyViewForm.value.UpoladedBefor,
        QuickCurrentPrior: this.MultiPropertyViewForm.value.QuickCurrentPrior,
        QuickTimePeriod: this.MultiPropertyViewForm.value.QuickTimePeriod,
        IsDelete:0,
        IsArchive:0
    }
    request.UploadedAfter =
        ("0" + (request.UploadedAfter.getMonth() + 1)).slice(-2) +
        "/" +
        ("0" + request.UploadedAfter.getDate()).slice(-2) +
        "/" +
        request.UploadedAfter.getFullYear();
    request.UpoladedBefor =
        ("0" + (request.UpoladedBefor.getMonth() + 1)).slice(-2) +
        "/" +
        ("0" + request.UpoladedBefor.getDate()).slice(-2) +
        "/" +
        request.UpoladedBefor.getFullYear();
    this.opdocsService.GetOPDocsMultiPropertyViewList(request).subscribe((res: any) => {
      this.dataSource.data = res.data.GetOPDocsMultiPropertyViewList;
    })
  }

  dataChange() {
    if (this.MultiPropertyViewForm.value.UploadedAfter >
      this.MultiPropertyViewForm.value.UpoladedBefor) {
        this.tostre.error("Before date shouild be greater then After date.", "", {
          positionClass: "toast-top-right",
        });
        this.MultiPropertyViewForm.patchValue({
          UploadedAfter: new Date(),
          UpoladedBefor: new Date()
        })
      }
  }


  /**
  * filter dropdown value START.
  */

  private filterGOE(name: string): any {
    const filterValue = name.toLowerCase();
    return this.getgoeList.filter((option) => {
      return option.EnvironmentName.toLowerCase().includes(filterValue);
    });
  }

  private filterCompany(name: string): any {
    const filterValue = name.toLowerCase();
    return this.getCompanyList.filter((option) => {
      return option.CompanyName.toLowerCase().includes(filterValue);
    });
  }

  private filterWorkgroup(name: string): any {
    const filterValue = name.toLowerCase();
    return this.getWorkgroupList.filter((option) => {
      return option.WorkGroupName.toLowerCase().includes(filterValue);
    });
  }

  /**
  * filter dropdown value END.
  */



  /**
  * capture dropdown value START.
  */

  onChangeGOE(event, idProp, id, nameProp, name) {
    if (event.isUserInput) {
      this.MultiPropertyViewFilters[idProp] = id
      this.MultiPropertyViewFilters[nameProp] = name
      // this.getRestrictCompanybyGOE()
    }
  }

  onChangeCompany(event, idProp, id, nameProp, name) {
    if (event.isUserInput) {
      this.MultiPropertyViewFilters[idProp] = id
      this.MultiPropertyViewFilters[nameProp] = name
      this.getWorkgroupListByCompanyID()
      this.getProperties(0, id, this.MultiPropertyViewFilters.GlobalEnvironmentID);
    }
  }

  onChangeWorkGroup(event, idProp, id, nameProp, name) {
    if (event.isUserInput) {
      this.MultiPropertyViewFilters[idProp] = id
      this.MultiPropertyViewFilters[nameProp] = name
      this.getProperties(id, this.MultiPropertyViewFilters.CompanyID, this.MultiPropertyViewFilters.GlobalEnvironmentID);
    }
  }

  /**
  * capture dropdown value END.
  */



  /**
  * autocomplete dropdown value START.
  */

  checkGOE(test) {
    this.getGOEResponse = this.MultiPropertyViewForm.controls.EnvironmentName.valueChanges.pipe(
      startWith(""),
      map((val: any) => (val.length >= 0 ? this.filterGOE(val) : []))
    );
    test.blur();
  }

  checkCompany(test) {
    this.getCompanyResponse = this.MultiPropertyViewForm.controls.CompanyName.valueChanges.pipe(
      startWith(""),
      map((val: any) => (val.length >= 0 ? this.filterCompany(val) : []))
    );
    test.blur();
  }

  checkWorkGroup(test) {
    this.getWorkgroupResponse = this.MultiPropertyViewForm.controls.WorkGroupName.valueChanges.pipe(
      startWith(""),
      map((val: any) => (val.length >= 0 ? this.filterWorkgroup(val) : []))
    );
    test.blur();
  }

  /**
  * autocomplete dropdown value END.
  */



  /**
  * remove dropdown value START.
  */

   removeGOEFilter(prop, nameProp) {
    this.MultiPropertyViewFilters[prop] = "";
    this.MultiPropertyViewFilters[nameProp] = "";
    this.getWorkgroupList = []
    this.MultiPropertyViewFilters['WorkGroupID'] = ""
    this.MultiPropertyViewFilters['WorkGroupName'] = ""
    this.MultiPropertyViewFilters['CompanyID'] = ""
    this.MultiPropertyViewFilters['CompanyName'] = ""
    this.getCompanyList = []
    this.getRestrictCompanybyGOE()
    this.getWorkgroupListByCompanyID()
  }

  removeCompanyFilter(prop, nameProp) {
    this.MultiPropertyViewFilters[prop] = "";
    this.MultiPropertyViewFilters[nameProp] = "";
    this.getWorkgroupList = []
    this.MultiPropertyViewFilters['WorkGroupID'] = ""
    this.MultiPropertyViewFilters['WorkGroupName'] = ""
    this.getWorkgroupListByCompanyID()
  }

  removeWorkGroupFilter(prop, nameProp) {
    this.MultiPropertyViewFilters[prop] = "";
    this.MultiPropertyViewFilters[nameProp] = "";
    this.propertyList = [];
    this.propertyIndex = [];
    this.categoryList = [];
  }


  /**
  * remove dropdown value END.
  */



  /**
  * API calling START.
  */

   GetGlobalEnvironmentByUserIDIR() {
    const param = {
      CurrentUserID: this.UserID,
    };

    this.opdocsService.GetGlobalEnvironmentByUserIDIR(param).subscribe(res => {
      this.getgoeList = res.data.GetGlobalEnvironmentByUserIDIR;
      this.getGOEResponse = this.MultiPropertyViewForm.controls.EnvironmentName.valueChanges.pipe(
        startWith(""),
        map((val: any) => (val.length >= 0 ? this.filterGOE(val) : []))
      );
      if (this.getgoeList && this.getgoeList.length != 0) {
        let UserGOEObj = this.getgoeList.filter(id => id.GlobalEnvironmentID == 1)
        this.MultiPropertyViewFilters["GlobalEnvironmentID"] = UserGOEObj[0].GlobalEnvironmentID;
        this.MultiPropertyViewFilters["EnvironmentName"] = UserGOEObj[0].EnvironmentName;
        this.getProperties(0, 0, this.MultiPropertyViewFilters.GlobalEnvironmentID);
        // this.getRestrictCompanybyGOE()
      }
    })
  }

  getRestrictCompanybyGOE() {
    let params = {
      CurrentUserID: this.UserID,
     }
    this.opdocsService.GetRestrictCompanybyGOE(params).subscribe((res: any) => {
      //  let dupli = res.getRestrictCompanybyGOE;
      //  this.getCompanyList = dupli.filter((ele, index) => dupli.findIndex(obj => obj.CompanyId == ele.CompanyId) == index)
      this.getCompanyList = res.data.GetCompanyByUserIDIR;
      this.getCompanyResponse = this.MultiPropertyViewForm.controls.CompanyName.valueChanges.pipe(
        startWith(""),
        map((val: any) => (val.length >= 0 ? this.filterCompany(val) : []))
      );
    })
  }

  getWorkgroupListByCompanyID() {
    if (this.MultiPropertyViewFilters["CompanyID"] == '') {
      this.MultiPropertyViewFilters["CompanyID"] = "0"
    }
    const data = {
      "CompanyID": +this.MultiPropertyViewFilters["CompanyID"],
    }
    this.opdocsService.getWorkgroupListByCompanyID(data).subscribe(
      (res: any) => {
        this.getWorkgroupList = res.Workgroup;
        this.getWorkgroupResponse = this.MultiPropertyViewForm.controls.WorkGroupName.valueChanges.pipe(
          startWith(""),
          map((val: any) => (val.length >= 0 ? this.filterWorkgroup(val) : []))
        );
      }
    );
  }

  /**
  * API calling END.
  */

}
