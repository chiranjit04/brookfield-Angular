import { TestBed } from '@angular/core/testing';

import { OpdocsService } from './opdocs.service';

describe('OpdocsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: OpdocsService = TestBed.get(OpdocsService);
    expect(service).toBeTruthy();
  });
});
