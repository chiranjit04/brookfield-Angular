import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import { OpdocsRoutingModule } from "./opdocs-routing.module";
import { FileuploadComponent } from "./fileupload/fileupload.component";
import { SinglepropertyviewComponent } from "./singlepropertyview/singlepropertyview.component";
import { MultipropertyviewComponent } from "./multipropertyview/multipropertyview.component";
import { ManagecategoriesComponent } from "./managecategories/managecategories.component";
import { OpdocsComponent } from "./opdocs.component";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { CKEditorModule } from "@ckeditor/ckeditor5-angular";
import { NgxDocViewerModule } from "ngx-doc-viewer";
import { SharedMaterialModule } from "src/app/shared/shared-material.module";
import { SinglePropertyAddDialogComponent } from "./singlepropertyview/single-property-add-dialog/single-property-add-dialog.component";

@NgModule({
  declarations: [
    OpdocsComponent,
    FileuploadComponent,
    SinglepropertyviewComponent,
    MultipropertyviewComponent,
    ManagecategoriesComponent,
    SinglePropertyAddDialogComponent,
  ],
  imports: [
    CommonModule,
    OpdocsRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    SharedMaterialModule,
    CKEditorModule,
    NgxDocViewerModule,
  ],
  entryComponents: [SinglePropertyAddDialogComponent],
})
export class OpdocsModule {}
