import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-opdocs',
  templateUrl: './opdocs.component.html',
  styleUrls: ['./opdocs.component.scss']
})
export class OpdocsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
