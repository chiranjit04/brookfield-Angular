import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '../../../guard/auth.guard';
import { FileuploadComponent } from './fileupload/fileupload.component';
import { ManagecategoriesComponent } from './managecategories/managecategories.component';
import { MultipropertyviewComponent } from './multipropertyview/multipropertyview.component';
import { SinglepropertyviewComponent } from './singlepropertyview/singlepropertyview.component';


// const routes: Routes = [];

// @NgModule({
//   imports: [RouterModule.forChild(routes)],
//   exports: [RouterModule]
// })
// export class OpdocsRoutingModule { }

const routes: Routes = [
  { path: '', canActivate: [AuthGuard], redirectTo: 'fileupload', pathMatch: 'full' },
  { path: 'fileupload', canActivate: [AuthGuard], component: FileuploadComponent },
  { path: 'singlepropertyview', canActivate: [AuthGuard], component: SinglepropertyviewComponent },
  { path: 'multipropertyview', canActivate: [AuthGuard], component: MultipropertyviewComponent },
  { path: 'managecategories', canActivate: [AuthGuard], component: ManagecategoriesComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OpdocsRoutingModule { }
