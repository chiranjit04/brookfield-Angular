import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from "rxjs";
import { HttpClient,HttpHeaders } from "@angular/common/http";
import { environment } from "../../../../environments/environment";
import { of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class OpdocsService {

  url: any;
  constructor(private http: HttpClient) {
    this.url = environment.origin;
  }
  GetGlobalEnvironmentByUserIDIR(data: any): Observable<any> {
    return this.http.post<any>(
      this.url + "api/GetGlobalEnvironmentByUserIDIR",
      data
    );
  }

  // GetRestrictCompanybyGOE(data: any): Observable<any> {
  //   return this.http.post<any>(
  //     this.url + "api/GetRestrictCompanybyGOE",
  //     data
  //   );
  // }
GetRestrictCompanybyGOE(data: any): Observable<any> {
    return this.http.post<any>(
      this.url + "api/GetCompanyByUserIDIR",
      data
    );
  }  

//   getWorkgroupListByCompanyID(data){
//     return this.http.post<any>(
//       `${this.url}api/GetWorkgroupByCompanyID`,
//       data
//       );
//  }

getWorkgroupListByCompanyID(data){
  return this.http.post<any>(
    `${this.url}api/getWorkGroupForUserByCompanyID`,
    data
    );
}

  // GetPropertyByGoeId(data: any): Observable<any> {
  //   return this.http.post<any>(
  //     this.url + "api/GetPropertyByGoeId",
  //     data
  //   );
  // }
/* Api for File Upload Section*/
GetOPFileList(data){
  return this.http.post<any>(
    `${this.url}api/opDocs/GetOPFileList`,
    data
    );  
} 
UpdateOPFile(data){
  return this.http.post<any>(
    `${this.url}api/opDocs/UpdateOPFile`,
    data
    ); 
}
GetOPFileByID(data){
  return this.http.post<any>(
    `${this.url}api/opDocs/GetOPFileByID`,
    data
    ); 
}  
DeleteOPFile(data){
  return this.http.post<any>(
    `${this.url}api/opDocs/DeleteOPFile`,
    data
    ); 
}
ArchiveOPFile(data){
  return this.http.post<any>(
    `${this.url}api/opDocs/ArchiveOPFile`,
    data
    ); 
}
UpdateOPFileCategory(data){
  return this.http.post<any>(
    `${this.url}api/opDocs/UpdateOPFileCategory`,
    data
    ); 
}
GetOPFileCategoryByOPFileID(data){
  return this.http.post<any>(
    `${this.url}api/opDocs/GetOPFileCategoryByOPFileID`,
    data
    ); 
}
UpdateOPFileCategoryProperty(data){
  return this.http.post<any>(
    `${this.url}api/opDocs/UpdateOPFileCategoryProperty`,
    data
    ); 
}
GetOPFileCategoryPropertyID(data){
  return this.http.post<any>(
    `${this.url}api/opDocs/GetOPFileCategoryPropertyID`,
    data
    ); 
}
GetOPDocsPropertyList(data){
  return this.http.post<any>(
    `${this.url}api/opDocs/GetOPDocsPropertyList`,
    data
    ); 
}
UpdateOPFileConfiguration(data){
  return this.http.post<any>(
    `${this.url}api/opDocs/UpdateOPFileConfiguration`,
    data
    ); 
}
UpdateOPFileDistribution(data){
  return this.http.post<any>(
    `${this.url}api/opDocs/UpdateOPFileDistribution`,
    data
    ); 
}
/**/
/* Manage Category Api*/
UpdateOPDocsCategoryGroup(data){
  return this.http.post<any>(
    `${this.url}api/opDocs/UpdateOPDocsCategoryGroup`,
    data
    ); 
}
GetOPDocsCategoryGroupList(data){
  return this.http.post<any>(
    `${this.url}api/opDocs/GetOPDocsCategoryGroupList`,
    data
    ); 
}
GetOPDocsCategoryGroupByID(data){
  return this.http.post<any>(
    `${this.url}api/opDocs/GetOPDocsCategoryGroupByID`,
    data
    ); 
}
OPDocsCategoryGroupStatus(data){
  return this.http.post<any>(
    `${this.url}api/opDocs/OPDocsCategoryGroupStatus`,
    data
    ); 
}
DeleteOPDocsCategoryGroup(data){
  return this.http.post<any>(
    `${this.url}api/opDocs/DeleteOPDocsCategoryGroup`,
    data
    ); 
}
UpdateOPDocsCategory(data){
  return this.http.post<any>(
    `${this.url}api/opDocs/UpdateOPDocsCategory`,
    data
    ); 
}
GetOPDocsCategoryList(data){
  return this.http.post<any>(
    `${this.url}api/opDocs/GetOPDocsCategoryList`,
    data
    ); 
}
GetOPDocsCategoryByID(data){
  return this.http.post<any>(
    `${this.url}api/opDocs/GetOPDocsCategoryByID`,
    data
    ); 
}
OPDocsCategoryStatus(data){
  return this.http.post<any>(
    `${this.url}api/opDocs/OPDocsCategoryStatus`,
    data
    ); 
}
DeleteOPDocsCategory(data){
  return this.http.post<any>(
    `${this.url}api/opDocs/DeleteOPDocsCategory`,
    data
    ); 
}
UpdateOPDocsCategoryGroupCategory(data){
  return this.http.post<any>(
    `${this.url}api/opDocs/UpdateOPDocsCategoryGroupCategory`,
    data
    ); 
}
UpdateOPDocsCategoryGroupProperty(data){
  return this.http.post<any>(
    `${this.url}api/opDocs/UpdateOPDocsCategoryGroupProperty`,
    data
    ); 
}
GetOPDocsPermissionElementList(data){
  return this.http.post<any>(
    `${this.url}api/opDocs/GetOPDocsPermissionElementList`,
    data
    ); 
}

GetPropertyIR(data){
  return this.http.post<any>(
    `${this.url}api/GetPropertyIR`,
    data
    ); 
}

GetOPDocsCategoryListByProperty(data) {
  return this.http.post<any>(
    `${this.url}api/opDocs/GetOPDocsCategoryListByProperty`,
    data
    );
}

GetOPDocsMultiPropertyViewList(request) {
  return this.http.post<any>(
    `${this.url}api/opDocs/GetOPDocsMultiPropertyViewList`,
    request
    );
}

GetOPDocsSinglePropertyViewList(request) {
  return this.http.post<any>(
    `${this.url}api/opDocs/GetOPDocsSinglePropertyViewList`,
    request
    );
}


UpdateOPDocsCategoryPermission(request) {
  return this.http.post<any>(
    `${this.url}api/opDocs/UpdateOPDocsCategoryPermission`,
    request
    );
}


DeleteOPFileCategoryProperty(request) {
  return this.http.post<any>(
    `${this.url}api/opDocs/DeleteOPFileCategoryProperty`,
    request
    );
}

GetMultiPropertyViewDownload(request) {
  return this.http.post<any>(
    `${this.url}api/opDocs/GetMultiPropertyViewDownload`,
    request
    );
}

TrnasferOPFileCategory(request) {
  return this.http.post<any>(
    `${this.url}api/opDocs/TrnasferOPFileCategory`,
    request
    );
}

UpdateOPDocsCategorySingleProperty(request) {
  return this.http.post<any>(
    `${this.url}api/opDocs/UpdateOPDocsCategorySingleProperty`,
    request
    );
}

GetOPDocsCategorySinglePropertyList(request) {
  return this.http.post<any>(
    `${this.url}api/opDocs/GetOPDocsCategorySinglePropertyList`,
    request
    );
}

GetOPDocsCategorySinglePropertyByID(request) {
  return this.http.post<any>(
    `${this.url}api/opDocs/GetOPDocsCategorySinglePropertyByID`,
    request
    );
}

UpdateOPFilePropertyDistribution(request) {
  return this.http.post<any>(
    `${this.url}api/opDocs/UpdateOPFilePropertyDistribution`,
    request
    );
}

ArchiveOPFileCategoryProperty(request) {
  return this.http.post<any>(
    `${this.url}api/opDocs/ArchiveOPFileCategoryProperty`,
    request
    );
}

GetOPDocsJobTitleList(data){
  return this.http.post<any>(
    `${this.url}api/opDocs/GetOPDocsJobTitleList`, data); 
}

getCurrentPriorArray() {
  return of('Current', 'Prior')
}

getTimePeriodArray() {
  return of('Day', 'Week', 'Month', 'Quarter', 'Year', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec')
}

getFilterValue() {
  return of('Delete', 'Archive')
}


/**/

}
