import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { map, startWith } from "rxjs/operators";
import { StorageService } from "src/app/services/storage.service";
import { environment } from "src/environments/environment";
import { OpdocsService } from "../opdocs.service";
import * as fs from "file-saver";
import { ToastrService } from "ngx-toastr";
import { MatDialog } from "@angular/material";
import { SinglePropertyAddDialogComponent } from "./single-property-add-dialog/single-property-add-dialog.component";
import Swal from "sweetalert2";

export interface PeriodicElement {
  name: string;
  position: number;
  weight: number;
  symbol: string;
  ftn: string;
  filesize: string;
  uploadeddate: string;
  uploadedby: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  // { position: 1, name: 'Hydrogen', weight: 1.0079, ftn: 'word abcd', filesize: '520 kb', uploadeddate: 'erret', uploadedby: 'sdfsdf', symbol: 'H' }
];

@Component({
  selector: "app-singlepropertyview",
  templateUrl: "./singlepropertyview.component.html",
  styleUrls: ["./singlepropertyview.component.scss"],
})
export class SinglepropertyviewComponent implements OnInit {
  displayedColumns: string[] = [
    "PropertyName",
    "Category",
    "DocName",
    "Notes",
    "FileTypeName",
    "FileSize",
    "UploadedDate",
    "UplodedBy",
    "Action",
  ];
  dataSource = new MatTableDataSource(ELEMENT_DATA);
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  SinglePropertyViewForm: FormGroup;
  SinglePropertyViewFilters = {
    GlobalEnvironmentID: "",
    EnvironmentName: "",
    FromDate: null,
    ToDate: null,
    Category: "",
    OPDocsCategoryID: "",
    CurrentPrior: "",
    TimePeriod: "",
    FilterValue: "",
    Category2: "",
    OPDocsCategoryID2: ""
  };
  getGOEResponse: any = [];
  getgoeList: any = [];
  getCompanyResponse: any = [];
  getCompanyList: any = [];
  getWorkgroupList: any = [];
  getWorkgroupResponse: any = [];
  userData = null;
  UserID = null;
  PropertyName = "";
  PropertyID = null;
  GlobalEnvironmentID: any;

  mindate: any;
  maxdate: any;

  getCategoryResponse: any = [];
  getCategoryResponse2: any = [];
  getOPDocsCategoryListByProperty: any = [];
  getOPDocsCategoryListByProperty2: any = [];

  getCurrentPriorArray: any = [];
  getTimePeriodArray: any = [];
  getFilterValueArray: any = [];
  tableData: any = [];
  filePath: any = "";
  constructor(
    private dialoagOpener: MatDialog,
    private storage: StorageService,
    private opdocsService: OpdocsService,
    private formBuilder: FormBuilder,
    private tostre: ToastrService
  ) {
    this.userData = JSON.parse(this.storage.getData("UserData"));
    this.UserID = this.userData[0].UserID;
    this.PropertyID = this.userData[0].PropertyID;
    this.PropertyName = this.userData[0].PropertyName;
    this.GlobalEnvironmentID = this.userData[0].GlobalEnvironmentID;
    this.dataSource = new MatTableDataSource([]);
    this.dataSource.sort = this.sort;
  }

  ngOnInit() {

    const todayDate = (new Date().getMonth()+1) + '/' + new Date().getDate() + '/' + new Date().getFullYear()
    this.SinglePropertyViewForm = this.formBuilder.group({
      EnvironmentName: "",
      FromDate: new Date(),
      ToDate: new Date(),
      Category: "",
      CurrentPrior: "",
      TimePeriod: "",
      FilterValue: "",
      Category2: ""
    });

    this.SinglePropertyViewFilters = {
      GlobalEnvironmentID: "",
      EnvironmentName: "",
      FromDate: todayDate,
      ToDate: todayDate,
      Category: "",
      OPDocsCategoryID: "",
      CurrentPrior: "",
      TimePeriod: "",
      FilterValue: "",
      Category2: "",
      OPDocsCategoryID2: ""
    };

    this.getGOEResponse =
      this.SinglePropertyViewForm.controls.EnvironmentName.valueChanges.pipe(
        startWith(""),
        map((value) => {
          let list = value.length >= 1 ? this.filterGOE(value) : [];
          if (list.length == 1 && list[0].EnvironmentName == value) {
            list = [];
          }
          return list;
        })
      );
    this.getCategoryResponse =
      this.SinglePropertyViewForm.controls.Category.valueChanges.pipe(
        startWith(""),
        map((value) => {
          let list = value.length >= 1 ? this.filterCategory(value) : [];
          if (list.length == 1 && list[0].Category == value) {
            list = [];
          }
          return list;
        })
      );

      this.getCategoryResponse2 =
      this.SinglePropertyViewForm.controls.Category2.valueChanges.pipe(
        startWith(""),
        map((value) => {
          let list = value.length >= 1 ? this.filterCategory2(value) : [];
          if (list.length == 1 && list[0].CategoryName == value) {
            list = [];
          }
          return list;
        })
      );

    this.GetGlobalEnvironmentByUserIDIR();
    this.opdocsService.getCurrentPriorArray().subscribe((res) => {
      this.getCurrentPriorArray.push(res);
    });
    this.opdocsService.getTimePeriodArray().subscribe((res) => {
      this.getTimePeriodArray.push(res);
    });
    this.opdocsService.getFilterValue().subscribe((res) => {
      this.getFilterValueArray.push(res);
    });
    if (environment.onProd == 1) {
      this.filePath = environment.imagePath + "opDocs/";
    } else {
      this.filePath = environment.imagePath + "opDocs/";
    }
  }

  public openAddPropertyModel(): void {
    const addPropertyCmpRef = this.dialoagOpener.open(
      SinglePropertyAddDialogComponent,{
        width: "40%",
        maxWidth: "100vw",
        data: {
          sendToPopUpData: {
            UserID: this.UserID,
            GlobalEnvironmentID: this.SinglePropertyViewFilters["GlobalEnvironmentID"],
            PropertyID: this.PropertyID,
          }
        },
        disableClose: true,
        autoFocus: false,
      });
      addPropertyCmpRef.afterClosed().subscribe((result) => {
        this.GetOPDocsCategorySinglePropertyList()
      });
  }


  /**
   * filter dropdown value START.
   */

  private filterGOE(name: string): any {
    const filterValue = name.toLowerCase();
    return this.getgoeList.filter((option) => {
      return option.EnvironmentName.toLowerCase().includes(filterValue);
    });
  }

  private filterCategory(name: string): any {
    const filterValue = name.toLowerCase();
    return this.getOPDocsCategoryListByProperty.filter((option) => {
      return option.Category.toLowerCase().includes(filterValue);
    });
  }

  private filterCategory2(name: string): any {
    const filterValue = name.toLowerCase();
    return this.getOPDocsCategoryListByProperty2.filter((option) => {
      return option.CategoryName.toLowerCase().includes(filterValue);
    });
  }

  /**
   * filter dropdown value END.
   */

  /**
   * capture dropdown value START.
   */

  onChangeGOE(event, idProp, id, nameProp, name) {
    if (event.isUserInput) {
      this.SinglePropertyViewFilters[idProp] = id;
      this.SinglePropertyViewFilters[nameProp] = name;
    }
  }

  onChangeCategory(event, idProp, id, nameProp, name) {
    if (event.isUserInput) {
      this.SinglePropertyViewFilters[idProp] = id;
      this.SinglePropertyViewFilters[nameProp] = name;
    }
  }

  onChangeCategory2(event, idProp, id, nameProp, name) {
    if (event.isUserInput) {
      this.SinglePropertyViewFilters[idProp] = id;
      this.SinglePropertyViewFilters[nameProp] = name;
    }
  }

  /**
   * capture dropdown value END.
   */

  /**
   * autocomplete dropdown value START.
   */

  checkGOE(test) {
    this.getGOEResponse =
      this.SinglePropertyViewForm.controls.EnvironmentName.valueChanges.pipe(
        startWith(""),
        map((val: any) => (val.length >= 0 ? this.filterGOE(val) : []))
      );
    test.blur();
  }

  checkCategory(test) {
    this.getCategoryResponse =
      this.SinglePropertyViewForm.controls.Category.valueChanges.pipe(
        startWith(""),
        map((val: any) => (val.length >= 0 ? this.filterCategory(val) : []))
      );
    test.blur();
  }

  checkCategory2(test) {
    this.getCategoryResponse2 =
      this.SinglePropertyViewForm.controls.Category2.valueChanges.pipe(
        startWith(""),
        map((val: any) => (val.length >= 0 ? this.filterCategory2(val) : []))
      );
    test.blur();
  }

  /**
   * autocomplete dropdown value END.
   */

  /**
   * remove dropdown value START.
   */

  removeGOEFilter(prop, nameProp) {
    this.SinglePropertyViewFilters[prop] = "";
    this.SinglePropertyViewFilters[nameProp] = "";
  }

  removeCategoryFilter(prop, nameProp) {
    this.SinglePropertyViewFilters[prop] = "";
    this.SinglePropertyViewFilters[nameProp] = "";
  }

  removeCategory2Filter(prop, nameProp) {
    this.SinglePropertyViewFilters[prop] = "";
    this.SinglePropertyViewFilters[nameProp] = "";
  }

  /**
   * remove dropdown value END.
   */

  /**
   * API calling START.
   */

  GetGlobalEnvironmentByUserIDIR() {
    const param = {
      CurrentUserID: this.UserID,
    };

    this.opdocsService
      .GetGlobalEnvironmentByUserIDIR(param)
      .subscribe((res) => {
        this.getgoeList = res.data.GetGlobalEnvironmentByUserIDIR;
        this.getGOEResponse =
          this.SinglePropertyViewForm.controls.EnvironmentName.valueChanges.pipe(
            startWith(""),
            map((val: any) => (val.length >= 0 ? this.filterGOE(val) : []))
          );
        if (this.getgoeList && this.getgoeList.length != 0) {
          let UserGOEObj = this.getgoeList.filter(
            (id) => id.GlobalEnvironmentID == 1
          );
          this.SinglePropertyViewFilters["GlobalEnvironmentID"] =
            UserGOEObj[0].GlobalEnvironmentID;
          this.SinglePropertyViewFilters["EnvironmentName"] =
            UserGOEObj[0].EnvironmentName;
          this.GetOPDocsCategoryListByProperty();
          this.GetOPDocsCategorySinglePropertyList()
        }
      });
  }

  GetOPDocsCategoryListByProperty() {
    const param = {
      GlobalEnvironmentID:
        +this.SinglePropertyViewFilters["GlobalEnvironmentID"],
      PropertIDs: this.PropertyID,
    };
    this.opdocsService
      .GetOPDocsCategoryListByProperty(param)
      .subscribe((res: any) => {
        this.getOPDocsCategoryListByProperty =
          res.data.GetOPDocsCategoryListByProperty;
        this.getCategoryResponse =
          this.SinglePropertyViewForm.controls.Category.valueChanges.pipe(
            startWith(""),
            map((val: any) => (val.length >= 0 ? this.filterCategory(val) : []))
          );
      });
  }

  GetOPDocsCategorySinglePropertyList() {

      const param = {
        "GlobalEnvironmentID": +this.SinglePropertyViewFilters["GlobalEnvironmentID"],
        "PropertyID": this.PropertyID
      }
  
      this.opdocsService.GetOPDocsCategorySinglePropertyList(param).subscribe((res: any) => {
        this.getOPDocsCategoryListByProperty2 =
        res.data.GetOPDocsCategorySinglePropertyList;
      this.getCategoryResponse2 =
        this.SinglePropertyViewForm.controls.Category2.valueChanges.pipe(
          startWith(""),
          map((val: any) => (val.length >= 0 ? this.filterCategory2(val) : []))
        );
      })

  }


  /**
   * API calling END.
   */

  /**
   * Filter functions calling Start.
   */

  preventInput() {
    return false;
  }

  showCurrentPriorData(option, lastInputRef) {
    if (lastInputRef != undefined) {
      lastInputRef.blur();
    }
    this.SinglePropertyViewFilters["CurrentPrior"] = option;
  }

  showTimePeriodData(option, lastInputRef) {
    if (lastInputRef != undefined) {
      lastInputRef.blur();
    }
    this.SinglePropertyViewFilters["TimePeriod"] = option;
  }

  showFilterValueData(option, lastInputRef) {
    if (lastInputRef != undefined) {
      lastInputRef.blur();
    }
    this.SinglePropertyViewFilters["FilterValue"] = option;
  }

  customDateSearch(prop, val) {
    this.SinglePropertyViewFilters[prop] = val;
    let month, day, year;
    month = parseInt(val.split("/")[0]);
    day = parseInt(val.split("/")[1]);
    year = parseInt(val.split("/")[2]);

    if (prop === "FromDate") {
      this.mindate = new Date(year, month - 1, day);
    } else {
      this.maxdate = new Date(year, month - 1, day);
    }
  }

  ApplyFilterToTable(str?: any) {
    if (this.SinglePropertyViewFilters["OPDocsCategoryID"] != "") {
      if (str != 'action') {
        this.mainGridID = [];
        this.toDownloadArray = [];
      }
      this.isRightApply = false
      this.SinglePropertyViewFilters["OPDocsCategoryID2"] = ""
      this.SinglePropertyViewFilters["Category2"] = ""
      this.SinglePropertyViewForm.get("Category2").patchValue("")
      const param = {
        GlobalEnvironmentID:
          +this.SinglePropertyViewFilters["GlobalEnvironmentID"],
        PropertID: this.PropertyID,
        OPDocsCategoryID: +this.SinglePropertyViewFilters["OPDocsCategoryID"],
        UploadedAfter: this.SinglePropertyViewFilters["FromDate"] == "" ? null : this.SinglePropertyViewFilters["FromDate"],
        UpoladedBefor: this.SinglePropertyViewFilters["ToDate"] == "" ? null : this.SinglePropertyViewFilters["ToDate"],
        QuickCurrentPrior: this.SinglePropertyViewFilters["CurrentPrior"],
        QuickTimePeriod: this.SinglePropertyViewFilters["TimePeriod"],
        IsDelete:
          this.SinglePropertyViewFilters["FilterValue"] == "Delete" ? 1 : 0,
        IsArchive:
          this.SinglePropertyViewFilters["FilterValue"] == "Archive" ? 1 : 0,
      };
  
      this.opdocsService
        .GetOPDocsSinglePropertyViewList(param)
        .subscribe((res: any) => {
          this.tableData = res.data.GetOPDocsSinglePropertyViewList;
          this.dataSource.data = this.tableData;
          this.dataSource.sort = this.sort;
          this.sort.disableClear = true;
        });
    } else {
      this.tostre.warning('Please Select category first.')
    }
  }

  ApplyFilterToTableRight(str?: any) {
    if (this.SinglePropertyViewFilters["OPDocsCategoryID2"] != "") {
      this.SinglePropertyViewForm = this.formBuilder.group({
        EnvironmentName: this.SinglePropertyViewFilters["EnvironmentName"],
        FromDate: new Date(),
        ToDate: new Date(),
        Category: "",
        CurrentPrior: "",
        TimePeriod: "",
        FilterValue: ""
      });
      const todayDate = (new Date().getMonth()+1) + '/' + new Date().getDate() + '/' + new Date().getFullYear()
  
      this.SinglePropertyViewFilters = {
        GlobalEnvironmentID: this.SinglePropertyViewFilters["GlobalEnvironmentID"],
        EnvironmentName: this.SinglePropertyViewFilters["EnvironmentName"],
        FromDate: todayDate,
        ToDate: todayDate,
        Category: "",
        OPDocsCategoryID: "",
        CurrentPrior: "",
        TimePeriod: "",
        FilterValue: "",
        Category2: this.SinglePropertyViewFilters["Category2"],
        OPDocsCategoryID2: this.SinglePropertyViewFilters["OPDocsCategoryID2"]
      };
  
      if (str != 'action') {
        this.mainGridID = [];
        this.toDownloadArray = [];
      }
      const param = {
        GlobalEnvironmentID:
          +this.SinglePropertyViewFilters["GlobalEnvironmentID"],
        PropertID: this.PropertyID,
        OPDocsCategoryID: +this.SinglePropertyViewFilters["OPDocsCategoryID2"],
        UploadedAfter: null,
        UpoladedBefor: null,
        // UpoladedBefor: this.SinglePropertyViewFilters["ToDate"] == "" ? null : this.SinglePropertyViewFilters["ToDate"],
        QuickCurrentPrior: "",
        QuickTimePeriod: "",
        IsDelete: 0,
        IsArchive: 0 
      };
  
      this.opdocsService
        .GetOPDocsSinglePropertyViewList(param)
        .subscribe((res: any) => {
          this.tableData = res.data.GetOPDocsSinglePropertyViewList;
          this.dataSource.data = this.tableData;
          this.dataSource.sort = this.sort;
          this.sort.disableClear = true;
        });
    } else {
      this.tostre.warning('Please Select category first.')
    }
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }

  isRightApply: any = false
  ApplyRight() {
    this.isRightApply = true
    this.ApplyFilterToTableRight()
  }

  showMessageFileUpload() {
    this.tostre.warning('Please Select category first.')
  }

  /**
   * Filter functions calling Start.
   */

  onFileSelect(event) {
    if (event.target.files && event.target.files.length > 0) {
      this.UpdateOPFile([event.target.files]);
    }
  }

  UpdateOPFile(fileMetaDataArray) {
    const formData = new FormData();
    formData.append("OPDocsCategoryID", this.SinglePropertyViewFilters["OPDocsCategoryID2"]);
    formData.append("GlobalEnvironmentID", this.SinglePropertyViewFilters["GlobalEnvironmentID"]);
    formData.append("PropertyID", this.PropertyID);
    formData.append("FileDesc", null);
    formData.append("CreatedBy", this.UserID);
    fileMetaDataArray.forEach((file) => {
      formData.append("FileName", file);
    });
    this.opdocsService.UpdateOPFilePropertyDistribution(formData).subscribe(
      (res: any) => {
        if (res.status) {
          this.tostre.success(res.message)
          this.ApplyFilterToTableRight();
        }
      },
      (err) => {}
    );
  }


  mainGridID: any = [];
  toDownloadArray: any = [];
  rowHighlight(valID, row) {
    if (!this.mainGridID.includes(valID)) {
      this.mainGridID.push(valID);
      this.toDownloadArray.push({id: valID, val: row});
    } else {
      this.mainGridID = this.mainGridID.filter((item) => item != valID);
      this.toDownloadArray = this.toDownloadArray.filter((item) => item.id != valID)
    }
  }

  MoveFilesTO() {
    if (this.SinglePropertyViewFilters["OPDocsCategoryID2"] != "") {
      if (this.toDownloadArray && this.toDownloadArray.length != 0) {
        let sampleArray = this.toDownloadArray.map(item => item.val.OPFileCategoryPropertyID)
        const param = {
          "OPFileCategoryPropertyID": sampleArray.toString(),
          "OPDocsCategoryID": this.SinglePropertyViewFilters["OPDocsCategoryID2"]
        }
        this.opdocsService.TrnasferOPFileCategory(param).subscribe(res => {
          let zipData = res.data.TrnasferOPFileCategory
          this.tostre.success(res.message)
          this.ApplyFilterToTableRight();
        })
      }
    } else {
      this.tostre.warning('Please Select category first.')
    }
  }

  downloadFile() {
    if (this.mainGridID && this.mainGridID.length == 0) {
      this.tostre.warning("Please select a record.");
    } else {
      event.stopPropagation();
      if (this.toDownloadArray && this.toDownloadArray.length > 1) {
        let sampleArray = this.toDownloadArray.map(item => item.val.OPFileCategoryPropertyID)
        const param = {
          "OPFileCategoryPropertyID": sampleArray.toString()
        }
        this.opdocsService.GetMultiPropertyViewDownload(param).subscribe(res => {
          let zipData = res.data.GetMultiPropertyViewDownload[0]
          if (zipData) {
            const zipFileName = zipData.zipPath.split('/')[1]
            this.download(`${this.filePath}${zipFileName}`, zipFileName)
          }
        })
      } else if (this.toDownloadArray && this.toDownloadArray.length == 1) {
        const name = this.toDownloadArray[0].val.FileTypeName.split(" ")[1];
        this.download(`${this.filePath}${name}`, name);
      }
    }
  }

  download(pdfUrl: string, pdfName: string) {
    fs.saveAs(pdfUrl, pdfName);
  }


  ArchiveRow(data) {
    const param = {
      "OPFileCategoryPropertyID": +data.OPFileCategoryPropertyID
  }

  Swal.fire({
    text: `Are you sure you want to archive this record?`,
    showCancelButton: true,
    width: "30%",
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes",
  }).then((result) => {
    if (result.value) {
      this.opdocsService.ArchiveOPFileCategoryProperty(param).subscribe(res => {
        if (this.isRightApply){
          this.ApplyFilterToTableRight('action')
        } else {
          this.ApplyFilterToTable('action')
        }
      })
    }
  });

  }

  DeleteRow(data) {
    const param = {
      "OPFileCategoryPropertyID": +data.OPFileCategoryPropertyID
  }


  Swal.fire({
    text: `Are you sure you want to delete this record?`,
    showCancelButton: true,
    width: "30%",
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes",
  }).then((result) => {
    if (result.value) {
      this.opdocsService.DeleteOPFileCategoryProperty(param).subscribe(res => {
        if (this.isRightApply){
          this.ApplyFilterToTableRight('action')
        } else {
          this.ApplyFilterToTable('action')
        }
      })
    }
  });

  }

  ViewRow(data) {
    window.open(`${this.filePath}${data.FileTypeName.split(" ")[1]}`, '_blank');
  }

}
