import { Component, HostListener, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { map, startWith } from 'rxjs/operators';
import { StorageService } from 'src/app/services/storage.service';
import { OpdocsService } from '../../opdocs.service';
import Swal from "sweetalert2";
import { ToastrService } from "ngx-toastr";
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-single-property-add-dialog',
  templateUrl: './single-property-add-dialog.component.html',
  styleUrls: ['./single-property-add-dialog.component.scss']
})
export class SinglePropertyAddDialogComponent implements OnInit {


  categoryList: any = []
  getOPDocsCategoryByIDEdit: any = []
  isCategoryAddToggle: boolean = false
  isCategoryUpdateToggle: boolean = false
  categoryName: any = ""
  categoryDesc: any = ""
  oPDocsCategoryID: any = ""
  isCategoryHighlight: any = []


  getOPDocsPermissionElementList: any = []

  isPropertyHighlight: any = false
  propertyList: any = []
  userData = null;
  UserID = null;
  GlobalEnvironmentID: any

  isDocumentCategoriesTab: boolean = true;
  isCategoryPermissionTab: boolean = false;

  getOPDocsJobTitleList: any = []
  isJobTitleHighlight: any = false
  oPDocsPermissionElementID: any = '2'
  // categoriesToAssignToGroup: any = [];
  // propertyToAssignToGroup: any = [];
  PropertyID: any

  constructor(private opdocsService: OpdocsService, public dialogRef: MatDialogRef<SinglePropertyAddDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public singleViewData: any, private tostre: ToastrService) {
      this.UserID = this.singleViewData.sendToPopUpData.UserID
      this.GlobalEnvironmentID = this.singleViewData.sendToPopUpData.GlobalEnvironmentID
      this.PropertyID = this.singleViewData.sendToPopUpData.PropertyID
  }

  ngOnInit() {

    this.GetOPDocsCategorySinglePropertyList()
  }



  /**
  * API calling START.
  */



  GetOPDocsCategorySinglePropertyList() {
    const param = {
      "GlobalEnvironmentID": +this.GlobalEnvironmentID,
      "PropertyID": this.PropertyID
    }

    this.opdocsService.GetOPDocsCategorySinglePropertyList(param).subscribe((res: any) => {
      this.categoryList = res.data.GetOPDocsCategorySinglePropertyList
    })

  }


  GetOPDocsJobTitleList(OPDocsCategoryIDs, OPDocsPermissionElementID) {
    const param = {
      "OPDocsPermissionElementID": +OPDocsPermissionElementID,
      "OPDocsCategoryIDs": OPDocsCategoryIDs.toString()
  }
    this.opdocsService.GetOPDocsJobTitleList(param).subscribe((res: any) => {
      this.getOPDocsJobTitleList = res.data.GetOPDocsJobTitleList
      this.isJobTitleHighlight = false
    })
  }


  GetOPDocsPermissionElementList() {
    const param = {
      "UserID": this.UserID
    }
    this.opdocsService.GetOPDocsPermissionElementList(param).subscribe((res: any) => {
      let response = res.data.GetOPDocsPermissionElementList
      this.getOPDocsPermissionElementList = []
      response.forEach(element => {
        if (element.ElementTitle != 'Access') {
          this.getOPDocsPermissionElementList.push(element)
        }
      });
      this.GetOPDocsJobTitleList(this.isCategoryHighlight, this.oPDocsPermissionElementID)
    })
  }

  UpdateOPDocsCategoryPermission(OPDocsPermissionElementID, JobTitleID, IsAssign) {
    const param = {
      "OPDocsPermissionElementID": +OPDocsPermissionElementID,
      "OPDocsCategoryIDs": this.isCategoryHighlight.toString(),
      "JobTitleID": +JobTitleID,
      "IsAssign": IsAssign
  }

  this.opdocsService.UpdateOPDocsCategoryPermission(param).subscribe(res => {
    this.GetOPDocsJobTitleList(this.isCategoryHighlight, OPDocsPermissionElementID)
  })
  
  }

  /**
  * API calling END.
  */

   selectPermission(OPDocsPermissionElementID) {
     this.oPDocsPermissionElementID = OPDocsPermissionElementID
     this.GetOPDocsJobTitleList(this.isCategoryHighlight, OPDocsPermissionElementID)
   }

   selectJobTitle(obj) {
    if (this.isJobTitleHighlight == obj.JobTitleID || obj.IsSelected == 1) {
      this.isJobTitleHighlight = false
      this.UpdateOPDocsCategoryPermission(this.oPDocsPermissionElementID, obj.JobTitleID, 0)
    } else {
      this.isJobTitleHighlight = obj.JobTitleID
      this.UpdateOPDocsCategoryPermission(this.oPDocsPermissionElementID, obj.JobTitleID, 1)
    }
   }



  /**
  * Category Actions functions START.
  */

  ChangeCategoryStatus(OPDocsCategoryID, status) {
    const param = {
      "OPDocsCategoryID": +OPDocsCategoryID
    }

    let sta = "";

    if (status == false) {
      sta = "activate";
    } else {
      sta = "deactivate";
    }

    Swal.fire({
      text: `Are you sure you want to ${sta} this?`,
      showCancelButton: true,
      width: "30%",
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes",
    }).then((result) => {
      if (result.value) {
        this.opdocsService.OPDocsCategoryStatus(param).subscribe((res: any) => {
          this.GetOPDocsCategorySinglePropertyList()
        })
      }
    });

  }

  EditCategory(obj) {
    this.oPDocsCategoryID = obj.OPDocsCategoryID
    const param = {
      "OPDocsCategoryID": +this.oPDocsCategoryID
    }

    this.opdocsService.GetOPDocsCategorySinglePropertyByID(param).subscribe((res: any) => {
      this.getOPDocsCategoryByIDEdit = res.data.GetOPDocsCategorySinglePropertyByID
      // this.isCategoryAddToggle = true
      this.isCategoryUpdateToggle = true
      this.categoryName = obj.CategoryName
      this.categoryDesc = obj.CategoryDesc
    })
  }

  DeleteCategory(OPDocsCategoryID) {
    const param = {
      "OPDocsCategoryID": +OPDocsCategoryID
    }

    Swal.fire({
      text: 'Are you sure want to delete this category?',
      showCancelButton: true,
      width: "30%",
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes",
    }).then((result) => {
      if (result.value) {
        this.opdocsService.DeleteOPDocsCategory(param).subscribe((res: any) => {
          this.GetOPDocsCategorySinglePropertyList()
        })
      }
    });

  }

  categorySelection(obj) {

    if ((this.isCategoryHighlight.includes(obj.OPDocsCategoryID)) && this.isCategoryUpdateToggle == false) {
      this.isCategoryHighlight = this.isCategoryHighlight.filter((item) => item != obj.OPDocsCategoryID);
    } else {
      this.isCategoryHighlight.push(obj.OPDocsCategoryID)
    }
  }


  /**
  * Category Actions functions END.
  */




  /**
  * Plus Button functions START.
  */

  AddUpdateCategory() {
      // commit 17749 start
      if(this.isCategoryAddToggle == true) {
      this.oPDocsCategoryID = ""
    }
      // commit 17749 end
      const param = {
      "OPDocsCategoryID": (this.oPDocsCategoryID == undefined || this.oPDocsCategoryID == "") ? 0 : +this.oPDocsCategoryID,
      "GlobalEnvironmentID": +this.GlobalEnvironmentID,
      "CategoryName": this.categoryName,
      "CategoryDesc": this.categoryDesc,
      "PropertyID": this.PropertyID
    }

    this.opdocsService.UpdateOPDocsCategorySingleProperty(param).subscribe((res: any) => {
      this.GetOPDocsCategorySinglePropertyList()
      // commit 17749 end
      this.isCategoryAddToggle = false
      this.isCategoryUpdateToggle = false
      this.tostre.success('Document Category Saved Successfully.')
    })
  }

  /**
 * Plus Button functions END.
 */



  /**
  * Category Tab Switch Work START...
  */

  DocumentCategoriesSwitch() {
    this.isDocumentCategoriesTab = true;
    this.isCategoryPermissionTab = false;
    this.getOPDocsJobTitleList = []
  }

  CategoryPermissionSwitch() {
    this.isCategoryPermissionTab = true;
    this.isDocumentCategoriesTab = false;
    this.isCategoryAddToggle = false
    this.oPDocsPermissionElementID = '2'
    // this.isDocumentCategoriesTab1Function()
    this.GetOPDocsPermissionElementList()
  }

  /**
  * Category Tab Switch Work START...
  */




}
