import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SinglePropertyAddDialogComponent } from './single-property-add-dialog.component';

describe('SinglePropertyAddDialogComponent', () => {
  let component: SinglePropertyAddDialogComponent;
  let fixture: ComponentFixture<SinglePropertyAddDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SinglePropertyAddDialogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SinglePropertyAddDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
