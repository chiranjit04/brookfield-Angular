import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SinglepropertyviewComponent } from './singlepropertyview.component';

describe('SinglepropertyviewComponent', () => {
  let component: SinglepropertyviewComponent;
  let fixture: ComponentFixture<SinglepropertyviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SinglepropertyviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SinglepropertyviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
