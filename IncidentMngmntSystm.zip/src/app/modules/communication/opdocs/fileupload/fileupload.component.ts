import { Component, OnInit, HostListener, } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { map, startWith } from 'rxjs/operators';
import { StorageService } from "../../../../services/storage.service";
import {OpdocsService} from "./../opdocs.service";
import { ToastrService } from "ngx-toastr";
import Swal from "sweetalert2";

@Component({
  selector: 'app-fileupload',
  templateUrl: './fileupload.component.html',
  styleUrls: ['./fileupload.component.scss']
})
export class FileuploadComponent implements OnInit {
  show = false;
  userData = null;
  UserID = null;
  goeList: any = [];
  _gId:any;
  fileUploadViewForm: FormGroup;
  fileUploadView = {
    GlobalEnvironmentID: ''
   };
  // fileUploadFilters = {
  //   GlobalEnvironmentID: "",
  // };
  getGOEResponse: any = [];
  getgoeList: any = [];
  GlobalEnvironmentID: any;
  selectedFile1:any = [];
  placeholderTitle:any = "File Name";
  constructor(private storage: StorageService,private opdocsService:OpdocsService,
    private toastr:ToastrService,
    private formBuilder: FormBuilder) {
      this.userData = JSON.parse(this.storage.getData("UserData"));
      this.UserID = this.userData[0].UserID;
      this.GlobalEnvironmentID = this.userData[0].GlobalEnvironmentID;
   }

  ngOnInit() {
   // this.GetGOE();
   this.fileUploadViewForm = this.formBuilder.group({
    GlobalEnvironmentID:  "",
    Company:"",
    Workgroup:"",
    FileDocTitle:"",
    FileAbout:"",
    FileArchiveDays:"",
    FileReadMe:"",
    FileDeleteyDays:""
   });
   this.getGOEList();
   this.getRestrictCompanybyGOE();
   this.getWorkgroupListByCompanyID();
   this.GetOPFileList();
   this.GetOPDocsCategoryList(0,0, this.GlobalEnvironmentID);
   //this.GetPropertyIR();
   this.GetOPDocsPropertyList();
  }
selectedFilesList:any = [];  
onFileSelect(event) {
    if(event.target.files.length > 1){
      for (var i = 0; i < event.target.files.length; i++) { 
        this.selectedFile1.push(event.target.files[i]);
         this.selectedFilesList.push(this.selectedFile1);
      }
      this.UpdateOPFile();
    }else{
    this.selectedFile1.push(event.target.files[0]);
    let name:string = event.target.files[0].name;
    let fileName = name.split('.');
    this.UpdateOPFile(fileName[0]);
    }
} 
numberOnly(event): boolean {
  const charCode = (event.which) ? event.which : event.keyCode;
  if (charCode > 31 && (charCode < 48 || charCode > 57)) {
    return false;
  }
  return true;

} 
firstSaveApi(hiddenfileinput: any){
  hiddenfileinput.click();
}
clearAllFiles(){
 this.OPFileID = 0;
 this.getSelectedOPFileLeft = [];
 let arr = [];
 this.OPFileList.forEach(element => {
    arr.push(element.OPFileID);
 });
 let OPFileIDs = arr.toString();
//  this.fileUploadViewForm.patchValue({
//    FileDocTitle: '',
//    FileAbout: '',
//    FileArchiveDays: '',
//    FileReadMe: false,
//    FileDeleteyDays: '',
//  });
 this.placeholderTitle = "Filename";
 this.fileUploadViewForm.controls['FileDocTitle'].enable();
 this.DeleteOPFile(OPFileIDs);
}
getGOEList(){
  const param = {
    CurrentUserID: this.UserID,
   };
   this.opdocsService.GetGlobalEnvironmentByUserIDIR(param).subscribe(res => {
     this.getgoeList = res.data.GetGlobalEnvironmentByUserIDIR;
     this.getGOEResponse = this.fileUploadViewForm.controls.GlobalEnvironmentID.valueChanges.pipe(
       startWith(""),
       map((val: any) => (val.length >= 0 ? this.filterProperty(val) : []))
     );
     if (this.getgoeList && this.getgoeList.length != 0) {
      let UserGOEObj = this.getgoeList.filter(id => id.GlobalEnvironmentID == this.GlobalEnvironmentID)
     // this.fileUploadView.EnvironmentName = UserGOEObj[0].EnvironmentName;
     // this.fileUploadFilters["GlobalEnvironmentID"] = UserGOEObj[0].GlobalEnvironmentID;
      this.fileUploadViewForm.controls['GlobalEnvironmentID'].patchValue(UserGOEObj[0].EnvironmentName);
      this.fileUploadView.GlobalEnvironmentID = this.GlobalEnvironmentID;
    }
    })

 

   this.getGOEResponse = this.fileUploadViewForm.controls.GlobalEnvironmentID.valueChanges.pipe(
     startWith(""),
     map((value) => {
       let list = value.length >= 1 ? this.filterProperty(value) : [];
       if (list.length == 1 && list[0].EnvironmentName == value) {
         list = [];
       }
       return list;
      })
    );
}
private filterProperty(name: string): any {
    const filterValue = name.toLowerCase();
    return this.getgoeList.filter((option) => {
      return option.EnvironmentName.toLowerCase().includes(filterValue);
    });
  }
private filterCompany(name: string): any {
    const filterValue = name.toLowerCase();
    return this.getCompanyList.filter((option) => {
      return option.CompanyName.toLowerCase().includes(filterValue);
    });
  } 
private filterWorkgroup(name: string): any {
    const filterValue = name.toLowerCase();
    return this.getWorkgroupList.filter((option) => {
      return option.WorkGroupName.toLowerCase().includes(filterValue);
    });
  }    

chcekGOE(test) {
    this.getGOEResponse = this.fileUploadViewForm.controls.GlobalEnvironmentID.valueChanges.pipe(
      startWith(""),
      map((val: any) => (val.length >= 0 ? this.filterProperty(val) : []))
    );
    test.blur();
  }
chcekCompany(test) {
    this.getCompanyResponse = this.fileUploadViewForm.controls.Company.valueChanges.pipe(
      startWith(""),
      map((val: any) => (val.length >= 0 ? this.filterCompany(val) : []))
    );
    test.blur();
  } 
chcekWorkgroup(test) {
    this.getWorkgroupResponse = this.fileUploadViewForm.controls.Workgroup.valueChanges.pipe(
      startWith(""),
      map((val: any) => (val.length >= 0 ? this.filterWorkgroup(val) : []))
    );
    test.blur();
  }   

  removeFilter(event, prop) {
  //  this.fileUploadFilters[prop] = "";
    this.fileUploadViewForm.controls['GlobalEnvironmentID'].patchValue("");
    this.GlobalEnvironmentID = 0;
    this.fileUploadView.GlobalEnvironmentID = '';
    this.CompanyID = 0;
    this.WorkgroupID = 0;
    this.fileUploadViewForm.controls['Workgroup'].patchValue("");
    this.fileUploadViewForm.controls['Company'].patchValue("");
    this.GetOPDocsCategoryList(0,0,this.GlobalEnvironmentID);
    this.getWorkgroupListByCompanyID();
   // this.GetPropertyIR();
    this.GetOPDocsPropertyList();
  }
  removeWorkGroupFilter(event, prop){
    this.fileUploadViewForm.controls['Workgroup'].patchValue("");
    this.WorkgroupID = 0;
    this.GetOPDocsCategoryList(0,0,this.GlobalEnvironmentID);
    this.getWorkgroupListByCompanyID();
  //  this.GetPropertyIR();
    this.GetOPDocsPropertyList();
  }
  changeShowAll(event, prop, value) {
    if (event.isUserInput) {
      this.GlobalEnvironmentID = value;
      this.fileUploadView.GlobalEnvironmentID = value;
      // this.CompanyID = 0;
      // this.WorkgroupID = 0;
      // this.fileUploadViewForm.controls['Workgroup'].patchValue("");
      // this.fileUploadViewForm.controls['Company'].patchValue("");
      this.GetOPDocsCategoryList(0,0,this.GlobalEnvironmentID);
     // this.GetPropertyIR();
     this.GetOPDocsPropertyList();
    }
  }
  CompanyID:any = '';
  changeCompany(event,value){
     if(event.isUserInput){
       this.CompanyID = value;
       this.WorkgroupID = 0;
       this.fileUploadViewForm.controls['Workgroup'].patchValue("");
       this.getWorkgroupListByCompanyID();
      // this.GetPropertyIR();
       this.GetOPDocsPropertyList();
     }
  }
  WorkgroupID:any = 0;
  changeWorkgroup(event,value){
    if(event.isUserInput){
      this.WorkgroupID = value;
     // this.GetPropertyIR();
      this.GetOPDocsPropertyList();
    }
 }
  removeCompanyFilter(event,prop){
     this.fileUploadViewForm.controls['Company'].patchValue("");
     this.CompanyID = 0;
     this.getWorkgroupListByCompanyID();
    // this.GetPropertyIR();
     this.GetOPDocsPropertyList();
  }
  getCompanyList:any = [];
  getCompanyResponse:any;
  getRestrictCompanybyGOE(){
     let params = {
      CurrentUserID: this.UserID,
     }
     this.opdocsService.GetRestrictCompanybyGOE(params).subscribe((res:any)=>{
      this.getCompanyList = res.data.GetCompanyByUserIDIR;
      this.getCompanyResponse = this.fileUploadViewForm.controls.Company.valueChanges.pipe(
        startWith(""),
        map((val: any) => (val.length >= 0 ? this.filterCompany(val) : []))
      );
     },
     err=>{

     })
     this.getCompanyResponse = this.fileUploadViewForm.controls.Company.valueChanges.pipe(
      startWith(""),
      map((value) => {
        let list = value.length >= 1 ? this.filterCompany(value) : [];
        if (list.length == 1 && list[0].CompanyName == value) {
          list = [];
        }
        return list;
       })
     );  
  }
getWorkgroupList:any = [];
getWorkgroupResponse:any;
getWorkgroupListByCompanyID(){
   if(this.CompanyID == ''){
     this.CompanyID = 0;
   }
  //  let data = {
  //   CompanyID: parseInt(this.CompanyID), 
  //   WorkGroupTypeId: 0
  //  }
  const data = {
    "CompanyID": parseInt(this.CompanyID),
  }
  this.opdocsService.getWorkgroupListByCompanyID(data).subscribe(
    (res:any)=>{
      this.getWorkgroupList = res.Workgroup;
      this.getWorkgroupResponse = this.fileUploadViewForm.controls.Workgroup.valueChanges.pipe(
        startWith(""),
        map((val: any) => (val.length >= 0 ? this.filterWorkgroup(val) : []))
      );
    },
    err =>{

    }
  );
  this.getWorkgroupResponse = this.fileUploadViewForm.controls.Workgroup.valueChanges.pipe(
    startWith(""),
    map((value) => {
      let list = value.length >= 1 ? this.filterWorkgroup(value) : [];
      if (list.length == 1 && list[0].WorkGroupName == value) {
        list = [];
      }
      return list;
     })
   );  
}  

// distribute(){
//   let FileDocTitle = this.fileUploadViewForm.controls['FileDocTitle'].value;
//   let FileAbout = this.fileUploadViewForm.controls['FileAbout'].value;
//   let FileArchiveDays = this.fileUploadViewForm.controls['FileArchiveDays'].value;
//   let FileReadMe = this.fileUploadViewForm.controls['FileReadMe'].value;
//   let FileDeleteyDays = this.fileUploadViewForm.controls['FileDeleteyDays'].value;
//   let obj = {
//     FileDocTitle:FileDocTitle,
//     FileAbout:FileAbout,
//     FileArchiveDays:FileArchiveDays,
//     FileReadMe:FileReadMe,
//     FileDeleteyDays:FileDeleteyDays
//   }
//   console.log("obj---->",obj);
// }
OPFileList:any = [];
GetOPFileList(){
  let params = {
    "UserID":this.UserID,
    "GlobalEnvironmentID":this.GlobalEnvironmentID
  }
  this.opdocsService.GetOPFileList(params).subscribe(
    (res:any)=>{
        let data = res.data;
        this.OPFileList = data.GetOPFileList;
    },
    err =>{

    }
  )
}
UpdateOPFile(FileName?:any){
  /*params should be in form data*/
  // let fileTitle  = this.fileUploadViewForm.controls['FileDocTitle'].value;
  // let fileAbout  = this.fileUploadViewForm.controls['FileAbout'].value;
  if(FileName == undefined){
    FileName = "Multiple Files Selected";
  }
  const formData = new FormData();
  formData.append("OPFileID",'0');
  formData.append("GlobalEnvironmentID",this.GlobalEnvironmentID);
  formData.append("FileTitle",FileName);
  formData.append("FileDesc",'');
  this.selectedFile1.forEach((file) => { formData.append('FileName', file); });
 // formData.append("FileName",this.selectedFile1);
  formData.append("CreatedBy",this.UserID);
  this.opdocsService.UpdateOPFile(formData).subscribe(
    (res:any)=>{
        if(res.status){
          this.GetOPFileList();
        }
    },
    err =>{

    }
  )
}
DeleteOPFile(OPFileID:any,event?:any){
  if(event != undefined){
  event.stopPropagation();
  }
  let params = {
    "OPFileIDs":OPFileID
  }

  Swal.fire({
    text: 'Are you sure want to delete this File?',
    showCancelButton: true,
    width: "30%",
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText: "Yes",
  }).then((result) => {
    if (result.value) {
      this.opdocsService.DeleteOPFile(params).subscribe(
        (res:any)=>{
             if(res.status){
               let data = res.data.DeleteOPFile;
               this.toastr.success(data[0].Message);
               this.GetOPFileList();
             }
        },
        err =>{
          
        }
      )
    }
  });
}
categoryList: any = [];
GetOPDocsCategoryList(OPDocsCategoryID, OPDocsCategoryGroupID, GlobalEnvironmentID) {
  const param = {
    "OPDocsCategoryID": +OPDocsCategoryID,
    "GlobalEnvironmentID": +GlobalEnvironmentID,
    "OPDocsCategoryGroupID": +OPDocsCategoryGroupID
}

this.opdocsService.GetOPDocsCategoryList(param).subscribe((res: any) => {
  this.categoryList = res.data.GetOPDocsCategoryList
})
  
}
propertyList:any = [];
GetOPDocsPropertyList(){
  if(this.CompanyID == ''){
    this.CompanyID = 0;
  }
  if(this.WorkgroupID == ''){
    this.WorkgroupID = 0;
  }
  const param = {
    "GlobalEnvironmentID":this.GlobalEnvironmentID,
    "CompanyID":this.CompanyID,
    "WorkgroupID":this.WorkgroupID,
    "OPDocsCategoryGroupID":0,
    "OPDocsCategoryID":this.CategoryID
  }
  this.opdocsService.GetOPDocsPropertyList(param).subscribe(
    (res:any)=>{
      this.propertyList = res.data.GetOPDocsPropertyList;
    },
    err =>{

    }
  )
}
CategoryID:any = 0;
selectCategory(comp){
  if(this.CategoryID == comp.OPDocsCategoryID){
    this.CategoryID = 0;
    this.GetOPDocsPropertyList();
    return;
  }
  this.CategoryID = comp.OPDocsCategoryID;
  this.GetOPDocsPropertyList();
}
OPFileID:any = 0;
// selectFile(file:any){
//    if(this.OPFileID == file.OPFileID){
//      this.OPFileID = 0;
//      this.fileUploadViewForm.patchValue({
//       FileDocTitle: '',
//       FileAbout: '',
//       FileArchiveDays: '',
//       FileReadMe: false,
//       FileDeleteyDays: '',
//     });
//      return ;
//    }
//    this.OPFileID = file.OPFileID
//    this.fileUploadViewForm.patchValue({
//     FileDocTitle: file.FileTitle,
//     FileAbout: file.FileDesc,
//     FileArchiveDays: file.ArchiveIn,
//     FileReadMe: file.IsReaMe,
//     FileDeleteyDays: file.DeleteIn,
//   });
// }
UpdateOPFileConfiguration(){
   // this.GetGOE();
  let FileDesc = this.fileUploadViewForm.controls['FileAbout'].value;
  let FileTitle = this.fileUploadViewForm.controls['FileDocTitle'].value;
  let ArchiveIn = this.fileUploadViewForm.controls['FileArchiveDays'].value;
  let DeleteIn = this.fileUploadViewForm.controls['FileDeleteyDays'].value;
  let IsReaMe = this.fileUploadViewForm.controls['FileReadMe'].value;
  let OPFilesID = this.channgeFileArrayIntoString();
  if(IsReaMe){
    IsReaMe = 1;
  }else{
    IsReaMe = 0;
  }
  let params = {
    "OPFileIDs":OPFilesID,
    "FileTitle":FileTitle,
    "FileDesc":FileDesc,
    "ArchiveIn":ArchiveIn,
    "DeleteIn":DeleteIn,
    "IsReaMe":IsReaMe
  }
  this.opdocsService.UpdateOPFileConfiguration(params).subscribe(
    (res:any)=>{
        if(res.status){
          this.toastr.success("Record Updated Successfully");
          this.GetOPFileList();
        }
    },
    err =>{

    }
  )
}

UpdateOPFileDistribution(){
  let propertyIDs = this.channgePropertyArrayIntoString();
  let OPFIleIDs = this.channgeFileArrayIntoString();
  console.log("opfileIds and propertyids,category",propertyIDs,OPFIleIDs,this.CategoryID);
  if(OPFIleIDs == ''){
    this.toastr.warning("Please select files first.");
    return ;
  }
  if(this.CategoryID == 0){
    this.toastr.warning("Please select category.");
    return ;
  }
  if(propertyIDs == ''){
    this.toastr.warning("Please select property.");
    return ;
  }
  let FileDesc = this.fileUploadViewForm.controls['FileAbout'].value;
  let FileTitle = this.fileUploadViewForm.controls['FileDocTitle'].value;
  let ArchiveIn = this.fileUploadViewForm.controls['FileArchiveDays'].value;
  let DeleteIn = this.fileUploadViewForm.controls['FileDeleteyDays'].value;
  let IsReaMe = this.fileUploadViewForm.controls['FileReadMe'].value;
  let params = {
    "OPDocsCategoryID":this.CategoryID,
    "OPFileIDs":OPFIleIDs,
    "PropertyIDs":propertyIDs,
    "FileTitle":FileTitle,
    "FileDesc":FileDesc,
    "ArchiveIn":ArchiveIn,
    "DeleteIn":DeleteIn,
    "IsReaMe":IsReaMe
  }
  console.log("Distribute Params",params);
  this.opdocsService.UpdateOPFileDistribution(params).subscribe(
    (res:any)=>{
       if(res.status){
         let data = res.data.UpdateOPFileDistribution;
         this.toastr.success("Files are distributed successfully");
         this.fileUploadViewForm.patchValue({
          FileDocTitle: '',
          FileAbout: '',
          FileArchiveDays: '',
          FileReadMe: false,
          FileDeleteyDays: '',
        });
        this.getSelectedPropertyLeft = [];
        this.getSelectedOPFileLeft = [];
        this.CategoryID = 0;
        this.GetOPDocsPropertyList();
       }
    },
    err =>{

    }
  )
}
ctrl = false;
testDummy = false;
flag = true;
@HostListener("window:keydown", ["$event"])
keyDownCtrl(event: KeyboardEvent) {
  if (event.keyCode === 17) this.ctrl = true;

  if (event.shiftKey) {
    this.ctrl = true;
    this.testDummy = true;
  }
}

@HostListener("window:keyup", ["$event"])
keyUpCtrl(event: KeyboardEvent) {
  if (event.keyCode === 17) this.ctrl = false;

  this.flag = true;
  this.testDummy = false;
  this.ctrl = false;
}
getSelectedPropertyLeft:any = [];
propertyId:any ;
/* ctrl+ and shift+ selection code for property*/ 
onDWRPropertySelect(value: any) {
  this.propertyId = value.PropertyID;
  if (!this.ctrl) {
    this.getSelectedPropertyLeft.length = 1;

    if (this.getSelectedPropertyLeft[0]) {
      if (this.getSelectedPropertyLeft[0].PropertyID == value.PropertyID) {
        this.getSelectedPropertyLeft = [];
      } else {
        this.getSelectedPropertyLeft[0] = value;
      }
    } else {
      this.getSelectedPropertyLeft[0] = value;
    }
    return;
  }

  let indexOfExistsItem = this.getSelectedPropertyLeft.findIndex(
    (accu: { [key: string]: string | number }) =>
      accu.PropertyID == value.PropertyID
  );
  if (indexOfExistsItem >= 0) {
    this.getSelectedPropertyLeft.splice(indexOfExistsItem, 1);
  } else {
    this.getSelectedPropertyLeft.push(value);
  }
  if (this.testDummy) {
    this.getSelectedPropertyLeft.push(value);
    this.sortDataLeftProperty();
  }
}
sortDataLeftProperty() {
  if (this.flag) {
    let indexes = this.getSelectedPropertyLeft
      .map((accu) => {
        return this.propertyList.findIndex((elem) => {
          if (elem.PropertyID == accu.PropertyID) {
            return true;
          }
        });
      })
      .sort();

    this.flag = false;
    this.getSelectedPropertyLeft = [];
    let temp = [indexes[0], indexes[indexes.length - 1]];
    indexes = [];
    for (let i = temp[0]; i <= temp[1]; i++) {
      indexes.push(i);
    }

    indexes.forEach((elem) => {
      this.getSelectedPropertyLeft.push(this.propertyList[elem]);
    });
  }
}

findIndexOfLeftProperty(prop) {
  let indexOfExistsItem = this.getSelectedPropertyLeft.findIndex(
    (accu: { [key: string]: string | number }) =>
      accu.PropertyID == prop.PropertyID
  );

  if (indexOfExistsItem >= 0) {
    return "selected";
  } else {
    return "";
  }
}
channgePropertyArrayIntoString() {
  let arr = []
  if (this.getSelectedPropertyLeft.length > 0) {
    this.getSelectedPropertyLeft.forEach(element => {
      arr.push(element.PropertyID);
    });
    return arr.toString();
  } else {
    return '';
  }
}
/**/
/*ctrl+ and shift+ selection code for files*/
getSelectedOPFileLeft:any = [];
//OPFIleId:any ;
onOPFileSelect(value: any) {
  this.OPFileID = value.OPFileID;
  let fileName = value.FileName;
  let nfileName = fileName.split('.');
  if (!this.ctrl) {
    this.getSelectedOPFileLeft.length = 1;

    if (this.getSelectedOPFileLeft[0]) {
      if (this.getSelectedOPFileLeft[0].OPFileID == value.OPFileID) {
        this.getSelectedOPFileLeft = [];
        this.fileUploadViewForm.patchValue({
          FileDocTitle: ''
        });
        this.placeholderTitle = "File Name";
        this.fileUploadViewForm.controls['FileDocTitle'].enable();
      } else {
        this.getSelectedOPFileLeft[0] = value;
        this.fileUploadViewForm.patchValue({
          FileDocTitle: nfileName[0],
        });
        this.placeholderTitle = "File Name";
        this.fileUploadViewForm.controls['FileDocTitle'].enable();
      }
    } else {
      this.getSelectedOPFileLeft[0] = value;
      this.fileUploadViewForm.patchValue({
        FileDocTitle: nfileName[0],
      });
      this.placeholderTitle = "File Name";
      this.fileUploadViewForm.controls['FileDocTitle'].enable();
    }
    return;
  }
  this.placeholderTitle = "Multiple Files Selected";
  this.fileUploadViewForm.patchValue({
    FileDocTitle: '',
  });
  this.fileUploadViewForm.controls['FileDocTitle'].disable();
  let indexOfExistsItem = this.getSelectedOPFileLeft.findIndex(
    (accu: { [key: string]: string | number }) =>
      accu.OPFileID == value.OPFileID
  );
  if (indexOfExistsItem >= 0) {
    this.getSelectedOPFileLeft.splice(indexOfExistsItem, 1);
  } else {
    this.getSelectedOPFileLeft.push(value);
  }
  if (this.testDummy) {
    this.getSelectedOPFileLeft.push(value);
    this.sortOPFile();
  }
}
sortOPFile() {
  if (this.flag) {
    let indexes = this.getSelectedOPFileLeft
      .map((accu) => {
        return this.OPFileList.findIndex((elem) => {
          if (elem.OPFileID == accu.OPFileID) {
            return true;
          }
        });
      })
      .sort();

    this.flag = false;
    this.getSelectedOPFileLeft = [];
    let temp = [indexes[0], indexes[indexes.length - 1]];
    indexes = [];
    for (let i = temp[0]; i <= temp[1]; i++) {
      indexes.push(i);
    }

    indexes.forEach((elem) => {
      this.getSelectedOPFileLeft.push(this.OPFileList[elem]);
    });
  }
}

findIndexOfLeftFile(prop) {
  let indexOfExistsItem = this.getSelectedOPFileLeft.findIndex(
    (accu: { [key: string]: string | number }) =>
      accu.OPFileID == prop.OPFileID
  );

  if (indexOfExistsItem >= 0) {
    return "selected";
  } else {
    return "";
  }
}
channgeFileArrayIntoString() {
  let arr = []
  if (this.getSelectedOPFileLeft.length > 0) {
    this.getSelectedOPFileLeft.forEach(element => {
      arr.push(element.OPFileID);
    });
    return arr.toString();
  } else {
    return '';
  }
}
/**/  

  toggle() {
    this.show = !this.show

    // if(this.show) {
    // this.buttonName = 'Hide'
    // console.log(this.show)
    // }
    // else {
    // this.buttonName = 'Show'
    // }
  }
}
