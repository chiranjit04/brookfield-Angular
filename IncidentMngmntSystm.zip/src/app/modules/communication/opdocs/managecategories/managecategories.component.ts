import { Component, HostListener, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { map, startWith } from 'rxjs/operators';
import { StorageService } from 'src/app/services/storage.service';
import { OpdocsService } from '../opdocs.service';
import Swal from "sweetalert2";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: 'app-managecategories',
  templateUrl: './managecategories.component.html',
  styleUrls: ['./managecategories.component.scss']
})
export class ManagecategoriesComponent implements OnInit {
  ManageCategoryViewForm: FormGroup;
  ManageCategoryViewFilters = {
    GlobalEnvironmentID: "",
    EnvironmentName: "",
    CompanyID: "",
    CompanyName: "",
    WorkGroupName: "",
    WorkGroupID: ""
  };
  getGOEResponse: any = [];
  getgoeList: any = [];
  getCompanyResponse: any = [];
  getCompanyList: any = [];
  getWorkgroupList: any = [];
  getWorkgroupResponse: any = [];


  groupCategoryList: any = []
  getOPDocsCategoryGroupByIDEdit: any = []
  isCategoryGroupAddToggle: boolean = false
  isCategoryGroupUpdateToggle: boolean = false
  categoryGroupName: any = ""
  categoryGroupDesc: any = ""
  oPDocsCategoryGroupID: any = ""
  isCategoryGroupHighlight: any = false


  categoryList: any = []
  getOPDocsCategoryByIDEdit: any = []
  isCategoryAddToggle: boolean = false
  isCategoryUpdateToggle: boolean = false
  categoryName: any = ""
  categoryDesc: any = ""
  oPDocsCategoryID: any = ""
  isCategoryHighlight: any = []


  getOPDocsPermissionElementList: any = []

  isPropertyHighlight: any = false
  propertyList: any = []
  userData = null;
  UserID = null;
  GlobalEnvironmentID: any

  isDocumentCategoriesTab: boolean = true;
  isCategoryPermissionTab: boolean = false;

  getOPDocsJobTitleList: any = []
  isJobTitleHighlight: any = false
  oPDocsPermissionElementID: any = '1'
  // categoriesToAssignToGroup: any = [];
  // propertyToAssignToGroup: any = [];

  constructor(private storage: StorageService, private opdocsService: OpdocsService, private formBuilder: FormBuilder,
    private tostre: ToastrService) {
    this.userData = JSON.parse(this.storage.getData("UserData"));
    this.UserID = this.userData[0].UserID;
    this.GlobalEnvironmentID = this.userData[0].GlobalEnvironmentID;
  }

  ngOnInit() {

    this.ManageCategoryViewForm = this.formBuilder.group({
      EnvironmentName: "",
      CompanyName: "",
      WorkGroupName: ""
    });

    this.getGOEResponse = this.ManageCategoryViewForm.controls.EnvironmentName.valueChanges.pipe(
      startWith(""),
      map((value) => {
        let list = value.length >= 1 ? this.filterGOE(value) : [];
        if (list.length == 1 && list[0].EnvironmentName == value) {
          list = [];
        }
        return list;
      })
    );

    this.getCompanyResponse = this.ManageCategoryViewForm.controls.CompanyName.valueChanges.pipe(
      startWith(""),
      map((value) => {
        let list = value.length >= 1 ? this.filterCompany(value) : [];
        if (list.length == 1 && list[0].CompanyName == value) {
          list = [];
        }
        return list;
      })
    );

    this.getWorkgroupResponse = this.ManageCategoryViewForm.controls.WorkGroupName.valueChanges.pipe(
      startWith(""),
      map((value) => {
        let list = value.length >= 1 ? this.filterWorkgroup(value) : [];
        if (list.length == 1 && list[0].WorkGroupName == value) {
          list = [];
        }
        return list;
      })
    );

    this.GetGlobalEnvironmentByUserIDIR()
    this.getRestrictCompanybyGOE()
    this.getWorkgroupListByCompanyID()
    this.GetOPDocsCategoryGroupList(this.GlobalEnvironmentID)
    this.GetOPDocsCategoryList(0, 0, this.GlobalEnvironmentID)
    this.GetOPDocsPropertyList(0, 0, 0, 0, this.GlobalEnvironmentID)
  }


  /**
  * filter dropdown value START.
  */

  private filterGOE(name: string): any {
    const filterValue = name.toLowerCase();
    return this.getgoeList.filter((option) => {
      return option.EnvironmentName.toLowerCase().includes(filterValue);
    });
  }

  private filterCompany(name: string): any {
    const filterValue = name.toLowerCase();
    return this.getCompanyList.filter((option) => {
      return option.CompanyName.toLowerCase().includes(filterValue);
    });
  }

  private filterWorkgroup(name: string): any {
    const filterValue = name.toLowerCase();
    return this.getWorkgroupList.filter((option) => {
      return option.WorkGroupName.toLowerCase().includes(filterValue);
    });
  }

  /**
  * filter dropdown value END.
  */



  /**
  * capture dropdown value START.
  */

  onChangeGOE(event, idProp, id, nameProp, name) {
    if (event.isUserInput) {
      this.ManageCategoryViewFilters[idProp] = id
      this.ManageCategoryViewFilters[nameProp] = name
      // this.getRestrictCompanybyGOE()
      this.GetOPDocsCategoryGroupList(this.ManageCategoryViewFilters["GlobalEnvironmentID"])
      this.GetOPDocsCategoryList(0, 0, this.ManageCategoryViewFilters["GlobalEnvironmentID"])
      this.GetOPDocsPropertyList(this.ManageCategoryViewFilters["CompanyID"], this.ManageCategoryViewFilters["WorkGroupID"], 0, 0, this.ManageCategoryViewFilters["GlobalEnvironmentID"])
    }
  }

  onChangeCompany(event, idProp, id, nameProp, name) {
    if (event.isUserInput) {
      this.ManageCategoryViewFilters[idProp] = id
      this.ManageCategoryViewFilters[nameProp] = name
      this.getWorkgroupListByCompanyID()
      this.GetOPDocsPropertyList(this.ManageCategoryViewFilters["CompanyID"], this.ManageCategoryViewFilters["WorkGroupID"], 0, 0, this.ManageCategoryViewFilters["GlobalEnvironmentID"])
    }
  }

  onChangeWorkGroup(event, idProp, id, nameProp, name) {
    if (event.isUserInput) {
      this.ManageCategoryViewFilters[idProp] = id
      this.ManageCategoryViewFilters[nameProp] = name
      this.GetOPDocsPropertyList(this.ManageCategoryViewFilters["CompanyID"], this.ManageCategoryViewFilters["WorkGroupID"], 0, 0, this.ManageCategoryViewFilters["GlobalEnvironmentID"])
    }
  }

  /**
  * capture dropdown value END.
  */



  /**
  * autocomplete dropdown value START.
  */

  checkGOE(test) {
    this.getGOEResponse = this.ManageCategoryViewForm.controls.EnvironmentName.valueChanges.pipe(
      startWith(""),
      map((val: any) => (val.length >= 0 ? this.filterGOE(val) : []))
    );
    test.blur();
  }

  checkCompany(test) {
    this.getCompanyResponse = this.ManageCategoryViewForm.controls.CompanyName.valueChanges.pipe(
      startWith(""),
      map((val: any) => (val.length >= 0 ? this.filterCompany(val) : []))
    );
    test.blur();
  }

  checkWorkGroup(test) {
    this.getWorkgroupResponse = this.ManageCategoryViewForm.controls.WorkGroupName.valueChanges.pipe(
      startWith(""),
      map((val: any) => (val.length >= 0 ? this.filterWorkgroup(val) : []))
    );
    test.blur();
  }

  /**
  * autocomplete dropdown value END.
  */



  /**
  * remove dropdown value START.
  */

  removeGOEFilter(prop, nameProp) {
    this.ManageCategoryViewFilters[prop] = "";
    this.ManageCategoryViewFilters[nameProp] = "";
    this.getWorkgroupList = []
    this.ManageCategoryViewFilters['WorkGroupID'] = ""
    this.ManageCategoryViewFilters['WorkGroupName'] = ""
    this.ManageCategoryViewFilters['CompanyID'] = ""
    this.ManageCategoryViewFilters['CompanyName'] = ""
    this.getCompanyList = []
    this.getRestrictCompanybyGOE()
    this.getWorkgroupListByCompanyID()
    this.GetOPDocsPropertyList(this.ManageCategoryViewFilters["CompanyID"], this.ManageCategoryViewFilters["WorkGroupID"], 0, 0, this.ManageCategoryViewFilters["GlobalEnvironmentID"])
  }

  removeCompanyFilter(prop, nameProp) {
    this.ManageCategoryViewFilters[prop] = "";
    this.ManageCategoryViewFilters[nameProp] = "";
    this.getWorkgroupList = []
    this.ManageCategoryViewFilters['WorkGroupID'] = ""
    this.ManageCategoryViewFilters['WorkGroupName'] = ""
    this.getWorkgroupListByCompanyID()
    this.GetOPDocsPropertyList(this.ManageCategoryViewFilters["CompanyID"], this.ManageCategoryViewFilters["WorkGroupID"], 0, 0, this.ManageCategoryViewFilters["GlobalEnvironmentID"])
  }

  removeWorkGroupFilter(prop, nameProp) {
    this.ManageCategoryViewFilters[prop] = "";
    this.ManageCategoryViewFilters[nameProp] = "";
    this.GetOPDocsPropertyList(this.ManageCategoryViewFilters["CompanyID"], this.ManageCategoryViewFilters["WorkGroupID"], 0, 0, this.ManageCategoryViewFilters["GlobalEnvironmentID"])
  }

  /**
  * remove dropdown value END.
  */



  /**
  * API calling START.
  */

  GetGlobalEnvironmentByUserIDIR() {
    const param = {
      CurrentUserID: this.UserID,
    };

    this.opdocsService.GetGlobalEnvironmentByUserIDIR(param).subscribe(res => {
      this.getgoeList = res.data.GetGlobalEnvironmentByUserIDIR;
      this.getGOEResponse = this.ManageCategoryViewForm.controls.EnvironmentName.valueChanges.pipe(
        startWith(""),
        map((val: any) => (val.length >= 0 ? this.filterGOE(val) : []))
      );
      if (this.getgoeList && this.getgoeList.length != 0) {
        let UserGOEObj = this.getgoeList.filter(id => id.GlobalEnvironmentID == 1)
        this.ManageCategoryViewFilters["GlobalEnvironmentID"] = UserGOEObj[0].GlobalEnvironmentID;
        this.ManageCategoryViewFilters["EnvironmentName"] = UserGOEObj[0].EnvironmentName;
        // this.getRestrictCompanybyGOE()
      }
    })
  }

  getRestrictCompanybyGOE() {
    let params = {
      CurrentUserID: this.UserID,
    }
    this.opdocsService.GetRestrictCompanybyGOE(params).subscribe((res: any) => {
      //  let dupli = res.getRestrictCompanybyGOE;
      //  this.getCompanyList = dupli.filter((ele, index) => dupli.findIndex(obj => obj.CompanyId == ele.CompanyId) == index)
      this.getCompanyList = res.data.GetCompanyByUserIDIR;
      this.getCompanyResponse = this.ManageCategoryViewForm.controls.CompanyName.valueChanges.pipe(
        startWith(""),
        map((val: any) => (val.length >= 0 ? this.filterCompany(val) : []))
      );
    })
  }

  getWorkgroupListByCompanyID() {
    if (this.ManageCategoryViewFilters["CompanyID"] == '') {
      this.ManageCategoryViewFilters["CompanyID"] = "0"
    }
    const data = {
      "CompanyID": +this.ManageCategoryViewFilters["CompanyID"],
    }
    this.opdocsService.getWorkgroupListByCompanyID(data).subscribe(
      (res: any) => {
        this.getWorkgroupList = res.Workgroup;
        this.getWorkgroupResponse = this.ManageCategoryViewForm.controls.WorkGroupName.valueChanges.pipe(
          startWith(""),
          map((val: any) => (val.length >= 0 ? this.filterWorkgroup(val) : []))
        );
      }
    );
  }

  GetOPDocsCategoryGroupList(id) {
    const param = {
      "GlobalEnvironmentID": +id
    }
    this.opdocsService.GetOPDocsCategoryGroupList(param).subscribe((res: any) => {
      this.groupCategoryList = res.data.GetOPDocsCategoryGroupList
    })
  }

  GetOPDocsCategoryList(OPDocsCategoryID, OPDocsCategoryGroupID, GlobalEnvironmentID) {
    const param = {
      "OPDocsCategoryID": +OPDocsCategoryID,
      "GlobalEnvironmentID": +GlobalEnvironmentID,
      "OPDocsCategoryGroupID": +OPDocsCategoryGroupID
    }

    this.opdocsService.GetOPDocsCategoryList(param).subscribe((res: any) => {
      this.categoryList = res.data.GetOPDocsCategoryList
      // commit 17749 start
      if (!this.isCategoryGroupHighlight) {
        this.isCategoryHighlight = []
      }
      // commit 17749 end
    })

  }

  GetOPDocsPropertyList(CompanyID, WorkGroupID, OPDocsCategoryGroupID, OPDocsCategoryID, GlobalEnvironmentID) {
    // const param = {
    // "CurrentUserID": +this.UserID,
    // "CompanyID": +CompanyID,
    // "WorkgroupID": +WorkGroupID,
    // "GlobalEnvironmentID": +GlobalEnvironmentID,
    //   "CountryID": 0,
    //   "StateID": 0,
    //   "CompanyTypeID": 0,
    //   // "CityName": null,
    //   // "TierID": 0,
    // }

    const param = {
      "CompanyID": +CompanyID,
      "WorkgroupID": +WorkGroupID,
      "GlobalEnvironmentID": +GlobalEnvironmentID,
      "OPDocsCategoryGroupID": +OPDocsCategoryGroupID,
      "OPDocsCategoryID": +OPDocsCategoryID
    }


    this.opdocsService.GetOPDocsPropertyList(param).subscribe((res: any) => {
      this.propertyList = res.data.GetOPDocsPropertyList
      this.isPropertyHighlight = false
    })

  }

  GetOPDocsJobTitleList(OPDocsCategoryIDs, OPDocsPermissionElementID) {
    const param = {
      "OPDocsPermissionElementID": +OPDocsPermissionElementID,
      "OPDocsCategoryIDs": OPDocsCategoryIDs.toString()
  }
    this.opdocsService.GetOPDocsJobTitleList(param).subscribe((res: any) => {
      this.getOPDocsJobTitleList = res.data.GetOPDocsJobTitleList
      this.isJobTitleHighlight = false
    })
  }


  GetOPDocsPermissionElementList() {
    const param = {
      "UserID": this.UserID
    }
    this.opdocsService.GetOPDocsPermissionElementList(param).subscribe((res: any) => {
      this.getOPDocsPermissionElementList = res.data.GetOPDocsPermissionElementList
      this.GetOPDocsJobTitleList(this.isCategoryHighlight, this.oPDocsPermissionElementID)
    })
  }

  UpdateOPDocsCategoryPermission(OPDocsPermissionElementID, JobTitleID, IsAssign) {
    const param = {
      "OPDocsPermissionElementID": +OPDocsPermissionElementID,
      "OPDocsCategoryIDs": this.isCategoryHighlight.toString(),
      "JobTitleID": +JobTitleID,
      "IsAssign": IsAssign
  }

  this.opdocsService.UpdateOPDocsCategoryPermission(param).subscribe(res => {
    this.GetOPDocsJobTitleList(this.isCategoryHighlight, OPDocsPermissionElementID)
  })
  
  }

  /**
  * API calling END.
  */

   selectPermission(OPDocsPermissionElementID) {
     this.oPDocsPermissionElementID = OPDocsPermissionElementID
     this.GetOPDocsJobTitleList(this.isCategoryHighlight, OPDocsPermissionElementID)
   }

   selectJobTitle(obj) {
    if (this.isJobTitleHighlight == obj.JobTitleID || obj.IsSelected == 1) {
      this.isJobTitleHighlight = false
      this.UpdateOPDocsCategoryPermission(this.oPDocsPermissionElementID, obj.JobTitleID, 0)
    } else {
      this.isJobTitleHighlight = obj.JobTitleID
      this.UpdateOPDocsCategoryPermission(this.oPDocsPermissionElementID, obj.JobTitleID, 1)
    }
   }


  /**
  * Category Group Actions functions START.
  */

  EditCategoryGroup(obj) {
    this.oPDocsCategoryGroupID = obj.OPDocsCategoryGroupID
    const param = {
      "OPDocsCategoryGroupID": +obj.OPDocsCategoryGroupID
    }

    this.opdocsService.GetOPDocsCategoryGroupByID(param).subscribe((res: any) => {
      this.getOPDocsCategoryGroupByIDEdit = res.data.GetOPDocsCategoryByID
      // this.isCategoryGroupAddToggle = true
      this.isCategoryGroupUpdateToggle = true
      this.categoryGroupName = obj.CategoryGroupName
      this.categoryGroupDesc = obj.CategoryGroupDesc
    })
  }

  changeCategoryGroupStatus(OPDocsCategoryGroupID, status) {
    const param = {
      "OPDocsCategoryGroupID": +OPDocsCategoryGroupID
    }

    let sta = "";

    if (status == false) {
      sta = "activate";
    } else {
      sta = "deactivate";
    }

    Swal.fire({
      text: `Are you sure you want to ${sta} this?`,
      showCancelButton: true,
      width: "30%",
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes",
    }).then((result) => {
      if (result.value) {
        this.opdocsService.OPDocsCategoryGroupStatus(param).subscribe((res: any) => {
          this.GetOPDocsCategoryGroupList(this.ManageCategoryViewFilters["GlobalEnvironmentID"])
        })
      }
    });

  }

  DeleteCategoryGroup(OPDocsCategoryGroupID) {
    const param = {
      "OPDocsCategoryGroupID": +OPDocsCategoryGroupID
    }


    Swal.fire({
      text: 'Are you sure want to delete this category group?',
      showCancelButton: true,
      width: "30%",
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes",
    }).then((result) => {
      if (result.value) {
        this.opdocsService.DeleteOPDocsCategoryGroup(param).subscribe((res: any) => {
          this.GetOPDocsCategoryGroupList(this.ManageCategoryViewFilters["GlobalEnvironmentID"])
        })
      }
    });

  }

  categoryGroupSelection(obj) {
      // commit 17749 start
    this.isCategoryHighlight = []
      // commit 17749 end
      if (this.isCategoryGroupHighlight == obj.OPDocsCategoryGroupID && this.isCategoryGroupUpdateToggle == false) {
      this.isCategoryGroupHighlight = false
      this.GetOPDocsPropertyList(this.ManageCategoryViewFilters["CompanyID"], this.ManageCategoryViewFilters["WorkGroupID"], 0, 0, this.ManageCategoryViewFilters["GlobalEnvironmentID"])
      // commit 17749 start --- group id change to 0
      this.GetOPDocsCategoryList(0, 0, this.ManageCategoryViewFilters["GlobalEnvironmentID"])
      // commit 17749 end
    } else {
      this.isCategoryGroupHighlight = obj.OPDocsCategoryGroupID
      this.GetOPDocsPropertyList(this.ManageCategoryViewFilters["CompanyID"], this.ManageCategoryViewFilters["WorkGroupID"], this.isCategoryGroupHighlight, 0, this.ManageCategoryViewFilters["GlobalEnvironmentID"])
      this.GetOPDocsCategoryList(0, obj.OPDocsCategoryGroupID, this.ManageCategoryViewFilters["GlobalEnvironmentID"])
    }
  }

  /**
  * Category Group Actions functions END.
  */



  /**
  * Category Actions functions START.
  */

  ChangeCategoryStatus(OPDocsCategoryID, status) {
    const param = {
      "OPDocsCategoryID": +OPDocsCategoryID
    }

    let sta = "";

    if (status == false) {
      sta = "activate";
    } else {
      sta = "deactivate";
    }

    Swal.fire({
      text: `Are you sure you want to ${sta} this?`,
      showCancelButton: true,
      width: "30%",
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes",
    }).then((result) => {
      if (result.value) {
        this.opdocsService.OPDocsCategoryStatus(param).subscribe((res: any) => {
          this.GetOPDocsCategoryList(0, 0, this.ManageCategoryViewFilters["GlobalEnvironmentID"])
        })
      }
    });

  }

  EditCategory(obj) {
    this.oPDocsCategoryID = obj.OPDocsCategoryID
    const param = {
      "OPDocsCategoryID": +this.oPDocsCategoryID
    }

    this.opdocsService.GetOPDocsCategoryByID(param).subscribe((res: any) => {
      this.getOPDocsCategoryByIDEdit = res.data.GetOPDocsCategoryByID
      // this.isCategoryAddToggle = true
      this.isCategoryUpdateToggle = true
      this.categoryName = obj.CategoryName
      this.categoryDesc = obj.CategoryDesc
    })
  }

  DeleteCategory(OPDocsCategoryID) {
    const param = {
      "OPDocsCategoryID": +OPDocsCategoryID
    }

    Swal.fire({
      text: 'Are you sure want to delete this category?',
      showCancelButton: true,
      width: "30%",
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes",
    }).then((result) => {
      if (result.value) {
        this.opdocsService.DeleteOPDocsCategory(param).subscribe((res: any) => {
          this.GetOPDocsCategoryList(0, 0, this.ManageCategoryViewFilters["GlobalEnvironmentID"])
        })
      }
    });

  }

  categorySelection(obj) {
    if (this.isCategoryGroupHighlight == false) {
      this.isCategoryGroupHighlight = 0
    }
    if ((this.isCategoryHighlight.includes(obj.OPDocsCategoryID) || obj.IsCategoryGroup == 1) && this.isCategoryUpdateToggle == false) {
      // this.isCategoryHighlight = false
      if (this.isCategoryGroupHighlight) {
        this.UpdateOPDocsCategoryGroupCategory(this.isCategoryGroupHighlight, obj.OPDocsCategoryID, 0)
      }
      this.isCategoryHighlight = this.isCategoryHighlight.filter((item) => item != obj.OPDocsCategoryID);
    } else {
      this.isCategoryHighlight.push(obj.OPDocsCategoryID)
      if (this.isCategoryGroupHighlight) {
        this.UpdateOPDocsCategoryGroupCategory(this.isCategoryGroupHighlight, obj.OPDocsCategoryID, 1)
      }
    }
  }

  UpdateOPDocsCategoryGroupCategory(OPDocsCategoryGroupID, OPDocsCategoryID, IsAssigned) {
    const param = {
      "OPDocsCategoryGroupID": +OPDocsCategoryGroupID,
      "OPDocsCategoryID": +OPDocsCategoryID,
      "IsAssigned": IsAssigned
    }
    this.opdocsService.UpdateOPDocsCategoryGroupCategory(param).subscribe((res: any) => {
      this.GetOPDocsCategoryList(0, OPDocsCategoryGroupID, this.ManageCategoryViewFilters["GlobalEnvironmentID"])
    })
  }

  /**
  * Category Actions functions END.
  */



  /**
  * Property functions START.
  */

  propertySelection(obj) {
    if (this.isCategoryGroupHighlight == false) {
      this.isCategoryGroupHighlight = 0
    }
    if (this.isPropertyHighlight == obj.PropertyID || obj.IsCategoryGroup == 1) {
      this.isPropertyHighlight = false
      this.UpdateOPDocsCategoryGroupProperty(this.isCategoryGroupHighlight, obj.PropertyID, 0)
    } else {
      if (this.isCategoryGroupHighlight != 0) {
        if (obj.IsPropertyAssigned == 1) {
          Swal.fire({
            text: 'This property property is already assigned to certain group. Do ypu want to reassign it to selected group?',
            showCancelButton: true,
            width: "30%",
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes",
          }).then((result) => {
            if (result.value) {
              this.isPropertyHighlight = obj.PropertyID
              this.UpdateOPDocsCategoryGroupProperty(this.isCategoryGroupHighlight, this.isPropertyHighlight, 1)
            }
          });
        } else {
          this.isPropertyHighlight = obj.PropertyID
          this.UpdateOPDocsCategoryGroupProperty(this.isCategoryGroupHighlight, this.isPropertyHighlight, 1)
        }
      } else {
        this.tostre.warning('Please select Category Group First.')
      }
    }
  }

  UpdateOPDocsCategoryGroupProperty(OPDocsCategoryGroupID, PropertyID, IsAssigned) {
    const param = {
      "OPDocsCategoryGroupID": +OPDocsCategoryGroupID,
      "PropertyID": +PropertyID,
      "IsAssigned": IsAssigned
    }
    this.opdocsService.UpdateOPDocsCategoryGroupProperty(param).subscribe((res: any) => {
      this.GetOPDocsPropertyList(this.ManageCategoryViewFilters["CompanyID"], this.ManageCategoryViewFilters["WorkGroupID"], this.isCategoryGroupHighlight, 0, this.ManageCategoryViewFilters["GlobalEnvironmentID"])
    })
  }

  /**
  * Property functions END.
  */




  /**
  * Plus Button functions START.
  */

  AddUpdateCategoryGroup() {
      // commit 17749 start
      if(this.isCategoryGroupAddToggle == true) {
      this.oPDocsCategoryGroupID = ""
    }
      // commit 17749 end
      const param = {
      "OPDocsCategoryGroupID": (this.oPDocsCategoryGroupID == undefined || this.oPDocsCategoryGroupID == "") ? 0 : +this.oPDocsCategoryGroupID,
      "GlobalEnvironmentID": +this.ManageCategoryViewFilters["GlobalEnvironmentID"],
      "CategoryGroupName": this.categoryGroupName,
      "CategoryGroupDesc": this.categoryGroupDesc
    }

    this.opdocsService.UpdateOPDocsCategoryGroup(param).subscribe((res: any) => {
      this.GetOPDocsCategoryGroupList(this.ManageCategoryViewFilters["GlobalEnvironmentID"])
      this.isCategoryGroupAddToggle = false
      this.isCategoryGroupUpdateToggle = false
      this.showValid('Category Group Saved Successfully.')
    })
  }

  AddUpdateCategory() {
      // commit 17749 start
      if(this.isCategoryAddToggle == true) {
      this.oPDocsCategoryID = ""
    }
      // commit 17749 end
      const param = {
      "OPDocsCategoryID": (this.oPDocsCategoryID == undefined || this.oPDocsCategoryID == "") ? 0 : +this.oPDocsCategoryID,
      "GlobalEnvironmentID": +this.ManageCategoryViewFilters["GlobalEnvironmentID"],
      "CategoryName": this.categoryName,
      "CategoryDesc": this.categoryDesc
    }

    this.opdocsService.UpdateOPDocsCategory(param).subscribe((res: any) => {
      // commit 17749 start
      if(!this.isCategoryGroupHighlight) {
        this.isCategoryGroupHighlight = 0
      }
      // commit 17749 end
      // commit 17749 start --- this.isCategoryGroupHighlight add instead of 0
      this.GetOPDocsCategoryList(0, this.isCategoryGroupHighlight, this.ManageCategoryViewFilters["GlobalEnvironmentID"])
      // commit 17749 end
      this.isCategoryAddToggle = false
      this.isCategoryUpdateToggle = false
      this.showValid('Document Category Saved Successfully.')
    })
  }

  /**
 * Plus Button functions END.
 */



  /**
  * Category Tab Switch Work START...
  */

  DocumentCategoriesSwitch() {
    this.isDocumentCategoriesTab = true;
    this.isCategoryPermissionTab = false;
  }

  CategoryPermissionSwitch() {
    this.isCategoryPermissionTab = true;
    this.isDocumentCategoriesTab = false;
    this.isCategoryAddToggle = false
    this.oPDocsPermissionElementID = '1'
    // this.isDocumentCategoriesTab1Function()
    this.GetOPDocsPermissionElementList()
  }

  /**
  * Category Tab Switch Work START...
  */



  /**
  * Category Selection Work START...
  */

  // categorySelection(value: any) {
  //   if (this.isCategoryGroupHighlight == false) {
  //     this.isCategoryGroupHighlight = "0"
  //   }

  //   // shift plus click start here in sortDataForCategory function
  //   if (this.isShiftPlusClick) {
  //     this.categoriesToAssignToGroup.push(value);
  //     this.sortDataForCategory();
  //   }

  //   if (!this.ctrl) {
  //     // single click
  //     this.categoriesToAssignToGroup.length = 1;
  //     if (this.categoriesToAssignToGroup[0]) {
  //       if (this.categoriesToAssignToGroup[0].OPDocsCategoryID == value.OPDocsCategoryID) {
  //         this.categoriesToAssignToGroup = [];
  //       } else {
  //         this.categoriesToAssignToGroup[0] = value;
  //       }
  //     } else {
  //       this.categoriesToAssignToGroup[0] = value;
  //     }
  //     const singleObj = {
  //       "OPDocsCategoryGroupID": +this.isCategoryGroupHighlight,
  //       "OPDocsCategoryID": +value.OPDocsCategoryID
  //     }
  //     this.opdocsService.UpdateOPDocsCategoryGroupCategory(singleObj).subscribe()
  //     return;
  //   } else {
  //     // ctrl plus single click
  //     if (!this.isShiftPlusClick) {
  //       let indexOfExistsItem = this.categoriesToAssignToGroup.findIndex(
  //         (accu: { [key: string]: string | number }) =>
  //           accu.OPDocsCategoryID == value.OPDocsCategoryID
  //       );
  //       if (indexOfExistsItem >= 0) {
  //         this.categoriesToAssignToGroup.splice(indexOfExistsItem, 1);
  //       } else {
  //         this.categoriesToAssignToGroup.push(value);
  //       }
  //       let categoryId = this.categoriesToAssignToGroup.map(function (a) {
  //         return a.OPDocsCategoryID;
  //       });
  //       const singleObj = {
  //         "OPDocsCategoryGroupID": +this.isCategoryGroupHighlight,
  //         "OPDocsCategoryID": categoryId.toString()
  //       }
  //       this.opdocsService.UpdateOPDocsCategoryGroupCategory(singleObj).subscribe()
  //     }
  //   }

  // }

  // findIndexOfCategoryClicked(prop) {
  //   let indexOfExistsItem = this.categoriesToAssignToGroup.findIndex(
  //     (accu: { [key: string]: string | number }) =>
  //       accu.OPDocsCategoryID == prop.OPDocsCategoryID
  //   );

  //   if (indexOfExistsItem >= 0) {
  //     return "selected";
  //   } else {
  //     return "";
  //   }
  // }

  // sortDataForCategory() {
  //   if (this.selectFlag) {
  //     let indexes = this.categoriesToAssignToGroup
  //       .map((accu) => {
  //         return this.categoryList.findIndex((elem) => {
  //           if (elem.OPDocsCategoryID == accu.OPDocsCategoryID) {
  //             return true;
  //           }
  //         });
  //       })
  //       .sort();
  //     this.selectFlag = false;
  //     this.categoriesToAssignToGroup = [];
  //     let temp = [indexes[0], indexes[indexes.length - 1]];
  //     indexes = [];
  //     for (let i = temp[0]; i <= temp[1]; i++) {
  //       indexes.push(i);
  //     }

  //     indexes.forEach((elem) => {
  //       this.categoriesToAssignToGroup.push(this.categoryList[elem]);
  //     });
  //     let categoryId = this.categoriesToAssignToGroup.map(function (a) {
  //       return a.OPDocsCategoryID;
  //     });
  //     const singleObj = {
  //       "OPDocsCategoryGroupID": +this.isCategoryGroupHighlight,
  //       "OPDocsCategoryID": categoryId.toString()
  //     }
  //     this.opdocsService.UpdateOPDocsCategoryGroupCategory(singleObj).subscribe()
  //     // shift plus single click
  //   }
  // }

  /**
  * Category Selection Work END...
  */



  /**
  * Property Selection Work START...
  */

  // propertySelection(value: any) {

  //   // shift plus click start here in sortDataForCategory function
  //   if (this.isShiftPlusClick) {
  //     this.propertyToAssignToGroup.push(value);
  //     this.sortDataForproperty();
  //   }

  //   if (!this.ctrl) {
  //     // single click
  //     this.propertyToAssignToGroup.length = 1;
  //     if (this.propertyToAssignToGroup[0]) {
  //       if (this.propertyToAssignToGroup[0].OPDocsCategoryID == value.OPDocsCategoryID) {
  //         this.propertyToAssignToGroup = [];
  //       } else {
  //         this.propertyToAssignToGroup[0] = value;
  //       }
  //     } else {
  //       this.propertyToAssignToGroup[0] = value;
  //     }
  //     console.log('single', this.propertyToAssignToGroup)
  //     return;
  //   } else {
  //     // ctrl plus single click
  //     if (!this.isShiftPlusClick) {
  //       let indexOfExistsItem = this.propertyToAssignToGroup.findIndex(
  //         (accu: { [key: string]: string | number }) =>
  //           accu.PropertyID == value.PropertyID
  //       );
  //       if (indexOfExistsItem >= 0) {
  //         this.propertyToAssignToGroup.splice(indexOfExistsItem, 1);
  //       } else {
  //         this.propertyToAssignToGroup.push(value);
  //       }
  //       console.log('ctrl', this.propertyToAssignToGroup)
  //     }
  //   }
  // }

  // findIndexOfPropertyClicked(prop) {
  //   let indexOfExistsItem = this.propertyToAssignToGroup.findIndex(
  //     (accu: { [key: string]: string | number }) =>
  //       accu.PropertyID == prop.PropertyID
  //   );

  //   if (indexOfExistsItem >= 0) {
  //     return "selected";
  //   } else {
  //     return "";
  //   }
  // }

  // sortDataForproperty() {
  //   if (this.selectFlag) {
  //     let indexes = this.propertyToAssignToGroup
  //       .map((accu) => {
  //         return this.propertyList.findIndex((elem) => {
  //           if (elem.PropertyID == accu.PropertyID) {
  //             return true;
  //           }
  //         });
  //       })
  //       .sort();
  //     this.selectFlag = false;
  //     this.propertyToAssignToGroup = [];
  //     let temp = [indexes[0], indexes[indexes.length - 1]];
  //     indexes = [];
  //     for (let i = temp[0]; i <= temp[1]; i++) {
  //       indexes.push(i);
  //     }

  //     indexes.forEach((elem) => {
  //       this.propertyToAssignToGroup.push(this.propertyList[elem]);
  //     });
  //     // shift plus single click
  //     console.log('shift', this.propertyToAssignToGroup)
  //   }
  // }

  /**
  * Property Selection Work END...
  */



  /**
  * Toaster Prototype Start...
  */

  showInvalid(msg) {
    this.tostre.error(msg, "", {
      positionClass: "toast-top-right",
    });
  }

  showValid(validMsg) {
    this.tostre.success(validMsg, "", {
      positionClass: "toast-top-right",
    });
  }

  /**
  * Toaster Prototype END...
  */




  /****************************************************************
* Common host listeners for shift and ctrl click - start
*/

  // ctrl = false;
  // isShiftPlusClick = false;
  // selectFlag = true;


  // @HostListener("window:keydown", ["$event"])
  // keyDownCtrl(event: KeyboardEvent) {
  //   if (event.keyCode === 17) this.ctrl = true;

  //   if (event.shiftKey) {
  //     this.ctrl = true;
  //     this.isShiftPlusClick = true;
  //   }
  // }

  // @HostListener("window:keyup", ["$event"])
  // keyUpCtrl(event: KeyboardEvent) {
  //   if (event.keyCode === 17) this.ctrl = false;

  //   this.selectFlag = true;
  //   this.isShiftPlusClick = false;
  //   this.ctrl = false;
  // }

  /****************************************************************
   * Common host listeners for shift and ctrl click - end
   */

}
