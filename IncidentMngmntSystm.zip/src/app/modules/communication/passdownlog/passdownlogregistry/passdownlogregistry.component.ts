import {
  Component,
  OnInit,
  ViewChild,
  Input,
  EventEmitter,
  Output,
  ElementRef,
  HostListener,
  Host,
} from "@angular/core";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { userService } from "src/app/modules/administration/organizationmanagement/users/user.service";
import { PassDownLogService } from "src/app/services/pass-down-log.service";
import { IncidentResearchService } from "src/app/modules/research/incidentresearch/incident-research.service";
import { FormBuilder, FormControl, FormGroup } from "@angular/forms";
import { startWith, map, take } from "rxjs/operators";
import Swal from "sweetalert2";
import * as fs from "file-saver";
import { environment } from "src/environments/environment";
import { StorageService } from "../../../../services/storage.service";
import {
  MomentDateAdapter,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS,
} from "@angular/material-moment-adapter";
import {
  DateAdapter,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE,
} from "@angular/material/core";

import * as _moment from "moment";
import { ActivatedRoute } from "@angular/router";
import { ToastrService } from "ngx-toastr";
const moment = _moment;

export const MY_FORMATS = {
  parse: {
    dateInput: "MM/DD/YYYY",
  },
  display: {
    dateInput: "MM/DD/YYYY",
    monthYearLabel: "MMM YYYY",
    dateA11yLabel: "LL",
    monthYearA11yLabel: "MMMM YYYY",
  },
};

export interface PeriodicElement {
  title: string;
  addedby: string;
  addeddt: string;
  displayduration: string;
  distribution: string;
  action: string;
}

@Component({
  selector: "app-passdownlogregistry",
  templateUrl: "./passdownlogregistry.component.html",
  styleUrls: ["./passdownlogregistry.component.scss"],
  providers: [
    userService,
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS],
    },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ],
})
export class PassdownlogregistryComponent implements OnInit {
  public show: boolean = false;
  FromDate = null;
  ToDate = null;
  userData = null;
  UserID = null;
  groupStatus: string;
  userValue1: string;
  userValue2: string;
  selectedValue: string;
  selectedValueName: string;
  selectedValueWorkGroup: string;
  hellomoto: any;
  getPassDownList: any;
  workGroupList: any;
  recipent: any;
  passDownTitle: string;
  passDownMsg: string;
  GetPassDownDisplayType: any;
  GetPassDownDisplayTypeFirst: any;
  GetPassDownDisplayTypeRest: any;
  GetPassDownDisplayTypeEditFirst: any;
  GetPassDownDisplayTypeEditRest: any;
  PassDownDisplayTypeDate: any;
  PassDownDisplayTypeID: any;
  PassDownLogID: string;
  days: any = [];
  showMore: boolean = false;
  // dataSource = new MatTableDataSource(ELEMENT_DATA);
  displayedColumns: string[] = [
    "Title",
    "UserName",
    "Date",
    "DisplayDate",
    "Distribution",
    "action",
  ];
  dataSource: MatTableDataSource<any>;
  imgURL: any = [];
  imgName: any = [];
  dateFlag: boolean = true;
  daysFlag: boolean = false;

  passDownLogFilterForm: FormGroup;
  passDownLogAssignmentForm: FormGroup;

  passDownLogFilter: any;
  passDownLogAssignment: any;
  passDownLogWorkGroup: any;

  passDownLogFormFilters = {
    PropertyID: "",
    FromDate: null,
    ToDate: null,
    groupStatus: [],
    userValue1: [],
    userValue2: [],
  };
  passDownLogFormAssignment = {
    CompanyID: "",
    WorkGroupID: "",
  };

  getProperty: any = [];
  getCompany: any = [];
  getWorkGroup: any = [];

  getPropertyResponse: any = [];
  getCompanyResponse: any = [];
  getWorkGroupResponse: any = [];

  getPropertyAssignment: any = [];
  propertyCount: any = 0;
  userCount: any = 0;

  @Input() viewShow: boolean;
  @Input() propertyIDValueFromView: any;
  @Input() viewArray: any;
  showViewListFlag: boolean = true;
  @Output() messageEvent = new EventEmitter<boolean>();

  UserPropertyID = "";
  UserPropertyName = "";
  formMinDate: Date;
  ToDispatch: boolean = false;

  @ViewChild(MatSort, { static: false }) sort: MatSort;
  filePath: any;
  hidecross: boolean = false
  constructor(
    private formBuilder: FormBuilder,
    public IncidentResearchService: IncidentResearchService,
    private userService: userService,
    private passDownLogService: PassDownLogService,
    private route: ActivatedRoute,
    private storage: StorageService,
    public tostre: ToastrService
  ) {
    this.userData = JSON.parse(this.storage.getData("UserData"));
    this.UserID = this.userData[0].UserID;
    this.UserPropertyID = this.userData[0].PropertyID;
    this.UserPropertyName = this.userData[0].PropertyName;
    this.dataSource = new MatTableDataSource([]);
    this.dataSource.sort = this.sort;
    this.initFormSetDate();
    this.initFormSetDateNotEdit();
    if (this.route.snapshot.routeConfig.path == "communications/passdownlogs") {
      this.ToDispatch = true;
    } else {
      this.ToDispatch = false;
    }
    if (environment.onProd == 1) {
      this.filePath = environment.imagePath + "passdownlog/";
    } else {
      this.filePath = environment.imagePath + "passDownLog/";
    }
  }

  ngOnInit() {
    let user = {
      UserId: parseInt(this.UserID),
    };
    // `${environment.origin}api`
    environment;
    // when coming from view page on edit
    if (this.viewArray != undefined) {
      this.show = !this.show;
      this.passDownLogService.GetPassDownDisplayType().subscribe((data) => {
        this.GetPassDownDisplayType = data.data.GetPassDownDisplayType;
        this.GetPassDownDisplayTypeRest = data.data.GetPassDownDisplayType;
        this.GetPassDownDisplayTypeFirst = data.data.GetPassDownDisplayType[0];
        this.GetPassDownDisplayTypeRest.splice(0, 1);
        this.EditPassDownLog(this.viewArray.PassDownLogID);
      });
    }

    if (this.getPassDownList == undefined) {
      this.noDataFound = true;
    }

    // when coming from view page on Add Entry
    if (this.viewShow != undefined) {
      this.noDataFound = false;
      this.show = !this.show;
    }
    this.formMinDate = new Date();

    this.passDownLogService
      .GetPropertyByUserIdPassdownLog()
      .subscribe((data) => {
        this.getProperty = data.data.getPropertyByUserIdPassdownLog[0];
        /* new code */
        this.getPropertyAssignment = this.getProperty;
        this.propertyCount = this.getPropertyAssignment.length;
        /**/
        this.userCount = this.getProperty.length;
        // this.getPropertyAssignment = data.data.getPropertyByUserIdPassdownLog[0];
        // this.propertyCount = this.getPropertyAssignment.length;

        // when coming form view page to display left side of data
        if (this.viewShow != undefined) {
          if (this.userCount == 1) {
            this.selectedpropertyList = this.getProperty;
            this.selectedpropertyListLength = this.selectedpropertyList.length;
            this.hidecross = true
          } else {
            this.hidecross = false

          }
        }
        this.getPropertyResponse = this.passDownLogFilterForm.controls.PropertyID.valueChanges.pipe(
          startWith(""),
          map((val: any) => (val.length >= 0 ? this.filterProperty(val) : []))
        );

        if (this.userCount == 1) {
          for (const view of this.getProperty) {
            this.passDownLogFilter.PropertyID = view.PropertyName;
            this.passDownLogFormFilters["PropertyID"] = view.PropertyID;
          }
          this.hidecross = true
        } else {
          this.hidecross = false

        }
        if (this.passDownLogFormFilters.PropertyID == "") {
          this.passDownLogFormFilters.PropertyID = null;
        }
        let getFirstCallObj = {
          PropertyID: this.passDownLogFormFilters.PropertyID,
          FromDate: this.FromDate,
          ToDate: this.ToDate,
          PassDownStatus: "Active",
          UserId: this.passDownLogFilter.userValue1 == "" ? null : this.UserID,
          IsShowMultiPropertyOnly:
            this.passDownLogFilter.userValue2 == "" ? null : "Yes",
        };
        this.getPassDownListOnMain(getFirstCallObj);
      });
    this.passDownLogService.getAssignedCompany(user).subscribe((data) => {
      this.getCompany = data.companySearchList;
      this.getCompanyResponse = this.passDownLogAssignmentForm.controls.CompanyID.valueChanges.pipe(
        startWith(""),
        map((val: any) => (val.length >= 0 ? this.filterCompany(val) : []))
      );
    });

    // to display grid of date in Add pass down log entry on edit mode
    if (this.viewArray == undefined) {
      this.passDownLogService.GetPassDownDisplayType().subscribe((data) => {
        this.GetPassDownDisplayType = data.data.GetPassDownDisplayType;
        this.GetPassDownDisplayTypeRest = data.data.GetPassDownDisplayType;
        this.GetPassDownDisplayTypeFirst = data.data.GetPassDownDisplayType[0];
        this.GetPassDownDisplayTypeRest.splice(0, 1);
      });
    } else {
      this.passDownLogService.GetAssignedWorkGroup().subscribe((data) => {
        this.getWorkGroup = data.getAssigedWorkGroup;
        this.getWorkGroupResponse = this.passDownLogAssignmentForm.controls.WorkGroupID.valueChanges.pipe(
          startWith(""),
          map((val: any) => (val.length >= 0 ? this.filterWorkGroup(val) : []))
        );
      });
    }
    let param = {
      CurrentUserID: this.UserID,
    };

    // this.IncidentResearchService.GetWorkGroupbyUserIDIR(param).subscribe(
    //   (x: any) => {
    //     this.workGroupList = x.data.GetWorkGroupbyUserIDIR;
    //   }
    // );
    this.passDownLogFilter = {
      PropertyID: "",
      FromDate: "",
      ToDate: "",
      groupStatus: [],
      userValue1: [],
      userValue2: [],
    };
    this.passDownLogFilterForm = this.formBuilder.group({
      PropertyID: "",
      FromDate: "",
      ToDate: "",
      groupStatus: [],
      userValue1: [],
      userValue2: [],
    });

    this.passDownLogAssignment = {
      CompanyID: "",
      WorkGroupID: "",
    };
    this.passDownLogAssignmentForm = this.formBuilder.group({
      CompanyID: "",
      WorkGroupID: "",
    });

    this.getPropertyResponse = this.passDownLogFilterForm.controls.PropertyID.valueChanges.pipe(
      startWith(""),
      map((value) => {
        let list = value.length >= 1 ? this.filterProperty(value) : [];
        if (list.length == 1 && list[0].PropertyName == value) {
          list = [];
        }
        return list;
      })
    );
    this.getCompanyResponse = this.passDownLogAssignmentForm.controls.CompanyID.valueChanges.pipe(
      startWith(""),
      map((value) => {
        let list = value.length >= 1 ? this.filterCompany(value) : [];
        if (list.length == 1 && list[0].CompanyName == value) {
          list = [];
        }
        return list;
      })
    );
    this.getWorkGroupResponse = this.passDownLogAssignmentForm.controls.WorkGroupID.valueChanges.pipe(
      startWith(""),
      map((value) => {
        let list = value.length >= 1 ? this.filterWorkGroup(value) : [];
        if (list.length == 1 && list[0].WorkGroupName == value) {
          list = [];
        }
        return list;
      })
    );

    // let getFirstCallObj = {
    //   PropertyID: null,
    //   FromDate: null,
    //   ToDate: null,
    //   PassDownStatus: this.passDownLogFilter.groupStatus,
    //   UserId: null,
    //   IsShowMultiPropertyOnly: null,
    // };

    // this.getPassDownListOnMain(getFirstCallObj);
  }

  // to emit values at view page
  showViewList() {
    this.messageEvent.emit(this.showViewListFlag);
  }

  ApplyFilter() {
    if (this.passDownLogFormFilters.PropertyID == "") {
      this.passDownLogFormFilters.PropertyID = null;
    }
    // let val = this.tableShowMe
    let getFirstCallObj = {
      PropertyID: this.passDownLogFormFilters.PropertyID,
      FromDate: this.FromDate,
      ToDate: this.ToDate,
      PassDownStatus:
        this.passDownLogFilter.groupStatus.length == 0
          ? "Active"
          : this.passDownLogFilter.groupStatus[0],
      UserId: this.passDownLogFilter.userValue1 == "" ? null : this.UserID,
      IsShowMultiPropertyOnly:
        this.passDownLogFilter.userValue2 == "" ? null : "Yes",
    };
    this.getPassDownListOnMain(getFirstCallObj);
  }

  // to open form on add entry button click
  toggle() {
    // this.selectedpropertyList = []
    // if (this.passDownLogFormFilters.PropertyID != '') {
    //   this.selectedpropertyList.push({
    //     PropertyID: this.UserPropertyID,
    //     PropertyName: this.UserPropertyName
    //   })
    //   this.selectedpropertyListLength = this.selectedpropertyList.length
    // }
    // if (this.propertyCount == 1) {
    //   this.selectedpropertyList = this.getPropertyAssignment;
    //   this.selectedpropertyListLength = this.selectedpropertyList.length;
    // }
    this.getPropertyAssignment.length = 0;
    this.mainGridID = 0;
    this.removeFilterCompany(event, "CompanyID");
    this.removeFilterWorkGroup(event, "WorkGroupID");
    if (this.passDownLogFormAssignment["CompanyID"] == "") {
      this.getWorkGroup = []
      // this.getWorkGroupResponse = []
    }
    this.passDownLogAssignment.CompanyID = "";
    this.passDownLogAssignment.WorkGroupID = "";
    this.nonEditFileUploadSelect = false;
    this.indexFiles = -1;
    this.myGroupNotEdit.reset();

    this.tempVar1 = {
      PassDownDisplayTypeID: null,
    };

    this.myGroupEdit.reset();

    this.tempVar = {
      PassDownDisplayTypeID: null,
    };
    this.GetPassDownLogFileNameList = [];
    this.GetFileNameList = [];
    this.GetFileNameList.length = 0;
    this.GetPassDownLogFileNameList.length = 0;
    this.imgName = [];
    this.imgURL = [];
    this.FileMeta = [];
    this.FileMeta.length = 0;
    this.selectedpropertyList = [];
    this.selectedpropertyListLength = 0;

    if (this.userCount == 1) {
      for (const view of this.getProperty) {
        this.selectedpropertyList.push(view);
        this.selectedpropertyListLength = this.selectedpropertyList.length;
      }
    }

    this.show = !this.show;

    if ((this.show = true)) {
      this.noDataFound = false;
    }
    this.passDownMsg = "";
    this.passDownTitle = "";
    this.days.length = 0;
    this.showDate = false;
    this.isEdit = false;
    this.imgName.length = 0;
    this.imgURL.length = 0;
    // this.myGroupEdit.reset()
    // // this.myGroupNotEdit.reset()
    // this.tempVar1.PassDownDisplayTypeID = undefined
    // this.tempVar.PassDownDisplayTypeID = undefined
    this.showMore = false;
  }

  private filterProperty(name: string): any {
    const filterValue = name.toLowerCase();
    return this.getProperty.filter((option) => {
      return option.PropertyName.toLowerCase().includes(filterValue);
    });
  }

  private filterCompany(name: string): any {
    const filterValue = name.toLowerCase();
    return this.getCompany.filter((option) => {
      return option.CompanyName.toLowerCase().includes(filterValue);
    });
  }

  private filterWorkGroup(name: string): any {
    const filterValue = name.toLowerCase();
    return this.getWorkGroup.filter((option) => {
      return option.WorkGroupName.toLowerCase().includes(filterValue);
    });
  }

  changeShowAll(event, prop, value) {
    if (event.isUserInput) {
      this.passDownLogFormFilters[prop] = value;
      let getFirstCallObj = {
        PropertyID: this.passDownLogFormFilters[prop],
        FromDate: this.FromDate,
        ToDate: this.ToDate,
        PassDownStatus:
          this.passDownLogFilter.groupStatus.length == 0
            ? "Active"
            : this.passDownLogFilter.groupStatus[0],
        UserId: this.passDownLogFilter.userValue1 == "" ? null : this.UserID,
        IsShowMultiPropertyOnly:
          this.passDownLogFilter.userValue2 == "" ? null : "Yes",
      };

      this.getPassDownListOnMain(getFirstCallObj);
    }
  }

  chcekProperty(test) {
    this.getPropertyResponse = this.passDownLogFilterForm.controls.PropertyID.valueChanges.pipe(
      startWith(""),
      map((val: any) => (val.length >= 0 ? this.filterProperty(val) : []))
    );
    test.blur();
  }

  removeFilter(event, prop) {
    this.passDownLogFormFilters[prop] = "";
    let getFirstCallObj = {
      PropertyID: null,
      FromDate: this.FromDate,
      ToDate: this.ToDate,
      PassDownStatus:
        this.passDownLogFilter.groupStatus.length == 0
          ? "Active"
          : this.passDownLogFilter.groupStatus[0],
      UserId: this.passDownLogFilter.userValue1 == "" ? null : this.UserID,
      IsShowMultiPropertyOnly:
        this.passDownLogFilter.userValue2 == "" ? null : "Yes",
    };

    this.getPassDownListOnMain(getFirstCallObj);
  }

  removeFilterDateFrom() {
    this.FromDateBind = null;
    this.FromDate = null;
  }

  removeFilterToTo() {
    this.ToDateBind = null;
    this.ToDate = null;
  }

  changeShowAllCompany(event, prop, value) {
    if (event.isUserInput) {
      this.passDownLogFormAssignment[prop] = value;
    }
    // this.passDownLogFormAssignment["WorkGroupID"] = ""
    // this.passDownLogAssignment.WorkGroupID = ""
    let obj1 = {
      CompanyId: this.passDownLogFormAssignment[prop],
      currentUserId: this.UserID,
    };
    let obj2 = {
      CompanyID: this.passDownLogFormAssignment[prop],
    };
    this.passDownLogService
      .GetPropertyListByCompanyId(obj1)
      .pipe(take(1))
      .subscribe((data) => {
        this.getPropertyAssignment = data.data.getPropertyListByCompanyId;
        this.propertyCount = this.getPropertyAssignment.length;
      });
    this.userService.GetWorkgroup(obj2).subscribe((data) => {
      this.getWorkGroup = data.Workgroup;
      this.getWorkGroupResponse = this.passDownLogAssignmentForm.controls.WorkGroupID.valueChanges.pipe(
        startWith(""),
        map((val: any) => (val.length >= 0 ? this.filterWorkGroup(val) : []))
      );
    });
  }

  chcekPropertyCompany(test) {
    this.getCompanyResponse = this.passDownLogAssignmentForm.controls.CompanyID.valueChanges.pipe(
      startWith(""),
      map((val: any) => (val.length >= 0 ? this.filterCompany(val) : []))
    );
    test.blur();
  }

  removeFilterCompany(event, prop) {
    this.passDownLogFormAssignment[prop] = "";
    this.passDownLogFormAssignment["WorkGroupID"] == ""
    this.passDownLogAssignment.WorkGroupID = ""
    this.getPropertyAssignment.length = 0;
    this.getWorkGroup = []
    /* dispaly all properties when no company has selected */
    this.getPropertyAssignment = this.getProperty;
    this.propertyCount = this.getPropertyAssignment.length;
    /**/
    // if (this.passDownLogFormAssignment["WorkGroupID"] == "") {
    //   this.getPropertyAssignment.length = 0;
    // } else {
    //   let obj = {
    //     WorkGroupId: this.passDownLogFormAssignment["WorkGroupID"],
    //     currentUserId: this.UserID,
    //   };
    //   this.passDownLogService
    //     .GetPropertyByWorkGroupId(obj)
    //     .subscribe((data) => {
    //       this.getPropertyAssignment = data.data.Properties;
    //       this.propertyCount = this.getPropertyAssignment.length;
    //     });
    // }
    // this.getPropertyAssignment = this.getProperty;
    // this.propertyCount = this.getPropertyAssignment.length;
    // if (event == 'clearWorkgroup') {

    // } else {
    //   this.passDownLogService.GetAssignedWorkGroup().subscribe((data) => {
    //     this.getWorkGroup = data.getAssigedWorkGroup;
    //     this.getWorkGroupResponse = this.passDownLogAssignmentForm.controls.WorkGroupID.valueChanges.pipe(
    //       startWith(""),
    //       map((val: any) => (val.length >= 0 ? this.filterWorkGroup(val) : []))
    //     );
    //   });
    // }
  }

  changeShowAllWorkGroup(event, prop, value) {
    if (event.isUserInput) {
      this.passDownLogFormAssignment[prop] = value;
    }
    // this.passDownLogFormAssignment["CompanyID"] = ""
    // this.passDownLogAssignment.CompanyID = ""
    let obj = {
      WorkGroupId: this.passDownLogFormAssignment[prop],
      currentUserId: this.UserID,
    };
    this.passDownLogService.GetPropertyByWorkGroupId(obj).subscribe((data) => {
      this.getPropertyAssignment = data.data.Properties;
      this.propertyCount = this.getPropertyAssignment.length;
    });
  }

  chcekPropertyWorkGroup(test) {
    this.getWorkGroupResponse = this.passDownLogAssignmentForm.controls.WorkGroupID.valueChanges.pipe(
      startWith(""),
      map((val: any) => (val.length >= 0 ? this.filterWorkGroup(val) : []))
    );
    test.blur();
  }

  removeFilterWorkGroup(event, prop) {
    this.passDownLogFormAssignment[prop] = "";
    if (this.passDownLogFormAssignment["CompanyID"] == "") {
      this.getPropertyAssignment.length = 0;
    } else {
      let obj1 = {
        CompanyId: this.passDownLogFormAssignment["CompanyID"],
        currentUserId: this.UserID,
      };
      this.passDownLogService
        .GetPropertyListByCompanyId(obj1)
        .pipe(take(1))
        .subscribe((data) => {
          this.getPropertyAssignment = data.data.getPropertyListByCompanyId;
          this.propertyCount = this.getPropertyAssignment.length;
        });
    }
    // this.getPropertyAssignment = this.getProperty;
    // this.propertyCount = this.getPropertyAssignment.length;
  }

  getPassDownListOnMain(getFirstCallObj) {
    let obj = getFirstCallObj;
    this.passDownLogService.getPassDownList(obj).subscribe((data) => {
      this.getPassDownList = data.data.GetPassDownList;
      this.dataSource = new MatTableDataSource([]);
      this.dataSource.data = this.getPassDownList;
      this.dataSource.sort = this.sort;
      this.sort.disableClear = true;
      if (data.data.GetPassDownList.length === 0) {
        this.noDataFound = true;
      } else {
        this.noDataFound = false;
      }
    });
  }

  ActiveInActiveDeleteToggle(event) {
    if (this.passDownLogFormFilters.PropertyID == "") {
      this.passDownLogFormFilters.PropertyID = null;
    }
    if (event && event.value.length > 1) {
      event.value.shift();
    }
    let toggle = event.source;
    if (toggle) {
      let group = toggle.buttonToggleGroup;
      if (event.value.some((item) => item == toggle.value)) {
        group.value = [toggle.value];
        this.passDownLogFilter["groupStatus"] = group.value;
        let getFirstCallObj = {
          PropertyID: this.passDownLogFormFilters.PropertyID,
          FromDate: this.FromDate,
          ToDate: this.ToDate,
          PassDownStatus:
            this.passDownLogFilter.groupStatus.length == 0
              ? "Active"
              : this.passDownLogFilter.groupStatus[0],
          UserId: this.passDownLogFilter.userValue1 == "" ? null : this.UserID,
          IsShowMultiPropertyOnly:
            this.passDownLogFilter.userValue2 == "" ? null : "Yes",
        };
        this.getPassDownListOnMain(getFirstCallObj);
      }
    } else {
      this.passDownLogFilter["groupStatus"] = [];
      let getFirstCallObj = {
        PropertyID: this.passDownLogFormFilters.PropertyID,
        FromDate: this.FromDate,
        ToDate: this.ToDate,
        PassDownStatus: "Active",
        UserId: this.passDownLogFilter.userValue1 == "" ? null : this.UserID,
        IsShowMultiPropertyOnly:
          this.passDownLogFilter.userValue2 == "" ? null : "Yes",
      };
      this.getPassDownListOnMain(getFirstCallObj);
    }

    // let getFirstCallObj = {
    //   PropertyID: this.passDownLogFormFilters.PropertyID,
    //   FromDate: this.FromDate,
    //   ToDate: this.ToDate,
    //   PassDownStatus: this.passDownLogFilter.groupStatus,
    //   UserId: this.passDownLogFilter.userValue == "0" ? this.UserID : null,
    //   IsShowMultiPropertyOnly: this.passDownLogFilter.userValue == "0" || this.passDownLogFilter.userValue == "" ? null : 'Yes'
    // }
    // this.getPassDownListOnMain(getFirstCallObj)
  }

  /**********************************
   * working with hostlistener bindings
   */
  getSelectedArr = [];
  getSelected1Arr = [];
  ctrl = false;
  testDummy = false;
  testDummy1 = false;

  selectByPerson: any = false;
  onleftPersonSelect(value: any) {
    if (!this.ctrl) {
      // if (this.getSelectedArr[0]) {
      //   this.getSelectedArr = [];
      // } else {
      //   this.getSelectedArr[0] = value;
      // }
      this.getSelectedArr.length = 1;

      if (this.getSelectedArr[0]) {
        if (this.getSelectedArr[0].PropertyID == value.PropertyID) {
          this.getSelectedArr = [];
        } else {
          this.getSelectedArr[0] = value;
        }
      } else {
        this.getSelectedArr[0] = value;
      }

      return;
    }

    /******************************* for multiple selection
     * TDOD: modify as per need
     */

    let indexOfExistsItem = this.getSelectedArr.findIndex(
      (accu: { [key: string]: string | number }) =>
        accu.PropertyID == value.PropertyID
    );
    if (indexOfExistsItem >= 0) {
      this.getSelectedArr.splice(indexOfExistsItem, 1);
    } else {
      this.getSelectedArr.push(value);
    }
    if (this.testDummy) {
      this.getSelectedArr.push(value);
      this.sortData();
    }
    // this.selectedpropertyList = this.getSelectedArr;
  }

  /********************************
   * you can use same function for both for now not enough time to do that.
   */
  findIndexOf(prop) {
    let indexOfExistsItem = this.getSelectedArr.findIndex(
      (accu: { [key: string]: string | number }) =>
        accu.PropertyID == prop.PropertyID
    );

    if (indexOfExistsItem >= 0) {
      return "selected";
    } else {
      return "";
    }
  }
  findIndexOf1(prop) {
    let indexOfExistsItem = this.getSelected1Arr.findIndex(
      (accu: { [key: string]: string | number }) =>
        accu.PropertyID == prop.PropertyID
    );

    if (indexOfExistsItem >= 0) {
      return "selected";
    } else {
      return "";
    }
  }
  /****************************************************************
   * hostbindig for keydown
   */

  @HostListener("window:keydown", ["$event"])
  keyDownCtrl(event: KeyboardEvent) {
    if (event.keyCode === 17) this.ctrl = true;

    if (event.shiftKey) {
      this.ctrl = true;
      this.testDummy = true;
    }
  }
  /********************************
   * hoslistener for keyup
   */
  @HostListener("window:keyup", ["$event"])
  keyUpCtrl(event: KeyboardEvent) {
    if (event.keyCode === 17) this.ctrl = false;

    this.flag = true;
    this.testDummy = false;
    this.ctrl = false;
  }

  /******************************* host host lisen for ctrl and shift  */
  // @HostListener("window:keydown", ["$event"])
  // keyDownCtrlWithShift(event: KeyboardEvent) {
  //   if (event.ctrlKey && event.shiftKey) {
  //     this.sortData();
  //   }
  // }
  ////////////////////////////////
  flag = true;
  sortData() {
    if (this.flag) {
      let indexes = this.getSelectedArr
        .map((accu) => {
          return this.getPropertyAssignment.findIndex((elem) => {
            if (elem.PropertyID == accu.PropertyID) {
              return true;
            }
          });
        })
        .sort();
      //console.log(indexes);
      this.flag = false;
      this.getSelectedArr = [];
      let temp = [indexes[0], indexes[indexes.length - 1]];
      indexes = [];
      for (let i = temp[0]; i <= temp[1]; i++) {
        indexes.push(i);
      }

      indexes.forEach((elem) => {
        this.getSelectedArr.push(this.getPropertyAssignment[elem]);
      });
    }
  }
  sortData1() {
    if (this.flag) {
      let indexes = this.getSelected1Arr
        .map((accu) => {
          return this.selectedpropertyList.findIndex((elem) => {
            if (elem.PropertyID == accu.PropertyID) {
              return true;
            }
          });
        })
        .sort();
      //console.log(indexes);
      this.flag = false;
      this.getSelected1Arr = [];
      let temp = [indexes[0], indexes[indexes.length - 1]];
      indexes = [];
      for (let i = temp[0]; i <= temp[1]; i++) {
        indexes.push(i);
      }

      indexes.forEach((elem) => {
        this.getSelected1Arr.push(this.selectedpropertyList[elem]);
      });
    }
  }
  /******************************* */
  selectByPerson1: any = false;
  onleftPersonSelect1(value: any) {
    if (!this.ctrl) {
      this.getSelected1Arr.length = 1;

      if (this.getSelected1Arr[0]) {
        if (this.getSelected1Arr[0].PropertyID == value.PropertyID) {
          this.getSelected1Arr = [];
        } else {
          this.getSelected1Arr[0] = value;
        }
      } else {
        this.getSelected1Arr[0] = value;
      }
      return;
    }

    let indexOfExistsItem = this.getSelected1Arr.findIndex(
      (accu: { [key: string]: string | number }) =>
        accu.PropertyID == value.PropertyID
    );
    if (indexOfExistsItem >= 0) {
      this.getSelected1Arr.splice(indexOfExistsItem, 1);
    } else {
      this.getSelected1Arr.push(value);
    }
    if (this.testDummy) {
      this.getSelected1Arr.push(value);
      this.sortData1();
    }
  }

  // upper
  ChangePassDownLogStatusActive(passDownLogID) {
    let obj = {
      PassDownLogID: passDownLogID,
    };

    Swal.fire({
      text: "Are you sure you want to deactivate this?",
      showCancelButton: true,
      width: "30%",
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes",
    }).then((result) => {
      if (result.value) {
        this.passDownLogService
          .ChangePassDownLogStatus(obj)
          .subscribe((data) => {
            // let val = this.tableShowMe
            // this.onValChange(this.tableShowMe);
            if (this.passDownLogFormFilters.PropertyID == "") {
              this.passDownLogFormFilters.PropertyID = null;
            }
            let getFirstCallObj = {
              PropertyID: this.passDownLogFormFilters.PropertyID,
              FromDate: this.FromDate,
              ToDate: this.ToDate,
              PassDownStatus:
                this.passDownLogFilter.groupStatus.length == 0
                  ? "Active"
                  : this.passDownLogFilter.groupStatus[0],
              UserId:
                this.passDownLogFilter.userValue1 == "" ? null : this.UserID,
              IsShowMultiPropertyOnly:
                this.passDownLogFilter.userValue2 == "" ? null : "Yes",
            };
            this.getPassDownListOnMain(getFirstCallObj);
            // Swal.fire({ html: data.message });
            this.showValid(data.message);
          });
      }
    });
  }

  // upper
  ChangePassDownLogStatusInActive(passDownLogID) {
    let obj = {
      PassDownLogID: passDownLogID,
    };

    Swal.fire({
      text: "Are you sure you want to activate this?",
      showCancelButton: true,
      width: "30%",
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes",
    }).then((result) => {
      if (result.value) {
        this.passDownLogService
          .ChangePassDownLogStatus(obj)
          .subscribe((data) => {
            // this.onValChange(this.tableShowMe);
            if (this.passDownLogFormFilters.PropertyID == "") {
              this.passDownLogFormFilters.PropertyID = null;
            }
            let getFirstCallObj = {
              PropertyID: this.passDownLogFormFilters.PropertyID,
              FromDate: this.FromDate,
              ToDate: this.ToDate,
              PassDownStatus:
                this.passDownLogFilter.groupStatus.length == 0
                  ? "Active"
                  : this.passDownLogFilter.groupStatus[0],
              UserId:
                this.passDownLogFilter.userValue1 == "" ? null : this.UserID,
              IsShowMultiPropertyOnly:
                this.passDownLogFilter.userValue2 == "" ? null : "Yes",
            };
            this.getPassDownListOnMain(getFirstCallObj);
            // Swal.fire({ html: data.message });
            this.showValid(data.message);
          });
      }
    });
  }

  // lower do not delete
  ChangePassDownLogStatusActiveEdit(passDownLogFileID) {
    let obj = {
      PassDownLogFileID: passDownLogFileID,
    };

    Swal.fire({
      text: "Are you sure you want to deactivate this?",
      showCancelButton: true,
      width: "30%",
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes",
    }).then((result) => {
      if (result.value) {
        this.passDownLogService
          .ChangePassDownLogFileStatus(obj)
          .subscribe((data) => {
            // let newPassDownLogID = data.data.ChangePassDownLogStatus
            this.GetPassDownLogFileNameList.forEach((element, index) => {
              if (element.PassDownLogFileID == passDownLogFileID) {
                this.GetPassDownLogFileNameList[index].IsActive = false;
              }
            });
            // Swal.fire({ html: data.message });
            this.showValid(data.message);
          });
      }
    });
  }

  // lower do not delete
  ChangePassDownLogStatusInActiveEdit(passDownLogFileID) {
    let obj = {
      PassDownLogFileID: passDownLogFileID,
    };

    Swal.fire({
      text: "Are you sure you want to activate this?",
      showCancelButton: true,
      width: "30%",
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes",
    }).then((result) => {
      if (result.value) {
        this.passDownLogService
          .ChangePassDownLogFileStatus(obj)
          .subscribe((data) => {
            // let PassDownLogFileID = data.data.ChangePassDownLogFileStatus
            this.GetPassDownLogFileNameList.forEach((element, index) => {
              if (element.PassDownLogFileID == passDownLogFileID) {
                this.GetPassDownLogFileNameList[index].IsActive = true;
              }
            });
            // Swal.fire({ html: data.message });
            this.showValid(data.message);
          });
      }
    });
  }

  // for upper date
  mindate: any;
  maxdate: any;
  customDateSearch(type, elem) {
    let val = elem.value.trim();
    let month, day, year;
    if (val == "") {
      val = null;
    } else {
      month = parseInt(val.split("/")[0]);
      day = parseInt(val.split("/")[1]);
      year = parseInt(val.split("/")[2]);
    }

    if (type === "FromDate") {
      this.FromDate = val;
      this.mindate = new Date(year, month - 1, day);
    } else {
      this.maxdate = new Date(year, month - 1, day);
      this.ToDate = val;
    }
  }

  // for form day and date
  datee: any;
  GetPassDownDisplayTypeDate(date, PassDownDisplayTypeID, arr, index) {
    let val = date.value.trim();
    if (val == "") {
      val = null;
    }
    if (val.length > 10) {
      let newDate = new Date(val);
      let month = newDate.getMonth() + 1;
      let date = newDate.getDate() + 1;
      val = month + "/" + date + "/" + newDate.getFullYear();
    }

    if (arr && arr.length == index + 1 && val != "") {
      this.daysFlag = true;
    } else {
      this.daysFlag = false;
      this.days.length = 0;
    }

    this.PassDownDisplayTypeDate = val;
    this.PassDownDisplayTypeID = PassDownDisplayTypeID;
  }

  getPropertyResponseName(name) {}

  getWorkGroupName(name) {}

  // on click of only me and multi select button
  // tableShowMe: any;
  noDataFound: boolean = false;
  onValChange1(event) {
    if (this.passDownLogFormFilters.PropertyID == "") {
      this.passDownLogFormFilters.PropertyID = null;
    }

    let toggle = event.source;
    if (toggle) {
      let group = toggle.buttonToggleGroup;
      if (event.value.some((item) => item == toggle.value)) {
        group.value = [toggle.value];
        this.passDownLogFilter["userValue1"] = group.value;
        let getFirstCallObj = {
          PropertyID: this.passDownLogFormFilters.PropertyID,
          FromDate: this.FromDate,
          ToDate: this.ToDate,
          PassDownStatus:
            this.passDownLogFilter.groupStatus.length == 0
              ? "Active"
              : this.passDownLogFilter.groupStatus[0],
          UserId: this.passDownLogFilter.userValue1 == "" ? null : this.UserID,
          IsShowMultiPropertyOnly:
            this.passDownLogFilter.userValue2 == "" ? null : "Yes",
        };
        this.getPassDownListOnMain(getFirstCallObj);
      }
    } else {
      this.passDownLogFilter["userValue1"] = "";
      let getFirstCallObj = {
        PropertyID: this.passDownLogFormFilters.PropertyID,
        FromDate: this.FromDate,
        ToDate: this.ToDate,
        PassDownStatus:
          this.passDownLogFilter.groupStatus.length == 0
            ? "Active"
            : this.passDownLogFilter.groupStatus[0],
        UserId: this.passDownLogFilter.userValue1 == "" ? null : this.UserID,
        IsShowMultiPropertyOnly:
          this.passDownLogFilter.userValue2 == "" ? null : "Yes",
      };
      this.getPassDownListOnMain(getFirstCallObj);
    }
  }

  onValChange2(event) {
    if (this.passDownLogFormFilters.PropertyID == "") {
      this.passDownLogFormFilters.PropertyID = null;
    }
    // if (this.passDownLogFilter.groupStatus && this.passDownLogFilter.groupStatus.length == 0) {
    //   this.passDownLogFilter.groupStatus = ["ALL"]
    // }

    let toggle = event.source;
    if (toggle) {
      let group = toggle.buttonToggleGroup;
      if (event.value.some((item) => item == toggle.value)) {
        group.value = [toggle.value];
        this.passDownLogFilter["userValue2"] = group.value;
        let getFirstCallObj = {
          PropertyID: this.passDownLogFormFilters.PropertyID,
          FromDate: this.FromDate,
          ToDate: this.ToDate,
          PassDownStatus:
            this.passDownLogFilter.groupStatus.length == 0
              ? "Active"
              : this.passDownLogFilter.groupStatus[0],
          UserId: this.passDownLogFilter.userValue1 == "" ? null : this.UserID,
          IsShowMultiPropertyOnly:
            this.passDownLogFilter.userValue2 == "" ? null : "Yes",
        };
        this.getPassDownListOnMain(getFirstCallObj);
      }
    } else {
      this.passDownLogFilter["userValue2"] = "";
      let getFirstCallObj = {
        PropertyID: this.passDownLogFormFilters.PropertyID,
        FromDate: this.FromDate,
        ToDate: this.ToDate,
        PassDownStatus:
          this.passDownLogFilter.groupStatus.length == 0
            ? "Active"
            : this.passDownLogFilter.groupStatus[0],
        UserId: this.passDownLogFilter.userValue1 == "" ? null : this.UserID,
        IsShowMultiPropertyOnly:
          this.passDownLogFilter.userValue2 == "" ? null : "Yes",
      };
      this.getPassDownListOnMain(getFirstCallObj);
    }
  }

  // upper
  DeletePassDownLog(passDownLogID) {
    let obj = {
      PassDownLogID: passDownLogID,
    };
    // let val = this.tableShowMe;

    Swal.fire({
      text: "Are you sure want to delete this record?",
      showCancelButton: true,
      width: "30%",
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes",
    }).then((result) => {
      if (result.value) {
        this.passDownLogService.DeletePassDownLog(obj).subscribe((data) => {
          // this.onValChange(val);
          if (this.passDownLogFormFilters.PropertyID == "") {
            this.passDownLogFormFilters.PropertyID = null;
          }
          let getFirstCallObj = {
            PropertyID: this.passDownLogFormFilters.PropertyID,
            FromDate: this.FromDate,
            ToDate: this.ToDate,
            PassDownStatus:
              this.passDownLogFilter.groupStatus.length == 0
                ? "Active"
                : this.passDownLogFilter.groupStatus[0],
            UserId:
              this.passDownLogFilter.userValue1 == "" ? null : this.UserID,
            IsShowMultiPropertyOnly:
              this.passDownLogFilter.userValue2 == "" ? null : "Yes",
          };
          this.getPassDownListOnMain(getFirstCallObj);
          // Swal.fire({ html: "Record Deleted Successfully." });
          this.showValid("Record Deleted Successfully.");
        });
      }
    });
  }

  // for uploading other files except images
  detectOther(event) {
    let files = event.target.files;
    if (files) {
      for (let file of files) {
        if (file.type.endsWith("document")) {
          this.imgName.push(file.name);
          this.imgURL.push(
            "../../../../../assets/images/material-icons/word_image.jpg"
          );
          if (this.isEdit == true) {
            this.GetPassDownLogFileNameList.push({
              PassDownFileName: file.name,
              IsActive: true,
            });
            this.GetFileNameList.push(file.name);
            this.imgName = [];
          }
        } else if (file.type.startsWith("video")) {
          this.imgName.push(file.name);
          this.imgURL.push(
            "../../../../../assets/images/material-icons/Video_image.png"
          );
          if (this.isEdit == true) {
            this.GetPassDownLogFileNameList.push({
              PassDownFileName: file.name,
              IsActive: true,
            });
            this.GetFileNameList.push(file.name);
            this.imgName = [];
          }
        } else if (file.type.startsWith("audio")) {
          this.imgName.push(file.name);
          this.imgURL.push(
            "../../../../../assets/images/material-icons/Audio_image.png"
          );
          if (this.isEdit == true) {
            this.GetPassDownLogFileNameList.push({
              PassDownFileName: file.name,
              IsActive: true,
            });
            this.GetFileNameList.push(file.name);
            this.imgName = [];
          }
        } else if (file.type.includes("audio/ogg")) {
          this.imgName.push(file.name);
          this.imgURL.push(
            "../../../../../assets/images/material-icons/ogg.png"
          );
          if (this.isEdit == true) {
            this.GetPassDownLogFileNameList.push({
              PassDownFileName: file.name,
              IsActive: true,
            });
            this.GetFileNameList.push(file.name);
            this.imgName = [];
          }
        } else if (file.type.length == 0) {
          this.imgName.push(file.name);
          this.imgURL.push(
            "../../../../../assets/images/material-icons/ra.png"
          );
          if (this.isEdit == true) {
            this.GetPassDownLogFileNameList.push({
              PassDownFileName: file.name,
              IsActive: true,
            });
            this.GetFileNameList.push(file.name);
            this.imgName = [];
          }
        } else if (file.type.endsWith("pdf")) {
          this.imgName.push(file.name);
          this.imgURL.push(
            "../../../../../assets/images/material-icons/PDF_image.png"
          );
          if (this.isEdit == true) {
            this.GetPassDownLogFileNameList.push({
              PassDownFileName: file.name,
              IsActive: true,
            });
            this.GetFileNameList.push(file.name);
            this.imgName = [];
          }
        } else if (file.type.endsWith("sheet")) {
          this.imgName.push(file.name);
          this.imgURL.push(
            "../../../../../assets/images/material-icons/Excel_image.jpg"
          );
          if (this.isEdit == true) {
            this.GetPassDownLogFileNameList.push({
              PassDownFileName: file.name,
              IsActive: true,
            });
            this.GetFileNameList.push(file.name);
            this.imgName = [];
          }
        } else if (file.type.endsWith("presentation")) {
          this.imgName.push(file.name);
          this.imgURL.push(
            "../../../../../assets/images/material-icons/ppt_image.png"
          );
          if (this.isEdit == true) {
            this.GetPassDownLogFileNameList.push({
              PassDownFileName: file.name,
              IsActive: true,
            });
            this.GetFileNameList.push(file.name);
            this.imgName = [];
          }
        }
      }
    }
  }

  // for uploading images
  FileMeta: any = [];
  detectFiles(event) {
    this.FileMeta.push(<File>event.target.files[0]);
    let files = event.target.files;
    if (files) {
      for (let file of files) {
        if (file.type.startsWith("image")) {
          if (this.isEdit == true) {
            this.GetPassDownLogFileNameList.push({
              PassDownFileName: file.name,
              IsActive: true,
            });
            this.GetFileNameList.push(file.name);
            this.imgName = [];
          } else {
            this.GetPassDownLogFileNameList = [];
            this.imgName.push(file.name);
          }
          let reader = new FileReader();
          reader.onload = (e: any) => {
            if (this.isEdit == true) {
              let len = this.GetPassDownLogFileNameList.length - 1;
              this.GetPassDownLogFileNameList[len] = Object.assign(
                { url: e.target.result },
                this.GetPassDownLogFileNameList[len]
              );
              this.GetPassDownLogFileNameList[len] = Object.assign(
                { isLocalURL: true },
                this.GetPassDownLogFileNameList[len]
              );
              //console.log("Edit: upload", this.GetPassDownLogFileNameList);
            } else {
              this.imgURL.push(e.target.result);
            }
          };
          reader.readAsDataURL(file);
        }
      }
    }
  }

  // save button on form
  isErrorTitle: boolean = false;
  isErrorMsg: boolean = false;
  isErrorDate: boolean = false;
  EditPassDownLogID: any;
  savePassLog() {
    // if (this.propertyIDValueFromView !== undefined) {
    //   this.passDownLogFormFilters.PropertyID = this.propertyIDValueFromView
    // }
    // if (this.passDownLogFormFilters.PropertyID == '') {
    //   this.passDownLogFormFilters.PropertyID = this.UserPropertyID
    // }
    if (this.passDownTitle == undefined || this.passDownTitle == "") {
      this.isErrorTitle = true;
      this.showInvalid("Title is required.");
    } else {
      this.isErrorTitle = false;
    }
    if (this.passDownMsg == undefined || this.passDownMsg == "") {
      this.isErrorMsg = true;
      this.showInvalid("Pass Down Entry Message is required.");
    } else {
      this.isErrorMsg = false;
    }
    if (this.PassDownDisplayTypeDate == undefined || this.PassDownDisplayTypeDate == "") {
      this.isErrorDate = true;
      this.showInvalid("Pass Down Log Display Date is required.");
    } else {
      this.isErrorDate = false;
    }
    
    let obj = {
      PassDownLogID:
        this.EditPassDownLogID == undefined ? 0 : this.EditPassDownLogID,
      PropertyID: parseInt(this.UserPropertyID),
      Title: this.passDownTitle,
      Message: this.passDownMsg,
      CreatedBy: this.UserID,
    };
    if (this.isErrorTitle == false && this.isErrorMsg == false && this.isErrorDate == false) {
      this.passDownLogService.UpdatePassDownLog(obj).subscribe((data) => {
        let PassDownLogID = data.data.UpdatePassDownLog[0].PassDownLogID;
        this.UpdatePassDownLogDisplay(PassDownLogID);
        this.onUpload(PassDownLogID);
        this.UpdatePassDownLogAssignment(PassDownLogID);
      });
    }
  }

  // to upload assigned properties to the API
  ToDateBind: any;
  FromDateBind: any;
  UpdatePassDownLogAssignment(PassDownLogID) {
    let listOfPropertyIds = [];
    if (this.selectedpropertyListLength !== 0) {
      listOfPropertyIds = this.selectedpropertyList.map((data) => {
        return data.PropertyID;
      });
      let obj = {
        PassDownLogID: PassDownLogID,
        PropertyIDs: listOfPropertyIds.toString(),
      };
      this.passDownLogService
        .UpdatePassDownLogAssignment(obj)
        .subscribe((data) => {
          //console.log(
          //   this.FromDate,
          //   this.ToDate,
          //   this.ToDateBind,
          //   this.FromDateBind
          // );
          // Swal.fire({ html: "Pass down log Details saved Successfully." });
          this.showValid("Pass down log Details saved Successfully.");
          this.show = !this.show;
          this.isEdit = false;
          // let val = this.tableShowMe
          if (this.getPassDownList == undefined) {
            this.noDataFound = true;
          } else if (this.getPassDownList.length == 0) {
            this.noDataFound = true;
          } else {
            this.noDataFound = false;
          }
          if (this.viewShow != undefined) {
            this.showViewList();
          } else {
            if (this.FromDate != null) {
              this.FromDateBind = new Date(this.FromDate);
            } else {
              this.FromDateBind = null;
            }
            if (this.ToDate != null) {
              this.ToDateBind = new Date(this.ToDate);
            } else {
              this.ToDateBind = null;
            }
            // this.onValChange(this.tableShowMe);
            if (this.passDownLogFormFilters.PropertyID == "") {
              this.passDownLogFormFilters.PropertyID = null;
            }
            let getFirstCallObj = {
              PropertyID: this.passDownLogFormFilters.PropertyID,
              FromDate: this.FromDate,
              ToDate: this.ToDate,
              PassDownStatus:
                this.passDownLogFilter.groupStatus.length == 0
                  ? "Active"
                  : this.passDownLogFilter.groupStatus[0],
              UserId:
                this.passDownLogFilter.userValue1 == "" ? null : this.UserID,
              IsShowMultiPropertyOnly:
                this.passDownLogFilter.userValue2 == "" ? null : "Yes",
            };
            this.getPassDownListOnMain(getFirstCallObj);
          }
        });
    } else {
      // Swal.fire({ html: "Please assign at least one Property." });
      this.showInvalid("Please assign at least one Property.");
    }
  }

  // to upload date and day(s) to API
  UpdatePassDownLogDisplay(PassDownLogID) {
    let forDisplay = {
      PassDownLogID: PassDownLogID,
      DisplayTypeID: this.PassDownDisplayTypeID,
      DisplayDate: this.PassDownDisplayTypeDate,
      DisplayDays: this.days.length == 0 ? "" : this.days.toString(),
    };
    this.passDownLogService
      .UpdatePassDownLogDisplay(forDisplay)
      .subscribe((data2) => {});
  }

  // to upload files to backend through API
  private onUpload(PassDownLogID) {
    let imagesEdit = this.GetPassDownLogFileNameList.map((data) => {
      return data.PassDownFileName;
    });
    // let imagesName = [...new Set(this.imgName.concat(imagesEdit))];
    let imagesName = this.imgName.concat(imagesEdit);
    let IsShowOnTiles = [];
    for (let index = 0; index < imagesName.length; index++) {
      if (imagesName[index] == this.nonEditFileUploadSelect) {
        IsShowOnTiles.push(1);
      } else {
        IsShowOnTiles.push(0);
      }
    }
    let obj = {
      PassDownLogID: PassDownLogID,
      PassDownFileNames: imagesName.toString(),
      Files: this.FileMeta,
      IsShowOnTiles: IsShowOnTiles.toString(),
    };
    //console.log("122", this.nonEditFileUploadSelect);
    let fd = new FormData();
    fd.append("PassDownLogID", obj.PassDownLogID);
    fd.append("PassDownFileNames", obj.PassDownFileNames);
    fd.append("IsShowOnTiles", obj.IsShowOnTiles);

    for (let i of this.FileMeta) {
      fd.append("Files", i);
    }
    //console.log("Upload: to API", imagesName.toString(), this.FileMeta);

    this.passDownLogService.UpdatePassDownLogFile(fd).subscribe((res) => {
      // this.GetPassDownLogFileByPassDownLogID();
    });
  }

  // for lower
  DeletePassDownLogFile( name, index) {
    Swal.fire({
      text: "Are you sure want to delete this record?",
      showCancelButton: true,
      width: "30%",
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes",
    }).then((result) => {
      if (result.value) {
        // this.imgName = this.imgName.filter((item) => item !== name);
        // this.imgURL = this.imgURL.filter((item) => item !== url);
        this.imgName.splice(index, 1);
        this.imgURL.splice(index, 1);
        this.FileMeta.splice(index, 1);
        if (this.isEdit) {
          this.GetFileNameList.splice(index, 1)
        }
        // Swal.fire({ html: "Record Deleted Successfully." });
        this.showValid("Record Deleted Successfully.");
      }
    });
  }

  // for lower on edit
  DeletePassDownLogFileEdit(name, PassDownLogFileID, index) {
    let obj = {
      PassDownLogFileID: parseInt(PassDownLogFileID),
    };
    // let passDownLogID = PassDownLogID;
    if (PassDownLogFileID == undefined) {
      Swal.fire({
        text: "Are you sure want to delete this record?",
        showCancelButton: true,
        width: "30%",
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes",
      }).then((result) => {
        if (result.value) {
          // this.GetPassDownLogFileNameList = this.GetPassDownLogFileNameList.filter(
          //   (item) => item.PassDownFileName !== name
          // );
          // this.FileMeta = this.FileMeta.filter((item) => item.name != name);
          this.GetPassDownLogFileNameList.splice(index, 1);
          this.FileMeta.splice(index, 1);
          this.GetFileNameList.splice(index, 1);
          // Swal.fire({ html: "Record Deleted Successfully." });
          this.showValid("Record Deleted Successfully.");
        }
      });
    } else {
      Swal.fire({
        text: "Are you sure want to delete this record?",
        showCancelButton: true,
        width: "30%",
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes",
      }).then((result) => {
        if (result.value) {
          this.passDownLogService
            .DeletePassDownLogFile(obj)
            .subscribe((data) => {
              this.GetPassDownLogFileNameList.splice(index, 1);
              this.GetFileNameList.splice(index, 1);
              // Swal.fire({ html: "Record Deleted Successfully." });
              this.showValid("Record Deleted Successfully.");
            });
        }
      });
    }
  }

  // button in form to show more and less toggle
  showMoreFlag() {
    this.showMore = !this.showMore;
  }

  selectedpropertyList: any = [];
  selectedpropertyListLength: number = 0;

  //opertions on assignment
  AddProperty() {
    if (this.getSelectedArr.length == 0) {
      // Swal.fire({ html: 'Please select Property from the left panel, then click add.' })
      this.showInvalid(
        "Please select Property from the left panel, then click add."
      );
    } else {
      this.getSelectedArr.forEach((elem) => {
        let ext = this.selectedpropertyList.find((accu) => {
          if (accu.PropertyID == elem.PropertyID) return elem;
        });

        if (!ext) {
          this.selectedpropertyList.push(elem);
          this.selectedpropertyListLength = this.selectedpropertyList.length;
        }
      });

      this.getSelectedArr = [];
      this.getSelected1Arr = [];
    }

    // if (this.selectByPerson && this.selectedpropertyListLength == 0) {
    //   this.selectedpropertyList.push(this.selectByPerson);
    //   this.selectedpropertyListLength = this.selectedpropertyList.length;
    // } else {
    //   let returnArray = this.selectedpropertyList.filter((data) => {
    //     return data.PropertyID == this.selectByPerson.PropertyID;
    //   });
    //   if (returnArray.length == 0) {
    //     this.selectedpropertyList.push(this.selectByPerson);
    //     this.selectedpropertyListLength = this.selectedpropertyList.length;
    //   } else {
    //     Swal.fire({ html: "Property already selected." });
    //   }
    // }
  }

  AddAllProperty() {
    this.selectedpropertyList = [];
    this.selectedpropertyList = [
      ...new Set(this.getPropertyAssignment.concat(this.selectedpropertyList)),
    ];
    this.selectedpropertyListLength = this.selectedpropertyList.length;
  }

  RemoveProperty() {
    // if (this.getSelected1Arr.length > 0) {
    if (this.getSelected1Arr.length == 0) {
      // Swal.fire({ html: 'Please select Property  from the right panel, then click remove.' })
      this.showInvalid(
        "Please select Property  from the right panel, then click remove."
      );
    } else {
      this.getSelected1Arr.forEach((elem) => {
        let index = this.selectedpropertyList.findIndex((accu) => {
          if (accu.PropertyID == elem.PropertyID) {
            return true;
          }
        });
        //console.log(index);

        if (index >= 0) {
          this.selectedpropertyList.splice(index, 1);
        }
      });
    }

    // return;
    // }
    // let index = this.selectedpropertyList
    //   ? this.selectedpropertyList.indexOf(this.selectByPerson1)
    //   : -1;
    // if (index > -1) {
    //   this.selectedpropertyList.splice(index, 1);
    //   this.selectedpropertyListLength = this.selectedpropertyList.length;
    // } else {
    //   Swal.fire({ html: "Please select a Property." });
    // }
  }

  ClearProperty() {
    this.selectedpropertyList = [];
    this.selectedpropertyListLength = this.selectedpropertyList.length;
  }

  // on row edit
  isEdit: boolean = false;
  EditPassDownLog(passDownLogID) {
    this.EditPassDownLogID = passDownLogID;
    this.isEdit = true;
    this.show = !this.show;
    this.FileMeta = [];
    this.FileMeta.length = 0;
    // this.GetPassDownLogFileNameList = [];
    // this.GetFileNameList = []
    // this.GetFileNameList.length = 0
    // this.GetPassDownLogFileNameList.length = 0
    this.imgName = [];
    this.imgURL = [];
    this.imgName.length = 0;
    this.imgURL.length = 0;
    this.GetPassDownLogByPassDownLogID(passDownLogID);
    this.GetPassDownLogDisplayPassDownLogID(passDownLogID);
    this.GetPassDownLogFileByPassDownLogID(passDownLogID);
    this.GetPassDownLogAssignmentByPassDownLogID(passDownLogID);
  }

  // get title and msg on edit
  GetPassDownLogByPassDownLogID(passDownLogID) {
    let obj = {
      PassDownLogID: passDownLogID,
    };
    this.passDownLogService
      .GetPassDownLogByPassDownLogID(obj)
      .subscribe((data) => {
        let GetPassDownLogByPassDownLogID =
          data.data.GetPassDownLogByPassDownLogID;
        this.passDownLogFormFilters.PropertyID =
          GetPassDownLogByPassDownLogID[0].PropertyID;
        this.passDownMsg = GetPassDownLogByPassDownLogID[0].Message;
        this.passDownTitle = GetPassDownLogByPassDownLogID[0].Title;
      });
  }

  // get day(s) and date on edit
  tempVar: any = {
    PassDownDisplayTypeID: null,
  };
  tempVar1: any = {
    PassDownDisplayTypeID: null,
  };

  showDate: boolean = false;
  GetPassDownLogDisplayPassDownLogID(passDownLogID) {
    let obj = {
      PassDownLogID: passDownLogID,
    };
    this.passDownLogService
      .GetPassDownLogDisplayPassDownLogID(obj)
      .subscribe((data) => {
        let GetPassDownLogDisplayPassDownLogID =
          data.data.GetPassDownLogDisplayPassDownLogID[0];
        if (GetPassDownLogDisplayPassDownLogID.DisplayTypeId == 1) {
          this.showMore = false;
        } else {
          this.showMore = true;
        }
        this.PassDownDisplayTypeID =
          GetPassDownLogDisplayPassDownLogID.DisplayTypeId;
        this.PassDownDisplayTypeDate =
          GetPassDownLogDisplayPassDownLogID.DisplayDate;
        this.days = GetPassDownLogDisplayPassDownLogID.DisplayDays.split(",");
        this.GetPassDownDisplayType = [
          ...new Set(
            this.GetPassDownDisplayTypeRest.concat(
              this.GetPassDownDisplayTypeFirst
            )
          ),
        ];
        this.GetPassDownDisplayTypeEditFirst = this.GetPassDownDisplayType.filter(
          (a) => {
            return (
              a.PassDownDisplayTypeID ==
              GetPassDownLogDisplayPassDownLogID.DisplayTypeId
            );
          }
        );
        if (!this.GetPassDownDisplayTypeEditFirst.length) {
          this.GetPassDownDisplayTypeEditFirst[0] = {
            PassDownDisplayTypeID: null,
          };
          this.showMore = false;
        }
        this.tempVar = this.GetPassDownDisplayTypeEditFirst[0] || {
          PassDownDisplayTypeID: null,
        };

        this.datee = new Date(GetPassDownLogDisplayPassDownLogID.DisplayDate);
        this.showDate = true;
      });
  }

  // get files name on edit
  GetPassDownLogFileNameList: any = [];
  GetFileNameList: any = [];
  GetPassDownLogFileNameListLength: number;
  GetPassDownLogFileByPassDownLogID(passDownLogID) {
    let obj = {
      PassDownLogID: passDownLogID,
    };
    this.passDownLogService
      .GetPassDownLogFileByPassDownLogID(obj)
      .subscribe((data) => {
        this.GetPassDownLogFileNameList = [];
        this.GetFileNameList = [];
        let getFileData = data.data.GetPassDownLogFileByPassDownLogID;
        this.GetPassDownLogFileNameListLength = getFileData.length;
        for (let viewFiles of getFileData) {
          viewFiles = Object.assign({ isLocalURL: false }, viewFiles);
          this.GetPassDownLogFileNameList.push(viewFiles);
          this.GetFileNameList.push(
            this.removeHashFromFile(viewFiles.PassDownFileName)
          );
          if (viewFiles.IsShowOnTile == true) {
            this.nonEditFileUploadSelect = viewFiles.PassDownFileName;
            for (let index = 0; index < getFileData.length; index++) {
              if (getFileData[index].IsShowOnTile == true) {
                this.indexFiles = index;
              }
            }
          }
        }
        // //console.log(
        //   "Get: File",
        //   this.GetPassDownLogFileNameList,
        //   this.GetFileNameList
        // );
      });
  }

  // removing files hash from their name
  private removeHashFromFile(fileName) {
    if (fileName.includes(".")) {
      let fileSplitArray = fileName.split(".");
      let lastDashIndex = fileSplitArray[0].lastIndexOf("-");
      let firstPart = fileSplitArray[0].slice(0, lastDashIndex);
      return firstPart + "." + fileSplitArray[1];
    }

    return fileName;
  }

  // get assignment values on edit
  GetPassDownLogAssignmentByPassDownLogID(passDownLogID) {
    let obj = {
      PassDownLogID: passDownLogID,
    };
    this.passDownLogService
      .GetPassDownLogAssignmentByPassDownLogID(obj)
      .subscribe((data) => {
        let getPassDownLogAssignmentByPassDownLogID =
          data.data.getPassDownLogAssignmentByPassDownLogID;
        this.selectedpropertyList = [];
        this.selectedpropertyListLength = 0;
        if (
          getPassDownLogAssignmentByPassDownLogID &&
          getPassDownLogAssignmentByPassDownLogID.length != 0
        ) {
          for (let editAssignmentArray of getPassDownLogAssignmentByPassDownLogID) {
            this.selectedpropertyList.push({
              PropertyID: editAssignmentArray.PropertyID,
              PropertyName: editAssignmentArray.PropertyName,
            });
          }
          this.selectedpropertyListLength = this.selectedpropertyList.length;
        }
      });
  }

  // on click of Pass down log breadcrum
  tableShow() {
    this.nonEditFileUploadSelect = false;
    this.indexFiles = -1;
    if (this.viewShow != undefined) {
      this.showViewList();
    } else {
      this.show = false;
    }
    if (this.getPassDownList == undefined) {
      this.noDataFound = true;
    } else if (this.getPassDownList.length == 0) {
      this.noDataFound = true;
    } else {
      this.noDataFound = false;
    }
  }

  selectedDateColor: any = false;
  dateSelectColor(value: any) {
    if (this.selectedDateColor == value) {
      this.selectedDateColor = false;
    } else {
      this.selectedDateColor = value;
    }
  }

  /****************************************************************
   * date clear on next date select in passdownlog entry
   */
  myGroupEdit: FormGroup;
  initFormSetDate() {
    this.myGroupEdit = this.formBuilder.group({
      i0: new FormControl(""),
      i1: new FormControl(""),
      i2: new FormControl(""),
      i3: new FormControl(""),
      i4: new FormControl(""),
      i10: new FormControl(""),
    });
  }
  cleanRestArea(idValue: number | string) {
    //console.log(this.myGroupEdit);

    let fCtrlKeys = Object.keys(this.myGroupEdit.controls);
    let check = "i" + idValue;

    fCtrlKeys.forEach((elem: string) => {
      if (check !== elem) {
        this.myGroupEdit.controls[elem].setValue("");
        // //console.log(this.myGroupEdit, this.myGroupEdit.controls[elem].setValue(""), elem);
      }
    });
  }

  removeEdit(ele) {
    let fCtrlKeys = Object.keys(this.myGroupEdit.controls);
    let check = "i" + ele;

    fCtrlKeys.forEach((elem: string) => {
      if (check == elem) {
        this.myGroupEdit.controls[elem].setValue("");
      }
    });
  }

  myGroupNotEdit: FormGroup;
  initFormSetDateNotEdit() {
    this.myGroupNotEdit = this.formBuilder.group({
      i0: new FormControl(""),
      i1: new FormControl(""),
      i2: new FormControl(""),
      i3: new FormControl(""),
    });
  }
  cleanRestAreaNotEdit(idValue: number | string) {
    //console.log(this.myGroupNotEdit);

    let fCtrlKeys = Object.keys(this.myGroupNotEdit.controls);
    let check = "i" + idValue;

    fCtrlKeys.forEach((elem: string) => {
      if (check !== elem) {
        this.myGroupNotEdit.controls[elem].setValue("");
      }
    });
  }
  removeNotEdit(ele) {
    //console.log(ele)
    let fCtrlKeys = Object.keys(this.myGroupNotEdit.controls);
    let check = "i" + ele;
    fCtrlKeys.forEach((elem: string, index) => {
      if (check == elem) {
        this.myGroupNotEdit.controls[elem].setValue("");
      }
    });
  }

  downloadFile(name) {
    event.stopPropagation();
    // this.download(environment.imagePath + `passDownLog/${name}`, name);
    this.download(`${this.filePath}${name}`, name);
  }
  download(pdfUrl: string, pdfName: string) {
    fs.saveAs(pdfUrl, pdfName);
  }

  nonEditFileUploadSelect: any = false;
  indexFiles: any = -1;
  selectNonEditFileUpload(value: any, i) {
    if (this.nonEditFileUploadSelect == value) {
      this.nonEditFileUploadSelect = false;
      this.indexFiles = -1;
    } else {
      this.nonEditFileUploadSelect = value;
      this.indexFiles = i;
    }
  }
  reset() {
    this.myGroupEdit.reset();
  }

  mainGridID: number = 0;
  mainGridHighlight(valID) {
    if (this.mainGridID != valID) {
      this.mainGridID = valID;
    }
  }

  showInvalid(msg) {
    this.tostre.error(msg, "", {
      positionClass: "toast-top-right",
    });
  }
  showValid(validMsg) {
    this.tostre.success(validMsg, "", {
      positionClass: "toast-top-right",
    });
  }
}
