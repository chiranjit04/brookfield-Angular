import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PassdownlogregistryComponent } from './passdownlogregistry.component';

describe('PassdownlogregistryComponent', () => {
  let component: PassdownlogregistryComponent;
  let fixture: ComponentFixture<PassdownlogregistryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PassdownlogregistryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PassdownlogregistryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
