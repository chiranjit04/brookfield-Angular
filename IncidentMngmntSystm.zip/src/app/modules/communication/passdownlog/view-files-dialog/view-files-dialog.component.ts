import { Component, OnInit, Inject, ViewChild } from "@angular/core";
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from "@angular/material/dialog";
import Swal from "sweetalert2";
import { PassDownLogService } from "src/app/services/pass-down-log.service";
import { environment } from "src/environments/environment";
import * as fs from "file-saver";
import { MatSort, MatTableDataSource } from "@angular/material";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-view-files-dialog",
  templateUrl: "./view-files-dialog.component.html",
  styleUrls: ["./view-files-dialog.component.scss"],
})
export class ViewFilesDialogComponent implements OnInit {
  dataSource: any;
  displayedColumns: string[] = ["Files", "Actions"];
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  filePath: string;
  constructor(
    public dialogRef: MatDialogRef<ViewFilesDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private passDownLogService: PassDownLogService,
    public tostre: ToastrService
  ) {
    this.dataSource = new MatTableDataSource();
    this.dataSource.sort = this.sort;
    // this.filePath = environment.imagePath;
    if (environment.onProd == 1) {
      this.filePath = environment.imagePath + "passdownlog/";
    } else {
      this.filePath = environment.imagePath + "passDownLog/";
    }
  }

  ngOnInit() {
    this.dataSource.data = this.data;
    console.log(this.data);
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  customClass: {
    container: "your-container-class";
  };
  DeletePassDownLogFileEdit(passDownLogID, name, PassDownLogFileID) {
    let deleteFileObj = {
      PassDownLogFileID: parseInt(PassDownLogFileID),
    };
    // let passDownLogID = PassDownLogID;
    Swal.fire({
      customClass: { container: "viewpassdownlogx-index" },
      text: "Are you sure want to delete this record?",
      showCancelButton: true,
      width: "80%",
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes",
    }).then((result) => {
      if (result.value) {
        this.passDownLogService
          .DeletePassDownLogFile(deleteFileObj)
          .subscribe((res) => {
            let getFileObj = {
              PassDownLogID: passDownLogID,
            };
            this.passDownLogService
              .GetPassDownLogFileByPassDownLogID(getFileObj)
              .subscribe((data) => {
                this.dataSource.data =
                  data.data.GetPassDownLogFileByPassDownLogID;
                this.passDownLogService.sendChangedDialogValue("Refresh.");
              });
            // Swal.fire({ html: "Record Deleted Successfully." });
            this.showValid("Record Deleted Successfully.");
          });
      }
    });
  }

  downloadFile(name) {
    event.stopPropagation();
    // this.download(environment.imagePath + `passDownLog/${name}`, name);
    this.download(`${this.filePath}${name}`, name);
  }
  download(pdfUrl: string, pdfName: string) {
    fs.saveAs(pdfUrl, pdfName);
  }

  showInvalid(msg) {
    this.tostre.error(msg, "", {
      positionClass: "toast-top-right",
    });
  }
  showValid(validMsg) {
    this.tostre.success(validMsg, "", {
      positionClass: "toast-top-right",
    });
  }
}
