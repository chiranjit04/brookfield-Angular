import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewFilesDialogComponent } from './view-files-dialog.component';

describe('ViewFilesDialogComponent', () => {
  let component: ViewFilesDialogComponent;
  let fixture: ComponentFixture<ViewFilesDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewFilesDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewFilesDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
