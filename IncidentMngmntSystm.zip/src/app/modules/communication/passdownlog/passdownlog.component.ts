import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-passdownlog',
  templateUrl: './passdownlog.component.html',
  styleUrls: ['./passdownlog.component.scss']
})
export class PassdownlogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
