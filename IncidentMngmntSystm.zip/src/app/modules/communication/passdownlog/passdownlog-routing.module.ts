import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PassdownlogComponent } from './passdownlog.component';
import { PassdownlogregistryComponent } from './passdownlogregistry/passdownlogregistry.component';
import { ViewpassdownlogsComponent } from './viewpassdownlogs/viewpassdownlogs.component';
import { AuthGuard } from "./../../../guard/auth.guard";

const routes: Routes = [
  { path: '',canActivate: [ AuthGuard ],  redirectTo: 'passdownlogregistry', pathMatch:'full'  },
  { path: 'passdownlogregistry',canActivate: [ AuthGuard ], component: PassdownlogregistryComponent },
  { path: 'viewpassdownlogs',canActivate: [ AuthGuard ], component: ViewpassdownlogsComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PassdownlogRoutingModule { }
