import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PassdownlogRoutingModule } from './passdownlog-routing.module';
import { PassdownlogComponent } from './passdownlog.component';
import { PassdownlogregistryComponent } from './passdownlogregistry/passdownlogregistry.component';
import { ViewpassdownlogsComponent } from './viewpassdownlogs/viewpassdownlogs.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { ViewFilesDialogComponent } from './view-files-dialog/view-files-dialog.component';
import { SharedMaterialModule } from './../../../shared/shared-material.module';
import { SharedModule } from 'src/app/shared/shared.module';

@NgModule({
  declarations: [
    PassdownlogComponent,
    PassdownlogregistryComponent,
    ViewpassdownlogsComponent,
    ViewFilesDialogComponent
  ],
  imports: [
    CommonModule,
    PassdownlogRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    Ng2SearchPipeModule,
    DragDropModule,
    SharedMaterialModule,
    SharedModule
  ],
  exports:[
    PassdownlogComponent,
    PassdownlogregistryComponent,
    ViewpassdownlogsComponent
  ],
  entryComponents: [
    ViewFilesDialogComponent
  ]
})
export class PassdownlogModule { }
