import { Component, Input, OnInit } from "@angular/core";
import { userService } from "src/app/modules/administration/organizationmanagement/users/user.service";
import { FormGroup, FormBuilder, FormControl } from "@angular/forms";
import { startWith, map } from "rxjs/operators";
import { PassDownLogService } from "src/app/services/pass-down-log.service";
import Swal from "sweetalert2";
import * as fs from "file-saver";

import {
  MomentDateAdapter,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS,
} from "@angular/material-moment-adapter";
import {
  DateAdapter,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE,
} from "@angular/material/core";

import * as _moment from "moment";
import { ActivatedRoute } from "@angular/router";
import { MatDialog } from "@angular/material";
import { ViewFilesDialogComponent } from "../view-files-dialog/view-files-dialog.component";
import { ToastrService } from "ngx-toastr";
import { environment } from "src/environments/environment";
// tslint:disable-next-line:no-duplicate-imports
// import {default as _rollupMoment} from 'moment';

// const moment = _rollupMoment || _moment;
const moment = _moment;

export const MY_FORMATS = {
  parse: {
    dateInput: "LL",
  },
  display: {
    dateInput: "dddd, LL",
    monthYearLabel: "MMM YYYY",
    dateA11yLabel: "LL",
    monthYearA11yLabel: "MMMM YYYY",
  },
};

@Component({
  selector: "app-viewpassdownlogs",
  templateUrl: "./viewpassdownlogs.component.html",
  styleUrls: ["./viewpassdownlogs.component.scss"],
  providers: [
    userService,
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS],
    },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ],
})
export class ViewpassdownlogsComponent implements OnInit {
  passDownLogFormFilters = {
    PropertyID: "",
    FromDate: "",
  };

  days = {
    Sun: "Sunday",
    Mon: "Monday",
    Tue: "Tueday",
    Wed: "Wednesday",
    Thu: "Thursday",
    Fri: "Friday",
    Sat: "Saturday",
  };
  getProperty: any = [];
  getPropertyResponse: any = [];
  getPerson:any = [];
  // getPerson = [
  //   {
  //   "UserID": "11",
  //   "FirstName": "Amy",
  //   "LastName": "Gower",
  //   "EmployeeCode": "45455",
  //   "UnitNumber": "54544"
  //   },
  //   {
  //   "UserID": "2038",
  //   "FirstName": "Bill",
  //   "LastName": "joy",
  //   "EmployeeCode": "5612",
  //   "UnitNumber": ""
  //   }
  // ];
  getPersonListResponse: any = [];
  selectedUserID:any ='';
  passDownLogFilter: any;
  passDownLogFilterViewForm: FormGroup;
  show: boolean = false;
  showViewListFlag: boolean;
  getPassDownListView: any = [];
  getPassDownListViewFinal: any = [];
  dateToSend: any;
  selected: any;
  userCount: any = 0;
  changeToDispatch: boolean = false;
  filePath: string;
  @Input() selectedPropertyID:any;
  hidecross: boolean = false
  constructor(
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private userService: userService,
    private passDownLogService: PassDownLogService,
    public dialog: MatDialog,
    public tostre: ToastrService
  ) {
    if (this.route.snapshot.routeConfig.path == "communications/passdownlogs") {
      this.changeToDispatch = true;
    } else {
      this.changeToDispatch = false;
    }
    // this.filePath = environment.imagePath;
    if (environment.onProd == 1) {
      this.filePath = environment.imagePath + "passdownlog/";
    } else {
      this.filePath = environment.imagePath + "passDownLog/";
    }
  }

  ngOnInit() {
    this.passDownLogService.getChangedDialogValue().subscribe((data) => {
      //console.log(data);
      let val;
      if (this.convertDateString(this.dateToSend).length > 10) {
        let newDate = new Date(this.convertDateString(this.dateToSend));
        let month = newDate.getMonth() + 1;
        let date = newDate.getDate();
        val = month + "/" + date + "/" + newDate.getFullYear();
      }
      let obj = {
        PropertyID:
          this.passDownLogFormFilters.PropertyID == ""
            ? null
            : parseInt(this.passDownLogFormFilters.PropertyID),
        FromDate: val,
        ToDate: val,
        PassDownStatus: "Active",
        UserID:0,
      };

    //  this.getPassDownList(obj);
    //  this.getPersonList(obj.PropertyID);
    });

    if (this.showViewListFlag != undefined) {
      this.show = false;
    }
    this.dateToSend = new Date();

    this.passDownLogService
      .GetPropertyByUserIdPassdownLog()
      .subscribe((data) => {
        // this.getProperty = data.getPropertyResponse;
        this.getProperty = data.data.getPropertyByUserIdPassdownLog[0];
        this.userCount = this.getProperty.length;
        this.getPropertyResponse = this.passDownLogFilterViewForm.controls.PropertyID.valueChanges.pipe(
          startWith(""),
          map((val: any) => (val.length >= 0 ? this.filterProperty(val) : []))
        );
        if (this.userCount == 1) {
          for (const view of this.getProperty) {
            this.passDownLogFilter.PropertyID = view.PropertyName;
            this.passDownLogFormFilters["PropertyID"] = view.PropertyID;
          }
          this.hidecross = true
        } else {
          this.hidecross = false
        }
        this.getDateFormatToSend(this.dateToSend);
      });
    this.passDownLogFilter = {
      PropertyID: "",
      FromDate: "",
    };
    let currentDate = this.convertDateString(new Date());
    // this.getDateFormatToSend(this.dateToSend)

    this.passDownLogFilterViewForm = this.formBuilder.group({
      PropertyID: "",
      PersonName:"",
      cPassword:"",
      // FromDate: [currentDate],
      FromDate: new FormControl(moment()),
    });
    /**/
    if(this.selectedPropertyID != undefined){
      this.passDownLogFilter.PropertyID = this.selectedPropertyID[0].PropertyName;
      this.passDownLogFormFilters["PropertyID"] = this.selectedPropertyID[0].PropertyID;
      this.getPersonList(this.selectedPropertyID[0].PropertyID);
    }
    /**/
    this.getPropertyResponse = this.passDownLogFilterViewForm.controls.PropertyID.valueChanges.pipe(
      startWith(""),
      map((value) => {
        let list = value.length >= 1 ? this.filterProperty(value) : [];
        if (list.length == 1 && list[0].PropertyName == value) {
          list = [];
        }
        return list;
      })
    );
    this.getPersonListResponse = this.passDownLogFilterViewForm.controls.PersonName.valueChanges.pipe(
      startWith(""),
      map((val: any) =>(val.length >= 0 ? this.filterPerson(val) : []))
    );
  }

  // func. to convert date to string
  private convertDateString(currentDate) {
    let m = currentDate.toString().split(" ", 4).join(" ");
    let array1 = m.split(" ");
    let dayChange = this.days[array1[0]].split();
    array1.splice(0, 1, ...dayChange);
    return array1[0] + ", " + array1[1] + " " + array1[2] + ", " + array1[3];
  }

  private filterProperty(name: string): any {
    const filterValue = name.toLowerCase();
    return this.getProperty.filter((option) => {
      return option.PropertyName.toLowerCase().includes(filterValue);
    });
  }
  private filterPerson(name: string): any {
    const filterValue = name.toLowerCase();
    return this.getPerson.filter((option) => {
      return option.PersonName.toLowerCase().includes(filterValue);
    });
  }

  // get each value of property selected
  changeShowAll(event, prop, value) {
    if (event.isUserInput) {
      this.passDownLogFormFilters[prop] = value;
      let obj = {
        PropertyID:
          this.passDownLogFormFilters.PropertyID == ""
            ? null
            : parseInt(this.passDownLogFormFilters.PropertyID),
        FromDate: this.convertDateString(this.dateToSend),
        ToDate: this.convertDateString(this.dateToSend),
        PassDownStatus: "Active",
        UserID: 0,
      };
      console.log("property id -->",obj.PropertyID);
      this.resetUser();
      this.getPersonList(obj.PropertyID);
      this.getPassDownList(obj);
    }
  }

  // material search
  chcekProperty(test) {
    this.getPropertyResponse = this.passDownLogFilterViewForm.controls.PropertyID.valueChanges.pipe(
      startWith(""),
      map((val: any) => (val.length >= 0 ? this.filterProperty(val) : []))
    );
    test.blur();
  }

  removeFilter(event, prop) {
    this.passDownLogFormFilters[prop] = "";
    let obj = {
      PropertyID: null,
      FromDate: this.dateToSend,
      ToDate: this.dateToSend,
      PassDownStatus: "Active",
    };

    this.getPassDownList(obj);
    this.getPersonList(obj.PropertyID);
  }

  toggle() {
    this.show = !this.show;
    this.viewArray = undefined;
  }

  // sending event to pass down log registry
  recieveMessage($event) {
    this.showViewListFlag = $event;
    this.show = false;
    this.getDateFormatToSend(this.dateToSend);
  }

  addEvent(event) {
    //console.log(event.target._value._d, event.target._value._i, k, k);
    this.dateToSend = event.target._value._d;
    this.getDateFormatToSend(event.target._value._d);
  }

  // select next date
  setNextDate(control: any) {
    const lastDay = new Date(this.passDownLogFilterViewForm.get(control).value);
    //console.log(lastDay);
    let i = lastDay.valueOf() + 86400000;
    let sendDate: any = new Date(i);
    let val = this.convertDateString(new Date(sendDate));
    //console.log(val);
    this.passDownLogFilterViewForm.patchValue({ FromDate: new Date(val) });
    this.dateToSend = sendDate;
    this.getDateFormatToSend(sendDate);
    // this.passDownLogFilterViewForm.get(control).setValue(val.toString().split(' ', 4).join(' '));
  }

  // select prev date
  setPrevDate(control: any) {
    const lastDay = new Date(this.passDownLogFilterViewForm.get(control).value);
    let i = lastDay.valueOf() - 86400000;
    let sendDate: any = new Date(i);
    let val = this.convertDateString(sendDate);
    this.dateToSend = sendDate;
    this.passDownLogFilterViewForm.patchValue({ FromDate: new Date(val) });
    this.getDateFormatToSend(sendDate);
    // this.passDownLogFilterViewForm.get(control).setValue(val.toString().split(' ', 4).join(' '));
  }

  // get date formatted to send to api
  getDateFormatToSend(sendDate) {
    sendDate =
      ("0" + (sendDate.getMonth() + 1)).slice(-2) +
      "/" +
      ("0" + sendDate.getDate()).slice(-2) +
      "/" +
      sendDate.getFullYear();

    let obj = {
      PropertyID:
        this.passDownLogFormFilters.PropertyID == ""
          ? null
          : parseInt(this.passDownLogFormFilters.PropertyID),
      FromDate: sendDate,
      ToDate: sendDate,
      PassDownStatus: "Active",
      UserID:this.selectedPersonID
    };

    this.getPassDownList(obj);
  }

  getPassDownListAddingFile: any = [];
  noDataFound: boolean = false;
  getPassDownListF: any = [];
  getPassDownListFirst: any = [];
  getPassDownList(obj) {
    console.log("get pass down -->",obj);
    this.getPassDownListView = [];
    this.getPassDownListViewFinal = [];
    this.getPassDownListAddingFile = [];
    this.passDownLogService.GetPassDownListWithRule(obj).subscribe((data) => {
      let viewPropertyData = data.data.GetPassDownList;
      if (viewPropertyData.length == 0) {
        this.noDataFound = true;
      } else {
        this.noDataFound = false;
      }
      for (let view of viewPropertyData) {
        let obj2 = {
          PassDownLogID: view.PassDownLogID,
        };
        this.GetPassDownLogFileNameList = [];
        this.passDownLogService
          .GetPassDownLogFileByPassDownLogID(obj2)
          .subscribe((data) => {
            this.GetPassDownLogFileNameList.push(
              data.data.GetPassDownLogFileByPassDownLogID
            );
            if (
              this.GetPassDownLogFileNameList.length == viewPropertyData.length
            ) {
              const flat = (arr) =>
                [].concat.apply(
                  [],
                  arr.map((a) => (Array.isArray(a) ? flat(a) : a))
                );
              let fla = flat(this.GetPassDownLogFileNameList);
              let ShowOnGridToTrueFilter = fla.filter((a) => {
                return a.IsShowOnTile == true;
              });
              var group_to_values = fla.reduce(function (obj, item) {
                obj[item.PassDownLogID] = obj[item.PassDownLogID] || [];
                obj[item.PassDownLogID].push(item.PassDownFileName);
                return obj;
              }, {});
              var fileNames = Object.keys(group_to_values).map(function (key) {
                return {
                  PassDownLogID: key,
                  PassDownFileNames: group_to_values[key],
                };
              });
              //console.log("1", this.getPassDownListView);
              //console.log("2", fileNames);
              for (
                let index = 0;
                index < this.getPassDownListView.length;
                index++
              ) {
                for (let index1 = 0; index1 < fileNames.length; index1++) {
                  if (
                    this.getPassDownListView[index].PassDownLogID ==
                    fileNames[index1].PassDownLogID
                  ) {
                    this.getPassDownListView[index] = Object.assign(
                      { PassDownFileName: fileNames[index1].PassDownFileNames },
                      this.getPassDownListView[index]
                    );
                    this.getPassDownListView[index] = Object.assign(
                      {
                        PassDownFileNameLength:
                          fileNames[index1].PassDownFileNames.length - 1,
                      },
                      this.getPassDownListView[index]
                    );
                    this.getPassDownListAddingFile.push(
                      this.getPassDownListView[index]
                    );
                  }
                }
              }
              //console.log("3", this.getPassDownListAddingFile);
              const results = this.getPassDownListView.filter(
                ({ PassDownLogID: id1 }) =>
                  !this.getPassDownListAddingFile.some(
                    ({ PassDownLogID: id2 }) => id2 === id1
                  )
              );
              this.getPassDownListF = [];
              
              this.getPassDownListViewFinal = this.getPassDownListAddingFile.concat(
                results
              );
              console.log("obj-->1",obj);
              this.getPassDownListViewFinal.map((data) => {
                if (data.PassDownFileName) {
                  this.getPassDownListF.push(data);
                } else {
                  data = Object.assign({ PassDownFileName: [] }, data);
                  data = Object.assign({ PassDownFileNameLength: 0 }, data);
                  this.getPassDownListF.push(data);
                  // this.getPassDownListViewFinal.splice(this.getPassDownListViewFinal.indexOf(data), 1, data)
                }
                console.log("obj-->",this.getPassDownListF,obj);
                if(obj.UserID !=undefined){
                  if(obj.UserID == 0){
                    this.getPassDownListFirst = [];
                    this.getPassDownListFirst = this.getPassDownListF;
                    console.log("first time ",this.getPassDownListFirst);
                  }
                }
              });
             
              //console.log("4", this.getPassDownListViewFinal);
              //console.log("5", this.getPassDownListF);
            }
          });
        let date = new Date(view.Date);
        let day = this.days[date.toString().split(" ")[0]];
        view = Object.assign({ CreatedDay: day }, view);
        this.getPassDownListView.push(view);
      }
    });
  }

  GetPassDownLogFileNameList: any = [];
  IdFileNameMap: any = [];
  ChangePassDownLogStatus(passDownLogID) {
    let obj = {
      PassDownLogID: passDownLogID,
    };

    this.passDownLogService.ChangePassDownLogStatus(obj).subscribe((data) => {
      this.showValid(data.message);
      this.getPassDownListViewFinal.filter((data) => {
        if (data.PassDownLogID == passDownLogID) {
          data.IsActive = false;
        }
      });
      let returnArray = this.getPassDownListViewFinal.filter((data) => {
        return data.IsActive != false;
      });
      this.getPassDownListViewFinal = returnArray;
      this.getDateFormatToSend(this.dateToSend);
    });
    // Swal.fire({
    //   text: "Are you sure you want to deactivate this?",
    //   showCancelButton: true,
    //   width: "30%",
    //   confirmButtonColor: "#3085d6",
    //   cancelButtonColor: "#d33",
    //   confirmButtonText: "Yes",
    // }).then((result) => {
    //   if (result.value) {}
    //       });
    //   }
    // });
  }

  DeletePassDownLog(passDownLogID) {
    let obj = {
      PassDownLogID: passDownLogID,
    };

    Swal.fire({
      text: "Are you sure want to delete this record?",
      showCancelButton: true,
      width: "30%",
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes",
    }).then((result) => {
      if (result.value) {
        this.passDownLogService.DeletePassDownLog(obj).subscribe((data) => {
          // Swal.fire({ html: "Record Deleted Successfully." })
          this.showValid("Record Deleted Successfully.");
          let returnArray = this.getPassDownListViewFinal.filter((data) => {
            return data.PassDownLogID != passDownLogID;
          });
          this.getPassDownListViewFinal = returnArray;
          this.getDateFormatToSend(this.dateToSend);
        });
      }
    });
  }

  viewArray: any;
  EditRowData(viewData) {
    this.toggle();
    this.viewArray = viewData;
  }

  filesViewOnPopup: any;
  filesViewOnPopupLength: number = 0;
  // getFiles(passDownLogID) {
  //   this.filesViewOnPopup = []
  //   this.filesViewOnPopupLength = 0
  //   let obj = {
  //     "PassDownLogID": passDownLogID
  //   }
  //   this.passDownLogService.GetPassDownLogFileByPassDownLogID(obj).subscribe(data => {
  //     this.filesViewOnPopup = data.data.GetPassDownLogFileByPassDownLogID
  //     this.filesViewOnPopupLength = this.filesViewOnPopup.length
  //   })
  // }

  openDialog(passDownLogID) {
    this.filesViewOnPopup = [];
    this.filesViewOnPopupLength = 0;
    let obj = {
      PassDownLogID: passDownLogID,
    };
    this.passDownLogService
      .GetPassDownLogFileByPassDownLogID(obj)
      .subscribe((data) => {
        this.filesViewOnPopup = data.data.GetPassDownLogFileByPassDownLogID;
        this.filesViewOnPopupLength = this.filesViewOnPopup.length;
        this.popUp(this.filesViewOnPopup);
      });
  }

  popUp(data) {
    const dialogRef = this.dialog.open(ViewFilesDialogComponent, {
      height: "300px",
      width: "600px",
      data: data,
    });

    dialogRef.afterClosed().subscribe((result) => {
      // let obj = {
      //   "PropertyID": this.passDownLogFormFilters.PropertyID == '' ? null : parseInt(this.passDownLogFormFilters.PropertyID),
      //   "FromDate": this.convertDateString(this.dateToSend),
      //   "ToDate": this.convertDateString(this.dateToSend),
      //   "PassDownStatus": "Active"
      // }
      // this.getPassDownList(obj)
    });
  }

  // color the row on click
  selectedRow: any = false;
  selectRow(passDownLogID: any) {
    if (this.selectedRow == passDownLogID) {
      this.selectedRow = false;
    } else {
      this.selectedRow = passDownLogID;
    }
  }

  // // select date on calender open
  // showCalender: boolean = false
  // selectDateFunc(date) {
  //   this.showCalender = false
  //   let val = this.convertDateString(date);
  //   this.dateToSend = val
  //   this.getDateFormatToSend(date)
  //   this.passDownLogFilterViewForm.get('FromDate').setValue(val.toString().split(' ', 4).join(' '));
  // }

  // toggle calender button
  // toggleCalender() {
  //   this.showCalender = !this.showCalender
  // }

  showInvalid(msg) {
    this.tostre.error(msg, "", {
      positionClass: "toast-top-right",
    });
  }
  showValid(validMsg) {
    this.tostre.success(validMsg, "", {
      positionClass: "toast-top-right",
    });
  }

  /* get user list*/ 
  getPersonList(propertyID:any){
    let obj = {
      "PropertyID":propertyID
    };
    this.passDownLogService.getPaasDownLogPersonList(obj).subscribe((res:any)=>{
         if(res.data.GetPersonList){
         let data = res.data.GetPersonList;
         this.getPerson = data;
         this.getPersonListResponse = this.passDownLogFilterViewForm.controls.PersonName.valueChanges.pipe(
          startWith(""),
          map((val: any) => (val.length >= 0 ? this.filterPerson(val) : []))
        );
         }
    })
  }
  /**/
  /* validate user */
  hide:boolean = true;
  validateUser(userObj,password){
    let obj = {
      "UserName":userObj.UserLogin,
      "Password":password
    }
    this.passDownLogService.passDownLogValidateUser(obj).subscribe((res:any)=>{
         if(res.status){
           let data = res.data.PassdownLogvalidateUser;
           if(data){
           let userId = data[0].UserID;
           if(userId){
           this.updatePassDownLogHistory(userId);
           }else{
             this.tostre.error("Please enter valid password.");
           }
           }
         }
    },
    err =>{

    })
  }
  /**/
  /* update pass down log history */
  PassDownLogIDs:any = [];
   updatePassDownLogHistory(userId:any){
     let PassDownLogIDString:string = '';
     if(this.PassDownLogIDs.length >0){
         PassDownLogIDString = this.PassDownLogIDs.toString();
     }
     let obj = {
      "PassDownLogIDs":PassDownLogIDString,
      "UserID":userId,
      "PassDownLogActionID":1 
     }
     this.passDownLogService.updatePassDownLogHistory(obj).subscribe((res:any)=>{
         if(res.status){
           this.tostre.success(res.message);
          //  this.passDownLogFilterViewForm.controls['cPassword'].patchValue('');
          // this.passDownLogFilterViewForm.controls['PersonName'].patchValue('');
           this.refreshPassDownList(0);
           this.getPassDownListF = [];
           this.resetUser();
         }
     },
     err=>{

     })
   }
  /**/
  /* read and unread check event*/
  clickEvent(event:any, viewData:any){
    if(viewData.IsRead){
      event.preventDefault();
      return ;
   }
   if(this.userObj == undefined || this.userObj == ''){
     this.tostre.warning('Please first Select a Person from menu above.');
     event.preventDefault();
     return;
   }
  }
  checkEvent(event:any, viewData:any){
     if(viewData.IsRead){
         event.preventDefault();
         return ;
      }
      if(this.userObj == undefined || this.userObj == ''){
        this.tostre.warning('Please first Select a Person from menu above.');
        event.preventDefault();
        return;
      }
      if(event.checked){
         this.PassDownLogIDs.push(viewData.PassDownLogID);
      }else{
        if(this.PassDownLogIDs.length >0)
        this.PassDownLogIDs.splice(this.PassDownLogIDs.indexOf(this.PassDownLogIDs.find(row => row == viewData.PassDownLogID)), 1);
      }
  }
  /**/
  /* set user*/
  userObj:any;
  selectedUser:boolean = true;
  selectedPersonID:any = 0;
  changeUser(event:any,userObj:any){
    if (event && event.isUserInput) {
      this.userObj = userObj;
       let UserID = userObj.UserID;
      this.selectedPersonID = UserID; 
      this.selectedUser = false;
     // this.getPassDownListF = [];
      this.refreshPassDownList(UserID);
    }
  }
  /**/
  /* reset user */
  resetUser(){
    this.userObj = '';
    this.selectedUser = true;
    this.passDownLogFilterViewForm.controls['PersonName'].patchValue('');
    this.passDownLogFilterViewForm.controls['cPassword'].patchValue('');
    this.selectedRow = false;
    this.getPassDownListF = [];
    this.getPassDownListF = this.getPassDownListFirst;
    this.selectedPersonID = 0;
  }
  /**/
  markedItem(){
    let userName = this.passDownLogFilterViewForm.controls.PersonName.value;
    let password = this.passDownLogFilterViewForm.controls.cPassword.value;
    if(userName == undefined || userName == ''){
      let userMsg = "Please select person first.";
      this.showInvalid(userMsg);
      return;
    }
    if(password == undefined || password == ''){
      let userMsg = "Please Enter user Password.";
      this.showInvalid(userMsg);
      return;
    }
    //let index = this.getPerson.indexOf()
    this.validateUser(this.userObj,password);
  }

  /*get pass down list after user reset*/
  refreshPassDownList(userId) {
     // this.passDownLogFormFilters[prop] = value; 
      let obj = {
        PropertyID:
          this.passDownLogFormFilters.PropertyID == ""
            ? null
            : parseInt(this.passDownLogFormFilters.PropertyID),
        FromDate: this.convertDateString(this.dateToSend),
        ToDate: this.convertDateString(this.dateToSend),
        PassDownStatus: "Active",
        UserID :userId,
      };
      console.log("property id -->",obj.PropertyID);
    //  this.getPersonList(obj.PropertyID);
      this.getPassDownList(obj);
  }
  /**/
  downloadFile(name) {
    event.stopPropagation();
    // this.download(environment.imagePath + `passDownLog/${name}`, name);
    this.download(`${this.filePath}${name}`, name);
  }
  download(pdfUrl: string, pdfName: string) {
    fs.saveAs(pdfUrl, pdfName);
  }

}
