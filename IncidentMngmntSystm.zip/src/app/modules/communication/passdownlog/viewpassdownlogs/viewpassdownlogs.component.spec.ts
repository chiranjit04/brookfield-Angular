import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewpassdownlogsComponent } from './viewpassdownlogs.component';

describe('ViewpassdownlogsComponent', () => {
  let component: ViewpassdownlogsComponent;
  let fixture: ComponentFixture<ViewpassdownlogsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewpassdownlogsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewpassdownlogsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
