import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PassdownlogComponent } from './passdownlog.component';

describe('PassdownlogComponent', () => {
  let component: PassdownlogComponent;
  let fixture: ComponentFixture<PassdownlogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PassdownlogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PassdownlogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
