import { Component, OnInit } from "@angular/core";
import { NotificationserviceService } from "../incidentnotification/notificationservice.service";
import { UserPermissionService } from "../../../services/user-permission.service";
import { StorageService } from "../../../services/storage.service";
import { NavigationEnd, Router } from "@angular/router";
import { ToastrService } from "ngx-toastr";
import { map } from "rxjs/internal/operators/map";
import { filter } from "rxjs/internal/operators/filter";
import { Subscription } from "rxjs/internal/Subscription";
import { ManagetutorialComponent } from "../../global/managetutorial/managetutorial.component";
import { MatDialog } from "@angular/material/dialog";
import { environment } from "../../../../environments/environment";
@Component({
  selector: "app-communicationnav",
  templateUrl: "./communicationnav.component.html",
  styleUrls: ["./communicationnav.component.scss"],
})
export class CommunicationnavComponent implements OnInit {
  router: any;
  routerSubscribe: Subscription;
  menuitems: any = [];
  incidentnotify: any;
  passdownlogsubitems: any;

  addnotification: any;
  usermessagesubitems: any;

  UserPermissionData: any = [];

  showItem = "incidentnotification";
  showItem1 = "addnotify";
  showTabs: any;
  IsTraningButtonShow: boolean;
  systemAlertSubMenuItems: { routerLink: string[]; text: string }[];
  opdocssubitems: any[];

  constructor(
    public NotificationserviceService: NotificationserviceService,
    private readonly UserPermission: UserPermissionService,
    private readonly storage: StorageService,
    private routers: Router,
    private readonly toasterService: ToastrService,
    public dialog: MatDialog
  ) {
    this.IsTraningButtonShow = environment.IsTraningButtonShow;
    this.routerSubscribe = this.routers.events
      .pipe(
        map((elem: any) => {
          if (elem instanceof NavigationEnd) {
            return elem;
          }
        }),
        filter((elem: any) => elem)
      )
      .subscribe((elem) => {
        if (!elem) {
          return;
        } else {
          const url = elem.url.split("/");
          const lastPath = url[url.length - 1];

          this.showItem = lastPath;
          this.createPermissionBasedMenu();
        }
      });
  }

  ngOnInit() {
    let pos = location.pathname.split("/");
    // this.showItem = pos[3];
  }

  // mainmenu(item, current) {
  //   console.log(item[0]);
  //   this.showItem = item[0];
  // }

  async createPermissionBasedMenu() {
    console.log("hello");
    // let result = await this.UserPermission.GetUserProfilePermission({
    //   ModuleIDs: "5",
    // }).toPromise();
    // this.UserPermissionData = result.ProfilePermissionList;
    // this.storage.setData(
    //   "UserPermissionData",
    //   JSON.stringify(this.UserPermissionData)
    // );

    let pos = location.pathname.split("/");
    this.showItem = pos[3];

    this.menuitems = [
      {
        routerLink: ["/products/list"],
        text: "Home",
      },
    ];
    let incidentNotification = this.UserPermission.checkPermission(
      "access_incident_notifications"
    );
    if (incidentNotification) {
      this.menuitems.push({
        routerLink: ["incidentnotification"],
        // text: 'Inspection Activities',
        text: "Incident Notifications",
      });
    }
    let systemAlert = this.UserPermission.checkPermission(
      "access_system_alerts"
    );
    if (systemAlert) {
      this.menuitems.push({
        routerLink: ["systemlaert"],
        text: "System Alerts",
      });
    }

    // let accessOrder = this.UserPermission.checkPermission("access_post_orders");
    // if (accessOrder) {
    //   this.menuitems.push({
    //     routerLink: ["postorder"],
    //     text: "Post Orders",
    //   });
    // }
    let accessService = this.UserPermission.checkPermission(
      "access_service_providers"
    );
    if (accessService) {
      this.menuitems.push({
        routerLink: ["serviceprovider"],
        text: "Service Providers",
      });
    }
    let accessUser = this.UserPermission.checkPermission(
      "access_user_messages"
    );
    if (accessUser) {
      this.menuitems.push({
        routerLink: ["usermessage"],
        text: "User Messages",
      });
    }
    let passdownLog = this.UserPermission.checkPermission(
      "access_pass_down_log"
    );
    if (passdownLog) {
      this.menuitems.push({
        routerLink: ["passdownlog"],
        text: "Pass Down Log",
      });
    }

    // let opDocs = this.UserPermission.checkPermission(
    //   "access_pass_down_log"
    // );
    // if (passdownLog) {
    this.menuitems.push({
      routerLink: ["opdocs"],
      text: "OP DOCS",
    });
    //}

    // if (
    //   !incidentNotification &&
    //   !systemAlert &&
    //   !accessOrder &&
    //   !accessService &&
    //   !accessUser &&
    //   !passdownLog
    // ) {
    //   this.routers.navigate(["products/list"]);
    //   this.toasterService.warning("You don't have permission.", "", {
    //     positionClass: "toast-top-right",
    //   });
    // }

    this.incidentnotify = [
      {
        routerLink: ["incidentnotification/createmanage"],
        text: "Create/Manage",
      },
      {
        routerLink: ["incidentnotification/sentregister"],
        text: "Sent Registry",
      },
    ];
    this.systemAlertSubMenuItems = [
      {
        routerLink: ["systemlaert/createalert"],
        text: "Create Alert",
      },
      {
        routerLink: ["systemlaert/sentregistry"],
        text: "Sent Registry",
      },
    ];
    this.passdownlogsubitems = [
      {
        routerLink: ["passdownlog/passdownlogregistry"],
        text: "PASS DOWN LOG REGISTRY",
      },
      {
        routerLink: ["passdownlog/viewpassdownlogs"],
        text: "VIEW PASS DOWN LOGS",
      },
    ];

    this.usermessagesubitems = [
      {
        routerLink: ["usermessage/mymessages"],
        text: "My Messages",
      },
      {
        routerLink: ["usermessage/createmessages"],
        text: "Create Messages",
      },
      {
        routerLink: ["usermessage/messageregistry"],
        text: "Messages Registry",
      },
    ];

    this.opdocssubitems = [
      {
        routerLink: ["opdocs/fileupload"],
        text: "File Upload",
      },
      {
        routerLink: ["opdocs/singlepropertyview"],
        text: "Single Property View",
      },
      {
        routerLink: ["opdocs/multipropertyview"],
        text: "Multi Property View",
      },
      {
        routerLink: ["opdocs/managecategories"],
        text: "Manage Categories",
      },
    ]

  }
  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    if (this.routerSubscribe) {
      this.routerSubscribe.unsubscribe();
    }
  }
  openmanagetutorialpop() {
    const dialogRef = this.dialog.open(ManagetutorialComponent, {
      width: "40%",
      autoFocus: false,
    });
  }
}
