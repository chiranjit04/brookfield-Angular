import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommunicationnavComponent } from './communicationnav.component';

describe('CommunicationnavComponent', () => {
  let component: CommunicationnavComponent;
  let fixture: ComponentFixture<CommunicationnavComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommunicationnavComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommunicationnavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
