import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

import { CommunicationComponent } from "./communication.component";
import { AuthGuard } from "./../../guard/auth.guard";

const routes: Routes = [
  {
    path: "",
    canActivate: [AuthGuard],
    component: CommunicationComponent,
    children: [
      { path: "", redirectTo: "", pathMatch: "full" },
      {
        path: "incidentnotification",
        loadChildren: () =>
          import("./incidentnotification/incidentnotification.module").then(
            (m) => m.IncidentnotificationModule
          ),
      },
      {
        path: "systemlaert",
        loadChildren: () =>
          import("./systemlaert/systemlaert.module").then(
            (m) => m.SystemlaertModule
          ),
      },
      {
        path: "postorder",
        loadChildren: () =>
          import("./postorder/postorder.module").then((m) => m.PostorderModule),
      },
      {
        path: "serviceprovider",
        loadChildren: () =>
          import("./serviceprovider/serviceprovider.module").then(
            (m) => m.ServiceproviderModule
          ),
      },
      {
        path: "usermessage",
        loadChildren: () =>
          import("./usermessage/usermessage.module").then(
            (m) => m.UsermessageModule
          ),
      },
      {
        path: "passdownlog",
        loadChildren: () =>
          import("./passdownlog/passdownlog.module").then(
            (m) => m.PassdownlogModule
          ),
      },
      {
        path: "opdocs",
        loadChildren: () =>
          import("./opdocs/opdocs.module").then(
            (m) => m.OpdocsModule
          ),
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CommunicationRoutingModule {
  constructor() {
    /**
     * NOTE: Obs$ unSubscription
     * don't need to unsubscribe this subject Observable,
     * because take will automatically unsubscribe this subject when it subscribe,
     * and automatically subscribe Obs$ when emits next functionality
     */
  }
}
