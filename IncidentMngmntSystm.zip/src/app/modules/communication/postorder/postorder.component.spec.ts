import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PostorderComponent } from './postorder.component';

describe('PostorderComponent', () => {
  let component: PostorderComponent;
  let fixture: ComponentFixture<PostorderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PostorderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PostorderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
