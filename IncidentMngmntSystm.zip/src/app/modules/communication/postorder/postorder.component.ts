import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-postorder',
  templateUrl: './postorder.component.html',
  styleUrls: ['./postorder.component.scss']
})
export class PostorderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
