import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PostorderRoutingModule } from './postorder-routing.module';
import { PostorderComponent } from './postorder.component';


@NgModule({
  declarations: [PostorderComponent],
  imports: [
    CommonModule,
    PostorderRoutingModule
  ]
})
export class PostorderModule { }
