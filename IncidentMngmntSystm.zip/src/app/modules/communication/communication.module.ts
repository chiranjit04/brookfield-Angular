import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import { CommunicationRoutingModule } from "./communication-routing.module";
import { CommunicationComponent } from "./communication.component";
import { CommunicationnavComponent } from "./communicationnav/communicationnav.component";
import { GlobalModule } from "../global/global.module";
import { ToastrService } from "ngx-toastr";
import { ActivatedRoute, Router } from "@angular/router";
import { UserPermissionService } from "src/app/services/user-permission.service";
import { RouteCheckLevelOne } from "./route-check";
import { map } from "rxjs/internal/operators/map";
import { switchMap } from "rxjs/internal/operators/switchMap";
import { of } from "rxjs/internal/observable/of";
import { SharedMaterialModule } from "../../shared/shared-material.module";

@NgModule({
  declarations: [CommunicationComponent, CommunicationnavComponent],
  imports: [
    CommonModule,
    CommunicationRoutingModule,
    GlobalModule,
    SharedMaterialModule,
  ],
})
export class CommunicationModule {
  constructor() {}
}
