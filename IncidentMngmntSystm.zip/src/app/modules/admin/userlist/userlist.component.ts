import { Component, OnInit } from '@angular/core';
// import { Adduser } from 'src/app/class/adduser';
import { AdduserService } from 'src/app/services/adduser.service';

@Component({
  selector: 'app-userlist',
  templateUrl: './userlist.component.html',
  styleUrls: ['./userlist.component.scss'],
})

export class UserlistComponent implements OnInit {
  userdata = [];

  recordset: any;
  data: any;
  constructor(private adduserfile: AdduserService) { }

  ngOnInit() {
    // this.getUser();
  }

  // getUser() {
  //   this.adduserfile.getUsers()
  //     .subscribe(data => {
  //       this.data = data.User.recordset;
  //       console.log(this.data);
  //     });
  // }
}
