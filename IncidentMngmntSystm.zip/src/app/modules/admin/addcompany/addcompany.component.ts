import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addcompany',
  templateUrl: './addcompany.component.html',
  styleUrls: ['./addcompany.component.scss']
})
export class AddcompanyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
