import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AdduserService } from 'src/app/services/adduser.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-adduser',
  templateUrl: './adduser.component.html',
  styleUrls: ['./adduser.component.scss']
})
export class AdduserComponent implements OnInit {
  addUser: FormGroup;
  data: any;

  constructor(
    private fb: FormBuilder,
    public adduserfile: AdduserService,
    public tostmsg: ToastrService
  ) {}

  ngOnInit() {
    this.addUser = this.fb.group({
      UName: ['', Validators.required],
      Passwords: ['', Validators.required]
    });
  }
  AddUser() {
    this.adduserfile.addUsers(this.addUser.value).subscribe(data => {
      this.data = data;
     // console.log(this.data);
      this.tostmsg.success('User added successfuly');
    });
  }
}
