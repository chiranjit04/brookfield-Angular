import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CompanylistComponent } from './companylist/companylist.component';
import { AdminComponent } from './admin.component';
import { AddcompanyComponent } from './addcompany/addcompany.component';
import { AdduserComponent } from './adduser/adduser.component';
import { UserlistComponent } from './userlist/userlist.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { AuthGuard } from "./../../guard/auth.guard";
const appRoutes: Routes = [
  {
    path: '', component: AdminComponent,
    canActivate: [ AuthGuard ],
    children:
      [
        { path: '', redirectTo: 'admin-home', pathMatch: 'full' },
        { path: 'admin-home', component: AdminHomeComponent },
        { path: 'companylist', component: CompanylistComponent },
        { path: 'addcompany', component: AddcompanyComponent },
        { path: 'adduser', component: AdduserComponent },
        { path: 'userlist', component: UserlistComponent }
      ]
  },
];
@NgModule({
  imports: [RouterModule.forChild(appRoutes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
