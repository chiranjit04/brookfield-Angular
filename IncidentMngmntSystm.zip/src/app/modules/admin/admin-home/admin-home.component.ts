import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-home',
  templateUrl: './admin-home.component.html',
  styleUrls: ['./admin-home.component.scss']
})
export class AdminHomeComponent implements OnInit {

  admintiles: any;
  constructor() {
    this.admintiles = [
      {
        routerLink: [''],
        title: ' Package Type',
        subtitle: 'Management',
        icom: '/assets/img/company.svg'
      },
      {
        routerLink: [''],
        title: ' Destination Region Type ',
        subtitle: 'Management',
        icom: '/assets/img/isci.svg'
      },
      {
        routerLink: [''],
        title: ' Destination ',
        subtitle: 'Management',
        icom: '/assets/img/reportingset.svg'
      },
      {
        routerLink: [''],
        title: ' Holiday Package Category ',
        subtitle: 'Management',
        icom: '/assets/img/propertyset.svg'
      },
      {
        routerLink: [''],
        title: ' Holiday Package Sub-Category ',
        subtitle: 'Management',
        icom: '/assets/img/property.svg'
      },
      {
        routerLink: [''],
        title: ' Destination Popular Place ',
        subtitle: 'Management',
        icom: '/assets/img/locationcode.svg'
      },
      {
        routerLink: [''],
        title: ' Holiday Package Detail ',
        subtitle: 'Management',
        icom: '/assets/img/patrolzone.svg'
      },
      {
        routerLink: [''],
        title: ' Itinerary ',
        subtitle: 'Management',
        icom: '/assets/img/floorpanmap.png'
      },
      {
        routerLink: [''],
        title: ' Photo Gallery ',
        subtitle: 'Management',
        icom: '/assets/img/sector.png'
      },
      {
        routerLink: [''],
        title: ' Video Gallery ',
        subtitle: 'Management',
        icom: '/assets/img/usermgt.png'
      },
      // {
      //   routerLink: [''],
      //   title: ' Testimonials ',
      //   subtitle: 'Management',
      //   icom: '/assets/img/profile.png'
      // },
      // {
      //   routerLink: [''],
      //   title: ' Blog Category ',
      //   subtitle: 'Management',
      //   icom: '/assets/img/sector.png'
      // },
      // {
      //   routerLink: [''],
      //   title: ' Blog Detail ',
      //   subtitle: 'Management',
      //   icom: '/assets/img/serviceprowider.png'
      // },
      // {
      //   routerLink: [''],
      //   title: ' Blog User Comment ',
      //   subtitle: 'Management',
      //   icom: '/assets/img/questionmapping.png'
      // },
      // {
      //   routerLink: [''],
      //   title: ' Manage Layout ',
      //   subtitle: 'Management',
      //   icom: '/assets/img/menu.png'
      // },
      // {
      //   routerLink: [''],
      //   title: '  Manage Account  ',
      //   subtitle: 'Management',
      //   icom: '/assets/img/permission.png'
      // },
    ];
  }
  ngOnInit() {
  }

}
