import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdminRoutingModule } from './admin-routing.module';
import { AdminComponent } from './admin.component';
import { AdminNavComponent } from './admin-nav/admin-nav.component';
import { AdduserComponent } from './adduser/adduser.component';
import { UserlistComponent } from './userlist/userlist.component';
import { AddcompanyComponent } from './addcompany/addcompany.component';
import { CompanylistComponent } from './companylist/companylist.component';
import { GlobalModule } from '../global/global.module';
import { AdminHomeComponent } from './admin-home/admin-home.component';


@NgModule({
  declarations: [
    AdminComponent,
    AdminNavComponent,
     AdduserComponent,
      UserlistComponent,
       AddcompanyComponent,
        CompanylistComponent,
         AdminHomeComponent
        ],
  imports: [
    CommonModule,
    AdminRoutingModule,
    GlobalModule,
    ReactiveFormsModule,
    FormsModule
  ]
})
export class AdminModule { }
