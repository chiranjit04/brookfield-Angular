// export class Adduser {
//   UName: string;
//   Passwords: string;
// }
