export class Auth {
  UserInfo: any;
  UserID: number;
  FirstName: any;
  LastName: any;
}
export interface IAuth {
  UserInfo: any;
  UserID: number;
  FirstName: any;
  LastName: any;
}
