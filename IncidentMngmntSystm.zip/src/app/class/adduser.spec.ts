import { Adduser } from './adduser';

describe('Adduser', () => {
  it('should create an instance', () => {
    expect(new Adduser()).toBeTruthy();
  });
});
