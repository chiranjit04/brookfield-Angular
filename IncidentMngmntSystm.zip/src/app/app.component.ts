import { filter } from "rxjs/internal/operators/filter";
import { Component } from "@angular/core";
import { Event as RouterEvent } from "@angular/router";
import { Router, NavigationEnd, NavigationStart } from "@angular/router";
import { map } from "rxjs/internal/operators/map";
import { take } from "rxjs/internal/operators/take";
import { delay } from "rxjs/internal/operators/delay";
import { tap } from "rxjs/internal/operators/tap";
import { ToastrService } from 'ngx-toastr';
import { fromEvent, Observable, Subscription } from 'rxjs';

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.scss"],
})
export class AppComponent {
  title = "BrookField";
  public isShowingRouteLoadIndicator: Promise<boolean> = Promise.resolve(false);
  onlineEvent: Observable<Event>;
  offlineEvent: Observable<Event>;
  subscriptions: Subscription[] = [];

  connectionStatusMessage: string;
  connectionStatus: string;


  constructor(private router: Router, private tostre: ToastrService) {
    // As the router loads modules asynchronously (via loadChildren), we're going to
    // keep track of how many asynchronous requests are currently active. If there is
    // at least one pending load request, we'll show the indicator.
    // The Router emits special events for "loadChildren" configuration loading. We
    // just need to listen for the Start and End events in order to determine if we
    // have any pending configuration requests.
    // router.events.subscribe((event: RouterEvent): void => {
    //   switch (true) {
    //     // case event instanceof RouteConfigLoadStart:
    //     case event instanceof NavigationStart: {
    //       asyncLoadCount++;
    //       break;
    //     }
    //     // case event instanceof RouteConfigLoadEnd:
    //     case event instanceof NavigationEnd:
    //     // case event instanceof NavigationCancel:
    //     // case event instanceof NavigationError: {
    //     //   asyncLoadCount--;
    //     //   break;
    //     // }
    //     default: {
    //       break;
    //     }
    //   }
    //   // If there is at least one pending asynchronous config load request,
    //   // then let's show the loading indicator.
    //   // CAUTION: I'm using CSS to include a small delay such that this loading
    //   // indicator won't be seen by people with sufficiently fast connections.
    //   this.isShowingRouteLoadIndicator = !!asyncLoadCount;
    // });
    /**
     * do not unsubscribe this router subscription because it automatically unsubscribe from obs$ emiited
     */
   
    try {
      this.router.events
        .pipe(
          map((elem) => {
            if (elem instanceof NavigationStart) {
              return {
                loading: true,
              };
            } else if (elem instanceof NavigationEnd) {
              return { loading: false };
            }
          }),
          filter((elem: any) => elem),
          delay(0)
        )
        .subscribe((routing) => {
          // console.log(routing);
          this.isShowingRouteLoadIndicator = Promise.resolve(routing.loading);
        });
    } catch (e) {
      this.isShowingRouteLoadIndicator = Promise.resolve(false);
    }
  }

  ngAfterViewChecked() {}

  ngOnInit() {
    this.onlineEvent = fromEvent(window, 'online');
    this.offlineEvent = fromEvent(window, 'offline');

    this.subscriptions.push(this.onlineEvent.subscribe(e => {
      this.connectionStatusMessage = 'Back to online';
      this.connectionStatus = 'online';
      console.log('Online...');
      this.tostre.success(this.connectionStatusMessage, '', {
        positionClass: 'toast-bottom-right',
      });
      this.isShowingRouteLoadIndicator = Promise.resolve(false);
    }));

    this.subscriptions.push(this.offlineEvent.subscribe(e => {
      this.connectionStatusMessage = 'Connection lost! You are not connected to internet';
      this.connectionStatus = 'offline';
      console.log('Offline...');
      this.tostre.error(this.connectionStatusMessage, '', {
        positionClass: 'toast-bottom-right',
      });
    }));
  }
}
