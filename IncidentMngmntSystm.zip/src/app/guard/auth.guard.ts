import { Injectable } from '@angular/core';
import { CanLoad, CanActivate, Router, Route, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from '../services/auth.service';

@Injectable({
  providedIn: 'root'
})
 
export class AuthGuard implements CanLoad, CanActivate {
  constructor(private auth: AuthService, private router: Router) {}

  canLoad(route: Route): boolean {
    
    if (!this.auth.isAuthenticated()) {
      this.router.navigate(['login']);
      return false;
    }
    return true;
  }

  async canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    let tokenInfo= await this.auth.validateToken();

    if (!this.auth.isAuthenticated() || !tokenInfo || tokenInfo.success==false) {
      this.auth.logoutUser();
      return false;
    }
    return true;  
  }
}
