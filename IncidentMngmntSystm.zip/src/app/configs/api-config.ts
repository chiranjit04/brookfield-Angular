import { environment } from "../../environments/environment";


export let apiConfig = {
  urls: {
    getGoeList: getUrl('/getGoeByUser'),
    getTierProgramList: getUrl('/manageTierProgrames/GetTierProgramList'),
    deleteTierProgram: getUrl('/manageTierProgrames/DeleteTierProgram'),
    getProgramOwnerList: getUrl('/manageTierProgrames/GetUserByGlobalEnvironmentID'),
    changeProgTierStatus: getUrl('/manageTierProgrames/ChangeTierProgramStatus'),
    saveOrUpdateTierProgram: getUrl('/manageTierProgrames/UpdateTierProgram'),
    getTierProgDetails: getUrl('/manageTierProgrames/GetTierProgramByTierProgramID'),
    getTierFactorDetails: getUrl('/manageTierProgrames/GetTierFactorDetails'),
    saveTierFactorInfo: getUrl('/manageTierProgrames/UpdateTierFactor'),
    deleteTierFactor: getUrl('/manageTierProgrames/DeleteTierFactor '),
    getAdditionalDataElementAndQueryList: getUrl('/manageTierProgrames/GetAdditionalDataElementAndQueryList'),
    updateTierFactorMapping: getUrl('/manageTierProgrames/UpdateTierFactorItem'),
    getTierLevelListInfo: getUrl('/manageTierProgrames/GetTierLevelDetails'),
    addUpdateTierLevel: getUrl('/manageTierProgrames/UpdateTierLevel'),
    deleteTierLevel: getUrl('/manageTierProgrames/DeleteTierLevel'),
    programPropertyList: getUrl('/manageTierProgrames/GetPropertyListTierProgram'),
    assignPropertyToProgram: getUrl('/manageTierProgrames/UpdateTierProperty'),
    getAssignedProgProperty: getUrl('/manageTierProgrames/GetTierPropertyByTierProgramID'),
    getTierCycleList: getUrl('/manageTierProgrames/GetTierCycle'),
    getTierProgSettings: getUrl('/manageTierProgrames/GetTierSettingsByTierProgramID'),
    updateTierSettings: getUrl('/manageTierProgrames/UpdateTierSettings'),
    getTierFactorAssociatedItemList: getUrl('/manageTierProgrames/GetTierFactorItemDetails'),
    getProgramHistoryInfo: getUrl('/manageTierProgrames/GetTierProgramChangeHistory'),
    saveTierProgHistory: getUrl('/manageTierProgrames/InsertTierProgramChangeHistory'),
    getTierProgramByTierProgramID: getUrl('/manageTierProgrames/GetTierProgramByTierProgramID'),
    deleteTierFactorItem: getUrl('/manageTierProgrames/DeleteTierFactorItem'),
    updatePrimaryTierProgram: getUrl('/manageTierProgrames/UpdatePrimaryTierProgram'),
    createProgramClone: getUrl('/manageTierProgrames/UpdateTierProgramClone'),
    updateTierDesignationProcessData: getUrl('/manageTierProgrames/UpdateTierDesignationProcessData'),
    updateManulOverrideTierDesignation: getUrl('/manageTierProgrames/UpdateManulOverrideTierDesignation')
  },
  dashboardUrls: {
    getTierProgDashboardInfo: getUrl('/tierProgramDashboard/GetTierProgramDashBoard'),
    getTierPropDashBoardInfo: getUrl('/tierProgramDashboard/GetTierPropertyDashBoard'),
    getTierDesignationDashBoardInfo: getUrl('/tierProgramDashboard/GetTierDesignationDashBoard'),
    getTierProgDetailsDashBoard: getUrl('/tierProgramDashboard/GetTierProgramDetailsDashBoard'),
    getTierDesignationHistoryInfo: getUrl('/tierProgramDashboard/GetTierDesignationHistoryDashBoard'),
    getSubTierDesignationDetailInfo: getUrl('/tierProgramDashboard/GetSubTierFactorDetailDashBoard'),
    getLastTierDesignation:getUrl('/tierProgramDashboard/GetLastTierDesignation'),
    getTierLevel: getUrl('/tierProgramDashboard/GetTierLevel'),
    getTierProgramExcelView: getUrl('/tierProgramDashboard/GetExcelView')
  }
};

function getUrl(url) {
  // return url.indexOf('.json') > -1 ? url : 'http://198.12.156.249:2004/api' + url;
  return url.indexOf('.json') > -1 ? url : `${environment.origin}api` + url;  
}
